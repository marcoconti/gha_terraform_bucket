# minha-lib

Biblioteca contendo métodos, funções e padrões a serem utilizados em pipelines de ingestão de dados.

## Exemplo de uso

```python
!
```
