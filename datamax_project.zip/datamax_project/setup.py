from setuptools import setup, find_packages

setup(
    name="datamax",
    version="0.1.15",
    description="Biblioteca de padrões utilizados na ingestão de dados",
    author="Marco Conti",
    author_email="marco.conti@yamaha-motor.com.br",
    packages=find_packages("."),
    python_requires=">=3.7",
)
