import pytest

from datamax.table_infos import get_partitions_columns

