from datetime import datetime, timezone, timedelta
import os, io, json, re
from git import Repo
from datamax.commons import get_env


def create_clone_git_repo(dbutils, env, branch):
    """
        Cria um clone do repositório Git que será utilizado para carregar as versões do framework
    """
    token = dbutils.secrets.get(scope="git-token", key="token").strip()

    repo_path  = f"https://{token}@github.com/YMH-BR/data.git"
    timestamp  = int(datetime.now(timezone(timedelta(hours=-3))).timestamp())
    clone_path = f"/tmp/clone_ymhbr_framework_version_{timestamp}"

    if branch == "":
        branch = env if env == "dev" else "main"

    repo = Repo.clone_from(repo_path, clone_path, branch=branch)
    return repo, clone_path

def rmdir_clone_git_repo(clone_path):
    """
        Remove o diretório temporário usado para clonar o repositório Git
    """
    try:
        if os.path.exists(clone_path):
            import shutil
            shutil.rmtree(clone_path)
            print("Diretório temp para clone Git repo removido com sucesso")    
    except Exception as e:
        print("Não foi possível excluir a pasta temporaria")

def get_last_version_framework(dbutils, branch, framework_file, file_ext):
    """
        Recupera a última versão do Framework de Ingestão
    """
    def remove_version(pattern, filename):
        match = pattern.match(filename)
        if match:
            return (match.group(0)
                   ,match.group(1)
                   ,match.group(0).replace(match.group(1),""))
        else:
            return (filename, filename, "")
    try:
        env = get_env()
        repo, clone_path = create_clone_git_repo(dbutils, env, branch)

        file_path = "framework/"
        version_pattern = re.compile(r"^(.*?)(?:[.-]v?\d+\.\d+\.\d+)$")
        full_name, file_prefix, version = \
            remove_version(version_pattern, os.path.basename(framework_file))

        # Pega as versões do Framework da brach que está em processamento 
        commit = repo.heads[branch].commit
        files  = [item.path for item in commit.tree.traverse() if item.type == "blob"]

        # Pega os arquivos do framework
        framework_versions = set()
        for f in files:
            if ((f.startswith(file_path + file_prefix + ".")) and (f.endswith(file_ext))):
                framework_versions.add(f)

        # Recupera a versão mais recente
        versions = []
        for f in framework_versions:
            full_name, file_prefix, version = \
                remove_version(version_pattern, os.path.basename(f).replace(file_ext,""))
            versions.append((version.replace("-",""), full_name))
        
        versions.sort(reverse=True)

        rmdir_clone_git_repo(clone_path)

        file_ret = str(versions[0][1]).replace(file_ext,"")

        return file_ret
    
    except Exception as e:
        rmdir_clone_git_repo(clone_path)
        return file_prefix