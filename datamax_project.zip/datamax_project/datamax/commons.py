from datetime import datetime, timezone, timedelta
import requests, json, os, time

def get_env():
    env = os.environ.get("DATABRICKS_ENV")
    return env.lower()

def get_job_variables(variable):
    env = get_env()
    if env == None:
        print("Não foi possível identificar o ambiente")
        return ""
        
    path = "/Workspace/Repos/YMH-BR/data/framework/create_ingestion_job_variables.json"

    ret_variable = ""
    try:
        with open(path) as json_file:
            create_ingestion_job_variables = json.load(json_file)
    except Exception as e:
        print(f"Não foi possível ler o arquivo de variáveis {path}, erro: \n {str(e)[0:100]}")
    
    try:
        ret_variable = \
            create_ingestion_job_variables[variable] if (type(create_ingestion_job_variables[variable]) == str) \
                                                   else create_ingestion_job_variables[variable][env]
    except Exception as e:
        print(f"Variavel: {variable} não encontrada")
        return ""

    return ret_variable

def teste(p1):
    print("teste")
    print(f"Imprimir: {p1}")