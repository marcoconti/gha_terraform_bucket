from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta

def get_interval_bronze_dates(start_date:         str  = None
                             ,end_date:           str  = None
                             ,days_past:          int  = 730
                             ,first_day_of_year:  bool = False) -> list:
    """
    A partir de uma data inicial e final ou a partir da quantidade de dias a retroagir
    monta uma lista de intervalo de meses (início e fim do mês):

        [{'first_day': '2025-04-01', 'last_day': '2025-04-30'}
        ,{'first_day': '2025-05-01', 'last_day': '2025-05-31'}
        ,{'first_day': '2025-06-01', 'last_day': '2025-06-30'}]
    """
    try:
        date_format = "%Y-%m-%d"
        default_days_past = 730
        days_past = default_days_past if days_past is None else days_past if days_past > default_days_past else default_days_past

        # Define data final
        if end_date:
            end = datetime.strptime(end_date, date_format)
        else:
            end = datetime.today()

        # Define data inicial
        if start_date:
            if days_past > default_days_past:
                first_day_of_year = True
                start = datetime.strptime(start_date, date_format) - timedelta(days = days_past)
            else:
                start = datetime.strptime(start_date, date_format)
        else:
            start = end - timedelta(days = days_past)

        # Ajusta para primeiro dia do ano, se solicitado
        if first_day_of_year:
            start = datetime(start.year, 1, 1)

        intervals = []
        current = start

        while current <= end:
            # Primeiro dia do intervalo
            first_day = current if current.day == 1 else max(current, datetime(current.year, current.month, 1))

            # Último dia do mês atual
            next_month = datetime(current.year, current.month, 1) + relativedelta(months=1)
            last_day_of_month = next_month - timedelta(days=1)

            # Último dia do intervalo
            last_day = min(last_day_of_month, end)

            if first_day < last_day:
                intervals.append({
                    "first_day": first_day.strftime(date_format),
                    "last_day" : last_day.strftime(date_format)
                })

            # Avança para o próximo mês
            current = next_month
    except:
        intervals = []

    return intervals