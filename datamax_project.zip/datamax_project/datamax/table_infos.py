def get_partitions_columns(spark_session, table_name: str) -> list:
    """
    Retorna a lista de colunas de partições para uma tabela específica.
    """
    partitions_columns = []
    try:
        desc_cmd = f"DESCRIBE DETAIL {table_name}"
        desc_tab = spark_session.sql(desc_cmd)
        partitions_columns = desc_tab.select("partitionColumns").collect()[0][0]

        if not partitions_columns:
            show_cmd = f"SHOW PARTITIONS {table_name}"
            parts_df = spark_session.sql(show_cmd)
            if parts_df.count() > 0:
                first_partition = parts_df.first()[0]
                partitions_columns = [p.split("=")[0] for p in first_partition.split("/")]

    except Exception as e:
        partitions_columns = []
    
    return partitions_columns

def get_lasts_partitions(spark_session, table_name: str, partitions_numbers: int = 1) -> list:
    """
    Retorna as últimas partições (de acordo com o paramerto informado) de uma tabela específica.
    """
    try:
        partition_cols = get_partitions_columns(spark_session, table_name)
        
        last_partitions = []
        if len(partition_cols) > 0:
            partitions_numbers = 1 if (partitions_numbers is None or partitions_numbers < 1) else partitions_numbers
            show_cmd = f"SHOW PARTITIONS {table_name}"
            last_partitions = \
                (spark_session.sql(show_cmd)
                              .orderBy(partition_cols, ascending = False)
                              .limit(partitions_numbers)
                              .collect()
                )
    except Exception as e:
        last_partitions = []

    return last_partitions