# Databricks notebook source
# MAGIC %md
# MAGIC #Metadados gerais

# COMMAND ----------

# MAGIC %md
# MAGIC **Criado por**: Malco Alves
# MAGIC
# MAGIC **Data criação**: 21/02/2025
# MAGIC
# MAGIC **Atualizado por**: Bruno Jander
# MAGIC
# MAGIC **Data atualização**: 04/04/2025
# MAGIC
# MAGIC [comment]: <> (Tem que vir do negócio)
# MAGIC **Descrição do dataset/tabela/view**: Tabela contendo concessionárias, disponibilizada pela área de planejamento de rede e negócio.
# MAGIC
# MAGIC [comment]: # (Lineage, nome de domínio, sub-domínio, tipo de agregação, business unit: Tem que vir do negócio)
# MAGIC **Tags**:
# MAGIC
# MAGIC [comment]: # (Tem que vir do negócio)
# MAGIC **Data owner**: 
# MAGIC
# MAGIC [comment]: # (Full/Incremental/Streaming/CDC/etc)
# MAGIC **Tipo de carga**: Full
# MAGIC
# MAGIC [comment]: # (Tem que vir de sistemas)
# MAGIC **Atualização**: Sob Demanda

# COMMAND ----------

# MAGIC %md
# MAGIC #### Fontes utilizadas nesse pipeline:
# MAGIC
# MAGIC [comment]: <> (tabelas utilizadas nesse notebook)
# MAGIC
# MAGIC - Tabelas não registradas no catálogo, apenas salvas no bucket (path_bronze)
# MAGIC - Arquivo fixo no bucket (path_landing)
# MAGIC - s_ymdb_silver.tb_flatfile_concessionaria

# COMMAND ----------

# MAGIC %md
# MAGIC #Configurações Iniciais

# COMMAND ----------

# DBTITLE 1,Importação de bibliotecas
from os import getenv
from boto3 import client
from io import BytesIO
from pandas import read_excel, to_datetime
from delta.tables import DeltaTable
from pyspark.sql.functions import col, monotonically_increasing_id, regexp_replace

# COMMAND ----------

# DBTITLE 1,Variáveis de ambiente
source_bucket_landing = getenv("param_bucket_landing")
ambiente = getenv("DATABRICKS_ENV")

# COMMAND ----------

# DBTITLE 1,Lineage de diretórios
# <database>/<sistema>/<esquema> ou <external>/<sistema>/<esquema>
# igual ao lineage do pipeline do Informatica
param_lineage = 'external/fileshareyamaha/corporativo/cadastro_concessionarias'
param_schema = "corporativo"
bronze_catalog = f'bronze_{ambiente}'
silver_catalog = f'silver_{ambiente}'

arquivo = '11- Cadastro_Novembro_2024v1.xlsx'


# Nome da tabela
param_nome_tabela = 'dm_concessionaria'

path_landing = f's3://{source_bucket_landing}/{param_lineage}/processar/'
#path_bronze = f's3://{source_bucket_bronze}/{param_lineage}'
#path_silver = f's3://{source_bucket_silver}/{param_lineage}'

# COMMAND ----------

# MAGIC %md
# MAGIC #Landing para Bronze

# COMMAND ----------

df_bronze = (
    spark.read
    .format("com.crealytics.spark.excel")
    .option("header", "true")
    .option("inferSchema", "true")
    .option("dataAddress", "'Cadastro CCY e PV'!A1") 
    .load(path_landing + arquivo)
)

# COMMAND ----------

# DBTITLE 1,Ajuste de nomeclatura e tipagem
from pyspark.sql.functions import col, monotonically_increasing_id, regexp_replace

df_bronze = (
    df_bronze
        .withColumn("ID_CONCESSIONARIA", monotonically_increasing_id().cast("string"))
        .withColumnRenamed('TIPO', 'DS_TIPO')
        .withColumnRenamed('SEG', 'DS_SEGMENTO')
        .withColumnRenamed('E-COMMERCE', 'FL_ECOMMERCE')
        .withColumnRenamed('CODIGO', 'CD_CONCESSIONARIA')
        .withColumnRenamed('COD E-MAIL', 'CD_EMAIL')
        .withColumnRenamed('REGIAO', 'CD_REGIAO')
        .withColumnRenamed('SUBREG', 'CD_SUB_REGIAO')
        .withColumnRenamed('TERRITÓRIO ENTREGA', 'SG_TERRITORIO_ENTREGA')
        .withColumnRenamed('TRANSIT TIME MTC', 'QT_TRANSIT_TIME_MTC')
        .withColumnRenamed('STATUS', 'FL_STATUS')
        .withColumnRenamed('EMPRESA', 'NM_EMPRESA')
        .withColumnRenamed('ABREMP', 'NM_ABREVIADO_EMPRESA')
        .withColumnRenamed('ENDERECO', 'NM_ENDERECO')
        .withColumnRenamed('BAIRRO', 'NM_BAIRRO')
        .withColumnRenamed('CIDADE', 'NM_CIDADE')
        .withColumnRenamed('ESTADO', 'SG_ESTADO')
        .withColumnRenamed('CEP', 'NR_CEP')
        .withColumn("NR_CEP_SEM_PONTUACAO", regexp_replace(col("NR_CEP"), "[^0-9]", ""))
        .withColumnRenamed('DDD', 'NR_DDD')
        .withColumnRenamed('FONE1', 'NR_FONE_1')
        .withColumnRenamed('FONE2', 'NR_FONE_2')
        .withColumnRenamed('CNPJ (S/PT)', 'DC_CNPJ_SEM_PONTUACAO')
        .withColumnRenamed('CNPJ', 'DC_CNPJ')
        .withColumnRenamed('CCY RESP', 'DC_CNPJ_MATRIZ')
        .withColumnRenamed('IEST', 'NR_INSCRICAO_ESTADUAL')
        .withColumnRenamed('CONTATO', 'NM_CONTATO')
        .withColumnRenamed('DATABERT', 'DT_ABERTURA')
        .withColumnRenamed('CODGEC', 'CD_GEC')
        .withColumnRenamed('GRUPO', 'NM_GRUPO')
        .withColumnRenamed('AREA_OP', 'NM_AREA_OPERACIONAL')
        .withColumnRenamed('NOME SITE', 'NM_SITE')
        .withColumnRenamed('COORDENADOR', 'NM_COORDENADOR')
        .withColumnRenamed('EMAIL MTC', 'DS_EMAIL_COORDENADOR')
        .withColumnRenamed("TEL MTC32", 'NR_FONE_COORDENADOR')
        .withColumnRenamed('CONSULTOR', 'NM_CONSULTOR')
        .withColumnRenamed('E MAIL MTC', 'DS_EMAIL_CONSULTOR')
        .withColumnRenamed("TEL MTC35", 'NR_FONE_CONSULTOR')
        .withColumnRenamed('COORDENADOR PÓS VENDAS', 'NM_COORDENADOR_POS_VENDAS')
        .withColumnRenamed('E-MAIL ', 'DS_EMAIL_COORDENADOR_POS_VENDAS')
        .withColumnRenamed('TEL ', 'NR_FONE_COORDENADOR_POS_VENDAS')
        .withColumnRenamed('REPRESENTANTE', 'NM_REPRESENTANTE')
        .withColumnRenamed('E MAIL DPS', 'DS_EMAIL_REPRESENTANTE')
        .withColumnRenamed('TEL DPS', 'NR_FONE_REPRESENTANTE')
        .withColumnRenamed('REG_EST', 'DS_REGIAO_ESTADO')
        .withColumnRenamed('.titular@yamahaconcessionaria.com.br', 'DS_EMAIL_TITULAR')
        .withColumnRenamed('.vendas@yamahaconcessionaria.com.br', 'DS_EMAIL_VENDAS')
        .withColumnRenamed('.servicos@yamahaconcessionaria.com.br', 'DS_EMAIL_SERVICOS')
        .withColumnRenamed('@yamahaconcessionaria.com.br', 'DS_EMAIL_GERAL')
        .withColumnRenamed('WhatsApp', 'NR_WHATSAPP')
        .withColumnRenamed('Site - ABRACY', 'DS_SITE_ABRACY')
        .withColumnRenamed('Site Concessionária', 'DS_SITE_CONCESSIONARIA')
        .withColumnRenamed('Email da Concessionária', 'DS_EMAIL_CONCESSIONARIA')
        .withColumnRenamed('longitude', 'NR_LONGITUDE')
        .withColumnRenamed('latitude', 'NR_LATITUDE')
        .withColumnRenamed('Cartão VISA', 'FL_CARTAO_VISA')
        .withColumnRenamed('Preço Fixo', 'FL_PRECO_FIXO')
        .withColumnRenamed('YRA', 'FL_YRA')
        .withColumnRenamed('Diamante', 'FL_DIAMANTE')
        .withColumnRenamed('Form.Leads', 'FL_FORM_LEADS')
        .withColumnRenamed('Racing Blue', 'FL_RACING_BLUE')
        .withColumnRenamed('Go!Yamaha', 'FL_GO_YAMAHA')
        .withColumnRenamed('Test Ride ', 'FL_TEST_RIDE')
        .withColumnRenamed('Cancelamento', 'DS_CANCELAMENTO')
        .withColumnRenamed('Data Email', 'DT_EMAIL')
)

#display(df_bronze)

# COMMAND ----------

from pyspark.sql import Window
from pyspark.sql.functions import row_number, lit, regexp_replace, col

df_bronze = (
    df_bronze
        .withColumn("ID_CONCESSIONARIA", row_number().over(Window.orderBy(lit(1))) - 1)
        .withColumnRenamed('TIPO', 'DS_TIPO')
        .withColumnRenamed('SEG', 'DS_SEGMENTO')
        .withColumnRenamed('E-COMMERCE', 'FL_ECOMMERCE')
        .withColumnRenamed('CODIGO', 'CD_CONCESSIONARIA')
        .withColumnRenamed('COD E-MAIL', 'CD_EMAIL')
        .withColumnRenamed('REGIAO', 'CD_REGIAO')
        .withColumnRenamed('SUBREG', 'CD_SUB_REGIAO')
        .withColumnRenamed('TERRITÓRIO ENTREGA', 'SG_TERRITORIO_ENTREGA')
        .withColumnRenamed('TRANSIT TIME MTC', 'QT_TRANSIT_TIME_MTC')
        .withColumnRenamed('STATUS', 'FL_STATUS')
        .withColumnRenamed('EMPRESA', 'NM_EMPRESA')
        .withColumnRenamed('ABREMP', 'NM_ABREVIADO_EMPRESA')
        .withColumnRenamed('ENDERECO', 'NM_ENDERECO')
        .withColumnRenamed('BAIRRO', 'NM_BAIRRO')
        .withColumnRenamed('CIDADE', 'NM_CIDADE')
        .withColumnRenamed('ESTADO', 'SG_ESTADO')
        .withColumnRenamed('CEP', 'NR_CEP')
        .withColumn("NR_CEP_SEM_PONTUACAO", regexp_replace(col("NR_CEP"), "[^0-9]", ""))
        .withColumnRenamed('DDD', 'NR_DDD')
        .withColumnRenamed('FONE1', 'NR_FONE_1')
        .withColumnRenamed('FONE2', 'NR_FONE_2')
        .withColumnRenamed('CNPJ (S/PT)', 'DC_CNPJ_SEM_PONTUACAO')
        .withColumnRenamed('CNPJ', 'DC_CNPJ')
        .withColumnRenamed('CCY RESP', 'DC_CNPJ_MATRIZ')
        .withColumnRenamed('IEST', 'NR_INSCRICAO_ESTADUAL')
        .withColumnRenamed('CONTATO', 'NM_CONTATO')
        .withColumnRenamed('DATABERT', 'DT_ABERTURA')
        .withColumnRenamed('CODGEC', 'CD_GEC')
        .withColumnRenamed('GRUPO', 'NM_GRUPO')
        .withColumnRenamed('AREA_OP', 'NM_AREA_OPERACIONAL')
        .withColumnRenamed('NOME SITE', 'NM_SITE')
        .withColumnRenamed('COORDENADOR', 'NM_COORDENADOR')
        .withColumnRenamed('EMAIL MTC', 'DS_EMAIL_COORDENADOR')
        .withColumnRenamed("TEL MTC32", 'NR_FONE_COORDENADOR')
        .withColumnRenamed('CONSULTOR', 'NM_CONSULTOR')
        .withColumnRenamed('E MAIL MTC', 'DS_EMAIL_CONSULTOR')
        .withColumnRenamed("TEL MTC35", 'NR_FONE_CONSULTOR')
        .withColumnRenamed('COORDENADOR PÓS VENDAS', 'NM_COORDENADOR_POS_VENDAS')
        .withColumnRenamed('E-MAIL ', 'DS_EMAIL_COORDENADOR_POS_VENDAS')
        .withColumnRenamed('TEL ', 'NR_FONE_COORDENADOR_POS_VENDAS')
        .withColumnRenamed('REPRESENTANTE', 'NM_REPRESENTANTE')
        .withColumnRenamed('E MAIL DPS', 'DS_EMAIL_REPRESENTANTE')
        .withColumnRenamed('TEL DPS', 'NR_FONE_REPRESENTANTE')
        .withColumnRenamed('REG_EST', 'DS_REGIAO_ESTADO')
        .withColumnRenamed('.titular@yamahaconcessionaria.com.br', 'DS_EMAIL_TITULAR')
        .withColumnRenamed('.vendas@yamahaconcessionaria.com.br', 'DS_EMAIL_VENDAS')
        .withColumnRenamed('.servicos@yamahaconcessionaria.com.br', 'DS_EMAIL_SERVICOS')
        .withColumnRenamed('@yamahaconcessionaria.com.br', 'DS_EMAIL_GERAL')
        .withColumnRenamed('WhatsApp', 'NR_WHATSAPP')
        .withColumnRenamed('Site - ABRACY', 'DS_SITE_ABRACY')
        .withColumnRenamed('Site Concessionária', 'DS_SITE_CONCESSIONARIA')
        .withColumnRenamed('Email da Concessionária', 'DS_EMAIL_CONCESSIONARIA')
        .withColumnRenamed('longitude', 'NR_LONGITUDE')
        .withColumnRenamed('latitude', 'NR_LATITUDE')
        .withColumnRenamed('Cartão VISA', 'FL_CARTAO_VISA')
        .withColumnRenamed('Preço Fixo', 'FL_PRECO_FIXO')
        .withColumnRenamed('YRA', 'FL_YRA')
        .withColumnRenamed('Diamante', 'FL_DIAMANTE')
        .withColumnRenamed('Form.Leads', 'FL_FORM_LEADS')
        .withColumnRenamed('Racing Blue', 'FL_RACING_BLUE')
        .withColumnRenamed('Go!Yamaha', 'FL_GO_YAMAHA')
        .withColumnRenamed('Test Ride ', 'FL_TEST_RIDE')
        .withColumnRenamed('Cancelamento', 'DS_CANCELAMENTO')
        .withColumnRenamed('Data Email', 'DT_EMAIL')
)

# COMMAND ----------

df_bronze.display()

# COMMAND ----------

from pyspark.sql import DataFrame
from pyspark.sql.functions import col

def reorganizar_colunas_dataframe(df: DataFrame) -> DataFrame:
    # Obter a lista atual de colunas
    colunas_atuais = df.columns

    # Remover as colunas que serão movidas da lista atual
    colunas_reordenadas = [c for c in colunas_atuais if c not in ["ID_CONCESSIONARIA", "NR_CEP_SEM_PONTUACAO"]]

    # Adicionar ID_CONCESSIONARIA no início
    colunas_finais = ["ID_CONCESSIONARIA"] + colunas_reordenadas

    # Encontrar a posição de NR_CEP e inserir NR_CEP_SEM_PONTUACAO após ela
    try:
        indice_nr_cep = colunas_finais.index("NR_CEP")
        colunas_finais.insert(indice_nr_cep + 1, "NR_CEP_SEM_PONTUACAO")
    except ValueError:
        print("A coluna 'NR_CEP' não foi encontrada no DataFrame. 'NR_CEP_SEM_PONTUACAO' será adicionada ao final.")
        colunas_finais.append("NR_CEP_SEM_PONTUACAO")

    # Selecionar as colunas na nova ordem
    return df.select([col(c) for c in colunas_finais])

# Exemplo de uso (assumindo que df_bronze já está definido):
df_bronze_reorganizado = reorganizar_colunas_dataframe(df_bronze)
#display(df_bronze_reorganizado)

# COMMAND ----------

# DBTITLE 1,Gravação da tabela na camada Bronze
(
    df_bronze_reorganizado
    .write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f'{bronze_catalog}.{param_schema}.{param_nome_tabela}')
)

# COMMAND ----------

# DBTITLE 1,Otimização da tabela na camada Bronze
deltaTable = DeltaTable.forTable(f'{bronze_catalog}.{param_schema}.{param_nome_tabela}')
deltaTable.vacuum()
deltaTable.optimize().executeCompaction()
