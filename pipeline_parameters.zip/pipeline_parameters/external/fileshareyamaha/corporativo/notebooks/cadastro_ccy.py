# Databricks notebook source
# Criado por        : Cesar Augusto Lagos Rojas
# Data criação      : 22/08/24
# Atualizado por    : Vinicius Geada
# Data atualização  : 13/08/25

# COMMAND ----------

import os, time
from pyspark.sql.functions import *
import re
# from pyspark.sql.types import *
# from delta.tables import *

# COMMAND ----------

def get_env():
    env = os.environ.get("DATABRICKS_ENV")
    return env.lower()

# COMMAND ----------

env = get_env()

source_bucket_landing   = f'/Volumes/landing_{env}/s3/'
param_lineage_landing   = 'external/fileshareyamaha/pecas/performance_vendas/processar/'

bronze_catalog          = f"bronze_{env.lower()}"
schema                  = "ext_perfomance"
table                   = "cadastro_ccy"

# COMMAND ----------

# Lista todos os arquivos no diretório
files = dbutils.fs.ls(source_bucket_landing + param_lineage_landing)

# Define o padrão esperado no nome do arquivo
pattern = r"(\d{8})_00_CADASTRO_CCY\.xlsx"
filtered_files = []

# Filtra e extrai data dos arquivos que seguem o padrão
for f in files:
    match = re.search(pattern, f.name)
    if match:
        file_date = match.group(1)
        filtered_files.append((file_date, f.name, f.path))

# Verifica se encontrou arquivos válidos
if filtered_files:
    print("Arquivos encontrados:")
    for file_date, file_name, _ in filtered_files:
        print(f"- {file_name}")

    # Ordena pela data (formato YYYYMMDD permite ordenação direta)
    filtered_files.sort(reverse=True)

    # Seleciona o mais recente
    latest_file_date, latest_file_name, latest_file_path = filtered_files[0]

    print(f"\nArquivo mais recente selecionado: {latest_file_name}")

    # Leitura do arquivo
    cadastro_ccy = (
        spark.read
             .format("com.crealytics.spark.excel")
             .option("maxRowsInMemory", "10000")
             .option("dataAddress", "'ccy_ativas'!A1")
             .option("header", True)
             .option("inferSchema", False)
             .load(latest_file_path)
             .drop("Coluna1")
             .na.drop(how="all")
    )
else:
    print("Nenhum arquivo correspondente encontrado.")


# COMMAND ----------

# Renomeação de campos
cadastro_ccy = (
    cadastro_ccy 
    .withColumnRenamed('SUB REG', 'SUB_REG')
    .withColumnRenamed('RAZÃO SOCIAL', 'RAZAO_SOCIAL')
    .withColumnRenamed('ENDEREÇO', 'ENDERECO')
    .withColumnRenamed('DATA INÍCIO', 'DATA_INICIO')


## Tipagem das colunas
   .withColumn("DATA_INICIO", to_date(col("DATA_INICIO"), "M/d/yy"))

)

print('Rename e Tipagens Ok')

# COMMAND ----------

print(f"Persiste os dados do DF na camada Bronze na tabela {bronze_catalog}.{schema}.{table}", end="")
(
    cadastro_ccy
        .write
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(f"{bronze_catalog}.{schema}.{table}")
)
print(" - Concluido com sucesso")
