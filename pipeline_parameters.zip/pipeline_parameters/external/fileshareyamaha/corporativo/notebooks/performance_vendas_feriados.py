# Databricks notebook source
import os, time
from pyspark.sql.functions import *
# from pyspark.sql.types import *
# from delta.tables import *

# COMMAND ----------

def get_env():
    env = os.environ.get("DATABRICKS_ENV")
    return env.lower()

# COMMAND ----------

env = get_env()

source_bucket_landing   = f'/Volumes/landing_{env}/s3/'
param_lineage_landing   = 'external/fileshareyamaha/pecas/performance_vendas/processar/'

silver_catalog          = f"silver_{env.lower()}"
schema                  = "ext_perfomance"
table                   = "feriados"
nome_arquivo            = '20250801_00_FERIADOS.xlsx'

path_landing_full       =  source_bucket_landing + param_lineage_landing + nome_arquivo

print(path_landing_full)

# s3://databricks-yamaha-dev-landing/external/fileshareyamaha/pecas/performance_vendas/processar/20250801_00_FERIADOS.xlsx

# COMMAND ----------

df_feriados = (
    spark.read
         .format("com.crealytics.spark.excel")
         .option("header", "true")
         .option("inferSchema", "true")
         .load(path_landing_full))

df_feriados = df_feriados.withColumn('DT_FERIADO', col('DT_FERIADO').cast('date'))

# COMMAND ----------

print(f"Persiste os dados do DF na camada Bronze na tabela {silver_catalog}.{schema}.{table}", end="")
(
    df_feriados
        .write
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(f"{silver_catalog}.{schema}.{table}")
)
print(" - Concluido com sucesso")
