# Databricks notebook source
# Criado por: Malco Alves
# Data Criação: 10-04-2025
# Atualizado por: Vinicius Geada
# Data Atualização: 04-08-2025

# COMMAND ----------

# MAGIC %md
# MAGIC **Importação das bibliotecas**

# COMMAND ----------

import datetime
import os
import boto3
from pyspark.sql.functions import *
from pyspark.sql.types import *
from delta.tables import *
from os import *

# COMMAND ----------

# MAGIC %md
# MAGIC Optimization method

# COMMAND ----------

def optimize_delta_table(table_path):
    """
        @param: IN table_path
        Run optimization commands and old snapshots
        Full load
    """
    deltaTable = DeltaTable.forPath(spark, table_path)
    deltaTable.vacuum()
    deltaTable.optimize().executeCompaction()
    print('optimized delta table.') 

# COMMAND ----------

# MAGIC %md
# MAGIC Variáveis

# COMMAND ----------

def get_env():
    env = os.environ.get("DATABRICKS_ENV")
    return env.lower()

# COMMAND ----------

env = get_env()

source_bucket_landing   = f'/Volumes/landing_{env}/s3/'
param_lineage_landing   = 'external/fileshareyamaha/controladoria/contabilidade/opex/realizado/processar/'

path_landing_full       =  source_bucket_landing + param_lineage_landing

bronze_catalog          = f"bronze_{env.lower()}"
schema                  = "ext_controladoria"
table                   = "opex_pbcs_realizado"

print(path_landing_full)
print(bronze_catalog)
print(schema)
print(table)

# COMMAND ----------

# MAGIC %md
# MAGIC Landing para Bronze

# COMMAND ----------

from pyspark.sql.functions import split

# Leitura do CSV
df_bronze = (
    spark
    .read
    .csv(path_landing_full, inferSchema=True, header=True)
)

# Quebrando os valores da coluna 'Point-of-View' em múltiplas colunas
df_split = df_bronze.withColumn("Point-of-View_Split", split(df_bronze["Point-of-View"], ","))

# Determinar o número máximo de splits
max_splits = df_split.selectExpr("size(`Point-of-View_Split`) as len").agg({"len": "max"}).collect()[0][0]

# Criar dinamicamente colunas COL_1, COL_2, ..., COL_n
for i in range(max_splits):
    df_split = df_split.withColumn(f"COL_{i+1}", df_split["Point-of-View_Split"].getItem(i))

# Remover colunas desnecessárias
df_split = df_split.drop("Point-of-View_Split", "Point-of-View")

# Reordenar colunas para que 'Data Load Clube Name' fique no final
cols = [col for col in df_split.columns if col != "Data Load Cube Name"]
cols.append("Data Load Cube Name")
df_final = df_split.select(cols)

# Exibir o resultado
#df_final.display()


# COMMAND ----------

# Renomeação de campos
df_final = (
    df_final 
    .withColumnRenamed('Conta', 'CONTA')
    .withColumnRenamed('Jan', 'JAN')
    .withColumnRenamed('Feb', 'FEB')
    .withColumnRenamed('Mar', 'MAR')
    .withColumnRenamed('Apr', 'APR')
    .withColumnRenamed('May', 'MAY')
    .withColumnRenamed('Jun', 'JUN')
    .withColumnRenamed('Jul', 'JUL')
    .withColumnRenamed('Aug', 'AUG')
    .withColumnRenamed('Sep', 'SEP')
    .withColumnRenamed('Oct', 'OCT')
    .withColumnRenamed('Nov', 'NOV')
    .withColumnRenamed('Dec', 'DEC')
    .withColumnRenamed('COL_1', 'POINT-OF-VIEW')
    .withColumnRenamed('COL_2', 'ORG')
    .withColumnRenamed('COL_3', 'TIPO')
    .withColumnRenamed('COL_4', 'INTERCOMPANHIA')
    .withColumnRenamed('COL_5', 'SEG')
    .withColumnRenamed('COL_6', 'CC')
    .withColumnRenamed('COL_7', 'CENARIO')
    .withColumnRenamed('COL_8', 'APROVADO')
    .withColumnRenamed('COL_9', 'ANO')
    .withColumnRenamed('Data Load Cube Name', 'DATA_LOAD_CUBE_NAME')
)
#df_final.display()

# COMMAND ----------

from pyspark.sql.functions import lit, to_date, regexp_extract, concat

# Dicionário de meses com os respectivos valores fixos (MM)
meses_para_datas = {
    "Jan": "01",
    "Feb": "02",
    "Mar": "03",
    "Apr": "04",
    "May": "05",
    "Jun": "06",
    "Jul": "07",
    "Aug": "08",
    "Sep": "09",
    "Oct": "10",
    "Nov": "11",
    "Dec": "12"
}

# Lista de colunas fixas (tirando os meses)
colunas_fixas = [col for col in df_final.columns if col not in meses_para_datas.keys()]

# Extraindo o ano corretamente da coluna ANO (de FY24 para 2024, por exemplo)
df_final = df_final.withColumn("ano_num", regexp_extract("ANO", r"FY(\d{2})", 1))
df_final = df_final.withColumn("ano_completo", concat(lit("20"), "ano_num"))  # FY24 → 2024

# Criando o novo dataframe transformado
df_transformado = None

for mes_coluna, mes_valor in meses_para_datas.items():
    df_mes = df_final.selectExpr(*[f"`{col}`" for col in colunas_fixas], f"`{mes_coluna}` as quantidade", "`ano_completo`") \
                      .withColumn("data", to_date(concat(lit(f"01/{mes_valor}/"), df_final["ano_completo"]), "dd/MM/yyyy"))
    
    df_transformado = df_mes if df_transformado is None else df_transformado.unionByName(df_mes)

# Selecionando as colunas desejadas e descartando auxiliares
df_transformado = df_transformado.select(*colunas_fixas, "DATA", "QUANTIDADE")

#df_transformado.display()

# COMMAND ----------

# DBTITLE 1,Gravação da tabela na camada Bronze
(
    df_transformado
    .write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f"{bronze_catalog}.{schema}.{table}")
)

# COMMAND ----------

# DBTITLE 1,Otimização da tabela na camada Bronze
deltaTable = DeltaTable.forTable(f'{bronze_catalog}.{schema}.{table}')
deltaTable.vacuum()
deltaTable.optimize().executeCompaction()
