# Databricks notebook source
import os, time
from pyspark.sql.functions import *

# COMMAND ----------

def get_env():
    env = os.environ.get("DATABRICKS_ENV")
    return env.lower()

# COMMAND ----------

env = get_env()

source_bucket_landing = f"/Volumes/landing_{env}/s3/"
param_lineage_landing = "external/fileshareyamaha/perfomance/processar/"
bronze_catalog        = f"bronze_{env.lower()}"
schema                = "ext_perfomance"
table                 = "cadastro_yamaha"
nome_arquivo          = "Cadastro Yamaha.xlsx"

path_landing_full     =  source_bucket_landing + param_lineage_landing + nome_arquivo

print(path_landing_full)

# s3://databricks-yamaha-dev-landing/external/fileshareyamaha/pecas/performance_vendas/processar/20250801_00_FERIADOS.xlsx

# COMMAND ----------

df_cadastro_yamaha = (
    spark.read
         .format("com.crealytics.spark.excel")
         .option("header", "true")
         .option("inferSchema", "true")
         .load(path_landing_full))

df_cadastro_yamaha = \
    df_cadastro_yamaha.withColumnRenamed("Razão Social", "RAZAO_SOCIAL")

# COMMAND ----------

print(f"Persiste os dados do DF na camada Bronze na tabela {bronze_catalog}.{schema}.{table}", end="")
(
    df_cadastro_yamaha
        .write
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(f"{bronze_catalog}.{schema}.{table}")
)
print(" - Concluido com sucesso")
