# Databricks notebook source
import os, time
from pyspark.sql.functions import *

# COMMAND ----------

def get_env():
    env = os.environ.get("DATABRICKS_ENV")
    return env.lower()

# COMMAND ----------

env = get_env()

source_bucket_landing = f"/Volumes/landing_{env}/s3/"
param_lineage_landing = "external/fileshareyamaha/perfomance/processar/"
bronze_catalog        = f"bronze_{env.lower()}"
schema                = "ext_perfomance"
table                 = "litros_yamalube"
nome_arquivo          = "Litros Yamalube.xlsx"

path_landing_full     =  source_bucket_landing + param_lineage_landing + nome_arquivo

# COMMAND ----------

df_litros_yamalube = (
    spark.read
         .format("com.crealytics.spark.excel")
         .option("header", "true")
         .option("inferSchema", "true")
         .load(path_landing_full))

drop_cols = ["Coluna1", "Coluna2"]
df_litros_yamalube = \
    df_litros_yamalube.withColumnRenamed("DESCRIÇÃO", "DESCRICAO") \
                      .drop(*drop_cols)

# Remove linhas em branco
df_litros_yamalube = df_litros_yamalube.filter("ITEM is not null")

# COMMAND ----------

print(f"Persiste os dados do DF na camada Bronze na tabela {bronze_catalog}.{schema}.{table}", end="")
(
    df_litros_yamalube
        .write
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(f"{bronze_catalog}.{schema}.{table}")
)
print(" - Concluido com sucesso")
