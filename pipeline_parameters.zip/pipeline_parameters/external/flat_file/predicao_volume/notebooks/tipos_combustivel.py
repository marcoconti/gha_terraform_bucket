# Databricks notebook source
# MAGIC %md
# MAGIC #Metadados gerais

# COMMAND ----------

# MAGIC %md
# MAGIC **Criado por**: Pedro Ernesto
# MAGIC
# MAGIC **Data criação**: 31/10/2023
# MAGIC
# MAGIC **Atualizado por**: Pedro Ernesto
# MAGIC
# MAGIC **Data atualização**: 12/03/2024
# MAGIC
# MAGIC **Atualizado por**: Bruno Jander
# MAGIC
# MAGIC **Data atualização**: 25/11/2024
# MAGIC
# MAGIC **Atualizado por**: Bruno Jander
# MAGIC
# MAGIC **Data atualização**: 14/01/2025
# MAGIC
# MAGIC **Atualizado por**: Bruno Jander
# MAGIC
# MAGIC **Data atualização**: 21/01/2025
# MAGIC
# MAGIC **Atualizado por**: Bruno Jander
# MAGIC
# MAGIC **Data atualização**: 10/07/2025
# MAGIC
# MAGIC [comment]: <> (Tem que vir do negócio)
# MAGIC **Descrição do dataset/tabela/view**: Tabela contendo os tipos de combustíveis, disponibilizada pela Abraciclo através de FTP.
# MAGIC
# MAGIC [comment]: # (Lineage, nome de domínio, sub-domínio, tipo de agregação, business unit: Tem que vir do negócio)
# MAGIC **Tags**:
# MAGIC
# MAGIC [comment]: # (Tem que vir do negócio)
# MAGIC **Data owner**: 
# MAGIC
# MAGIC [comment]: # (Full/Incremental/Streaming/CDC/etc)
# MAGIC **Tipo de carga**: Full
# MAGIC
# MAGIC [comment]: # (Tem que vir de sistemas)
# MAGIC **Atualização**: Diária

# COMMAND ----------

# MAGIC %md
# MAGIC #### Fontes utilizadas nesse pipeline:
# MAGIC
# MAGIC [comment]: <> (tabelas utilizadas nesse notebook)
# MAGIC
# MAGIC - bronze_catalog.planejamento_produto.flatfile_predicao_volume_tipos_combustivel
# MAGIC - silver_catalog.planejamento_produto.flatfile_predicao_volume_tipos_combustivel

# COMMAND ----------

# MAGIC %md
# MAGIC # Configurações Iniciais

# COMMAND ----------

# DBTITLE 1,Importação de bibliotecas
from os import getenv
from datetime import datetime
from pyspark.sql.functions import col, substring, trim, regexp_replace, upper
from pyspark.sql.types import IntegerType, StringType

# COMMAND ----------

# DBTITLE 1,Variáveis de ambiente
source_bucket_landing = getenv("param_bucket_landing")
source_bucket_bronze = getenv("param_bucket_bronze")
source_bucket_silver = getenv("param_bucket_silver")
ambiente = getenv("DATABRICKS_ENV")

# COMMAND ----------

# DBTITLE 1,Definição de datas de referência
current_year = datetime.now().strftime("%Y")
current_month = datetime.now().strftime("%m")

month_names = {
    "01": "Janeiro",
    "02": "Fevereiro",
    "03": "Marco",
    "04": "Abril",
    "05": "Maio",
    "06": "Junho",
    "07": "Julho",
    "08": "Agosto",
    "09": "Setembro",
    "10": "Outubro",
    "11": "Novembro",
    "12": "Dezembro",
}

# COMMAND ----------

# DBTITLE 1,Lineage de diretórios
# <database>/<sistema>/<esquema> ou <external>/<sistema>/<esquema>
# igual ao lineage do pipeline do Informatica
param_lineage_land = 'external/flat_file/abraciclo'
param_lineage = 'external/flat_file/planejamento_produto'
param_schema = "predicao_volume"
bronze_catalog = f'bronze_{ambiente}'
silver_catalog = f'silver_{ambiente}'

# Nome da tabela
param_nome_tabela = 'tipos_combustivel'

# Lineage completo
path_landing_full = "s3://" + source_bucket_landing + "/" + param_lineage_land + "/" + current_year + "/" + month_names[current_month]
path_bronze = "s3://" + source_bucket_bronze + "/" + param_lineage + "/" + param_nome_tabela
path_silver = "s3://" + source_bucket_silver + "/" + param_lineage + "/" + param_nome_tabela

# COMMAND ----------

# MAGIC %md
# MAGIC #Landing para Bronze

# COMMAND ----------

# DBTITLE 1,Levantamento do arquivo DT mais recente na Landing
def list_files_recursively(path, dbutils):
    files = []
    items = dbutils.fs.ls(path)
    
    for item in items:
        if item.isDir():  # Se for um diretório, faz listagem recursiva
            files.extend(list_files_recursively(item.path, dbutils))
        elif "DT" in item.path:  # Filtra somente arquivos DT (tradutoras)
            files.append(item.path)

    return files

folder_path = path_landing_full
file_paths = list_files_recursively(folder_path, dbutils)
latest_DT_file_path = file_paths[-1]
latest_DT_file_name = latest_DT_file_path.split("/")[-1]

# COMMAND ----------

# DBTITLE 1,Leitura do arquivo DT mais recente na Landing
df_bronze = (
    spark
    .read
    .load(
        path=latest_DT_file_path, 
        format="csv",
        header="False",
        encoding='cp1250'
        )
)

# COMMAND ----------

# DBTITLE 1,Ajuste de palavras com caracteres de outros idiomas
palavras_corrigir = {
    "Ă": "Ã",
    "Ő": "Õ",
    "Ę": "Ê",
    "Ş": "º"
}

for palavra in palavras_corrigir:
    df_bronze = (
        df_bronze
        .withColumn("_c0", regexp_replace(col("_c0"), palavra, palavras_corrigir[palavra]))
    )

# COMMAND ----------

# DBTITLE 1,Tratamento do arquivo DT
# Filtrando apenas a tradutora 03 (tipos de combustíveis)
df_bronze = df_bronze.filter(df_bronze[0].startswith("03"))

df_split_bronze = (
    df_bronze
    .withColumn("CD_COD", substring(df_bronze[0], 3, 4))
    .withColumn("DS_DESCRICAO", upper(substring(df_bronze[0], 9, 100)))
    .drop(df_bronze[0])
)

df_std_bronze = (
    df_split_bronze
    .withColumn(
        "CD_COD", col("CD_COD").cast(IntegerType()))
    .withColumn(
        "CD_COD", col("CD_COD").cast(StringType()))
    .withColumn("DS_DESCRICAO", trim(col("DS_DESCRICAO")))
)

# COMMAND ----------

# DBTITLE 1,Gravação da tabela na camada Bronze
(
    df_std_bronze
    .write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f'{bronze_catalog}.{param_schema}.{param_nome_tabela}')
)

# COMMAND ----------

# MAGIC %md
# MAGIC #BRONZE PARA SILVER

# COMMAND ----------

# DBTITLE 1,Leitura da tabela na camada Bronze
df_bronze_silver = (
    spark
    .read
    .format("delta")
    .table(f'{bronze_catalog}.{param_schema}.{param_nome_tabela}')
)

# COMMAND ----------

# DBTITLE 1,Gravação da tabela na camada Silver
(
    df_bronze_silver
    .write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f'{silver_catalog}.{param_schema}.{param_nome_tabela}')
)
