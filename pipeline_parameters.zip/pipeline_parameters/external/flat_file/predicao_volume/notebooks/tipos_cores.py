# Databricks notebook source
# MAGIC %md
# MAGIC #Metadados gerais

# COMMAND ----------

# MAGIC %md
# MAGIC **Criado por**: Pedro Ernesto
# MAGIC
# MAGIC **Data criação**: 31/10/2023
# MAGIC
# MAGIC **Atualizado por**: Pedro Ernesto
# MAGIC
# MAGIC **Data atualização**: 12/03/2024
# MAGIC
# MAGIC **Atualizado por**: Bruno Jander
# MAGIC
# MAGIC **Data atualização**: 11/07/2025
# MAGIC
# MAGIC [comment]: <> (Tem que vir do negócio)
# MAGIC **Descrição do dataset/tabela/view**: 
# MAGIC
# MAGIC [comment]: # (Lineage, nome de domínio, sub-domínio, tipo de agregação, business unit: Tem que vir do negócio)
# MAGIC **Tags**:
# MAGIC
# MAGIC [comment]: # (Tem que vir do negócio)
# MAGIC **Data owner**: 
# MAGIC
# MAGIC [comment]: # (Full/Incremental/Streaming/CDC/etc)
# MAGIC **Tipo de carga**: Full
# MAGIC
# MAGIC [comment]: # (Tem que vir de sistemas)
# MAGIC **Atualização**: Anual

# COMMAND ----------

# MAGIC %md
# MAGIC #### Fontes utilizadas nesse pipeline:
# MAGIC
# MAGIC [comment]: <> (tabelas utilizadas nesse notebook)
# MAGIC
# MAGIC - bronze_catalog.planejamento_produto.flatfile_predicao_volume_tipos_cores
# MAGIC - silver_catalog.planejamento_produto.flatfile_predicao_volume_tipos_cores

# COMMAND ----------

# MAGIC %md
# MAGIC # Configurações Iniciais

# COMMAND ----------

# DBTITLE 1,Importação de bibliotecas
from os import getenv
from pyspark.sql.functions import col

# COMMAND ----------

# DBTITLE 1,Variáveis de ambiente
source_bucket_landing = getenv("param_bucket_landing")
source_bucket_bronze = getenv("param_bucket_bronze")
source_bucket_silver = getenv("param_bucket_silver")
ambiente = getenv("DATABRICKS_ENV")

# COMMAND ----------

# DBTITLE 1,Lineage de diretórios
# <database>/<sistema>/<esquema> ou <external>/<sistema>/<esquema>
# igual ao lineage do pipeline do Informatica
param_lineage = 'external/flat_file/planejamento_produto'
param_schema = "predicao_volume"
bronze_catalog = f'bronze_{ambiente}'
silver_catalog = f'silver_{ambiente}'

# Nome da tabela
param_nome_tabela = 'tipos_cores'

# Lineage completo
path_landing_full = "s3://" + source_bucket_landing + "/" + param_lineage + "/" + param_nome_tabela + "/full"
path_bronze = "s3://" + source_bucket_bronze + "/" + param_lineage + "/" + param_nome_tabela
path_silver = "s3://" + source_bucket_silver + "/" + param_lineage + "/" + param_nome_tabela

# COMMAND ----------

# MAGIC %md
# MAGIC # Landing para Bronze

# COMMAND ----------

# DBTITLE 1,Leitura do arquivo fonte na Landing
df_bronze = (
    spark
    .read
    .options(
        delimiter=',', 
        encoding="UTF-8")
    .csv(
        path_landing_full, 
        inferSchema=False, 
        header=True)
)

# COMMAND ----------

# DBTITLE 1,Renomeação e Tipagem de Colunas
df_std_bronze = (
    df_bronze
    .select(
        col(df_bronze.columns[1])        .cast("string")        .alias('CD_COD'),
        col(df_bronze.columns[2])        .cast("string")        .alias('DS_DESCRICAO')
    )
)

# COMMAND ----------

# DBTITLE 1,Gravação da tabela na camada Bronze
(
    df_std_bronze
    .write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f'{bronze_catalog}.{param_schema}.{param_nome_tabela}')
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Bronze para Silver

# COMMAND ----------

# DBTITLE 1,Leitura da tabela na camada Bronze
df_bronze_silver = (
    spark
    .read
    .format("delta")
    .table(f'{bronze_catalog}.{param_schema}.{param_nome_tabela}')
)

# COMMAND ----------

# DBTITLE 1,Gravação da tabela na camada Silver
(
    df_bronze_silver
    .write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f'{silver_catalog}.{param_schema}.{param_nome_tabela}')
)
