# Databricks notebook source
# MAGIC %md
# MAGIC #Metadados gerais

# COMMAND ----------

# MAGIC %md
# MAGIC **Criado por**: Pedro Ernesto
# MAGIC
# MAGIC **Data criação**: 31/10/2023
# MAGIC
# MAGIC **Atualizado por**: Pedro Ernesto
# MAGIC
# MAGIC **Data atualização**: 28/03/2024
# MAGIC
# MAGIC **Atualizado por**: Pedro Ernesto
# MAGIC
# MAGIC **Data atualização**: 02/04/2024
# MAGIC
# MAGIC **Atualizado por**: Bruno Jander
# MAGIC
# MAGIC **Data atualização**: 11/07/2025
# MAGIC
# MAGIC [comment]: <> (Tem que vir do negócio)
# MAGIC **Descrição do dataset/tabela/view**: Tabela contendo emplacamento histórico de veículos, com tratamentos específicos nos arquivos fontes para consolidação final.
# MAGIC
# MAGIC [comment]: # (Lineage, nome de domínio, sub-domínio, tipo de agregação, business unit: Tem que vir do negócio)
# MAGIC **Tags**:
# MAGIC
# MAGIC [comment]: # (Tem que vir do negócio)
# MAGIC **Data owner**: 
# MAGIC
# MAGIC [comment]: # (Full/Incremental/Streaming/CDC/etc)
# MAGIC **Tipo de carga**: Full
# MAGIC
# MAGIC [comment]: # (Tem que vir de sistemas)
# MAGIC **Atualização**: Anual

# COMMAND ----------

# MAGIC %md
# MAGIC #### Fontes utilizadas nesse pipeline:
# MAGIC
# MAGIC [comment]: <> (tabelas utilizadas nesse notebook)
# MAGIC
# MAGIC - bronze_catalog.planejamento_produto.flatfile_predicao_volume_emplacamento_historico
# MAGIC - silver_catalog.planejamento_produto.flatfile_predicao_volume_emplacamento_historico

# COMMAND ----------

# MAGIC %md
# MAGIC # Configurações Iniciais

# COMMAND ----------

# DBTITLE 1,Importação de bibliotecas
from os import getenv
from pyspark.sql.functions import lit, col

# COMMAND ----------

# DBTITLE 1,Variáveis de ambiente
source_bucket_landing = getenv("param_bucket_landing")
source_bucket_bronze = getenv("param_bucket_bronze")
source_bucket_silver = getenv("param_bucket_silver")
ambiente = getenv("DATABRICKS_ENV")

# COMMAND ----------

# DBTITLE 1,Lineage de diretórios
# <database>/<sistema>/<esquema> ou <external>/<sistema>/<esquema>
# igual ao lineage do pipeline do Informatica
param_lineage = 'external/flat_file/planejamento_produto'
param_schema = "predicao_volume"
bronze_catalog = f'bronze_{ambiente}'
silver_catalog = f'silver_{ambiente}'

# Nome da tabela
param_nome_tabela = 'emplacamento_historico'

# Nome dos arquivos históricos
nm2004 = 'mn2004.csv' # Não utilizado
mn2005 = 'mn2005.csv' # Não utilizado
mn2006 = 'mn2006.csv'
mn2007 = 'mn2007.csv'
mn2008 = 'mn2008.csv'
mn2009 = 'mn2009.csv'
mn2010 = 'mn2010.csv'
mn2011 = 'mn2011.csv'
mn2012 = 'mn2012.csv'
mn2013 = 'mn2013.csv'
mn2014 = 'mn2014.csv'
mn2015 = 'mn2015.csv'
mn2016 = 'mn2016.csv'
mn2017 = 'mn2017.csv'
mn2018 = 'mn2018.csv'
mn2019 = 'mn2019.csv'
mn2020 = 'mn2020.csv'
mn2021 = 'mn2021.csv'
mn2022 = 'mn2022.csv'

# Lineage completo
path_landing_full = "s3://" + source_bucket_landing + "/" + param_lineage + "/" + param_nome_tabela + "/full/"
path_bronze = "s3://" + source_bucket_bronze + "/" + param_lineage + "/" + param_nome_tabela
path_silver = "s3://" + source_bucket_silver + "/" + param_lineage + "/" + param_nome_tabela

# COMMAND ----------

# MAGIC %md
# MAGIC # Landing para Bronze

# COMMAND ----------

# DBTITLE 1,Leitura dos arquivos fonte na Landing
#Ajustado o path de cada arquivo conforme solicitado no github (28-03-2024)
#Arquivo de 2004 possui 11 colunas
## CÓD | Veiculo | Fabricante | Marca-Modelo | AnoMod | Chassi | CNPJ | UF | Municipio | Proc | Data
#path_land_2004 = "s3://s3-yamaha-datalake-landing-dev/ftp/abraciclo/historico/mn2004.csv"
#path_land_2004 = "s3://s3-yamaha-datalake-landing-dev/external/flat_file/planejamento_produto/historico/full/" + nm2004
path_land_2004 = path_landing_full + nm2004
df_bronze_2004 = (spark.read.options(delimiter=';', encoding="UTF-8").csv(path_land_2004,inferSchema=False, header=True))
columns_to_drop = ['_c0']
df_bronze_2004 = df_bronze_2004.drop(*columns_to_drop)

#Arquivo de 2005 possui
## CÓD | Veiculo | Fabricante | Marca-Modelo | AnoMod | Chassi | CNPJ | UF | Municipio | Proc | Data
#path_land_2005 = "s3://s3-yamaha-datalake-landing-dev/ftp/abraciclo/historico/mn2005.csv"
#path_land_2005 = "s3://s3-yamaha-datalake-landing-dev/external/flat_file/planejamento_produto/historico/full/" + mn2005
path_land_2005 = path_landing_full + mn2005
df_bronze_2005 = (spark.read.options(delimiter=';', encoding="UTF-8").csv(path_land_2005,inferSchema=False, header=True))
columns_to_drop = ['_c0']
df_bronze_2005 = df_bronze_2005.drop(*columns_to_drop)

#Arquivo de 2006 possui
## CÓD | Veiculo | Fabricante | Marca-Modelo | AnoMod | Chassi | CNPJ | UF | Municipio | Proc | Data
#path_land_2006 = "s3://s3-yamaha-datalake-landing-dev/ftp/abraciclo/historico/mn2006.csv"
#path_land_2006 = "s3://s3-yamaha-datalake-landing-dev/external/flat_file/planejamento_produto/historico/full/" + mn2006
path_land_2006 = path_landing_full + mn2006
df_bronze_2006 = (spark.read.options(delimiter=';', encoding="UTF-8").csv(path_land_2006,inferSchema=False, header=True))
columns_to_drop = ['_c0']
df_bronze_2006 = df_bronze_2006.drop(*columns_to_drop)

## CÓD | Data | chassi | placa | doc | cnpj | uffat | doc2 | ufemp | munic | anofab | anomod | marcamod | tipo | especie | carroc | numcarroc | cor | comb | potencia | cilindrada | lugares | carga | pbt | cmt | proced | sitchas | cxcambio | eixos | numeixo | terceixo | motor | montagem | docimp | idimp | di | regdi | srf | atualiz | restr1 | restr2 | restr3 | restr4 | datarestr | sitveic |
#path_land_2007 = "s3://s3-yamaha-datalake-landing-dev/ftp/abraciclo/historico/mn2007.csv"
#path_land_2007 = "s3://s3-yamaha-datalake-landing-dev/external/flat_file/planejamento_produto/historico/full/" + mn2007
path_land_2007 = path_landing_full + mn2007
df_bronze_2007 = (spark.read.options(delimiter=';', encoding="UTF-8").csv(path_land_2007,inferSchema=False, header=True))
columns_to_drop = ['_c0']
df_bronze_2007 = df_bronze_2007.drop(*columns_to_drop)

#Arquivo de 2008 possui
## CÓD | Data | Chassi | Placa | Tipo_Doc | CNPJ | UF_Fat | Doc_Prop | UF | Municipio | Ano_Fabr | Ano_Mod | Marca-Modelo | Tipo | Especie | Carroceria | Num_Carroceria | Cor | Combustivel | Potencia | Cilindrada | Lugares | Cap_Carga | PBT | CMT | Proc | Sit_Chassi | Cx_cambio | Eixos | Eixo_Tras | Terceiro_eixo | Motor | Montagem | Doc_Imp | Id_Imp | DI | Data_DI | SRF | Data_Atual | Rest1 | Rest2 | Rest3 | Rest4 | Rest_Trib | Sit_Veic | Montadora
#path_land_2008 = "s3://s3-yamaha-datalake-landing-dev/ftp/abraciclo/historico/mn2008.csv"
#path_land_2008 = "s3://s3-yamaha-datalake-landing-dev/external/flat_file/planejamento_produto/historico/full/" + mn2008
path_land_2008 = path_landing_full + mn2008
df_bronze_2008 = (spark.read.options(delimiter=';', encoding="UTF-8").csv(path_land_2008,inferSchema=False, header=True))
columns_to_drop = ['_c0']
df_bronze_2008 = df_bronze_2008.drop(*columns_to_drop)

#Arquivo de 2009 possui
## CÓD | Data | Chassi | Placa | Tipo_Doc | CNPJ | UF_Fat | Doc_Prop | UF | Municipo | Ano_Fabr | Ano_Mod | Marca-Modelo | Tipo | Especie | Carroceria | Num_Carroceria | Cor | Combustivel | Potencia | Cilindrada | Lugares | Cap_Carga | PBT | CMT | Proc | Sit_CHassi | Cx_cambio | Eixos | Eixo_tras | Terceito_eixo | Motor | Montagem | Doc_Imp | Id_imp | DI | Data_DI | SRF | Data_Atual | Rest1 | Rest2 | Rest3 | Rest4 | Rest_Trib | Sit_Veic | Montadora
#path_land_2009 = "s3://s3-yamaha-datalake-landing-dev/ftp/abraciclo/historico/mn2009.csv"
#path_land_2009 = "s3://s3-yamaha-datalake-landing-dev/external/flat_file/planejamento_produto/historico/full/" + mn2009
path_land_2009 = path_landing_full + mn2009
df_bronze_2009 = (spark.read.options(delimiter=';', encoding="UTF-8").csv(path_land_2009,inferSchema=False, header=True))
columns_to_drop = ['_c0']
df_bronze_2009 = df_bronze_2009.drop(*columns_to_drop)

#Arquivo de 2010 possui
## CÓD | Data | Chassi | Placa | Tipo_Doc | CNPJ | UF_Fat | Doc_Proc | UF | Municipio | Ano_Fabr | Ano_Mod | Marca-Modelo | Tipo | Especie | Carroceria | Num_Carroceria | Cor | Combustivel | Potencia | Cilindrada | Lugares | Cap_Carga | PBT | CMT | Proc | Sit_Chassi | Cx_cambio | Eixos | Eixo_tras | Terceiro_eixo | Moto | Montagem | Doc_Imp | Id_Imp | DI | Data_DI | SRF | Data_Atual | Rest1 | Rest2 | Rest3 | Rest4 | Rest_Trib | Sit_Veic | Montadora
#path_land_2010 = "s3://s3-yamaha-datalake-landing-dev/ftp/abraciclo/historico/mn2010.csv"
#path_land_2010 = "s3://s3-yamaha-datalake-landing-dev/external/flat_file/planejamento_produto/historico/full/" + mn2010
path_land_2010 = path_landing_full + mn2010
df_bronze_2010 = (spark.read.options(delimiter=';', encoding="UTF-8").csv(path_land_2010,inferSchema=False, header=True))
columns_to_drop = ['_c0']
df_bronze_2010 = df_bronze_2010.drop(*columns_to_drop)

#Arquivo de 2011 possui
## CÓD | Data | Chassi | Placa | Tipo_Doc | CNPJ | UF_Fat | Doc_Prop | UF | Municipo | Ano_Fabr | Ano_Mod | Marca-Modelo | Tipo | Especie | Carroceria | Num_Carroceria | Cor | Combustivel | Potencia | Cilindrada | Lugares | Cap_Carga | PBT | CMT | Proc | Sit_Chassi | Cx_cambio | Eixos | Eixo_tras | Terceiro_eixo | Motor | Montagem | Doc_Imp | Id_Imp | DI | Data_DI | SRF | Data_Atual | Rest1 | Rest2 | Rest3 | Rest4 | Rest_Trib | Sit_Veic | Montadora
#path_land_2011 = "s3://s3-yamaha-datalake-landing-dev/ftp/abraciclo/historico/mn2011.csv"
#path_land_2011 = "s3://s3-yamaha-datalake-landing-dev/external/flat_file/planejamento_produto/historico/full/" + mn2011
path_land_2011 = path_landing_full + mn2011
df_bronze_2011 = (spark.read.options(delimiter=';', encoding="UTF-8").csv(path_land_2011,inferSchema=False, header=True))
columns_to_drop = ['_c0']
df_bronze_2011 = df_bronze_2011.drop(*columns_to_drop)

#Arquivo de 2012 possui
## CÓD | Data | Chassi | Placa | Tipo_Doc | CNPJ | UF_Fat | Doc_Prop | UF | Municipo | Ano_Fabr | Ano_Mod | Marca-Modelo | Tipo | Especie | Carroceria | Num_Carroceria | Cor | Combustivel | Potencia | Cilindrada | Lugares | Cap_Carga | PBT | CMT | Proc | Sit_Chassi | Cx_cambio | Eixos | Eixo_tras | Terceiro_eixo | Motor | Montagem | Doc_Imp | Id_Imp | DI | Data_DI | SRF | Data_Atual | Rest1 | Rest2 | Rest3 | Rest4 | Rest_Trib | Sit_Veic | Montadora
#path_land_2012 = "s3://s3-yamaha-datalake-landing-dev/ftp/abraciclo/historico/mn2012.csv"
#path_land_2012 = "s3://s3-yamaha-datalake-landing-dev/external/flat_file/planejamento_produto/historico/full/" + mn2012
path_land_2012 = path_landing_full + mn2012
df_bronze_2012 = (spark.read.options(delimiter=';', encoding="UTF-8").csv(path_land_2012,inferSchema=False, header=True))
columns_to_drop = ['_c0']
df_bronze_2012 = df_bronze_2012.drop(*columns_to_drop)

#Arquivo de 2013 possui
## CÓD | Data | Chassi | Placa | Tipo_Doc | CNPJ | UF_Fat | Doc_Prop | UF | Municipo | Ano_Fabr | Ano_Mod | Marca-Modelo | Tipo | Especie | Carroceria | Num_Carroceria | Cor | Combustivel | Potencia | Cilindrada | Lugares | Cap_Carga | PBT | CMT | Proc | Sit_Chassi | Cx_cambio | Eixos | Eixo_tras | Terceiro_eixo | Motor | Montagem | Doc_Imp | Id_Imp | DI | Data_DI | SRF | Data_Atual | Rest1 | Rest2 | Rest3 | Rest4 | Rest_Trib | Sit_Veic  | Montadora
#path_land_2013 = "s3://s3-yamaha-datalake-landing-dev/ftp/abraciclo/historico/mn2013.csv"
#path_land_2013 = "s3://s3-yamaha-datalake-landing-dev/external/flat_file/planejamento_produto/historico/full/" + mn2013
path_land_2013 = path_landing_full + mn2013
df_bronze_2013 = (spark.read.options(delimiter=';', encoding="UTF-8").csv(path_land_2013,inferSchema=False, header=True))
columns_to_drop = ['_c0']
df_bronze_2013 = df_bronze_2013.drop(*columns_to_drop)

#Arquivo de 2014 possui
## CÓD | Data | Chassi | Placa | Tipo_Doc | CNPJ | UF_Fat | Doc_Prop | UF | Municipio | Ano_Fabr | Ano_Mod | Marca-Modelo | Tipo | Especie | Carroceria | Num_Carroceria | Cor | Combustivel | Potencia | Cilindrada | Lugares | Cap_Carga | PBT | CMT | Proc | Sit_Chassi | Cx_cambio | Eixos | Eixo_tras | Terceiro_eixo | Motor | Montagem | Doc_Imp | Id_Imp | DI | Data_DI | SRF | Data_Atual | Rest1 | Rest2 | Rest3 | Rest4 | Rest_Trib | Sit Veic | Montadora
#path_land_2014 = "s3://s3-yamaha-datalake-landing-dev/ftp/abraciclo/historico/mn2014.csv"
#path_land_2014 = "s3://s3-yamaha-datalake-landing-dev/external/flat_file/planejamento_produto/historico/full/"+ mn2014
path_land_2014 = path_landing_full+ mn2014
df_bronze_2014 = (spark.read.options(delimiter=';', encoding="UTF-8").csv(path_land_2014,inferSchema=False, header=True))
columns_to_drop = ['_c0']
df_bronze_2014 = df_bronze_2014.drop(*columns_to_drop)

#Arquivo de 2015 possui
## CÓD | Data | Chassi | Placa | Tipo_Doc | CNPJ | UF_Fat | Doc_Prop | UF | Municipio | Ano_Fabr | Ano_Mod | Marca-Modelo | Tipo | Especie | Carroceria | Num_Carroceria | Cor | Combustivel | Potencia | Cilindrada | Lugares | Cap_Carga | PBT | CMT | Proc | Sit_Chassi | Cx_cambio | Eixos | Eixo_tras | Terceiro_eixo | Motor | Montagem | Doc_Imp | Id_Imp | DI | Data_DI | SRF | Data_Atual | Rest1 | Rest2 | Rest3 | Rest 4 | Rest_Trib | Sit_Veic | Montadora
#path_land_2015 = "s3://s3-yamaha-datalake-landing-dev/ftp/abraciclo/historico/mn2015.csv"
#path_land_2015 = "s3://s3-yamaha-datalake-landing-dev/external/flat_file/planejamento_produto/historico/full/" + mn2015
path_land_2015 = path_landing_full + mn2015
df_bronze_2015 = (spark.read.options(delimiter=';', encoding="UTF-8").csv(path_land_2015,inferSchema=False, header=True))
columns_to_drop = ['_c0']
df_bronze_2015 = df_bronze_2015.drop(*columns_to_drop)

#Arquivo de 2016 possui
## CÓD | Data | Chassi | Placa | Tipo_Doc | CNPJ | UF_Fat | Doc_Prop | UF | Municipio | Ano_Fabr | Ano_Mod | Marca-Modelo | Tipo | Especie | Carroceria | Num_Carroceria | Cor | Combustível | Potencia | Cilindrada | Lugares | Cap_Carga | PBT | CMT | Proc | Sit_Chassi | Cx_cambio | Eixos | Eixo_tras | Terceiro_ eixo | Motor | Montagem | Doc_Imp | Id_Imp | DI | Data_DI | SRF | Data_Atual | Rest1 | Rest2 | Rest3 | Rest4 | Rest_Trib | Sit_Veic | Montadora
#path_land_2016 = "s3://s3-yamaha-datalake-landing-dev/ftp/abraciclo/historico/mn2016.csv"
#path_land_2016 = "s3://s3-yamaha-datalake-landing-dev/external/flat_file/planejamento_produto/historico/full/" + mn2016
path_land_2016 = path_landing_full + mn2016
df_bronze_2016 = (spark.read.options(delimiter=';', encoding="UTF-8").csv(path_land_2016,inferSchema=False, header=True))
columns_to_drop = ['_c0']
df_bronze_2016 = df_bronze_2016.drop(*columns_to_drop)

#Arquivo de 2017 possui
## CÓD | Data | Chassi | Placa | Tipo_Doc | CNPJ | UF_Fat | Doc_Prop | UF | Municipio | Ano_Fabr | Marca-Modelo | Tipo | Especie | Carroceria | Num_Carroceria | Cor | Combustivel | Potencia | Cilindrada | Lugares | Cap_Carga | PBT | CMT | Proc | Sit_Chassi | Cx_cambio | Eixos | Eixo_tras | Terceiro_eixo | Motor | Montagem | Doc_Imp | Id_Imp | DI | Data_DI | SRF | Data_Atual | Rest1 | Rest2 | Rest3 | Rest4 | Rest_Trib | Sit_Veic | Montadora
#path_land_2017 = "s3://s3-yamaha-datalake-landing-dev/ftp/abraciclo/historico/mn2017.csv"
#path_land_2017 = "s3://s3-yamaha-datalake-landing-dev/external/flat_file/planejamento_produto/historico/full/" + mn2017
path_land_2017 = path_landing_full + mn2017
df_bronze_2017 = (spark.read.options(delimiter=';', encoding="UTF-8").csv(path_land_2017,inferSchema=False, header=True))
columns_to_drop = ['_c0']
df_bronze_2017 = df_bronze_2017.drop(*columns_to_drop)

#Arquivo de 2018 possui
## CÓD | Data | Chassi | Placa | Tipo_Doc | CNPJ | UF_Fat | Doc_Prop | UF | Municipio | Ano_Fabr | Marca-Modelo | Tipo | Especie | Carroceria | Num_Carroceria | Cor | Combustivel | Potencia | Cilindrada | Lugares | Cap_Carga | PBT | CMT | Proc | Sit_Chassi | Cx_cambio | Eixo | Eixo_tras | Terceiro_eixo | Motor | Montadora | Doc_Imp | Id_Imp | DI | Data_DI | SRF | Data_Atual | Rest1 | Rest2 | Rest3 | Rest4 | Rest_Trib | Sit_Veic | Montadora
#path_land_2018 = "s3://s3-yamaha-datalake-landing-dev/ftp/abraciclo/historico/mn2018.csv"
#path_land_2018 = "s3://s3-yamaha-datalake-landing-dev/external/flat_file/planejamento_produto/historico/full/" + mn2018
path_land_2018 = path_landing_full + mn2018
df_bronze_2018 = (spark.read.options(delimiter=';', encoding="UTF-8").csv(path_land_2018,inferSchema=False, header=True))
columns_to_drop = ['_c0']
df_bronze_2018 = df_bronze_2018.drop(*columns_to_drop)

#Arquivo de 2019 possui
## CÓD | Data | Chassi | Placa | Tipo_Doc | CNPJ | UF_Fat | Doc_Prop | UF | Municipio | Ano_Fabr | Ano_Mod | Marca-Modelo | Tipo | Especie | Carroceria | Num_Carroceria | Cor | Combustivel | Potencia | Cilindrada | Lugares | Cap_Carga | PBT | CMT | Proc | Sit_Chassi | Cx_cambio | Eixos | Eixo_tras | Terceiro_eixo | Motor | Montagem | Doc_Imp | Id_Imp | DI | Data_DI | SRF | Data_Atual | Rest1 | Rest2 | Rest3 | Rest4 | Rest_Trib | Sit_Veic | Montadora
#path_land_2019 = "s3://s3-yamaha-datalake-landing-dev/ftp/abraciclo/historico/mn2019.csv"
#path_land_2019 = "s3://s3-yamaha-datalake-landing-dev/external/flat_file/planejamento_produto/historico/full/" + mn2019
path_land_2019 = path_landing_full + mn2019
df_bronze_2019 = (spark.read.options(delimiter=';', encoding="UTF-8").csv(path_land_2019,inferSchema=False, header=True))
columns_to_drop = ['_c0']
df_bronze_2019 = df_bronze_2019.drop(*columns_to_drop)

#Arquivo de 2020 possui
## CÓD | Data | Chassi | Placa | Tipo_Doc | CNPJ | UF_Fat | Doc_Prop | UF | Municipio | Ano_Fabr | Ano_Mod | Marca-Modelo | Tipo | Especie | Carroceria | Num_Carroceria | Cor | Combustivel | Potencia | Cilindrada | Lugares | Cap_Carga | PBT | CMT | Proc | Sit_Chassi | Cx_cambio | Eixos | Terceiro_eixo | Motor | Montagem | Doc_Imp | Id_Imp | DI | Data_DI | SRF | Data_Atual | Rest1 | Rest2 | Rest3 | Rest4 | Rest_Trib | Sit_Veic | Montadora
#path_land_2020 = "s3://s3-yamaha-datalake-landing-dev/ftp/abraciclo/historico/mn2020.csv"
#path_land_2020 = "s3://s3-yamaha-datalake-landing-dev/external/flat_file/planejamento_produto/historico/full/" + mn2020
path_land_2020 = path_landing_full + mn2020
df_bronze_2020 = (spark.read.options(delimiter=';', encoding="UTF-8").csv(path_land_2020,inferSchema=False, header=True))
columns_to_drop = ['_c0']
df_bronze_2020 = df_bronze_2020.drop(*columns_to_drop)

#Arquivo de 2021 possui
## CÓD | Data | Chassi | Placa | Tipo_Doc | CNPJ | UF_Fat | Doc_Proc | UF | Municipio | Ano_Fabr | Ano_mod | Marca-Modelo | Tipo | Especie | Carroceria | Num_Carroceria | Cor | Combustivel | Potencia | Cilindrada | Lugares | Cap_Carga | PBT | CMT | Proc | Sit_Chassi | Cx_cambio | Eixos | Eixo_tras | Terceiro_eixo | Motor | Montagem | Doc_Imp | Id_Imp | DI | Data_DI | SRF | Data_Atual | Rest1 | Rest2 | Rest3 | Rest4 | Rest_Trib | Sit_Veic | Montadora
#path_land_2021 = "s3://s3-yamaha-datalake-landing-dev/ftp/abraciclo/historico/mn2021.csv"
#path_land_2021 ="s3://s3-yamaha-datalake-landing-dev/external/flat_file/planejamento_produto/historico/full/" + mn2021
path_land_2021 = path_landing_full + mn2021
df_bronze_2021 = (spark.read.options(delimiter=';', encoding="UTF-8").csv(path_land_2021,inferSchema=False, header=True))
columns_to_drop = ['_c0']
df_bronze_2021 = df_bronze_2021.drop(*columns_to_drop)

#Arquivo de 2022 possui
## CÓD | Data | Chassi | Placa | Tipo_Doc | CNPJ | UF_Fat | Doc_Prop | UF | Municipio | Ano_Fabr | Ano_Mod | Marca-Modelo | Tipo | Especie | Carroceria | Num_Carroceria | Cor | Combustivel | Potencia | Cilindrada | Lugares | Cap_Carga | PBT | CMT | Proc | Sit_Chassi | Cx_cambio | Eixos | Eixo_tras | Terceiro_ Eixo | Motor | Montagem | Doc_Imp | DI | Data_DI | SRF | Data_Atual | Rest1 | Rest2 | Rest3 | Rest4 | Rest_Trib | Sit_Veic | Montadora
#path_land_2022 = "s3://s3-yamaha-datalake-landing-dev/ftp/abraciclo/historico/mn2022.csv"
#path_land_2022 = "s3://s3-yamaha-datalake-landing-dev/external/flat_file/planejamento_produto/historico/full/" + mn2022
path_land_2022 = path_landing_full + mn2022
df_bronze_2022 = (spark.read.options(delimiter=';', encoding="UTF-8").csv(path_land_2022,inferSchema=False, header=True))
columns_to_drop = ['_c0']
df_bronze_2022 = df_bronze_2022.drop(*columns_to_drop)

# COMMAND ----------

# DBTITLE 1,Tratamento dos dados de 2006
#No arquivo de 2006 há várias colunas ausentes, como também o nome das colunas são muito diferente
df_bronze_2006 = df_bronze_2006.withColumnRenamed("Veiculo", "Tipo_doc").withColumnRenamed("Fabricante", "Montadora")
df_bronze_2006 = df_bronze_2006.withColumn("Placa",lit(None)).withColumn("UF_Fat",lit(None)).withColumn("Doc_Prop",lit(None)).withColumn("Ano_Fabr",lit(None)).withColumn("Tipo",lit(None)).withColumn("Especie",lit(None)).withColumn("Carroceria",lit(None))\
                        .withColumn("Num_Carroceria",lit(None)).withColumn("Cor",lit(None)).withColumn("Combustivel",lit(None)).withColumn("Potencia",lit(None)).withColumn("Cilindrada",lit(None)).withColumn("Lugares",lit(None)).withColumn("Cap_Carga",lit(None))\
                        .withColumn("PBT",lit(None)).withColumn("CMT",lit(None)).withColumn("Proc",lit(None)).withColumn("Sit_Chassi",lit(None)).withColumn("Cx_cambio",lit(None)).withColumn("Eixos",lit(None)).withColumn("Eixo_tras",lit(None)).withColumn("Terceiro_eixo",lit(None))\
                        .withColumn("Motor",lit(None)).withColumn("Montagem",lit(None)).withColumn("Doc_Imp",lit(None)).withColumn("Id_Imp",lit(None)).withColumn("DI",lit(None)).withColumn("Data_DI",lit(None)).withColumn("SRF",lit(None)).withColumn("Data_Atual",lit(None))\
                        .withColumn("Rest1",lit(None)).withColumn("Rest2",lit(None)).withColumn("Rest3",lit(None)).withColumn("Rest4",lit(None)).withColumn("Rest_Trib",lit(None)).withColumn("Sit_Veic",lit(None))

# COMMAND ----------

# DBTITLE 1,Tratamento dos dados de 2007
#No arquivo de 2007 não possui coluna "Montadora", logo estamos adicionando
#No arquivo de 2007 também estamos renomeando as colunas
df_bronze_2007 = df_bronze_2007.withColumn("Montadora", lit(None))
df_bronze_2007 = df_bronze_2007.toDF('CÓD','Data','Chassi','Placa','Tipo_Doc','CNPJ','UF_Fat','Doc_Prop','UF','Municipio','Ano_Fabr','Ano_Mod','Marca-Modelo','Tipo','Especie','Carroceria','Num_Carroceria','Cor','Combustivel','Potencia','Cilindrada','Lugares','Cap_Carga','PBT','CMT','Proc','Sit_Chassi','Cx_cambio','Eixos','Eixo_tras','Terceiro_eixo','Motor','Montagem','Doc_Imp','Id_Imp','DI','Data_DI','SRF','Data_Atual','Rest1','Rest2','Rest3','Rest4','Rest_Trib','Sit_Veic','Montadora')

# COMMAND ----------

# DBTITLE 1,União dos dataframes
df_concatenado = (
    df_bronze_2022
    .union(df_bronze_2021)
    .union(df_bronze_2020)
    .union(df_bronze_2019)
    .union(df_bronze_2018)
    .union(df_bronze_2017)
    .union(df_bronze_2016)
    .union(df_bronze_2015)
    .union(df_bronze_2014)
    .union(df_bronze_2013)
    .union(df_bronze_2012)
    .union(df_bronze_2011)
    .union(df_bronze_2010)
    .union(df_bronze_2009)
    .union(df_bronze_2008)
    .union(df_bronze_2007)
    .union(df_bronze_2006)
)

# COMMAND ----------

# DBTITLE 1,Renomeação e Tipagem de Colunas
df_concatenado = (
    df_concatenado
    .select(
        col(df_concatenado.columns[0])          .cast("string")         .alias('ID_CODIGO'),
        col(df_concatenado.columns[1])          .cast("string")         .alias('DT_DATA'),
        col(df_concatenado.columns[2])          .cast("string")         .alias('CD_CHASSI'),
        col(df_concatenado.columns[3])          .cast("string")         .alias('CD_PLACA'),
        col(df_concatenado.columns[4])          .cast("string")         .alias('ID_DOC'),
        col(df_concatenado.columns[5])          .cast("string")         .alias('CD_CNPJ'),
        col(df_concatenado.columns[6])          .cast("string")         .alias('NM_UF_FAT'),
        col(df_concatenado.columns[7])          .cast("string")         .alias('ID_DOC_PROP'),
        col(df_concatenado.columns[8])          .cast("string")         .alias('NM_UF'),
        col(df_concatenado.columns[9])          .cast("string")         .alias('ID_MUNICIPIO'),
        col(df_concatenado.columns[10])         .cast("string")         .alias('NR_ANO_FABR'),
        col(df_concatenado.columns[11])         .cast("string")         .alias('NR_ANO_MOD'),
        col(df_concatenado.columns[12])         .cast("string")         .alias('ID_MARCA_MODELO'),
        col(df_concatenado.columns[13])         .cast("string")         .alias('ID_TIPO'),
        col(df_concatenado.columns[14])         .cast("string")         .alias('ID_ESPECIE'),
        col(df_concatenado.columns[15])         .cast("string")         .alias('ID_CARROCERIA'),
        col(df_concatenado.columns[16])         .cast("string")         .alias('NR_CARROCERIA'),
        col(df_concatenado.columns[17])         .cast("string")         .alias('ID_COR'),
        col(df_concatenado.columns[18])         .cast("string")         .alias('ID_COMBUSTIVEL'),
        col(df_concatenado.columns[19])         .cast("string")         .alias('VL_POTENCIA'),
        col(df_concatenado.columns[20])         .cast("string")         .alias('VL_CILINDRADA'),
        col(df_concatenado.columns[21])         .cast("string")         .alias('VL_LUGARES'),
        col(df_concatenado.columns[22])         .cast("string")         .alias('VL_CAP_CARGA'),
        col(df_concatenado.columns[23])         .cast("string")         .alias('VL_PESO_BRUTO'),
        col(df_concatenado.columns[24])         .cast("string")         .alias('CD_CMT'),
        col(df_concatenado.columns[25])         .cast("string")         .alias('ID_PROC'),
        col(df_concatenado.columns[26])         .cast("string")         .alias('NM_SIT_CHASSI'),
        col(df_concatenado.columns[27])         .cast("string")         .alias('NR_CAIXA_CAMBIO'),
        col(df_concatenado.columns[28])         .cast("string")         .alias('NR_EIXOS'),
        col(df_concatenado.columns[29])         .cast("string")         .alias('NM_EIXO_TRASEIRO'),
        col(df_concatenado.columns[30])         .cast("string")         .alias('NM_TERCEIRO_EIXO'),
        col(df_concatenado.columns[31])         .cast("string")         .alias('NR_MOTOR'),
        col(df_concatenado.columns[32])         .cast("string")         .alias('ID_MONTAGEM'),
        col(df_concatenado.columns[33])         .cast("string")         .alias('ID_COD_IMP'),
        col(df_concatenado.columns[34])         .cast("string")         .alias('ID_IMP'),
        col(df_concatenado.columns[35])         .cast("string")         .alias('NR_DI'),
        col(df_concatenado.columns[36])         .cast("string")         .alias('DT_DI'),
        col(df_concatenado.columns[37])         .cast("string")         .alias('NR_SRF'),
        col(df_concatenado.columns[38])         .cast("string")         .alias('DT_ATUAL'),
        col(df_concatenado.columns[39])         .cast("string")         .alias('ID_REST1'),
        col(df_concatenado.columns[40])         .cast("string")         .alias('ID_REST2'),
        col(df_concatenado.columns[41])         .cast("string")         .alias('ID_REST3'),
        col(df_concatenado.columns[42])         .cast("string")         .alias('ID_REST4'),
        col(df_concatenado.columns[43])         .cast("string")         .alias('NR_REST_TRIB'),
        col(df_concatenado.columns[44])         .cast("string")         .alias('NM_SITUACAO_VEICULO'),
        col(df_concatenado.columns[45])         .cast("string")         .alias('ID_MONTADORA')
   )
)

# COMMAND ----------

# DBTITLE 1,Gravação da tabela na camada Bronze
(
    df_concatenado
    .write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f'{bronze_catalog}.{param_schema}.{param_nome_tabela}')
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Bronze para Silver

# COMMAND ----------

# DBTITLE 1,Leitura da tabela na camada Bronze
df_bronze_silver = (
    spark
    .read
    .format("delta")
    .table(f'{bronze_catalog}.{param_schema}.{param_nome_tabela}')
)

# COMMAND ----------

# DBTITLE 1,Gravação da tabela na camada Silver
(
    df_bronze_silver
    .write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f'{silver_catalog}.{param_schema}.{param_nome_tabela}')
)
