# Databricks notebook source
# MAGIC %md
# MAGIC #Metadados gerais

# COMMAND ----------

# MAGIC %md
# MAGIC **Criado por**: Pedro Ernesto
# MAGIC
# MAGIC **Data criação**: 30/01/2024
# MAGIC
# MAGIC **Atualizado por**: Pedro Ernesto
# MAGIC
# MAGIC **Data atualização**: 13/03/2024
# MAGIC
# MAGIC **Atualizado por**: Pedro Ernesto
# MAGIC
# MAGIC **Data atualização**: 21/03/2024
# MAGIC
# MAGIC **Atualizado por**: Pedro Ernesto
# MAGIC
# MAGIC **Data atualização**: 02/04/2024
# MAGIC
# MAGIC **Atualizado por**: Bruno Jander
# MAGIC
# MAGIC **Data atualização**: 11/07/2025
# MAGIC
# MAGIC [comment]: <> (Tem que vir do negócio)
# MAGIC **Descrição do dataset/tabela/view**: 
# MAGIC
# MAGIC [comment]: # (Lineage, nome de domínio, sub-domínio, tipo de agregação, business unit: Tem que vir do negócio)
# MAGIC **Tags**:
# MAGIC
# MAGIC [comment]: # (Tem que vir do negócio)
# MAGIC **Data owner**: 
# MAGIC
# MAGIC [comment]: # (Full/Incremental/Streaming/CDC/etc)
# MAGIC **Tipo de carga**: Full
# MAGIC
# MAGIC [comment]: # (Tem que vir de sistemas)
# MAGIC **Atualização**: Anual

# COMMAND ----------

# MAGIC %md
# MAGIC #### Fontes utilizadas nesse pipeline:
# MAGIC
# MAGIC [comment]: <> (tabelas utilizadas nesse notebook)
# MAGIC
# MAGIC - bronze_catalog.planejamento_produto.flatfile_predicao_volume_segmentos
# MAGIC - silver_catalog.planejamento_produto.flatfile_predicao_volume_segmentos

# COMMAND ----------

# MAGIC %md
# MAGIC # Configurações Iniciais

# COMMAND ----------

# DBTITLE 1,Importação de bibliotecas
from os import getenv
from pyspark.sql.functions import col

# COMMAND ----------

# DBTITLE 1,Variáveis de ambiente
source_bucket_landing = getenv("param_bucket_landing")
source_bucket_bronze = getenv("param_bucket_bronze")
source_bucket_silver = getenv("param_bucket_silver")
ambiente = getenv("DATABRICKS_ENV")

# COMMAND ----------

# DBTITLE 1,Lineage de diretórios
# <database>/<sistema>/<esquema> ou <external>/<sistema>/<esquema>
# igual ao lineage do pipeline do Informatica
param_lineage = 'external/flat_file/planejamento_produto'
param_schema = "predicao_volume"
bronze_catalog = f'bronze_{ambiente}'
silver_catalog = f'silver_{ambiente}'

# Nome da tabela
param_nome_tabela = 'segmentos'

# Lineage completo
path_landing_full = "s3://" + source_bucket_landing + "/" + param_lineage + "/" + param_nome_tabela + "/full/" + param_nome_tabela + ".xlsx"
path_bronze = "s3://" + source_bucket_bronze + "/" + param_lineage + "/" + param_nome_tabela
path_silver = "s3://" + source_bucket_silver + "/" + param_lineage + "/" + param_nome_tabela

# COMMAND ----------

# MAGIC %md
# MAGIC # Landing para Bronze

# COMMAND ----------

# DBTITLE 1,Leitura do arquivo fonte na Landing
df_bronze = (
    spark
    .read
    .format("com.crealytics.spark.excel")
    .option("header", "true")
    .option("inferSchema", "true")
    .load(path_landing_full)
    )

# COMMAND ----------

# DBTITLE 1,Renomeação das Colunas
df_bronze = (
    df_bronze
    .withColumnRenamed(df_bronze.columns[0],"BRAND")
    .withColumnRenamed(df_bronze.columns[1],"MODEL")
    .withColumnRenamed(df_bronze.columns[2],"SEGMENT_FULL_NEW")
    .withColumnRenamed(df_bronze.columns[3],"PPB_CBU")
    .withColumnRenamed(df_bronze.columns[4],"BRAND_NEW")
    .withColumnRenamed(df_bronze.columns[5],"FAMILY")
    .withColumnRenamed(df_bronze.columns[6],"DETAILED_SEGMENT")
)

# COMMAND ----------

# DBTITLE 1,Gravação da tabela na camada Bronze
(
    df_bronze
    .write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f'{bronze_catalog}.{param_schema}.{param_nome_tabela}')
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Bronze para Silver

# COMMAND ----------

# DBTITLE 1,Leitura da tabela na camada Bronze
df_silver = (
    spark
    .read
    .format("delta")
    .table(f'{bronze_catalog}.{param_schema}.{param_nome_tabela}')
)

# COMMAND ----------

# DBTITLE 1,Renomeação das Colunas
df_silver = (
    df_silver
    .withColumnRenamed(df_bronze.columns[0], "NM_BRAND")
    .withColumnRenamed(df_bronze.columns[1], "NM_MODEL")
    .withColumnRenamed(df_bronze.columns[2], "NM_SEGMENT_FULL_NEW")
    .withColumnRenamed(df_bronze.columns[3], "NM_PPB_CBU")
    .withColumnRenamed(df_bronze.columns[4], "NM_BRAND_NEW")
    .withColumnRenamed(df_bronze.columns[5], "NM_FAMILY")
    .withColumnRenamed(df_bronze.columns[6], "NM_DETAILED_SEGMENT")
)

# COMMAND ----------

# DBTITLE 1,Tipagem das Colunas
df_std_bronze = (
    df_silver
    .select(
        col("NM_BRAND")                   .cast("string")        .alias("NM_BRAND"),
        col("NM_MODEL")                   .cast("string")        .alias("NM_MODEL"),
        col("NM_SEGMENT_FULL_NEW")        .cast("string")        .alias("NM_SEGMENT_FULL_NEW"),
        col("NM_PPB_CBU")                 .cast("string")        .alias("NM_PPB_CBU"),
        col("NM_BRAND_NEW")               .cast("string")        .alias("NM_BRAND_NEW"),
        col("NM_FAMILY")                  .cast("string")        .alias("NM_FAMILY"),
        col("NM_DETAILED_SEGMENT")        .cast("string")        .alias("NM_DETAILED_SEGMENT")
        )
)

# COMMAND ----------

# DBTITLE 1,Gravação da tabela na camada Silver
(
    df_std_bronze
    .write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f'{silver_catalog}.{param_schema}.{param_nome_tabela}')
)
