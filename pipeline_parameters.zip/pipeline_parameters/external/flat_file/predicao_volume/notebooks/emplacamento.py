# Databricks notebook source
# MAGIC %md
# MAGIC #Metadados gerais

# COMMAND ----------

# MAGIC %md
# MAGIC **Criado por**: Pedro Ernesto
# MAGIC
# MAGIC **Data criação**: 07/11/2023
# MAGIC
# MAGIC **Atualizado por**: Pedro Ernesto
# MAGIC
# MAGIC **Data atualização**: 26/03/2024
# MAGIC
# MAGIC **Atualizado por**: Pedro Ernesto
# MAGIC
# MAGIC **Data atualização**: 02/04/2024
# MAGIC
# MAGIC **Atualizado por**: Pedro Ernesto
# MAGIC
# MAGIC **Data atualização**: 23/04/2024
# MAGIC
# MAGIC **Atualizado por**: Bruno Jander
# MAGIC
# MAGIC **Data atualização**: 25/12/2024
# MAGIC
# MAGIC **Atualizado por**: Bruno Jander
# MAGIC
# MAGIC **Data atualização**: 10/07/2025
# MAGIC
# MAGIC [comment]: <> (Tem que vir do negócio)
# MAGIC **Descrição do dataset/tabela/view**: Tabela contendo emplacamentos de veículos, disponibilizados pela Abraciclo através de FTP.
# MAGIC
# MAGIC [comment]: # (Lineage, nome de domínio, sub-domínio, tipo de agregação, business unit: Tem que vir do negócio)
# MAGIC **Tags**:
# MAGIC
# MAGIC [comment]: # (Tem que vir do negócio)
# MAGIC **Data owner**: 
# MAGIC
# MAGIC [comment]: # (Full/Incremental/Streaming/CDC/etc)
# MAGIC **Tipo de carga**: Full
# MAGIC
# MAGIC [comment]: # (Tem que vir de sistemas)
# MAGIC **Atualização**: Diária

# COMMAND ----------

# MAGIC %md
# MAGIC #### Fontes utilizadas nesse pipeline:
# MAGIC
# MAGIC [comment]: <> (tabelas utilizadas nesse notebook)
# MAGIC
# MAGIC - bronze_catalog.planejamento_produto.flatfile_predicao_volume_emplacamento
# MAGIC - silver_catalog.planejamento_produto.flatfile_predicao_volume_emplacamento

# COMMAND ----------

# MAGIC %md
# MAGIC # Configurações Iniciais

# COMMAND ----------

# DBTITLE 1,Importação de bibliotecas
from os import getenv
from pyspark.sql.functions import input_file_name, substring, col
from pyspark.sql.types import StructType, StructField, StringType

# COMMAND ----------

# DBTITLE 1,Variáveis de ambiente
source_bucket_landing = getenv("param_bucket_landing")
source_bucket_bronze = getenv("param_bucket_bronze")
source_bucket_silver = getenv("param_bucket_silver")
ambiente = getenv("DATABRICKS_ENV")

# COMMAND ----------

# DBTITLE 1,Lineage de diretórios
# <database>/<sistema>/<esquema> ou <external>/<sistema>/<esquema>
# igual ao lineage do pipeline do Informatica
param_lineage_land = 'external/flat_file/abraciclo'
param_lineage = 'external/flat_file/planejamento_produto'
param_schema = "predicao_volume"
bronze_catalog = f'bronze_{ambiente}'
silver_catalog = f'silver_{ambiente}'

# Nome da tabela
param_nome_tabela = 'emplacamento'

# Lineage completo
path_landing_full = "s3://" + source_bucket_landing + "/" + param_lineage_land
path_bronze = "s3://" + source_bucket_bronze + "/" + param_lineage + "/" + param_nome_tabela
path_silver = "s3://" + source_bucket_silver + "/" + param_lineage + "/" + param_nome_tabela

# COMMAND ----------

# MAGIC %md
# MAGIC # Landing para Bronze

# COMMAND ----------

# DBTITLE 1,Alteração da extensão dos arquivos
def rename_files_to_csv(folder_path):
    """
    Renomeia todos os arquivos no diretório especificado (e subdiretórios), acrescentando '.csv' ao final do nome do arquivo,
    exceto para arquivos que terminam com '.xlsx', contêm 'DT' no nome, ou começam com um prefixo específico.
    """
    file_infos = dbutils.fs.ls(folder_path)
    
    for file_info in file_infos:
        file_name = file_info.path.split("/")[-1]
        
        # Se é um diretório, chamada recursiva para renomear arquivos no subdiretório
        if file_info.isDir():
            rename_files_to_csv(file_info.path)
        else:
            # Aplica a condição específica antes de renomear
            if not file_name.endswith('.xlsx') and 'DT' not in file_name and not file_name.startswith('FECHAMENTO'):
                # Verifica se o arquivo já tem a extensão .csv
                if not file_info.path.endswith('.csv'):
                    new_file_path = file_info.path + '.csv'
                    # Renomeia o arquivo
                    dbutils.fs.mv(file_info.path, new_file_path)

rename_files_to_csv(path_landing_full)

# COMMAND ----------

# DBTITLE 1,Leitura dos arquivos necessários na Landing
# Exemplo de esquema, ajuste conforme a estrutura dos seus arquivos CSV
schema = StructType([
    StructField("Coluna1", StringType(), True)
    # Adicione ou modifique os campos conforme necessário
])

# Função para listar arquivos recursivamente ajustada para filtrar somente .csv
def list_csv_files_recursively(path, dbutils):
    files = []
    items = dbutils.fs.ls(path)
    
    for item in items:
        if item.isDir():  # Se for um diretório, faz listagem recursiva
            files.extend(list_csv_files_recursively(item.path, dbutils))
        elif item.path.endswith('.csv'):  # Filtra somente arquivos .csv
            files.append(item.path)
    
    return files

file_paths = list_csv_files_recursively(path_landing_full, dbutils)

# Lê os arquivos .csv considerando o esquema definido
dfs = []
for file_path in file_paths:
    df = spark.read.option("delimiter", ";").option("header", "true").schema(schema).csv(file_path)
    df_with_file_name = df.withColumn("file_name", col("_metadata.file_path"))
    dfs.append(df_with_file_name)

if dfs:
    df_final = dfs[0]
    for df in dfs[1:]:
        df_final = df_final.unionByName(df, allowMissingColumns=True)
else:
    print("Nenhum arquivo válido encontrado.")

# COMMAND ----------

# DBTITLE 1,Extração dos dados para colunas
# Assumindo que df_final é o seu DataFrame inicial contendo uma coluna 'value'
# Certifique-se de que df_final já foi definido e carregado com os dados desejados.

# Especificações das colunas
colunas = [
    "DATA_", "CHASSI", "PLACA", "TIPO_DOC", "CNPJ", "UF_FAT", "DOC_PROP", "UF", "MUNICIPIO",
    "ANO_FABR", "ANO_MOD", "MARCA_MODELO", "TIPO", "ESPECIE", "CARROCERIA", "NUM_CARROCERIA",
    "COR", "COMBUSTIVEL", "POTENCIA", "CILINDRADA", "LUGARES", "CAP_CARGA", "PBT", "CMT",
    "PROC", "SIT_CHASSI", "CX_CAMBIO", "EIXOS", "EIXO_TRAS", "TERCEIRO_EIXO", "MOTOR",
    "MONTAGEM", "DOC_IMP", "ID_IMP", "DI", "DATA_DI", "SRF", "DATA_ATUAL", "REST1", "REST2",
    "REST3", "REST4", "REST_TRIB", "SIT_VEIC","ID_MONTADORA"
]

inicio_coluna = [
    1, 9, 30, 37, 38, 52, 54, 55, 57, 61, 65, 69, 75, 77, 79, 82, 103, 105, 107, 110, 114,
    117, 122, 127, 132, 133, 134, 155, 157, 178, 199, 220, 221, 222, 236, 246, 254, 261,
    269, 271, 273, 275, 277, 285, 9
]

fim_coluna = [
    8, 29, 36, 37, 51, 53, 54, 56, 60, 64, 68, 74, 76, 78, 81, 102, 104, 106, 109, 113, 116,
    121, 126, 131, 132, 133, 154, 156, 177, 198, 219, 220, 221, 235, 245, 253, 260, 268,
    270, 272, 274, 276, 284, 285, 11  # Ajustado para corresponder ao número de itens em 'colunas' e 'inicio_coluna'
]

# Verifica se as listas têm o mesmo tamanho
if not (len(colunas) == len(inicio_coluna) == len(fim_coluna)):
    raise ValueError("As listas 'colunas', 'inicio_coluna', e 'fim_coluna' não têm o mesmo tamanho.")

df_final_2 = df_final

# Itera sobre as colunas e os intervalos para extrair os dados
for i in range(len(colunas)):
    coluna_atual = colunas[i]
    inicio_atual = inicio_coluna[i]
    fim_atual = fim_coluna[i] - inicio_coluna[i] + 1  # Ajuste para calcular a largura correta

    df_final_2 = df_final_2.withColumn(coluna_atual, substring(col("Coluna1"), inicio_atual, fim_atual))

# COMMAND ----------

# DBTITLE 1,Filtra apenas arquivos de emplacamento
df_filtrado = df_final_2.filter(df_final_2['file_name'].like('%DN%'))

# COMMAND ----------

# DBTITLE 1,Ajuste de nomenclatura
df_metas_renamed = df_filtrado.withColumnRenamed('Coluna1', 'NM_VALUE') \
    .withColumnRenamed('file_name', 'NM_FILE_NAME') \
    .withColumnRenamed('DATA_', 'DT_DATA') \
    .withColumnRenamed('CHASSI', 'CD_CHASSI') \
    .withColumnRenamed('PLACA', 'CD_PLACA') \
    .withColumnRenamed('TIPO_DOC', 'ID_DOC') \
    .withColumnRenamed('CNPJ', 'CD_CNPJ') \
    .withColumnRenamed('UF_FAT', 'NM_UF_FAT') \
    .withColumnRenamed('DOC_PROP', 'ID_DOC_PROP') \
    .withColumnRenamed('UF', 'NM_UF') \
    .withColumnRenamed('MUNICIPIO', 'ID_MUNICIPIO') \
    .withColumnRenamed('ANO_FABR', 'NR_ANO_FABR') \
    .withColumnRenamed('ANO_MOD', 'NR_ANO_MOD') \
    .withColumnRenamed('MARCA_MODELO', 'ID_MARCA_MODELO') \
    .withColumnRenamed('TIPO', 'ID_TIPO') \
    .withColumnRenamed('ESPECIE', 'ID_ESPECIE') \
    .withColumnRenamed('CARROCERIA', 'ID_CARROCERIA')\
    .withColumnRenamed('NUM_CARROCERIA', 'NR_CARROCERIA')\
    .withColumnRenamed('COR', 'ID_COR')\
    .withColumnRenamed('COMBUSTIVEL', 'ID_COMBUSTIVEL')\
    .withColumnRenamed('POTENCIA', 'VL_POTENCIA')\
    .withColumnRenamed('CILINDRADA', 'VL_CILINDRADA')\
    .withColumnRenamed('LUGARES', 'VL_LUGARES')\
    .withColumnRenamed('CAP_CARGA', 'VL_CAP_CARGA')\
    .withColumnRenamed('PBT', 'VL_PESO_BRUTO')\
    .withColumnRenamed('CMT', 'CD_CMT')\
    .withColumnRenamed('PROC', 'ID_PROC')\
    .withColumnRenamed('SIT_CHASSI', 'NM_SIT_CHASSI')\
    .withColumnRenamed('CX_CAMBIO', 'NR_CAIXA_CAMBIO')\
    .withColumnRenamed('EIXOS', 'NR_EIXOS')\
    .withColumnRenamed('EIXO_TRAS', 'NM_EIXO_TRASEIRO')\
    .withColumnRenamed('TERCEIRO_EIXO', 'NM_TERCEIRO_EIXO')\
    .withColumnRenamed('MOTOR', 'NR_MOTOR')\
    .withColumnRenamed('MONTAGEM', 'ID_MONTAGEM')\
    .withColumnRenamed('DOC_IMP', 'ID_COD_IMP')\
    .withColumnRenamed('ID_IMP', 'ID_IMP')\
    .withColumnRenamed('DI', 'NR_DI')\
    .withColumnRenamed('DATA_DI', 'DT_DI')\
    .withColumnRenamed('SRF', 'NR_SRF')\
    .withColumnRenamed('DATA_ATUAL', 'DT_ATUAL')\
    .withColumnRenamed('REST1', 'ID_REST1')\
    .withColumnRenamed('REST2', 'ID_REST2')\
    .withColumnRenamed('REST3', 'ID_REST3')\
    .withColumnRenamed('REST4', 'ID_REST4')\
    .withColumnRenamed('REST_TRIB', 'NR_REST_TRIB')\
    .withColumnRenamed('SIT_VEIC', 'NM_SITUACAO_VEICULO')\
    .withColumnRenamed('ID_MONTADORA', 'ID_MONTADORA')

# COMMAND ----------

# DBTITLE 1,Ajuste de tipagem
df_metas_types = df_metas_renamed.withColumn('NM_VALUE', col('NM_VALUE').cast(StringType())) \
                                 .withColumn('NM_FILE_NAME', col('NM_FILE_NAME').cast(StringType()))\
                                 .withColumn('DT_DATA', col('DT_DATA').cast(StringType()))\
                                 .withColumn('CD_CHASSI', col('CD_CHASSI').cast(StringType()))\
                                 .withColumn('CD_PLACA', col('CD_PLACA').cast(StringType()))\
                                 .withColumn('ID_DOC', col('ID_DOC').cast(StringType()))\
                                 .withColumn('CD_CNPJ', col('CD_CNPJ').cast(StringType()))\
                                 .withColumn('NM_UF_FAT', col('NM_UF_FAT').cast(StringType()))\
                                 .withColumn('ID_DOC_PROP', col('ID_DOC_PROP').cast(StringType()))\
                                 .withColumn('NM_UF', col('NM_UF').cast(StringType()))\
                                 .withColumn('ID_MUNICIPIO', col('ID_MUNICIPIO').cast(StringType()))\
                                 .withColumn('NR_ANO_FABR', col('NR_ANO_FABR').cast(StringType()))\
                                 .withColumn('NR_ANO_MOD', col('NR_ANO_MOD').cast(StringType()))\
                                 .withColumn('ID_MARCA_MODELO', col('ID_MARCA_MODELO').cast(StringType()))\
                                 .withColumn('ID_TIPO', col('ID_TIPO').cast(StringType()))\
                                 .withColumn('ID_ESPECIE', col('ID_ESPECIE').cast(StringType()))\
                                 .withColumn('ID_CARROCERIA', col('ID_CARROCERIA').cast(StringType()))\
                                 .withColumn('NR_CARROCERIA', col('NR_CARROCERIA').cast(StringType()))\
                                 .withColumn('ID_COR', col('ID_COR').cast(StringType()))\
                                 .withColumn('ID_COMBUSTIVEL', col('ID_COMBUSTIVEL').cast(StringType()))\
                                 .withColumn('VL_POTENCIA', col('VL_POTENCIA').cast(StringType()))\
                                 .withColumn('VL_CILINDRADA', col('VL_CILINDRADA').cast(StringType()))\
                                 .withColumn('VL_LUGARES', col('VL_LUGARES').cast(StringType()))\
                                 .withColumn('VL_CAP_CARGA', col('VL_CAP_CARGA').cast(StringType()))\
                                 .withColumn('VL_PESO_BRUTO', col('VL_PESO_BRUTO').cast(StringType()))\
                                 .withColumn('CD_CMT', col('CD_CMT').cast(StringType()))\
                                 .withColumn('ID_PROC', col('ID_PROC').cast(StringType()))\
                                 .withColumn('NM_SIT_CHASSI', col('NM_SIT_CHASSI').cast(StringType()))\
                                 .withColumn('NR_CAIXA_CAMBIO', col('NR_CAIXA_CAMBIO').cast(StringType()))\
                                 .withColumn('NR_EIXOS', col('NR_EIXOS').cast(StringType()))\
                                 .withColumn('NM_EIXO_TRASEIRO', col('NM_EIXO_TRASEIRO').cast(StringType()))\
                                 .withColumn('NM_TERCEIRO_EIXO', col('NM_TERCEIRO_EIXO').cast(StringType()))\
                                 .withColumn('NR_MOTOR', col('NR_MOTOR').cast(StringType()))\
                                 .withColumn('ID_MONTAGEM', col('ID_MONTAGEM').cast(StringType()))\
                                 .withColumn('ID_COD_IMP', col('ID_COD_IMP').cast(StringType()))\
                                 .withColumn('ID_IMP', col('ID_IMP').cast(StringType()))\
                                 .withColumn('NR_DI', col('NR_DI').cast(StringType()))\
                                 .withColumn('DT_DI', col('DT_DI').cast(StringType()))\
                                 .withColumn('NR_SRF', col('NR_SRF').cast(StringType()))\
                                 .withColumn('DT_ATUAL', col('DT_ATUAL').cast(StringType()))\
                                 .withColumn('ID_REST1', col('ID_REST1').cast(StringType()))\
                                 .withColumn('ID_REST2', col('ID_REST2').cast(StringType()))\
                                 .withColumn('ID_REST3', col('ID_REST3').cast(StringType()))\
                                 .withColumn('ID_REST4', col('ID_REST4').cast(StringType()))\
                                 .withColumn('NR_REST_TRIB', col('NR_REST_TRIB').cast(StringType()))\
                                 .withColumn('NM_SITUACAO_VEICULO', col('NM_SITUACAO_VEICULO').cast(StringType()))\
                                 .withColumn('ID_MONTADORA', col('ID_MONTADORA').cast(StringType()))

# COMMAND ----------

# DBTITLE 1,Otimização do dataframe para gravação
df_metas_types = df_metas_types.coalesce(7)

# COMMAND ----------

# DBTITLE 1,Gravação da tabela na camada Bronze
(
    df_metas_types
    .write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f'{bronze_catalog}.{param_schema}.{param_nome_tabela}')
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Bronze para Silver

# COMMAND ----------

# DBTITLE 1,Leitura da tabela na camada Bronze
df_bronze_silver = (
    spark
    .read
    .format("delta")
    .table(f'{bronze_catalog}.{param_schema}.{param_nome_tabela}')
)

# COMMAND ----------

# DBTITLE 1,Gravação da tabela na camada Silver
(
    df_bronze_silver
    .write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f'{silver_catalog}.{param_schema}.{param_nome_tabela}')
)
