# Databricks notebook source
# DBTITLE 1,Importação de bibliotecas
from ftplib import FTP
from os import getenv, path
from datetime import date, datetime, timedelta
from re import search
import time
import socket
import ftplib
import logging

# COMMAND ----------

# DBTITLE 1,Configuração de log
logging.basicConfig(level=logging.WARNING, format='%(asctime)s - %(levelname)s - %(message)s')

# COMMAND ----------

# DBTITLE 1,Variáveis de ambiente
# Definição do ambiente de execução (DEV/HML/PROD)
ambiente = getenv("DATABRICKS_ENV").lower()

# Dados de acesso ao FTP.
ftp_host = dbutils.secrets.get(scope = "connections", key = "ftp_abraciclo_host")
ftp_user = dbutils.secrets.get(scope = "connections", key = "ftp_abraciclo_user")
ftp_passwd = dbutils.secrets.get(scope = "connections", key = "ftp_abraciclo_pass")

# COMMAND ----------

# DBTITLE 1,Lineage de diretórios
# Raiz do diretório
volume_landing = f"/Volumes/landing_{ambiente}/s3/"

# <database>/<sistema>/<esquema> ou <external>/<sistema>/<esquema>
# igual ao lineage do pipeline do Informatica
param_lineage = 'external/flat_file/abraciclo'

# COMMAND ----------

# DBTITLE 1,Parametrização de arquivos
# Prefixos de arquivo desejados
file_prefixes = ['K3249.G29822DN', 'K3249.G29822DT']

# Data de processamento do(s) arquivo(s)
today = date.today() - timedelta(days=1)

# Nomes dos meses
month_names = ['Janeiro', 'Fevereiro', 'Marco', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro']

# COMMAND ----------

# DBTITLE 1,Definição de funções
def get_directory():
    year = today.strftime('%Y')
    month = today.strftime('%m')
    month_name = month_names[int(month) - 1]
    return '/' + year + '/' + month_name + '/'

def extract_date_from_filename(filename):
    # Extrai o mês e o dia do nome do arquivo usando expressão regular
    match = search(r'(\d{4})(\d{2})(\d{2})', filename)
    if match:
        return match.group(1), match.group(2), match.group(3)
    else:
        # Se nenhuma data é encontrada, retorna a data de hoje
        return today.strftime('%Y'), today.strftime('%m'), today.strftime('%d')
    
def copy_file_to_month_folder(source_path, ftp_host):
    ftp = ftp_host
    for prefix in file_prefixes:
        logging.info(f'3.1 - Verificando arquivo com prefixo {prefix}')

        year, month, day = extract_date_from_filename(path.basename(source_path))
        try:
            month_name = month_names[int(month) - 1]
        except IndexError:
            logging.info(f'Valor de mês inválido: {month} no arquivo {source_path}')
            return False

        s3_key = f'{year}/{month_name}/{path.basename(source_path)}'
        return upload_file_to_s3(s3_key, ftp)

    logging.info(f'Sem prefixos pro arquivo: {source_path}')
    return False

#Verifica se o arquivo existe no S3
def file_exists_in_s3(s3_key):
    try:
        dbutils.fs.ls(f"{volume_landing}{s3_key}")
        return True
    except Exception:
        return False

def is_relevant_file(filename):
    # Checa se é um arquivo xlsx
    if filename.endswith('.xlsx'):
        return True

    # Checa se o arquivo começa com um dos prefixos
    for prefix in file_prefixes:
        if filename.startswith(prefix):
            return True

    # Se não for um arquivo relevante, retorna False
    return False

#Faz o upload do arquivo para o S3
def upload_file_to_s3(s3_key, ftp_host):
    ftp = ftp_host
    if not file_exists_in_s3(s3_key):
        try:
            with open(volume_landing + param_lineage + "/" + s3_key, "wb") as local_file:
                ftp.retrbinary("RETR " + "/" + s3_key, local_file.write)
                local_file.close()
                logging.info(f'Arquivo enviado para S3: {s3_key}')
                return True
        except Exception as e:
            logging.info(f'Erro no upload para S3: {e}')
            return False
    else:
        logging.info(f'O arquivo já existe no S3: {s3_key}')
        return False

#Processa os arquivos no FTP de acordo com os prefixos e iguala o FTP com o diretório do S3.
def process_files_in_folder():
    # Tentativas de conexão com o FTP
    max_retries = 5
    retries = 0
    file_found = False
    
    while retries < max_retries:
        try:
            logging.info('1 - FTP')
            with FTP(ftp_host) as ftp:
                ftp.login(user=ftp_user, passwd=ftp_passwd)

                directory_ftp = get_directory()
                logging.info(f'2 - Diretório: {directory_ftp}')
                ftp.cwd(directory_ftp)

                files_processed = 0 # Contador de arquivos processados
                
                # Processa cada arquivo no diretório
                for file in ftp.nlst():
                    if is_relevant_file(file):
                        source_path = path.join(directory_ftp, file)
                        logging.info(f'3 - Processando o arquivo: {source_path}')

                        # Se o arquivo for um xlsx (Fechamento), envia para o S3
                        if file.endswith('.xlsx'):
                            file_found = upload_file_to_s3(source_path, ftp) or file_found
                            files_processed += 1
                        else:
                            file_found = copy_file_to_month_folder(source_path, ftp) or file_found
                            files_processed += 1
                    else:
                        logging.info(f'Arquivo {file} não relevante.')
                        files_processed += 1

                if files_processed > 0:
                    logging.info(f'Processados {files_processed} arquivos.')
                    break
        
        # Tratamento de erros do FTP e socket
        except ftplib.all_errors as e:
            logging.error(f'FTP erro: {e}')
            retries += 1
            logging.info(f'Tentando reconexão ({retries}/{max_retries})...')
            time.sleep(5)  # Espera 5 segundos antes de tentar novamente

        except socket.timeout as e:
            logging.error(f'Socket timeout: {e}')
            retries += 1
            logging.info(f'Tentando reconexão ({retries}/{max_retries})...')
            time.sleep(5)  # Espera 5 segundos antes de tentar novamente

        finally:
            logging.info('Saindo do FTP')

    if files_processed == 0:
        logging.info('Nenhum arquivo relevante.')

# COMMAND ----------

# DBTITLE 1,Execução de funções
process_files_in_folder()
