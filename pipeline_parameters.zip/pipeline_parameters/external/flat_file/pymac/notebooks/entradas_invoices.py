# Databricks notebook source
# MAGIC %md
# MAGIC # Parametros

# COMMAND ----------

import os
import pyspark.sql.functions as F
from datetime import date
from pathlib import Path

# COMMAND ----------

today = date.today()

source_bucket_landing = os.getenv("param_bucket_landing") # "s3-yamaha-datalake-landing-dev"
target_bucket_bronze = os.getenv("param_bucket_bronze") # "s3-yamaha-datalake-bronze-dev"

param_nome_arquivo = f"Entradas Invoices.xlsx"

param_nome_tabela = "entradas_invoices"

param_lineage = "external/flat_file/pymac"

base_path = "/Volumes/landing_dev/s3/external/flat_file/pymac/entradas_invoices/"

path = Path(base_path)
path_arquivo = f"{path}/Entradas Invoices.xlsx"

# COMMAND ----------

env = os.getenv("DATABRICKS_ENV")

# COMMAND ----------

# MAGIC %md
# MAGIC # Leitura Arquivo Atual

# COMMAND ----------

matches = list(path.glob(f"Entradas Invoices.xlsx"))

if not matches:
    dbutils.notebook.exit(f"Sem arquivos para ler no dia {today}")

file_to_read = max(matches, key=lambda p: p.stat().st_mtime)

# COMMAND ----------

print("Lendo:", file_to_read)
df = (
    spark.read
      .format("com.crealytics.spark.excel")
      .option("header", "true")
      .option("inferSchema", "true")
      .load(str(file_to_read))
      .withColumn("file_name", F.lit(file_to_read.name))
      )

# COMMAND ----------

# MAGIC %md
# MAGIC #Criando Bronze

# COMMAND ----------

df_final = (
    df.withColumn("ingested_at", F.current_date())
)

# COMMAND ----------

(
  df_final
    .write
    .format("parquet")
    .mode("overwrite")
    .save(base_path + "/full/")
)
