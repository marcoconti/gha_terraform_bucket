SELECT
  dia AS DIA
, cota_m AS COTA_M
, encheu_vazou_cm AS ENCHEU_VAZOU_CM
, filename AS FILENAME
, ano AS ANO
, mes AS MES
, semestre  AS SEMESTRE
, data_formatada AS DATA_COTA
, _year AS ANO_PARTICIONAMENTO
, _month AS MES_PARTICIONAMENTO
FROM silver_<env>.webscraping_industrial.nivel_rio_negro