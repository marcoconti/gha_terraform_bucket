# Databricks notebook source
# MAGIC %md
# MAGIC # Bibliotecas + Parametros Globais

# COMMAND ----------

# DBTITLE 1,import bibliotecas
# Importação das bibliotecas necessárias para a execução do código
import pyspark.sql.functions as F
import requests, io, datetime as dt
import pandas as pd
from dateutil.relativedelta import relativedelta
from dateutil.parser import parse
import builtins
import os

# COMMAND ----------

dbutils.widgets.text("START_DATE", ""   ,  "Data inicial (yyyy-MM-dd)")
dbutils.widgets.text("END_DATE"  , ""   ,  "Data final   (yyyy-MM-dd, opcional)")

# COMMAND ----------

source_bucket_landing = os.getenv("param_bucket_landing")

table_loc = "/external/api/banco_central/valor_dolar/full/"

output_path = "s3://" + source_bucket_landing + "/" + table_loc

series_id  = int("10813")

start_txt  = dbutils.widgets.get("START_DATE")
end_txt    = dbutils.widgets.get("END_DATE")

# start_date = parse(start_txt).date() if start_txt else dt.date.today()
start_date = parse(start_txt).date() if start_txt else dt.date(2020,8,10)  # Marco Conti, reescrever está lógica
end_date   = parse(end_txt).date()   if end_txt   else dt.date.today()

# COMMAND ----------

# MAGIC %md
# MAGIC # Get dos Dados

# COMMAND ----------

# DBTITLE 1,funções
BASE_URL = "https://api.bcb.gov.br/dados/serie/bcdata.sgs.{}/dados"

def fetch_sgs_daily(series_id:int,
                    start:dt.date,
                    end:dt.date|None=None):
    """
    Retorna Spark DataFrame (date, value) com a série SGS diária.
    Baixa em blocos de ≤10 anos.
    """
    end  = end  or dt.date.today()
    step = dt.timedelta(days=3650)  # 10 anos

    pdf_parts = []
    bloc_start = start
    while bloc_start <= end:
        bloc_end = builtins.min(bloc_start + step, end)
        url = (
            f"{BASE_URL.format(series_id)}?formato=csv"
            f"&dataInicial={bloc_start:%d/%m/%Y}"
            f"&dataFinal={bloc_end:%d/%m/%Y}"
        )

        print(f"Fazendo get na {url}")
        
        resp = requests.get(url, timeout=30)
        resp.raise_for_status()

        pdf = (
            pd.read_csv(io.StringIO(resp.text), sep=";")
              .rename(columns={"data": "date", "valor": "value"})
        )
        pdf["date"]  = pd.to_datetime(pdf["date"], dayfirst=True).dt.date
        pdf["value"] = pd.to_numeric(pdf["value"].str.replace(",", "."), errors="coerce")
        pdf_parts.append(pdf)

        bloc_start = bloc_end + dt.timedelta(days=1)

    full_pdf = pd.concat(pdf_parts, ignore_index=True)
    return spark.createDataFrame(full_pdf)

# COMMAND ----------

# MAGIC %md
# MAGIC # Escrita dos dados na Landing

# COMMAND ----------

# DBTITLE 1,Variaveis
df_sgs = fetch_sgs_daily(series_id, start_date, end_date)

(df_sgs
 .write
 .format("parquet")
 .mode("overwrite")               # ou "append"/merge incremental
 .save(output_path)
)

