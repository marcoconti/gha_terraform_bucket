Select 
     contactid as ID_CONTATO
    ,_odata_etag as _odata_etag
    ,_accountid_value as DS_CONTA
    ,_adx_preferredlanguageid_value as CD_ADX_IDIOMA_PREFERIDO
    ,_cr638_msevtmgt_eventregistration_value as CD_CR638_MS_EVTMGT_EVENTREGISTRATION
    ,_createdby_value as CD_CRIADO_POR
    ,_createdbyexternalparty_value as CD_CRIADO_POR_EXTERNO
    ,_createdonbehalfby_value as CD_CRIADO_EM_NOME_DE
    ,_defaultpricelevelid_value as CD_NIVEL_PRECO_PADRAO
    ,_fut_lk_cidade_value as CD_FUT_LK_CIDADE
    ,_masterid_value as CD_MESTRE
    ,_modifiedby_value as CD_MODIFICADO_POR
    ,_modifiedbyexternalparty_value as CD_MODIFICADO_POR_EXTERNO
    ,_modifiedonbehalfby_value as CD_MODIFICADO_EM_NOME_DE
    ,_msa_managingpartnerid_value as CD_MS_A_SOCIO_GERENTE
    ,_msdyn_contactkpiid_value as CD_MS_DYN_CONTATO_PIID
    ,_msdyn_segmentid_value as CD_MS_DYN_SEGMENTO
    ,_msdyncrm_contactid_value as CD_MS_DYN_CONTATO
    ,_msdyncrm_customerjourneyid_value as CD_MS_DYN_CRM_JORNADA_CLIENTE
    ,_msdyncrm_emailid_value as CD_MS_DYN_CRM_EMAIL
    ,_msdyncrm_marketingformid_value as CD_MS_DYN_CRM_FORMULARIO_MARKETING
    ,_msdyncrm_marketingpageid_value as CD_MS_DYN_CRM_PAGINA_MARKETING
    ,_msdyncrm_segmentmemberid_value as CD_MS_DYN_CRM_MEMBRO_SEGMENTO
    ,_msdynmkt_customerjourneyid_value as CD_MS_DYN_MKT_JORNADA_CLIENTE
    ,_msdynmkt_emailid_value as CD_MS_DYN_MKT_EMAIL
    ,_msdynmkt_marketingformid_value as CD_MS_DYN_MKT_FORMULARIO_MARKETING
    ,_msevtmgt_contactid_value as CD_MS_EVTMGT_CONTATO
    ,_msevtmgt_originatingeventid_value as CD_MS_EVTMGT_EVENTO_DE_ORIGEM
    ,_msgdpr_consentchangesourceformid_value as CD_MS_GDPR_FORMULARIO_ALTERACAO_CONSENTIMENTO
    ,_msgdpr_gdprparentid_value as CD_MS_GDPR_MATRIZ_GDPR
    ,_originatingleadid_value as CD_LEAD_DE_ORIGEM
    ,_ownerid_value as CD_PROPRIETARIO
    ,_owningbusinessunit_value as CD_UNIDADE_NEGOCIO_PROPRIETARIA
    ,_owningteam_value as CD_EQUIPE_PROPRIETARIA
    ,_owninguser_value as CD_USUARIO_PROPRIETARIO
    ,_parent_contactid_value as CD_RESPONSAVEL_CONTATO1
    ,_parentcontactid_value as CD_RESPONSAVEL_CONTATO2
    ,_parentcustomerid_value as CD_RESPONSAVEL_CLIENTE
    ,_preferredequipmentid_value as CD_EQUIPAMENTO_PREFERIDO
    ,_preferredserviceid_value as CD_SERVICO_PREFERIDO
    ,_preferredsystemuserid_value as CD_USUARIO_DE_SISTEMA_PREFERIDO
    ,_slaid_value as CD_SLA
    ,_slainvokedid_value as CD_SLA_INVOCADO
    ,_transactioncurrencyid_value as CD_MOEDA_DE_TRANSACAO
    ,accountrolecode as CD_FUNCAO_CONTA
    ,address1_addressid as CD_ENDERECO1
    ,address1_addresstypecode as CD_ENDERECO1_TIPO
    ,address1_city as NM_ENDERECO1_CIDADE
    ,address1_composite as DS_ENDERECO1_COMPOSTO
    ,address1_country as NM_ENDERECO1_PAIS
    ,address1_county as NM_ENDERECO1_DISTRITO
    ,address1_fax as NR_ENDERECO1_FAX
    ,address1_freighttermscode as CD_ENDERECO1_CONDICOES_FRETE
    ,address1_latitude as NR_ENDERECO1_LATITUDE
    ,address1_longitude as NR_ENDERECO1_LONGITUDE
    ,address1_line1 as NM_ENDERECO1_LOGRADOURO
    ,address1_line2 as NR_ENDERECO1_NUMERO
    ,address1_line3 as NM_ENDERECO1_BAIRRO
    ,address1_name as DS_ENDERECO1_NOME
    ,address1_postalcode as NR_ENDERECO1_CEP
    ,address1_postofficebox as DS_ENDERECO1_CAIXA_POSTAL
    ,address1_primarycontactname as NM_ENDERECO1_PRIMEIRO_CONTATO
    ,address1_shippingmethodcode as CD_ENDERECO1_METODO_ENVIO
    ,address1_stateorprovince as DS_ENDERECO1_ESTADO
    ,address1_telephone1 as NR_ENDERECO1_TELEFONE1
    ,address1_telephone2 as NR_ENDERECO1_TELEFONE2
    ,address1_telephone3 as NR_ENDERECO1_TELEFONE3
    ,address1_upszone as DS_ENDERECO1_ZONA_UPS
    ,address1_utcoffset as DS_ENDERECO1_UTC_OFFSET
    ,address2_addressid as CD_ENDERECO2
    ,address2_addresstypecode as CD_ENDERECO2_TIPO
    ,address2_city as NM_ENDERECO2_CIDADE
    ,address2_composite as DS_ENDERECO2_COMPOSTO
    ,address2_country as NM_ENDERECO2_PAIS
    ,address2_county as NM_ENDERECO2_DISTRITO
    ,address2_fax as NR_ENDERECO2_FAX
    ,address2_freighttermscode as CD_ENDERECO2_CONDICOES_FRETE
    ,address2_latitude as NR_ENDERECO2_LATITUDE
    ,address2_longitude as NR_ENDERECO2_LONGITUDE
    ,address2_line1 as NM_ENDERECO2_LOGRADOURO
    ,address2_line2 as NR_ENDERECO2_NUMERO
    ,address2_line3 as NM_ENDERECO2_BAIRRO
    ,address2_name as DS_ENDERECO2_NOME
    ,address2_postalcode as NR_ENDERECO2_CEP
    ,address2_postofficebox as DS_ENDERECO2_CAIXA_POSTAL
    ,address2_primarycontactname as NM_ENDERECO2_PRIMEIRO_CONTATO
    ,address2_shippingmethodcode as CD_ENDERECO2_METODO_ENVIO
    ,address2_stateorprovince as DS_ENDERECO2_ESTADO
    ,address2_telephone1 as NR_ENDERECO2_TELEFONE1
    ,address2_telephone2 as NR_ENDERECO2_TELEFONE2
    ,address2_telephone3 as NR_ENDERECO2_TELEFONE3
    ,address2_upszone as DS_ENDERECO2_ZONA_UPS
    ,address2_utcoffset as DS_ENDERECO2_UTC_OFFSET
    ,address3_addressid as CD_ENDERECO3
    ,address3_addresstypecode as CD_ENDERECO3_TIPO
    ,address3_city as NM_ENDERECO3_CIDADE
    ,address3_composite as DS_ENDERECO3_COMPOSTO
    ,address3_country as NM_ENDERECO3_PAIS
    ,address3_county as NM_ENDERECO3_DISTRITO
    ,address3_fax as NR_ENDERECO3_FAX
    ,address3_freighttermscode as CD_ENDERECO3_CONDICOES_FRETE
    ,address3_latitude as NR_ENDERECO3_LATITUDE
    ,address3_longitude as NR_ENDERECO3_LONGITUDE
    ,address3_line1 as NM_ENDERECO3_LOGRADOURO
    ,address3_line2 as NR_ENDERECO3_NUMERO
    ,address3_line3 as NM_ENDERECO3_BAIRRO
    ,address3_name as DS_ENDERECO3_NOME
    ,address3_postalcode as NR_ENDERECO3_CEP
    ,address3_postofficebox as DS_ENDERECO3_CAIXA_POSTAL
    ,address3_primarycontactname as NM_ENDERECO3_PRIMEIRO_CONTATO
    ,address3_shippingmethodcode as CD_ENDERECO3_METODO_ENVIO
    ,address3_stateorprovince as DS_ENDERECO3_ESTADO
    ,address3_telephone1 as NR_ENDERECO3_TELEFONE1
    ,address3_telephone2 as NR_ENDERECO3_TELEFONE2
    ,address3_telephone3 as NR_ENDERECO3_TELEFONE3
    ,address3_upszone as DS_ENDERECO3_ZONA_UPS
    ,address3_utcoffset as DS_ENDERECO3_UTC_OFFSET
    ,cast(adx_confirmremovepassword as boolean) as FL_ADX_CONFIRMACAO_REMOCAO_SENHA
    ,adx_createdbyipaddress as DS_ADX_CRIADO_POR_IP
    ,adx_createdbyusername as NM_ADX_CRIADO_POR_USUARIO
    ,cast(adx_identity_accessfailedcount as int) as QT_ADX_IDENTIDADE_FALHA_DE_ACESSO
    ,cast(adx_identity_emailaddress1confirmed as boolean) as FL_ADX_IDENTIDADE_EMAIL1_CONFIRMADO
    ,adx_identity_lastsuccessfullogin as DS_ADX_IDENTIDADE_ULTIMO_LOGIN
    ,cast(adx_identity_locallogindisabled as boolean) as FL_ADX_IDENTIDADE_LOGIN_LOCAL_DESABILITADO
    ,cast(adx_identity_lockoutenabled as boolean) as FL_ADX_IDENTIDADE_BLOQUEIO_HABILITADO
    ,adx_identity_lockoutenddate as DS_ADX_IDENTIDADE_DATA_TERMINO_BLOQUEIO
    ,cast(adx_identity_logonenabled as boolean) as FL_ADX_IDENTIDADE_LOGIN_HABILITADO
    ,cast(adx_identity_mobilephoneconfirmed as boolean) as FL_ADX_IDENTIDADE_TELEFONE_CELULAR_CONFIRMADO
    ,adx_identity_newpassword as DS_ADX_IDENTIDADE_NOVA_SENHA
    ,adx_identity_passwordhash as DS_ADX_IDENTIDADE_HASH_DE_SENHA
    ,adx_identity_securitystamp as CD_ADX_IDENTIDADE_SELO_DE_SEGURANCA
    ,cast(adx_identity_twofactorenabled as boolean) as FL_ADX_IDENTIDADE_MFA_HABILITADO
    ,adx_identity_username as NM_ADX_IDENTIDADE_USUARIO
    ,adx_modifiedbyipaddress as DS_ADX_MODIFICADO_POR_IP
    ,adx_modifiedbyusername as NM_ADX_MODIFICADO_POR_USUARIO
    ,adx_organizationname as NM_ADX_ORGANIZACAO
    ,adx_portalinvitationcode as CD_ADX_CONVITE_PORTAL
    ,adx_portalinvitationurl as DS_ADX_CONVITE_PORTAL_URL
    ,adx_preferredlcid as DS_ADX_LC_PREFERIDO
    ,cast(adx_profilealert as boolean) as FL_ADX_ALERTA_PERFIL
    ,adx_profilealertdate as DS_ADX_ALERTA_PERFIL_DATA
    ,adx_profilealertinstructions as DS_ADX_ALERTA_PERFIL_INSTRUCOES
    ,cast(adx_profileisanonymous as boolean) as FL_ADX_PERFIL_ANONIMO
    ,adx_profilelastactivity as DS_ADX_PERFIL_ULTIMA_ATIVIDADE
    ,adx_profilemodifiedon as DS_ADX_PERFIL_MODIFICADO_EM
    ,adx_publicprofilecopy as DS_ADX_PERFIL_PUBLICO_COPIA
    ,adx_timezone as DS_ADX_TIMEZONE
    ,aging30 as DS_AGING_30
    ,aging30_base as DS_AGING_30_BASE
    ,aging60 as DS_AGING_60
    ,aging60_base as DS_AGING_60_BASE
    ,aging90 as DS_AGING_90
    ,aging90_base as DS_AGING_90_BASE
    ,anniversary as DS_ANIVERSARIO
    ,annualincome as DS_RENDA_ANUAL
    ,annualincome_base as DS_RENDA_ANUAL_BASE
    ,assistantname as NM_ASSISTENTE
    ,assistantphone as NR_TELEFONE_ASSISTENTE
    ,cast(birthdate as date) as DT_NASCIMENTO
	,business2 as DS_BUSINESS2
    ,businesscard as DS_CARTAO_VISITA
    ,businesscardattributes as DS_ATRIBUTOS_CARTAO_VISITA
    ,callback as DS_CALLBACK
    ,childrensnames as NM_CRIANCAS
    ,company as NM_EMPRESA
    ,cast(createdon as timestamp) as DH_CRIADO_EM
	,creditlimit as DS_LIMITE_CREDITO
    ,creditlimit_base as DS_LIMITE_CREDITO_BASE
    ,cast(creditonhold as boolean) as FL_CREDITO_EM_ESPERA
    ,customersizecode as CD_TAMANHO_CLIENTE
    ,customertypecode as CD_TIPO_CLIENTE
    ,department as DS_DEPARTAMENTO
    ,description as DS_DETALHAMENTO
    ,cast(donotbulkemail as boolean) as FL_NAO_ENVIO_EMAIL_EM_MASSA
    ,cast(donotbulkpostalmail as boolean) as FL_NAO_ENVIO_CORRESPONDENCIA_EM_MASSA
    ,cast(donotemail as boolean) as FL_NAO_ENVIO_EMAIL
    ,cast(donotfax as boolean) as FL_NAO_ENVIO_FAX
    ,cast(donotphone as boolean) as FL_NAO_LIGAR
    ,cast(donotpostalmail as boolean) as FL_NAO_ENVIO_CORRESPONDENCIA
    ,cast(donotsendmm as boolean) as FL_NAO_ENVIO_MM
    ,educationcode as CD_EDUCACAO
    ,emailaddress1 as DS_EMAIL1
    ,emailaddress2 as DS_EMAIL2
    ,emailaddress3 as DS_EMAIL3
    ,employeeid as CD_FUNCIONARIO
    ,entityimage as DS_ENTIDADE_IMAGEM
    ,entityimage_timestamp as DS_ENTIDADE_TIMESTAMP
    ,entityimage_url as DS_ENTIDADE_URL
    ,entityimageid as CD_ENTIDADE_IMAGEM
    ,exchangerate as DS_TAXA_CAMBIO
    ,externaluseridentifier as CD_USUARIO_EXTERNO
    ,familystatuscode as CD_SITUACAO_FAMILIAR
    ,fax as DS_FAX
    ,firstname as NM_PRIMEIRO_NOME
    ,cast(followemail as boolean) as FL_SEGUIR_EMAIL
    ,ftpsiteurl as DS_FTP_SITE_URL
    ,fullname as NM_NOME_COMPLETO
    ,cast(fut_cel_mobilephone_valido as boolean) as FL_FUT_TELEFONE_CELULAR_VALIDO
    ,fut_cidadesmanual as DS_FUT_CIDADE_MANUAL
    ,cast(fut_comerc_telephone2_valido as boolean) as FL_FUT_TELEFONE_COMERCIAL2_VALIDO
    ,fut_ddd_mobilephone as NR_FUT_TELEFONE_CELULAR
    ,fut_ddd_telephone1 as NR_FUT_TELEFONE1
    ,fut_ddd_telephone2 as NR_FUT_TELEFONE2
    ,fut_ddd_telephone3 as NR_FUT_TELEFONE3
    ,cast(fut_email2_valido as boolean) as FL_FUT_EMAIL2_VALIDO
    ,cast(fut_email3_valido as boolean) as FL_FUT_EMAIL3_VALIDO
    ,cast(fut_email_princ_valido as boolean) as FL_FUT_EMAIL_PRINCIPAL_VALIDO
    ,cast(fut_endereco_valido as boolean) as FL_FUT_ENDERECO_VALIDO
    ,cast(fut_outro_telephone3_valido as boolean) as FL_FUT_OUTRO_TELEFONE3_VALIDO
    ,cast(fut_res_telephone1_valido as boolean) as FL_FUT_RES_TELEFONE1_VALIDO
    ,gendercode as CD_GENERO
    ,governmentid as CD_DO_GOVERNO
    ,haschildrencode as CD_TEM_FILHOS
    ,home2 as DS_CASA2
	,cast(importsequencenumber as int) as NR_SEQUENCIA_IMPORTACAO
	,inove_address1_line4 as DS_INOVE_ENDERECO1_LINHA4
    ,cast(isbackofficecustomer as boolean) as FL_CLIENTE_BACKOFFICE
    ,jobtitle as NM_CARGO
    ,lastname as NM_SOBRENOME
    ,lastonholdtime as DS_ULTIMO_TEMPO_DE_ESPERA
    ,lastusedincampaign as DS_ULTIMO_USO_NA_CAMPANHA
    ,leadsourcecode as CD_LEAD_SOURCE_CODE
    ,managername as NM_GERENTE
    ,managerphone as NR_TELEFONE_GERENTE
    ,cast(marketingonly as boolean) as FL_APENAS_MARKETING
    ,cast(merged as boolean) as FL_MERGED
    ,middlename as NM_NOME_DO_MEIO
    ,mobilephone as NR_TELEFONE_CELULAR
    ,cast(modifiedon as timestamp) as DH_MODIFICADO_EM
    ,msdyn_decisioninfluencetag as DS_MS_DYN_TAG_INFLUENCIA_DECISAO
    ,cast(msdyn_disablewebtracking as boolean) as FL_MS_DYN_DESATIVAR_RASTREIO_WEB
    ,cast(msdyn_gdproptout as boolean) as FL_MS_DYN_GDPR_EXCLUSAO
    ,cast(msdyn_isassistantinorgchart as boolean) as FL_MS_DYN_ASSISTENTE_EM_ORGANOGRAMA
    ,cast(msdyn_isminor as boolean) as FL_MS_DYN_MENOR_DE_IDADE
    ,cast(msdyn_isminorwithparentalconsent as boolean) as FL_MS_DYN_MENOR_DE_IDADE_COM_CONSENTIMENTO_PAIS
    ,msdyn_orgchangestatus as DS_MS_DYN_STATUS_ALTERACAO_ORGANIZACAO
    ,msdyn_portaltermsagreementdate as DS_MS_DYN_DATA_ACEITE_TERMOS_NO_PORTAL
    ,msdyn_primarytimezone as DS_MS_DYN_TIMEZONE_PRINCIPAL
    ,msdyncrm_insights_placeholder as DS_MS_DYN_CRM_ESPACO_RESERVADO_INSIGHTS
    ,msdyncrm_marketingformsubmissiondateprecise as DS_MS_DYN_CRM_DATA_ENVIO_FORMULARIO_MARKETING
    ,cast(msdyncrm_rememberme as boolean) as FL_MS_DYN_CRM_REMEMBER_ME
    ,msevtmgt_aadobjectid as CD_MS_EVTMGT_OBJETO_AAD
    ,cast(msgdpr_donottrack as boolean) as FL_MS_GDPR_NAO_RASTREIE
    ,msgdpr_gdprconsent as CD_MS_GDPR_CONSENTIMENTO
    ,cast(msgdpr_gdprischild as boolean) as FL_MS_GDPR_CRIANCA
    ,mspp_userpreferredlcid as DS_MS_PP_USUARIO_LC_PREFERIDO
    ,new_origemdocontato2 as CD_NOVA_ORIGEM_DO_CONTATO2
    ,nickname as NM_APELIDO
    ,cast(numberofchildren as int) as QT_CRIANCAS
	,onholdtime as DS_TEMPO_DE_ESPERA
    ,overriddencreatedon as DS_SUBSTITUIDO_CRIADO_EM
    ,pager as DS_PAGER
    ,cast(participatesinworkflow as boolean) as FL_PARTICIPA_NO_WORKFLOW
    ,paymenttermscode as CD_CONDICOES_DE_PAGAMENTO
    ,preferredappointmentdaycode as CD_DIA_DE_AGENDAMENTO_PREFERIDO
    ,preferredappointmenttimecode as CD_HORARIO_DE_AGENDAMENTO_PREFERIDO
    ,preferredcontactmethodcode as CD_METODO_DE_CONTATO_PREFERIDO
    ,processid as CD_PROCESSO
    ,salutation as DS_SAUDACAO
    ,shippingmethodcode as CD_METODO_ENVIO
    ,spousesname as NM_CONJUGE
    ,stageid as DS_ESTAGIO
    ,statecode as CD_ESTADO
    ,statuscode as CD_STATUS
    ,subscriptionid as CD_SUBSCRICAO
    ,suffix as DS_SUFIXO
    ,teamsfollowed as DS_TEAMS_FOLLOWED
    ,telephone1 as NR_TELEFONE1
    ,telephone2 as NR_TELEFONE2
    ,telephone3 as NR_TELEFONE3
    ,territorycode as CD_TERRITORIO
    ,timespentbymeonemailandmeetings as DS_TEMPO_GASTO_POR_MIM_EM_EMAIL_E_REUNIOES
    ,timezoneruleversionnumber as DS_TIMEZONE_RULE_VERSION_NUMBER
    ,traversedpath as DS_CAMINHO_PERCORRIDO
    ,utcconversiontimezonecode as DS_UTC_TIMEZONE_CONVERSION_CODE
    ,cast(versionnumber as int) as NR_VERSAO
    ,websiteurl as DS_URL_SITE
    ,ymdb_cartilhadocliente as DS_YMDB_CARTILHA_DO_CLIENTE
    ,ymdb_cartilhadocliente_name as DS_YMDB_CARTILHA_DO_CLIENTE_NOME
    ,cast(ymdb_consentimento as boolean) as FL_YMDB_CONSENTIMENTO
    ,cast(ymdb_contatoyamalog as boolean) as FL_YMDB_CONTATO_YAMALOG
    ,ymdb_cpf as DC_YMDB_CPF
    ,ymdb_cpflgpd as DC_YMDB_CPF_LGPD
    ,cast(ymdb_data_vigencia_clube_beneficios as timestamp) as DH_YMDB_VIGENCIA_CLUBE_BENEFICIOS
    ,ymdb_dataaniversario as DS_YMDB_DATA_ANIVERSARIO
    ,cast(ymdb_datacadastroapp as timestamp) as DH_YMDB_CADASTRO_APP
    ,cast(ymdb_datadeanonimizacao as timestamp) as DH_YMDB_ANONIMIZACAO
    ,cast(ymdb_dataorigemcrm360 as timestamp) as DH_YMDB_ORIGEM_CRM360
    ,ymdb_datasolicitacaoanonimizacao as DS_YMDB_DATA_SOLICITACAO_ANONIMIZACAO
    ,cast(ymdb_dataultimaalteracao as timestamp) as DH_YMDB_ULTIMA_ALTERACAO
    ,cast(ymdb_dataultimaatualizaocrm360 as timestamp) as DH_YMDB_ULTIMA_ATUALIZACAO_CRM360
    ,cast(ymdb_elegivel_clube_beneficios as boolean) as FL_YMDB_ELEGIVEL_CLUBE_BENEFICIOS
    ,ymdb_enviodebrindes as CD_YMDB_ENVIO_DE_BRINDES
    ,ymdb_gestordeleadsanonimizacao as DS_GESTOR_DE_LEADS_ANONIMIZACAO
    ,ymdb_id_responsys as CD_YMDB_RESPONSYS
    ,ymdb_id_user_app as CD_YMDB_USUARIO_APLICATIVO
    ,ymdb_id_usuario_arc as CD_YMDB_USUARIO_ARC
    ,ymdb_nacionalidade as CD_YMDB_NACIONALIDADE
    ,ymdb_nomedacampanha as CD_YMDB_NOME_CAMPANHA
    ,ymdb_origemdocontato as CD_YMDB_ORIGEM_CONTATO
    ,ymdb_origemdocontatocrm360 as CD_YMDB_ORIGEM_CONTATO_CRM360
    ,cast(ymdb_pontos as int) as QT_YMDB_PONTOS
    ,cast(ymdb_primeiro_acesso as timestamp) as DH_YMDB_PRIMEIRO_ACESSO
    ,ymdb_renda as DS_YMDB_RENDA
    ,ymdb_rg as DC_YMDB_RG
    ,ymdb_statusanonimizacaogestorleads as DS_YMDB_STATUS_ANONIMIZACAO_GESTOR_DE_LEADS
    ,ymdb_uf as CD_YMDB_UF
    ,ymdb_ultimaatualizaocrm360 as CD_YMDB_ULTIMA_ATUALIZACAO_CRM360
    ,yomifirstname as NM_YOMI_PRIMEIRO_NOME
    ,yomimiddlename as NM_YOMI_NOME_DO_MEIO
    ,yomilastname as NM_YOMI_SOBRENOME
    ,yomifullname as NM_YOMI_NOME_COMPLETO
    ,cast(_YEAR as int) as NR_ANO
    ,cast(_MONTH as int) as NR_MES
 from bronze_<env>.dynamics_365_sales_lifetime_customer.contact
