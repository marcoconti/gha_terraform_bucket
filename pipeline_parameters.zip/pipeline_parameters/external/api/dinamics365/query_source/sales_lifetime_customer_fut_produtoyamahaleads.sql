Select fut_produtoyamahaleadsid as ID_FUT_PRODUTO_YAMAHA_LEADS
      ,_odata_etag as DS_ODATA_ETAG
      ,_createdby_value as CD_CRIADO_POR
      ,_createdonbehalfby_value as CD_CRIADO_EM_NOME_DE
      ,_modifiedby_value as CD_MODIFICADO_POR
      ,_modifiedonbehalfby_value as CD_MODIFICADO_EM_NOME_DE
      ,_ownerid_value as CD_PROPRIETARIO
      ,_owningbusinessunit_value as CD_UNIDADE_NEGOCIO_PROPRIETARIA
      ,_owningteam_value as CD_EQUIPE_PROPRIETARIA
      ,_owninguser_value as CD_USUARIO_PROPRIETARIO
      ,_ymdb_areadenegocioid_value as CD_YMDB_AREA_DE_NEGOCIO
      ,_ymdb_segmentodeprodutoid_value as CD_YMDB_SEGMENTO_DE_PRODUTO
      ,_ymdb_tipodeprodutoid_value as CD_YMDB_TIPO_DE_PRODUTO
	  ,cast(createdon as timestamp) as DH_CRIADO_EM
	  ,fut_name as NM_FUT_PRODUTO
      ,fut_st_familiapsi as DS_FUT_ST_FAMILIA_PSI
      ,fut_st_identificacao as DS_FUT_ST_IDENTIFICACAO
      ,fut_st_segmento as DS_FUT_ST_SEGMENTO
      ,fut_st_tipo as DS_FUT_ST_TIPO
      ,fut_st_tipodeproduto as DS_FUT_ST_TIPODEPRODUTO
      ,fut_st_urlargumentosvendas as DS_FUT_ST_URL_ARGUMENTOS_VENDAS
      ,fut_st_urlimagenswhatsapp as DS_FUT_ST_URL_IMAGENS_WHATSAPP
      ,fut_st_urlnormalfoto as DS_FUT_ST_URL_FOTO_NORMAL
      ,fut_st_urlsmallfotopequena as DS_FUT_ST_URL_FOTO_PEQUENA
      ,importsequencenumber as NR_IMPORT_SEQUENCE
      ,inove_urlyoutube as DS_INOVE_URL_YOUTUBE
      ,cast(modifiedon as timestamp) as DH_MODIFICADO_EM
      ,overriddencreatedon as DS_SUBSTITUIDO_CRIADO_EM
      ,statecode as CD_ESTADO
      ,statuscode as CD_STATUS
      ,timezoneruleversionnumber as NR_TIMEZONE_RULE_VERSION
      ,utcconversiontimezonecode as CD_UTC_CONVERSION_TIMEZONE
      ,versionnumber as NR_VERSION
      ,ymdb_ds_categoria as DS_YMDB_CATEGORIA
      ,ymdb_ds_linha as DS_YMDB_LINHA
      ,ymdb_prod_origem as DS_YMDB_PROD_ORIGEM
      ,ymdb_situacao as DS_YMDB_SITUACAO
  from bronze_<env>.dynamics_365_sales_lifetime_customer.fut_produtoyamahaleads