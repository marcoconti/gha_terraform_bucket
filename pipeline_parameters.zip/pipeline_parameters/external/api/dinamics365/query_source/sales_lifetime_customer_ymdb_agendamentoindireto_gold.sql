Select ymdb_npspesquisaenviada
    ,ymdb_dataenvionpssms
    ,ymdb_npspesquisarespondida
    ,stageid as id_stageid
    ,actualend
    ,community as cd_community_value
    ,modifiedon
    ,prioritycode as cd_prioritycode_value
    ,onholdtime
    ,deliverylastattemptedon
    ,_owninguser_value as cd_owninguser_value
    ,_modifiedonbehalfby_value as cd_modifiedonbehalfby_value
    ,ismapiprivate
    ,description
    ,ymdb_currentkm
    ,isbilled
    ,_odata_etag
    ,statuscode
    ,instancetypecode as cd_instancetypecode_value
    ,_ownerid_value as id_ownerid_value
    ,ymdb_qtddias
    ,timezoneruleversionnumber
    ,_owningteam_value as cd_owningteam_value
    ,ymdb_chassi
    ,overriddencreatedon
    ,_slainvokedid_value as id_slainvokedid_value
    ,_owningbusinessunit_value as cd_owningbusinessunit_value
    ,createdon
    ,ymdb_idagendamentobluclub
    ,_transactioncurrencyid_value as id_transactioncurrencyid_value
    ,exchangeweblink
    ,descriptionblobid_name as id_descriptionblobid
    ,processid as id_processid
    ,_createdby_value as cd_createdby_value
    ,lastonholdtime
    ,ymdb_servicedate
    ,isworkflowcreated
    ,exchangeitemid as id_exchangeitemid
    ,ymdb_cnpjconcessionaria
    ,deliveryprioritycode as cd_deliveryprioritycode_value
    ,activitytypecode
    ,ymdb_npspesquisaenviadaporemail
    ,sortdate
    ,senton
    ,ymdb_npspesquisaenviadaporsms
    ,statecode
    ,descriptionblobid
    ,traversedpath
    ,actualdurationminutes
    ,scheduledend
    ,ymdb_placa
    ,formattedscheduledend
    ,versionnumber
    ,actualstart
    ,scheduleddurationminutes
    ,_ymdb_cliente_value as cd_ymdb_cliente_value
    ,ymdb_dataregistro
    ,ymdb_motorcyclemodel
    ,ymdb_status as cd_ymdb_status_value
    ,ymdb_servicetype
    ,ymdb_period as cd_ymdb_period_value
    ,subject
    ,leftvoicemail
    ,_modifiedby_value as cd_modifiedby_value
    ,activityid as id_activityid
    ,ymdb_datarespostanps
    ,ymdb_yearmodel
    ,ymdb_datacicloencerrado
    ,_sendermailboxid_value as id_sendermailboxid_value
    ,postponeactivityprocessinguntil
    ,importsequencenumber
    ,exchangerate
    ,ymdb_canalderesposta
    ,seriesid as id_seriesid
    ,ymdb_linkdapesquisacustomervoice
    ,activityadditionalparams
    ,scheduledstart
    ,utcconversiontimezonecode
    ,_serviceid_value as id_serviceid_value
    ,_regardingobjectid_value as id_regardingobjectid_value
    ,formattedscheduledstart
    ,_createdonbehalfby_value as cd_createdonbehalfby_value
    ,isregularactivity
    ,ymdb_dataenvionpsemail
    ,cr638_kmatual
    ,_ymdb_trade_name_value as nm_ymdb_trade_name_value
    ,_slaid_value as id_slaid_value
  from silver_<env>.dynamics_365_sales_lifetime_customer.ymdb_agendamentoindireto