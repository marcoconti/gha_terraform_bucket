# Databricks notebook source
# MAGIC %md ### Import bibliotecas

# COMMAND ----------

import os
import pyspark.sql.functions as F
from delta.tables import *
from pyspark.sql.window import Window

# COMMAND ----------

spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", "false")

# COMMAND ----------

# MAGIC %md ### Optimization Method

# COMMAND ----------

def optimize_delta_table(table_name):
    """
        @param: IN table_path
        Run optimization commands and old snapshots
        Full load
    """
    deltaTable = DeltaTable.forName(spark, table_name)
    deltaTable.vacuum(24)
    deltaTable.optimize().executeCompaction()
    print('Delta table optimized.') 

def get_env():
    return os.environ.get("DATABRICKS_ENV")

# COMMAND ----------

# MAGIC %md ### Variáveis

# COMMAND ----------

env     = get_env()
catalog = f"gold_{env.lower()}"
schema  = "comercial_planejamento_comercial"
table   = "ft_incidente"

# COMMAND ----------

# MAGIC %md ### Leitura tabelas

# COMMAND ----------

drop_cols = ["_odata_etag", "_hash", "_ingestionin"]
df_incident = \
    (spark.sql(f"""Select * 
                    from silver_{env}.dynamics_365_sales_lifetime_customer.incident""")
          .drop(*drop_cols))


# COMMAND ----------

# MAGIC %md #### Criar colunas ID_CONTACTID e ID_CALENDARIO

# COMMAND ----------

df_incident = (
    df_incident
        .withColumnRenamed('_ymdb_contatodocliente_value', 'id_contactid')
)

# Renomear coluna 
renames_cols = {"_ymdb_contatodocliente_value": "id_contactid"}
select_exprs = []
select_exprs = [f" {c} as {renames_cols.get(c, c)} " for c in df_incident.columns ]
df_incident = df_incident.selectExpr(*select_exprs)

# Criar coluna
select_exprs = df_incident.columns
# id_calendario = \
#     "concat(year(createdon) * 10000, month(createdon) * 100, day(createdon)) as id_calendario"

id_calendario = \
    "date_format(createdon,'yyyyMMdd') as id_calendario"

select_exprs.append(id_calendario)
df_incident = df_incident.selectExpr(select_exprs)


# COMMAND ----------

# MAGIC %md ### Tratamentos adicionais para os indicadores de "Qtd de cliente que já abriu algo no SAC "

# COMMAND ----------

TIPO_RESOLUCAO_MAP = {
    969830004: 'ENCAMINHADO PROTOCOLO DE OUVIDORIA',
    100000004: 'OPÇÕES DE DATAS YAMALOG',
    100000003: 'AGENDA SUGERIDA DO CLIENTE',
    1        : 'PERGUNTA',
    969830005: 'CONSULTA',
    969830000: 'CRÍTICA',
    969830001: 'DENÚNCIA',
    100000000: 'ELOGIO',
    969830007: 'ENGANO',
    969830003: 'INFORMAÇÃO',
    969830002: 'PROTOCOLO ABERTO',
    969830006: 'PROTOCOLO ENCAMINHADO',
    2        : 'RECLAMAÇÃO',
    100000002: 'SERVIÇO',
    3        : 'SOLICITAÇÃO',
    100000001: 'SUGESTÃO',
}

# Transforma os tipos de resolução em um map para usar no withColumn a seguir
mapping_expr = F.create_map([F.lit(x) for kv in TIPO_RESOLUCAO_MAP.items() for x in kv])

df_incident = \
    (df_incident.withColumn("tipo_resolucao"
                           ,F.coalesce(mapping_expr[F.col("casetypecode")]
                                      ,F.lit("NÃO MAPEADO"))))


# COMMAND ----------

FATOR_CONVERSAO_DIA = (60 * 60 * 24)

windowSpec  = Window.partitionBy("_contactid_value").orderBy("createdon")

df_incident = (
    df_incident
        .withColumns({'dt_incidente_anterior': F.lag('createdon', 1).over(windowSpec)
                     ,'nr_diferenca_incidente_atual_e_anterior_dias':  
                        F.round((F.col("createdon").cast("long") - F.col('dt_incidente_anterior').cast("long")) / FATOR_CONVERSAO_DIA).cast("int")}
        )
        .drop('dt_incidente_anterior')
)

# COMMAND ----------

# MAGIC %md ### Writing silver -> gold

# COMMAND ----------

print(f"Persiste os dados do DF na tabela {catalog}.{schema}.{table}", end="")
(
    df_incident
        .write
        .partitionBy("_year","_month")
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(f"{catalog}.{schema}.{table}")
)
print(" - Concluido com sucesso")

# COMMAND ----------

# optimization Gold layer
optimize_delta_table(f'{catalog}.{schema}.{table}')