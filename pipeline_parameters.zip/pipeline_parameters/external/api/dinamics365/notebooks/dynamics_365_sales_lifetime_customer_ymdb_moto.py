# Databricks notebook source
# MAGIC %md
# MAGIC - `Criado por:`  
# MAGIC - `Data Criação:` 
# MAGIC - `Atualizado por:` Caio Francisco 
# MAGIC - `Data Atualização:`07-11-2024
# MAGIC - `Atualizado por:` Marco Conti 
# MAGIC - `Data Atualização:`21-07-2025

# COMMAND ----------

# DBTITLE 1,import bibliotecas
# Importação das bibliotecas necessárias para a execução do código
import os
from pyspark.sql.functions import *
from pyspark.sql.types import *
from delta.tables import *
from cryptography.fernet import Fernet
import requests
import json
import urllib.parse
from datetime import date, datetime, timedelta
import time

# COMMAND ----------

# DBTITLE 1,funções
def get_refresh_headers():
    """
    Atualiza o token da api dynamics
    """
    my_dv_accessToken = get_access_token(
        tenant_id=my_ad_tenant, client_id=my_dv_clientId, client_secret=my_dv_secret
    )
    # Headers
    headers = {
        "Authorization": f"Bearer {my_dv_accessToken}",
        "Accept": "application/json",
        "Content-Type": "application/json; charset=utf-8",
        "OData-MaxVersion": "4.0",
        "OData-Version": "4.0",
        "Prefer": "odata.maxpagesize=50000"
    }
    return headers

def get_access_token(tenant_id, client_id, client_secret):
    # Set the token endpoint URL and the request payload
    token_endpoint_url = (
        f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"
    )
    payload = {
        "grant_type": "client_credentials",
        "client_id": client_id,
        "client_secret": client_secret,
        "scope": f"https://{my_dv_orgName}.crm2.dynamics.com/.default",  # IMPORTANT. The proper key is dependant upon this scope matching your dataverse url/.default
    }

    # Make the POST request to the token endpoint
    response = requests.post(token_endpoint_url, data=payload)
    print(f'\nheader Atualizado -> {response}')
    # Extract the access token from the response
    response_json = response.json()
    access_token = response_json["access_token"]

    return access_token

def get_api_response(endpoint, headers):
    """
    Checa se o codigo da requisicao é 200, se positivo retorna os dados.
    caso contrário, tenta novamente até 3 vezes. se mesmo assim não retornar 200, 
    retorna uma exceção e para o processo.
    """

    attempts = 0
    max_attempts = 3
    
    while attempts < max_attempts:
        response = requests.get(endpoint, headers=headers)
        
        if response.status_code == 200:
            print(f'\nRequisicao bem sucedida -> {response.status_code} \n')
            return response
        else:
            print(f"Erro na requisição, status code: {response.status_code}. Tentando novamente...")
            attempts += 1
            time.sleep(1)  # Espera 1 segundo antes de tentar novamente
    
    raise Exception("Falha ao obter uma resposta bem-sucedida após 3 tentativas.")

def write_landing_data(dataframe, target_path, method):
    # evitar small files, estava gerando vários arquivos de < 1mb
    dataframe = dataframe.coalesce(1)

    (dataframe
        .write
        .format("parquet")
        .mode(method)
        .save(target_path))

def read_json_data(json_list):
    json_keys = set().union(*(item.keys() for item in json_list))
    schema = StructType([StructField(key, StringType(), True) for key in json_keys])
    for item in json_list:
        for key in json_keys:
            val = item.get(key)
            item[key] = str(val) if val is not None else None

    df = spark.createDataFrame(json_list, schema=schema)
    return df

def load_api_data(endpoint, headers, target_path):
    _response = get_api_response(endpoint, headers)

    print(f'start load data - [{datetime.now()}]')

    data = None
    if "@odata.nextLink" in _response.json():
        print('Multi-parte')
        list_data = _response.json()["value"]

        if len(list_data) > 0:
            data = read_json_data(list_data)

        contador = 0
        while "@odata.nextLink" in _response.json():
            # Append the data returned by the endpoint to the list
            # Request the odata.nextLink URL
            if contador == 50:
                headers=get_refresh_headers()
                contador = 0
                print(f'header atualizado -> [{datetime.now()}]')

            _response = requests.get(_response.json()["@odata.nextLink"], headers=headers)
            list_data = _response.json()["value"]

            if len(list_data) > 0:
                data_aux  = read_json_data(list_data)
                data.union(data_aux)
            
            contador = contador + 1
    else:
        list_data = _response.json()["value"]
        if len(list_data) > 0:
            data = read_json_data(list_data)

    write_landing_data(data, target_path, 'overwrite')
    
    print(f'end data load - [{datetime.now()}]')


# COMMAND ----------

# DBTITLE 1,Variaveis
# <database>/<sistema>/<esquema> ou <external>/<sistema>/<esquema>
# igual ao lineage do pipeline do Informatica
param_lineage = 'external/api/dynamics365/lifetime_customer'

# Nome da tabela
param_nome_tabela = 'ymdb_moto'
param_nome_objeto_api = 'ymdb_motos'

# Get env values
source_bucket_landing = os.getenv("param_bucket_landing")

path_landing = f's3://{source_bucket_landing}/{param_lineage}/{param_nome_tabela}'

# parametros api
my_dv_orgName  = dbutils.secrets.get(scope='connections', key='dynamics365_sales_dv_orgName')
my_dv_clientId = dbutils.secrets.get(scope='connections', key='dynamics365_sales_dv_clientId')
my_dv_secret   = dbutils.secrets.get(scope='connections', key='dynamics365_sales_dv_secret')
my_ad_tenant   = dbutils.secrets.get(scope='connections', key='dynamics365_sales_dv_tenant')

"""
consulta com filtro de data
https://{my_dv_orgName}.crm2.dynamics.com/api/data/v9.2/{param_nome_objeto_api}?$filter=createdon ge 2024-01-01
"""

#requisicoes para api
endpoint = f'https://{my_dv_orgName}.crm2.dynamics.com/api/data/v9.2/{param_nome_objeto_api}'
headers =get_refresh_headers()

# COMMAND ----------

load_api_data(endpoint, headers, path_landing)