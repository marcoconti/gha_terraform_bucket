# Databricks notebook source
# DBTITLE 1,Importação das bibliotecas necessárias para a execução do código
import os, time
from pyspark.sql.functions import *
from pyspark.sql.types import *
from delta.tables import *

# COMMAND ----------

# DBTITLE 1,Método é função utilizados durante o processamento
def get_env():
    env = os.environ.get("DATABRICKS_ENV")
    return env.lower()

# COMMAND ----------

# DBTITLE 1,Variáveis
env = get_env()

source_bucket_landing   = f'/Volumes/landing_{env}/s3/'
param_lineage_landing   = 'external/fileshareyamaha/lifetime_customer/'

bronze_catalog          = f"bronze_{env.lower()}"
silver_catalog          = f"silver_{env.lower()}"
schema                  = "dynamics_365_sales_lifetime_customer"
table                   = "ret_campanha"
nome_arquivo            = 'RET_Campanha_30_09_2023.xlsx'

path_landing_full       =  source_bucket_landing + param_lineage_landing + table + "/full/" + nome_arquivo

# COMMAND ----------

# DBTITLE 1,Lê arquivo Excel e trata colunas
df_ret_campanha_bronze = (
    spark.read
         .format("com.crealytics.spark.excel")
         .option("header", "true")
         .option("inferSchema", "true")
         .load(path_landing_full)
    .select(
        col("TIPO DE REGISTRO").alias("TIPO_REGISTRO"),
        col("SEQUÊNCIA DO RELATÓRIO").alias("SEQUENCIA_RELATORIO"),
        "CHASSI",
        "CNPJ",
        col("TIPO CHASSI").alias("TIPO_CHASSI"),
        col("UF LICENCIAMENTO").alias("UF_LICENCIAMENTO"),
        col("UF PLACA").alias("UF_PLACA"),
        "PLACA",
        "RENAVAN",
        col("ANO FABRICAÇÃO").alias("ANO_FABRICACAO"),
        col("ANO MODELO").alias("ANO_MODELO"),
        col("TIPO GRAVAME").alias("TIPO_GRAVAME"),
        col("CÓDIGO AGENTE").alias("CODIGO_AGENTE"),
        col("NOME DO AGENTE").alias("NOME_AGENTE"),
        col("CNPJ DO AGENTE").alias("CNPJ_AGENTE"),
        col("NOME FINANCIADO").alias("NOME_FINANCIADO"),
        col("CPF CNPJ FINANCIADO").alias("CPF_CNPJ_FINANCIADO"),
        col("STATUS GRAVAME").alias("STATUS_GRAVAME"),
        col("Nº CONTRATO").alias("NRO_CONTRATO"),
        col("DATA CONTRATO").alias("DATA_CONTRATO"),
        "PRAZO",
        col("DATA INCLUSAO GRAVAME").alias("DATA_INCLUSAO_GRAVAME"),
        col("DATA FECHAMENTO GRAVAME").alias("DATA_FECHAMENTO_GRAVAME"),
        col("DATA EMISSÃO DOCTO").alias("DATA_EMISSAO_DOCTO"),
        col("INFORMANTE GRAVAME").alias("INFORMANTE_GRAVAME"),
        col("Nº GRAVAME").alias("NRO_GRAVAME"),
        col("TIPO DO DOCTO DO FINANCIADO").alias("TIPO_DOCTO_FINANCIADO")
    )
)

# COMMAND ----------

# DBTITLE 1,Persiste os dados do Excel na Bronze - ret_campanha

print(f"Persiste os dados do DF na camada Bronze na tabela {bronze_catalog}.{schema}.{table}", end="")
(
    df_ret_campanha_bronze
        .write
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(f"{bronze_catalog}.{schema}.{table}")
)
print(" - Concluido com sucesso")

# COMMAND ----------

# DBTITLE 1,Renomear colunas e deduplicar registros
renames_cols = \
    {'CHASSI': 'NR_CHASSI'
    ,'ANO_FABRICACAO': 'DT_ANO_FABRICACAO'
    ,'ANO_MODELO': 'DT_ANO_MODELO'
    ,'NRO_CONTRATO': 'NR_NRO_CONTRATO'
    ,'UF_PLACA': 'DS_UF_PLACA'
    ,'PLACA': 'DS_PLACA'
    ,'RENAVAN': 'NR_RENAVAN' 
    ,'NOME_FINANCIADO': 'NM_NOME_FINANCIADO'
    ,'CPF_CNPJ_FINANCIADO': 'DC_CPF_CNPJ_FINANCIADO'
    ,'NRO_GRAVAME': 'DS_NRO_GRAVAME'}

# Renomear as colunas 
select_exprs = []
select_exprs = [f" {c} as {renames_cols.get(c, c)} " for c in df_ret_campanha_bronze.columns ]
df_ret_campanha_silver = df_ret_campanha_bronze.selectExpr(*select_exprs)

# Remover duplicidades
df_ret_campanha_silver = df_ret_campanha_silver.dropDuplicates()

# COMMAND ----------

# DBTITLE 1,Anonimizar dados sensíveis
# Adiciona uma semente para dificultar o decode do sha2
timestamp = time.time()
seed = "seed_" + str((int(timestamp) ^ (int(timestamp) << 1)) % 10000000)

df_ret_campanha_silver = (
    df_ret_campanha_silver
        .withColumns({"DS_UF_PLACA": when( length(col("DS_UF_PLACA")) > 0, sha2(concat(col("DS_UF_PLACA"), lit(seed)), 256))
                     ,"DS_PLACA": when( length(col("DS_PLACA")) > 0, sha2(concat(col("DS_PLACA"), lit(seed)), 256))
                     ,"NR_RENAVAN": when( length(col("NR_RENAVAN")) > 0, sha2(concat(col("NR_RENAVAN"), lit(seed)), 256))
                     ,"NM_NOME_FINANCIADO": when( length(col("NM_NOME_FINANCIADO")) > 0, sha2(concat(col("NM_NOME_FINANCIADO"), lit(seed)), 256))
                     ,"DC_CPF_CNPJ_FINANCIADO": when( length(col("DC_CPF_CNPJ_FINANCIADO")) > 0, sha2(concat(col("DC_CPF_CNPJ_FINANCIADO"), lit(seed)), 256))
                     ,"DS_NRO_GRAVAME": when( length(col("DS_NRO_GRAVAME")) > 0, sha2(concat(col("DS_NRO_GRAVAME"), lit(seed)), 256))
                     })
    )


# COMMAND ----------

# DBTITLE 1,Persiste os dados na camada Silver
print(f"Persiste os dados do DF na camada Bronze na tabela {silver_catalog}.{schema}.{table}", end="")
(
    df_ret_campanha_silver
        .write
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(f"{silver_catalog}.{schema}.{table}")
)
print(" - Concluido com sucesso")