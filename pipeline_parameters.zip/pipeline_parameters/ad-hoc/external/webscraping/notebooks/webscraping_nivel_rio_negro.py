# Databricks notebook source
# - Criado por: Wagner Cavalcante  
# - Data Criação: 05-05-2025 
# - Atualizado por: Wagner Cavalcante 
# - Data Atualização: 11-07-2025

# Este notebook tem o objetivo de realizar a raspagem das informações referentes ao nível do Rio Negro diariamente

# COMMAND ----------

import requests
from bs4 import BeautifulSoup
from datetime import datetime, timedelta
import unicodedata
import os
import boto3
import json
from pyspark.sql.functions import *
from pyspark.sql.types import *
from delta.tables import *
from pyspark.sql import SparkSession
from pyspark.sql.window import Window
from pyspark.sql.functions import col, lit
from pyspark.sql.utils import AnalysisException

import pandas as pd
import pyarrow  # Para o engine do Parquet

# COMMAND ----------

# Configuração do bucket S3
s3_client = boto3.client("s3")

# Nome da tabela
table_name = 'nivel_rio_negro'

# Linhagem da tabela seguindo padrao informatica
param_lineage = 'external/webscrap/planejamento_controle_producao_pcp/nivel_rio_negro/'
param_land_lineage = 'external/webscrap/planejamento_controle_producao_pcp/nivel_rio_negro/'
schema = '_'.join(param_lineage.split('/')[:-1])

# Get env values
source_bucket_landing = os.getenv("param_bucket_landing")

# COMMAND ----------

# Função para normalizar texto (remover acentos, deixar minúsculo)
def normalize_text(text):
    return unicodedata.normalize("NFKD", text).encode("ASCII", "ignore").decode("utf-8").lower().strip()

# Lista com os meses em português (sem acento no "marco")
meses_pt = [
    "janeiro", "fevereiro", "marco", "abril", "maio", "junho",
    "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"]

# Obter o nome do mês atual
current_month = meses_pt[datetime.now().month - 1]    

# COMMAND ----------

# URL do site
url = "https://portodemanaus.com.br/nivel-do-rio-negro/"

# Cabeçalhos da requisição para simular um navegador
headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36"
}

# Realizar a requisição HTTP para o site
response = requests.get(url, headers=headers)

if response.status_code == 200:
    soup = BeautifulSoup(response.content, "html.parser")
    blocks = soup.find_all("div", class_="elementor-element")
    
    # Variável para armazenar a tabela do mês atual
    #arquivo_final = "nivel_rio_negro"  # Nome fixo do arquivo
    s3_file_path = f"{param_land_lineage}"
    tabela_encontrada = False
    
    # Iterar sobre os blocos e parar ao encontrar a primeira tabela válida do mês atual
    for i, block in enumerate(blocks, start=1):
        title = block.find("span", class_="elementor-icon-list-text")
        table = block.find("table")
        
        if title and table:
            titulo_completo = title.get_text(strip=True)
            titulo_normalizado = normalize_text(titulo_completo)
            mes_normalizado = normalize_text(current_month)
            
            if mes_normalizado not in titulo_normalizado:
                continue  # Ignorar títulos que não correspondem ao mês atual
            
            # Extrair conteúdo da tabela
            rows = table.find_all("tr")
            if rows:
                data_list = []
                headers = [col.get_text(strip=True) for col in rows[0].find_all(["th", "td"])]
                
                for row in rows[1:]:  # Pular o cabeçalho
                    cols = row.find_all(["th", "td"])
                    values = [col.get_text(strip=True) for col in cols]
                    row_data = dict(zip(headers, values))
                    
                    # Dicionário para renomear campos (se necessário)
                    field_mapping = {
                        # Exemplo: 'nome_original': 'nome_novo'
                        'Dia': 'dia',
                        'Cota (m)': 'cota_m',
                        'Encheu/ Vazou (cm)': 'encheu_vazou_cm',
                        'mes': 'mes',
                        'ano': 'ano',
                        'semestre': 'semestre',
                        'filename': 'filename'
                    }
                    
                    # Aplicar renomeação dos campos
                    renamed_data = {}
                    for old_key, value in row_data.items():
                        new_key = field_mapping.get(old_key, old_key)  # Usar novo nome se existir, senão manter original
                        renamed_data[new_key] = value
                    
                    # Adicionar mês, ano, semestre, path e nome do arquivo
                    mes_atual = datetime.now().month
                    renamed_data['mes'] = f"{mes_atual:02d}"
                    renamed_data['ano'] = datetime.now().year
                    renamed_data['semestre'] = 1 if mes_atual <= 6 else 2
                    renamed_data['filename'] = f"s3://{source_bucket_landing}/{s3_file_path}"
                    renamed_data['last_update'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    
                    data_list.append(renamed_data)
                
                # Criar DataFrame do Pandas
                df = pd.DataFrame(data_list)
                
                # Conversão de tipos de dados (opcional, mas recomendado para Parquet)
                # Você pode ajustar os tipos conforme necessário
                if 'dia' in df.columns:
                    df['dia'] = pd.to_numeric(df['dia'], errors='coerce')
                if 'cota_m' in df.columns:
                    df['cota_m'] = pd.to_numeric(df['cota_m'], errors='coerce')
                if 'encheu_vazou_cm' in df.columns:
                    df['encheu_vazou_cm'] = pd.to_numeric(df['encheu_vazou_cm'], errors='coerce')
                if 'ano' in df.columns:
                    df['ano'] = pd.to_numeric(df['ano'], errors='coerce')
                if 'semestre' in df.columns:
                    df['semestre'] = pd.to_numeric(df['semestre'], errors='coerce')
                if 'last_update' in df.columns:
                    df['last_update'] = pd.to_datetime(df['last_update'], errors='coerce')
                
                # Salvar no S3 usando diferentes abordagens
                # Abordagem 1: Usando Spark DataFrame (recomendado no Databricks)
                try:
                    # Converter pandas DataFrame para Spark DataFrame
                    spark_df = spark.createDataFrame(df)
                    
                    # Salvar no S3 com modo append para manter histórico
                    s3_full_path = f"s3a://{source_bucket_landing}/{s3_file_path}"

                    spark_df = spark_df \
                        .withColumn("dia", lpad(col("dia"), 2, "0")) \
                        .withColumn("data_formatada", concat(col("ano"), col("mes"), col("dia"))) \
                        .withColumn("data_formatada", to_date(col("data_formatada"), "yyyyMMdd")) \
                        .dropDuplicates(["data_formatada"])

                    # Coleta as datas únicas das partições a serem sobrescritas
                    datas_particao = [row["data_formatada"].strftime("%Y-%m-%d") for row in spark_df.select("data_formatada").distinct().collect()]
                    datas_str = ",".join([f"'{d}'" for d in datas_particao])

                    spark_df.write \
                        .mode("overwrite") \
                        .option("replaceWhere", f"data_formatada IN ({datas_str})")  \
                        .partitionBy("data_formatada") \
                        .parquet(s3_full_path)
                    
                    print(f"Dados adicionados ao arquivo Parquet no S3: s3://{source_bucket_landing}/{s3_file_path}")
                    
                except Exception as e:
                    print(f"Erro ao salvar com Spark: {e}")
                    
                    # Abordagem 2: Fallback usando DBFS com append manual
                    temp_dir = "/FileStore/shared_uploads/tmp"
                    temp_file_path = f"{temp_dir}/{arquivo_final}"
                    s3_full_path = f"s3a://{source_bucket_landing}/{s3_file_path}"
                    
                    # Criar diretório temporário se não existir
                    try:
                        dbutils.fs.mkdirs(temp_dir)
                    except:
                        pass  # Diretório já existe
                    
                    # Verificar se o arquivo já existe no S3
                    try:
                        # Tentar ler o arquivo existente
                        existing_df = pd.read_parquet(s3_full_path)
                        # Concatenar com os novos dados
                        combined_df = pd.concat([existing_df, df], ignore_index=True)
                        # Remover duplicatas se necessário (baseado em colunas chave)
                        # combined_df = combined_df.drop_duplicates(subset=['dia', 'mes', 'ano'], keep='last')
                    except:
                        # Se arquivo não existir, usar apenas os dados novos
                        combined_df = df
                    
                    # Escrever o DataFrame combinado como Parquet no DBFS temporário
                    combined_df.to_parquet(temp_file_path, engine='pyarrow', compression='snappy', index=False)
                    
                    # Copiar o arquivo do DBFS para o S3
                    dbutils.fs.cp(temp_file_path, s3_full_path)
                    
                    print(f"Dados adicionados ao arquivo Parquet no S3: s3://{source_bucket_landing}/{s3_file_path}")
                    
                    # Limpar o arquivo temporário do DBFS
                    dbutils.fs.rm(temp_file_path)
                
                tabela_encontrada = True
                break  # Para o loop após encontrar a primeira tabela do mês atual
    
    if not tabela_encontrada:
        print("Nenhuma tabela do mês atual foi encontrada.")
else:
    print(f"Erro ao acessar o site: {response.status_code}")
