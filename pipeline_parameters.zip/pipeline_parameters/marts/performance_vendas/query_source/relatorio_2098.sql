select
  REPLACE(REPLACE(o412285.CNPJ, '.', ''), '.', '') as CNPJ,
  o471515.MC_DESCRIPTION as CATEGORIA,
  o471515.PLANEJADOR,
  o471515.CATEGORIA_PRECO,
  o412285.CNPJ as CNPJ_CPF,
  o412285.ESTADO,
  o412285.GRUPO_GE,
  o412285.ITEM,
  o412285.NOME_CLIENTE,
  o412285.NOTA_FISCAL,
  o412285.NUMERO_ORDEM as PEDIDO,
  o412285.PRIORIDADE_ENTREGA,
  o412285.REGIAO,
  o412285.SUB_REGIAO,
  o412285.TIPO,
  o412285.TIPO_ORG,
  o412285.CIDADE,
  o412285.PL,
  o412285.VOLUME,
  o412285.TIPO_FRETE,
  o412285.TIPO_FISCAL_ITEM,
  SUM(o412285.SEGURO) as SEGURO,
  SUM(o412285.FRETE) as FRETE,
  SUM(NVL(o412285.VL_DEVOLVIDO, 0)) as VL_DEVOLVIDO,
  SUM(NVL(o412285.QT_DEVOLVIDO, 0)) as QT_DEVOLVIDO,
  SUM(o412285.VL_FCP) as VL_FCP,
  SUM(NVL(o412285.QT_FATURADO, 0)) as QT_FATURADO,
  SUM(NVL(o412285.VL_CANC, 0)) as VL_CANC,
  SUM(NVL(o412285.QT_CANC, 0)) as QT_CANC,
  SUM(NVL(o412285.VL_RET, 0)) as VL_RET,
  SUM(NVL(o412285.QT_RET, 0)) as QT_RET,
  SUM(NVL(o412285.VL_SEP, 0)) as VL_SEP,
  SUM(NVL(o412285.QT_SEP, 0)) as QT_SEP,
  SUM(NVL(o412285.VL_AE, 0)) as VL_AE,
  SUM(NVL(o412285.QT_AE, 0)) as QT_AE,
  SUM(NVL(o412285.VL_BO, 0)) as VL_BO,
  SUM(NVL(o412285.QT_BO, 0)) as QT_BO,
  SUM(NVL(o412285.VL_PEDIDO, 0)) as VL_PEDIDO,
  SUM(NVL(o412285.QT_PEDIDO, 0)) as QT_PEDIDO,
  (SUM(NVL(o412285.VL_FATURADO, 0))) -(SUM(NVL(o412285.VL_ICMS, 0))) -(SUM(NVL(o412285.VL_IPI, 0))) - o412285.VL_FCP as VL_LIQUIDO,
  (SUM(NVL(o412285.VL_FATURADO, 0))) -(SUM(NVL(o412285.VL_ICMS, 0))) as VL_SEM_ICMS_ST,
  SUM(NVL(o412285.VL_ICMS, 0)) as VL_ICMS_ST,
  (SUM(NVL(o412285.VL_FATURADO, 0))) -(SUM(NVL(o412285.VL_IPI, 0))) as VL_SEM_IPI,
  SUM(NVL(o412285.VL_IPI, 0)) as VL_IPI,
  SUM(NVL(o412285.VL_FATURADO, 0)) as VL_FATURADO,
  MAX(
    CASE
      WHEN NVL(o412285.REG, 0) = 2 THEN (o412285.DATA_SEL)
      ELSE TO_DATE(NULL, 'dd/mm/yyyy')
    END
  ) as DATA_FATURAMENTO,
  CAST(MIN(
    CASE
      WHEN NVL(o412285.REG, 0) IN (1, 2)
      AND (o412285.DATA_PEDIDO) IS NOT NULL THEN (o412285.DATA_PEDIDO)
      ELSE NULL
    END
  ) AS DATE) as DATA_PEDIDO
from
  (
    (
      /* Pedido */
      WITH sq_grupo_ge AS (
        SELECT
          max(
            T.customer_number || ' - ' || T.customer_name
          ) grupo,
          party.PARTY_ID
        FROM
          silver_<env>.ebs_apps.hz_cust_acct_relate_all REL
          join silver_<env>.ebs_apps.hz_cust_accounts CUST on REL.RELATED_CUST_ACCOUNT_ID = CUST.CUST_ACCOUNT_ID
          join silver_<env>.ebs_apps.hz_parties PARTY on CUST.PARTY_ID = PARTY.PARTY_ID
          join silver_<env>.ebs_apps.ar_lookups L on L.LOOKUP_CODE = REL.RELATIONSHIP_TYPE
          join silver_<env>.ebs_apps.ym_ra_customers_v T on REL.CUST_ACCOUNT_ID = T.customer_ID
          join silver_<env>.ebs_apps.ym_ra_customers_v V on PARTY.PARTY_ID = V.party_ID
        WHERE
          REL.ORG_ID = 85
          AND L.LOOKUP_TYPE = 'RELATIONSHIP_TYPE'
          AND REL.STATUS = 'A'
          AND REL.CUST_ACCT_RELATE_ID > 0
          and T.customer_number like 'GE%'
        group by
          party.PARTY_ID
      )
      select
        1 reg,
        cast(oh.order_number as string) numero_ordem,
        rc.CUSTOMER_NAME nome_cliente,
        decode(
          ol.FOB_POINT_CODE,
          'SEL',
          'Vendedor',
          'CIF',
          'Vendedor',
          'BUY',
          'Comprador',
          'FOB',
          'Comprador',
          'FCA',
          'Exportação',
          'CPT',
          'Exportação',
          'CIP',
          'Exportação'
        ) tipo_frete,
        sq_gg.grupo grupo_ge,
        cast(oh.order_number as string) order_number,
        ol.LINE_NUMBER,
        ol.SHIPMENT_NUMBER,
        oh.ordered_date data_sel,
        oh.creation_date data_pedido,
        oh.flow_status_code status,
        ol.ORDERED_ITEM item,
        wdd.REQUESTED_QUANTITY qt_pedido,
        ol.UNIT_SELLING_PRICE * wdd.REQUESTED_QUANTITY vl_pedido,case
          when ohh.HEADER_ID is not null then 0
          else decode(
            nvl(wda.RELEASED_STATUS, ' '),
            'B',
            nvl(wdd.REQUESTED_QUANTITY, 0),
            0
          )
        end qt_bo,case
          when ohh.HEADER_ID is not null then 0
          else decode(
            nvl(wda.RELEASED_STATUS, ' '),
            'B',
            nvl(wdd.REQUESTED_QUANTITY, 0),
            0
          ) * ol.UNIT_SELLING_PRICE
        end vl_bo,case
          when ohh.HEADER_ID is not null then 0
          else decode(
            nvl(wda.RELEASED_STATUS, ' '),
            'R',
            nvl(wdd.REQUESTED_QUANTITY, 0),
            0
          )
        end qt_ae,case
          when ohh.HEADER_ID is not null then 0
          else decode(
            nvl(wda.RELEASED_STATUS, ' '),
            'R',
            nvl(wdd.REQUESTED_QUANTITY, 0),
            0
          ) * ol.UNIT_SELLING_PRICE
        end vl_ae,
        decode(
          nvl(wda.RELEASED_STATUS, ' '),
          'Y',
          nvl(wdd.REQUESTED_QUANTITY, 0),
          0
        ) + decode(
          nvl(wda.RELEASED_STATUS, ' '),
          'S',
          nvl(wdd.REQUESTED_QUANTITY, 0),
          0
        ) qt_sep,(
          decode(
            nvl(wda.RELEASED_STATUS, ' '),
            'Y',
            nvl(wdd.REQUESTED_QUANTITY, 0),
            0
          ) * ol.UNIT_SELLING_PRICE
        ) + (
          decode(
            nvl(wda.RELEASED_STATUS, ' '),
            'S',
            nvl(wdd.REQUESTED_QUANTITY, 0),
            0
          ) * ol.UNIT_SELLING_PRICE
        ) vl_sep,
        decode(
          ohh.HEADER_ID,
          null,
          0,
          decode(
            ohh.HOLD_RELEASE_ID,
            null,
            nvl(wdd.REQUESTED_QUANTITY, 0),
            0
          )
        ) qt_ret,
        decode(
          ohh.HEADER_ID,
          null,
          0,
          decode(
            ohh.HOLD_RELEASE_ID,
            null,
            nvl(wdd.REQUESTED_QUANTITY, 0),
            0
          )
        ) * ol.UNIT_SELLING_PRICE vl_ret,
        decode(
          ol.FLOW_STATUS_CODE,
          'CANCELLED',
          nvl(wdd.CANCELLED_QUANTITY, 0),
          0
        ) qt_canc,
        decode(
          ol.FLOW_STATUS_CODE,
          'CANCELLED',
          nvl(wdd.CANCELLED_QUANTITY, 0),
          0
        ) * ol.UNIT_SELLING_PRICE vl_canc,
        0 qt_faturado,
        0 vl_faturado,
        0 qt_devolvido,
        0 vl_devolvido,
        0 vl_ipi,
        0 vl_icms,
        0 vl_fcp,
        decode(
          raa.global_attribute3,
          null,
          null,
          substr(lpad(raa.global_attribute3, 9, 0), 2, 2) || '.' || substr(lpad(raa.global_attribute3, 9, 0), 4, 3) || '.' || substr(lpad(raa.global_attribute3, 9, 0), 7, 3) || '/' || raa.global_attribute4 || '-' || raa.global_attribute5
        ) CNPJ,
        raa.city cidade,
        raa.state estado,
        rt.segment1 Regiao,
        rt.segment2 Sub_regiao,(
          select
            max(flv.MEANING)
          from
            silver_<env>.ebs_applsys.fnd_lookup_types flt
            join silver_<env>.ebs_apps.fnd_lookup_values flv on flt.LOOKUP_TYPE = flv.LOOKUP_TYPE
            and flt.APPLICATION_ID = flv.VIEW_APPLICATION_ID
          Where
            flv.LANGUAGE = 'PTB'
            and flv.SOURCE_LANG = 'PTB'
            and flt.LOOKUP_TYPE = 'SHIPMENT_PRIORITY'
            And flv.ENABLED_FLAG = 'Y'
            and flv.LOOKUP_CODE = nvl(
              OL.SHIPMENT_PRIORITY_CODE,
              OH.shipment_priority_code
            )
        ) prioridade_entrega,
        rc.CUSTOMER_TYPE Tipo_Org,(
          select
            max(ffvt.DESCRIPTION) ri_transaction
          from
            silver_<env>.ebs_apps.fnd_flex_values_tl ffvt
            join silver_<env>.ebs_apps.fnd_flex_values ffv on ffv.FLEX_VALUE_SET_ID = ffvt.FLEX_VALUE_ID
            join silver_<env>.ebs_apps.fnd_flex_value_sets ffvs on ffv.FLEX_VALUE_SET_ID = ffvs.FLEX_VALUE_SET_ID
          where
            ffv.ENABLED_FLAG = 'Y'
            and ffvt.LANGUAGE = 'PTB'
            and ffvs.FLEX_VALUE_SET_NAME = 'YM_AR_TIPO_CLIENTE'
            and ffvt.FLEX_VALUE_MEANING = PS.ATTRIBUTE3
        ) TIPO,(
          select
            max(rcta.TRX_NUMBER)
          from
            silver_<env>.ebs_apps.ra_customer_trx_lines_all rctla
            join silver_<env>.ebs_apps.ra_customer_trx_all rcta on rcta.CUSTOMER_TRX_ID = rctla.CUSTOMER_TRX_ID + 0
          where
            rctla.SALES_ORDER = cast(oh.order_number as string)
            and rctla.INTERFACE_LINE_ATTRIBUTE6 = cast(ol.LINE_ID as string)
        ) nota_fiscal,
        0 frete,
        0 seguro,(
          select
            max(cast(mmt.pick_slip_number as bigint)) as pick_slip_number
          from
            silver_<env>.ebs_inv.mtl_material_transactions mmt
          where
            mmt.transaction_ID = wdd.transaction_ID
            and mmt.inventory_item_ID = wdd.inventory_item_ID
            and mmt.organization_ID = wdd.organization_ID
        ) PL,
        cast(wdd.VOLUME as string) volume,(
          select
            max(msi.global_attribute4)
          from
            silver_<env>.ebs_apps.mtl_system_items_b msi
            join silver_<env>.ebs_apps.mtl_planners mp on msi.planner_code = mp.planner_code
            and msi.organization_ID = mp.organization_ID
          where
            msi.inventory_item_ID = ol.INVENTORY_ITEM_ID
            and msi.organization_ID = 91
        ) TIPO_FISCAL_ITEM,(
          select
            max(micat.category_concat_segs)
          from
            silver_<env>.ebs_apps.mtl_item_categories_v micat
            left join silver_<env>.ebs_apps.mtl_item_categories_v mc on micat.category_ID = mc.category_ID
          where
            micat.category_set_name = 'Categoria GPS Japão'
            and micat.inventory_item_ID = ol.INVENTORY_ITEM_ID
            and micat.organization_ID = 91
        ) CATEGORIA_GPS
      from
        silver_<env>.ebs_apps.oe_order_headers_all oh
        join silver_<env>.ebs_apps.oe_order_lines_all ol on oh.header_ID = ol.HEADER_ID
        left join silver_<env>.ebs_apps.oe_order_holds_all ohh on oh.header_ID = ohh.header_ID
        and oh.org_ID = ohh.org_ID
        and nvl(ohh.RELEASED_FLAG, 'N') = 'N'
        left join silver_<env>.ebs_apps.wsh_delivery_details wdd on ol.LINE_ID = wdd.SOURCE_LINE_ID
        join silver_<env>.ebs_apps.ar_customers rc on oh.sold_to_org_ID = rc.CUSTOMER_ID
        join silver_<env>.ebs_apps.ym_ra_site_uses_v rsua on oh.invoice_to_org_ID = rsua.site_use_ID
        join silver_<env>.ebs_apps.ym_ra_addresses_v raa on rsua.address_ID = raa.address_ID
        join silver_<env>.ebs_apps.oe_transaction_types_tl ott on oh.order_type_ID = ott.TRANSACTION_TYPE_ID
        left join silver_<env>.ebs_apps.wsh_deliverables_v wda on wdd.DELIVERY_DETAIL_ID = wda.DELIVERY_DETAIL_ID
        and nvl(wda.RELEASED_STATUS, ' ') <> 'C'
        left join silver_<env>.ebs_apps.ra_territories rt on rsua.territory_ID = rt.territory_ID
        join silver_<env>.ebs_apps.hz_party_sites ps on RAa.party_site_ID = PS.PARTY_SITE_ID
        left join sq_grupo_ge sq_gg on raa.party_ID = sq_gg.PARTY_ID
      where
        ol.ORDERED_ITEM like '%Z0'
        and nvl(ohh.ORDER_HOLD_ID, 0) = nvl(
          (
            select
              Max(ohhx.ORDER_HOLD_ID)
            from
              silver_<env>.ebs_apps.oe_order_holds_all ohhx
            where
              ohhx.header_ID = oh.header_ID
              and ohhx.org_ID = ohh.org_ID
              and ohhx.HOLD_RELEASE_ID is null
          ),
          0
        )
        and ott.NAME in (
          'YMB VD PECAS CONCES',
          'YMB VD EXPORTACAO PECAS',
          'YMB VD PECAS CONSUM',
          'YMB VD CONSUM NFCE',
          'YMB VD CONSUM NFCE',
          'YMB VD PECAS ECOMMERCE'
        )
        and ott.LANGUAGE = 'PTB'
    )
    UNION ALL
      /* Faturamento */
      (
        WITH tabela_ipi AS (
          select
            rcta.CUSTOMER_TRX_ID id_nf,
            nvl(rctla.TAX_RATE, 0) aliq_ipi,
            nvl(rctla.EXTENDED_AMOUNT, 0) * nvl(rcta.EXCHANGE_RATE, 1) val_ipi,
            rctla.LINK_TO_CUST_TRX_LINE_ID imposto
          from
            silver_<env>.ebs_apps.ra_customer_trx_all rcta
            join silver_<env>.ebs_apps.ra_customer_trx_lines_all rctla on rcta.CUSTOMER_TRX_ID = rctla.CUSTOMER_TRX_ID
            join silver_<env>.ebs_apps.ar_vat_tax_all avta on rctla.VAT_TAX_ID = avta.vat_tax_ID
          where
            rcta.COMPLETE_FLAG = 'Y'
            and rcta.STATUS_TRX = 'OP'
            and substr(avta.tax_code, 1, 3) = 'IPI'
            and rctla.TAX_RATE > 0
        ),
        tabela_fcp AS (
          select
            rcta.CUSTOMER_TRX_ID id_nf,
            nvl(rctla.TAX_RATE, 0) aliq_ipi,
            nvl(rctla.EXTENDED_AMOUNT, 0) * nvl(rcta.EXCHANGE_RATE, 1) val_fcp,
            rctla.LINK_TO_CUST_TRX_LINE_ID imposto
          from
            silver_<env>.ebs_apps.ra_customer_trx_all rcta
            JOIN silver_<env>.ebs_apps.ra_customer_trx_lines_all rctla ON rcta.CUSTOMER_TRX_ID = rctla.CUSTOMER_TRX_ID
            JOIN silver_<env>.ebs_apps.ar_vat_tax_all avta on rctla.VAT_TAX_ID = avta.vat_tax_ID
          where
            rcta.COMPLETE_FLAG = 'Y'
            and rcta.STATUS_TRX = 'OP'
            and substr(avta.tax_code, 1, 3) = 'FCP'
            and rctla.TAX_RATE > 0
        ),
        tabela_icms AS (
          select
            rcta.CUSTOMER_TRX_ID id_nf,
            nvl(rctla.TAX_RATE, 0) aliq_icms_st,
            nvl(rctla.EXTENDED_AMOUNT, 0) * nvl(rcta.EXCHANGE_RATE, 1) val_icms_st,
            rctla.LINK_TO_CUST_TRX_LINE_ID imposto
          from
            silver_<env>.ebs_apps.ra_customer_trx_all rcta
            join silver_<env>.ebs_apps.ra_customer_trx_lines_all rctla on rcta.CUSTOMER_TRX_ID = rctla.CUSTOMER_TRX_ID
            join silver_<env>.ebs_apps.ar_vat_tax_all avta on rctla.VAT_TAX_ID = avta.vat_tax_ID
          where
            rcta.COMPLETE_FLAG = 'Y'
            and rcta.STATUS_TRX = 'OP'
            and substr(avta.tax_code, 1, 7) = 'ICMS_ST'
            and rctla.TAX_RATE > 0
        ),
        sq_grupo_ge AS (
          SELECT
            max(
              T.customer_number || ' - ' || T.customer_name
            ) grupo,
            party.PARTY_ID
          FROM
            silver_<env>.ebs_apps.hz_cust_acct_relate_all REL
            join silver_<env>.ebs_apps.hz_cust_accounts CUST on REL.RELATED_CUST_ACCOUNT_ID = CUST.CUST_ACCOUNT_ID
            join silver_<env>.ebs_apps.hz_parties PARTY on CUST.PARTY_ID = PARTY.PARTY_ID
            join silver_<env>.ebs_apps.ar_lookups L on L.LOOKUP_CODE = REL.RELATIONSHIP_TYPE
            join silver_<env>.ebs_apps.ym_ra_customers_v T on REL.CUST_ACCOUNT_ID = T.customer_ID
            join silver_<env>.ebs_apps.ym_ra_customers_v V on PARTY.PARTY_ID = V.party_ID
          WHERE
            REL.ORG_ID = 85
            AND L.LOOKUP_TYPE = 'RELATIONSHIP_TYPE'
            AND REL.STATUS = 'A'
            AND REL.CUST_ACCT_RELATE_ID > 0
            and T.customer_number like 'GE%' /* and party.PARTY_ID = raa.party_ID */
          group by
            party.PARTY_ID
        ),
        sq_prioridade_entrega AS (
          select
            max(flv.MEANING) DS_MEANING,
            oh.order_number,
            ol.LINE_ID
          from
            silver_<env>.ebs_apps.oe_order_headers_all oh
            join silver_<env>.ebs_apps.oe_order_lines_all ol on oh.header_ID = ol.HEADER_ID
            join silver_<env>.ebs_apps.fnd_lookup_values flv on nvl(
              OL.SHIPMENT_PRIORITY_CODE,
              OH.shipment_priority_code
            ) = flv.LOOKUP_CODE
            join silver_<env>.ebs_applsys.fnd_lookup_types flt on flv.LOOKUP_TYPE = flt.LOOKUP_TYPE
            and flv.VIEW_APPLICATION_ID = flt.APPLICATION_ID /* join  on oh.order_number = rctla.SALES_ORDER */
            /* join  on and ol.LINE_ID = rctla.INTERFACE_LINE_ATTRIBUTE6 */
          Where
            flv.LANGUAGE = 'PTB'
            and flv.SOURCE_LANG = 'PTB'
            and flt.LOOKUP_TYPE = 'SHIPMENT_PRIORITY'
            and flv.ENABLED_FLAG = 'Y'
          group by
            oh.order_number,
            ol.LINE_ID
        )
        select
          2 reg,
          RCTLA.SALES_ORDER numero_ordem,
          hp.PARTY_NAME nome_cliente,
          decode(
            rcta.FOB_POINT,
            'SEL',
            'Vendedor',
            'CIF',
            'Vendedor',
            'BUY',
            'Comprador',
            'FOB',
            'Comprador',
            'FCA',
            'Exportação',
            'CPT',
            'Exportação',
            'CIP',
            'Exportação'
          ) tipo_frete,
          sq_gg.grupo grupo_ge,
          cast(RCTLA.SALES_ORDER as string) order_number,
          (
            select
              min(ol.LINE_NUMBER)
            from
              silver_<env>.ebs_apps.oe_order_lines_all ol
            where
              ol.LINE_ID = rctla.INTERFACE_LINE_ATTRIBUTE6
          ) line_number,
          (
            select
              min(ol.SHIPMENT_NUMBER)
            from
              silver_<env>.ebs_apps.oe_order_lines_all ol
            where
              ol.LINE_ID = rctla.INTERFACE_LINE_ATTRIBUTE6
          ) shipment_number,
          rcta.TRX_DATE data_sel,
          (
            select
              min(oh.ordered_date)
            from
              silver_<env>.ebs_apps.oe_order_headers_all oh
            where
              oh.order_number = rctla.SALES_ORDER
          ) data_pedido,
          ' ' status,
          msi.SEGMENT1 item,
          0 qt_pedido,
          0 vl_pedido,
          0 qt_bo,
          0 vl_bo,
          0 qt_ae,
          0 vl_ae,
          0 qt_sep,
          0 vl_sep,
          0 qt_ret,
          0 vl_ret,
          0 qt_canc,
          0 vl_canc,
          NVL(RCTLA.QUANTITY_INVOICED, 0) qt_faturado,
          (
            nvl(RCTLA.EXTENDED_AMOUNT, 0) * nvl(rcta.EXCHANGE_RATE, 1)
          ) vl_faturado,
          0 qt_devolvido,
          0 vl_devolvido,
          (
            nvl(t_ipi.val_ipi, 0) * DECODE(
              RCTA.INVOICE_CURRENCY_CODE,
              'BRL',
              1,
              NVL(RCTA.EXCHANGE_RATE, 1)
            )
          ) vl_ipi,
          (
            nvl(t_icms.val_icms_st, 0) * DECODE(
              RCTA.INVOICE_CURRENCY_CODE,
              'BRL',
              1,
              NVL(RCTA.EXCHANGE_RATE, 1)
            )
          ) vl_icms,
          (
            nvl(t_fcp.val_fcp, 0) * DECODE(
              RCTA.INVOICE_CURRENCY_CODE,
              'BRL',
              1,
              NVL(RCTA.EXCHANGE_RATE, 1)
            )
          ) vl_fcp,
          decode(
            raa.global_attribute3,
            null,
            null,
            substr(lpad(raa.global_attribute3, 9, 0), 2, 2) || '.' || substr(lpad(raa.global_attribute3, 9, 0), 4, 3) || '.' || substr(lpad(raa.global_attribute3, 9, 0), 7, 3) || '/' || raa.global_attribute4 || '-' || raa.global_attribute5
          ) CNPJ,
          raa.city cidade,
          raa.state estado,
          rt.segment1 Regiao,
          rt.segment2 Sub_regiao,
          sq_pe.DS_MEANING prioridade_entrega,
          rc.customer_type Tipo_Org,
          (
            Select
              max(ffvt.DESCRIPTION) ri_transaction
            from
              silver_<env>.ebs_apps.fnd_flex_values_tl ffvt
              join silver_<env>.ebs_apps.fnd_flex_values ffv on ffv.FLEX_VALUE_ID = ffvt.FLEX_VALUE_ID
              join silver_<env>.ebs_apps.fnd_flex_value_sets ffvs on ffv.FLEX_VALUE_SET_ID = ffvs.FLEX_VALUE_SET_ID
            where
              ffv.ENABLED_FLAG = 'Y'
              and ffvt.LANGUAGE = 'PTB'
              and ffvs.FLEX_VALUE_SET_NAME = 'YM_AR_TIPO_CLIENTE'
              and ffvt.FLEX_VALUE_MEANING = PS.ATTRIBUTE3
          ) TIPO,
          cast(rcta.TRX_NUMBER as string) nota_fiscal,
          case
            when rctla.ATTRIBUTE10 is null then 0
            else CAST(
              REPLACE(rctla.ATTRIBUTE10, ',', '.') AS DOUBLE
            )
          end frete,
          case
            when rctla.ATTRIBUTE11 is null then 0
            else CAST(
              REPLACE(rctla.ATTRIBUTE11, ',', '.') AS DOUBLE
            )
          end seguro,
          (
            select
              cast(max(cast(mmt.PICK_SLIP_NUMBER as bigint)) as string) PICK_SLIP_NUMBER
            from
              silver_<env>.ebs_inv.mtl_material_transactions mmt
              join silver_<env>.ebs_apps.wsh_delivery_details wdd on wdd.MOVE_ORDER_LINE_ID = mmt.SOURCE_LINE_ID
              and wdd.TRANSACTION_ID = mmt.TRANSACTION_ID
              and wdd.INVENTORY_ITEM_ID = mmt.INVENTORY_ITEM_ID
              and wdd.ORGANIZATION_ID = mmt.ORGANIZATION_ID
              join silver_<env>.ebs_apps.oe_order_lines_all ola on ola.HEADER_ID = wdd.SOURCE_HEADER_ID
              and ola.LINE_ID = wdd.SOURCE_LINE_ID
              and ola.ORG_ID = wdd.ORG_ID
            where
              ola.LINE_ID = rctla.INTERFACE_LINE_ATTRIBUTE6
          ) PL,
          nvl(rcta.GLOBAL_ATTRIBUTE13, '0') volume,
          (
            select
              max(msi2.GLOBAL_ATTRIBUTE4)
            from
              silver_<env>.ebs_apps.mtl_system_items_b msi2
              join silver_<env>.ebs_apps.mtl_planners mp on msi2.ORGANIZATION_ID = mp.ORGANIZATION_ID
            where
              msi.PLANNER_CODE = mp.PLANNER_CODE
              and msi2.INVENTORY_ITEM_ID = msi.INVENTORY_ITEM_ID
              and msi2.ORGANIZATION_ID = 91
          ) TIPO_FISCAL_ITEM,
          NULL CATEGORIA_GPS
        FROM
          silver_<env>.ebs_apps.hz_parties hp
          join silver_<env>.ebs_apps.hz_cust_accounts_all hca on HCA.PARTY_ID = HP.PARTY_ID
          join silver_<env>.ebs_apps.ra_customer_trx_all rcta on RCTA.BILL_TO_CUSTOMER_ID = HCA.CUST_ACCOUNT_ID
          join silver_<env>.ebs_apps.ra_customer_trx_lines_all rctla on RCTA.CUSTOMER_TRX_ID = RCTLA.CUSTOMER_TRX_ID
          join silver_<env>.ebs_apps.ra_cust_trx_types_all rctta on RCTA.CUST_TRX_TYPE_ID = RCTTA.CUST_TRX_TYPE_ID
          join silver_<env>.ebs_apps.mtl_system_items_b msi on RCTLA.INVENTORY_ITEM_ID = MSI.INVENTORY_ITEM_ID
          AND RCTLA.WAREHOUSE_ID = MSI.ORGANIZATION_ID
          join silver_<env>.ebs_apps.ym_ra_site_uses_v rsua on RCTA.BILL_TO_SITE_USE_ID = RSUA.site_use_ID
          join silver_<env>.ebs_apps.ym_ra_addresses_v raa on RSUA.address_ID = RAA.address_ID
          join silver_<env>.ebs_apps.mtl_item_categories mic on MSI.INVENTORY_ITEM_ID = MIC.INVENTORY_ITEM_ID
          AND MSI.ORGANIZATION_ID = MIC.ORGANIZATION_ID
          join silver_<env>.ebs_apps.mtl_category_sets mcs on MIC.CATEGORY_SET_ID = MCS.category_set_ID
          join silver_<env>.ebs_apps.mtl_categories mc on MIC.CATEGORY_ID = MC.category_ID
          join silver_<env>.ebs_apps.hz_party_sites ps on RAa.party_site_ID = PS.PARTY_SITE_ID
          join silver_<env>.ebs_apps.ym_ra_customers_v rc on rcta.SOLD_TO_CUSTOMER_ID = rc.customer_ID
          left join silver_<env>.ebs_apps.ra_territories rt on rsua.territory_ID = rt.territory_ID
          left join tabela_ipi t_ipi on rctla.CUSTOMER_TRX_LINE_ID = t_ipi.imposto
          left join tabela_icms t_icms on rctla.CUSTOMER_TRX_LINE_ID = t_icms.imposto
          left join tabela_fcp t_fcp on rctla.CUSTOMER_TRX_LINE_ID = t_fcp.imposto
          left join sq_grupo_ge sq_gg on raa.party_ID = sq_gg.PARTY_ID
          left join sq_prioridade_entrega sq_pe on rctla.SALES_ORDER = sq_pe.order_number
          and rctla.INTERFACE_LINE_ATTRIBUTE6 = sq_pe.LINE_ID
        WHERE
          RCTA.STATUS_TRX = 'OP'
          AND RCTTA.TYPE <> 'CM'
          AND RCTTA.DESCRIPTION NOT LIKE '%COLIG%'
          AND (
            RCTTA.ACCOUNTING_AFFECT_FLAG = 'Y'
            or rctta.ATTRIBUTE15 = 'PCS'
          )
          AND NVL(RCTTA.ATTRIBUTE13, 'X') <> 'S'
          AND RCTLA.LINE_TYPE = 'LINE'
          and rsua.site_use_code = 'BILL_TO'
          and MC.segment1 LIKE '%PÇS%'
      )
    UNION ALL
      /* Devolucoes */
      (
        WITH sq_grupo_ge AS (
          SELECT
            max(
              T.customer_number || ' - ' || T.customer_name
            ) grupo,
            party.PARTY_ID
          FROM
            silver_<env>.ebs_apps.hz_cust_acct_relate_all REL
            join silver_<env>.ebs_apps.hz_cust_accounts CUST on REL.RELATED_CUST_ACCOUNT_ID = CUST.CUST_ACCOUNT_ID
            join silver_<env>.ebs_apps.hz_parties PARTY on CUST.PARTY_ID = PARTY.PARTY_ID
            join silver_<env>.ebs_apps.ar_lookups L on L.LOOKUP_CODE = REL.RELATIONSHIP_TYPE
            join silver_<env>.ebs_apps.ym_ra_customers_v T on REL.CUST_ACCOUNT_ID = T.customer_ID
            join silver_<env>.ebs_apps.ym_ra_customers_v V on PARTY.PARTY_ID = V.party_ID
          WHERE
            REL.ORG_ID = 85
            AND L.LOOKUP_TYPE = 'RELATIONSHIP_TYPE'
            AND REL.STATUS = 'A'
            AND REL.CUST_ACCT_RELATE_ID > 0
            and T.customer_number like 'GE%'
          group by
            party.PARTY_ID
        )
        select
          3 reg,
          cast(ri.OPERATION_ID as string) numero_ordem,
          ac.customer_name nome_cliente,
          null tipo_frete,
          sq_gg.grupo grupo_ge,
          cast(null as string) order_number,
          null line_number,
          null shipment_number,
          reo.RECEIVE_DATE data_sel,
          reo.RECEIVE_DATE data_pedido,
          ' ' status,
          msi.SEGMENT1 item,
          0 qt_pedido,
          0 vl_pedido,
          0 qt_bo,
          0 vl_bo,
          0 qt_ae,
          0 vl_ae,
          0 qt_sep,
          0 vl_sep,
          0 qt_ret,
          0 vl_ret,
          0 qt_canc,
          0 vl_canc,
          0 qt_faturado,
          0 vl_faturado,
          NVL(ril.QUANTITY, 0) qt_devolvido,
          nvl(ril.TOTAL_AMOUNT, 0) - nvl(ril.IPI_AMOUNT, 0) - nvl(ril.ICMS_ST_AMOUNT, 0) vl_devolvido,
          0 vl_ipi,
          0 vl_icms,
          0 vl_fcp,
          decode(
            ra.global_attribute3,
            null,
            null,
            substr(lpad(ra.global_attribute3, 9, 0), 2, 2) || '.' || substr(lpad(ra.global_attribute3, 9, 0), 4, 3) || '.' || substr(lpad(ra.global_attribute3, 9, 0), 7, 3) || '/' || ra.global_attribute4 || '-' || ra.global_attribute5
          ) CNPJ,
          ra.city cidade,
          ra.state estado,
          rt.segment1 Regiao,
          rt.segment2 Sub_regiao,
          null prioridade_entrega,
          rc.party_type Tipo_Org,
          (
            select
              max(ffvt.DESCRIPTION) ri_transaction
            from
              silver_<env>.ebs_apps.fnd_flex_values_tl ffvt
              join silver_<env>.ebs_apps.fnd_flex_values ffv on ffv.FLEX_VALUE_ID = ffvt.FLEX_VALUE_ID
              join silver_<env>.ebs_apps.fnd_flex_value_sets ffvs on ffv.FLEX_VALUE_SET_ID = ffvs.FLEX_VALUE_SET_ID
            where
              ffv.ENABLED_FLAG = 'Y'
              and ffvt.LANGUAGE = 'PTB'
              and ffvs.FLEX_VALUE_SET_NAME = 'YM_AR_TIPO_CLIENTE'
              and ffvt.FLEX_VALUE_MEANING = PS.ATTRIBUTE3
          ) TIPO,
          '0' as nota_fiscal,
          0 frete,
          0 seguro,
          '0' PL,
          '0' volume,
          (
            select
              max(msi2.GLOBAL_ATTRIBUTE4)
            from
              silver_<env>.ebs_apps.mtl_system_items_b msi2
              join silver_<env>.ebs_apps.mtl_planners mp on msi2.ORGANIZATION_ID = mp.ORGANIZATION_ID
            where
              msi.PLANNER_CODE = mp.PLANNER_CODE
              and msi2.INVENTORY_ITEM_ID = msi.INVENTORY_ITEM_ID
              and msi2.ORGANIZATION_ID = 91
          ) TIPO_FISCAL_ITEM,
          NULL CATEGORIA_GPS
        FROM
          silver_<env>.ebs_apps.ym_ra_addresses_v ra
          join silver_<env>.ebs_cll.cll_f189_fiscal_entities_all rfea on rfea.ADDRESS_ID = ra.ADDRESS_ID
          join silver_<env>.ebs_cll.cll_f189_invoices ri on ri.ENTITY_ID = rfea.ENTITY_ID
          join silver_<env>.ebs_cll.cll_f189_invoice_types rtt on ri.INVOICE_TYPE_ID = rtt.INVOICE_TYPE_ID
          join silver_<env>.ebs_cll.cll_f189_invoice_lines ril on ri.INVOICE_ID = ril.INVOICE_ID
          join silver_<env>.ebs_cll.cll_f189_entry_operations reo on RI.OPERATION_ID = REO.OPERATION_ID
          AND RI.ORGANIZATION_ID = REO.ORGANIZATION_ID
          join silver_<env>.ebs_apps.hr_organization_units hou on ri.ORGANIZATION_ID = hou.ORGANIZATION_ID
          join silver_<env>.ebs_apps.mtl_system_items_b msi on ril.ITEM_ID = msi.INVENTORY_ITEM_ID
          and ril.ORGANIZATION_ID = msi.ORGANIZATION_ID
          join silver_<env>.ebs_apps.ym_ra_customers_v ac on ra.customer_ID = ac.customer_ID
          join silver_<env>.ebs_apps.ym_ra_site_uses_v rsua on RSUA.ADDRESS_ID = RA.ADDRESS_ID
          left join silver_<env>.ebs_apps.ra_territories rt on rsua.territory_ID = rt.territory_ID
          join silver_<env>.ebs_apps.hz_party_sites ps on RA.party_site_ID = PS.PARTY_SITE_ID
          join silver_<env>.ebs_apps.ym_ra_customers_v rc on ac.customer_ID = rc.customer_ID
          left join sq_grupo_ge sq_gg on ra.party_ID = sq_gg.PARTY_ID
        WHERE
          ri.AP_INTERFACE_FLAG = 'N'
          AND RTT.REQUISITION_TYPE = 'RM'
          and msi.SEGMENT1 like '%Z0'
          and rsua.site_use_code = 'BILL_TO'
      )
  ) o412285,
  (
    select
      msi.segment1,
      MC.DESCRIPTION mc_description,
      msi.planner_code planejador,
      (
        SELECT
          max(mcx.concatenated_segments)
        FROM
          silver_<env>.ebs_apps.mtl_item_categories micx
          join silver_<env>.ebs_apps.mtl_categories_b_kfv mcx on micx.category_ID = mcx.category_ID
        where
          MICx.ORGANIZATION_ID = MSI.ORGANIZATION_ID
          AND MICx.INVENTORY_ITEM_ID = MSI.INVENTORY_ITEM_ID
          and micx.category_set_ID in (1100000045)
      ) CATEGORIA_PRECO,
      (
        SELECT
          max(p.attribute1)
        FROM
          silver_<env>.ebs_apps.mtl_planners p
        WHERE
          p.planner_code = msi.planner_code
      ) MACRO_PLANEJ
    from
      silver_<env>.ebs_apps.mtl_system_items_b msi
      join silver_<env>.ebs_apps.mtl_item_categories MIC on MSI.INVENTORY_ITEM_ID = MIC.INVENTORY_ITEM_ID
      AND MSI.ORGANIZATION_ID = MIC.ORGANIZATION_ID
      join silver_<env>.ebs_apps.mtl_categories MC on MC.CATEGORY_ID = MIC.CATEGORY_ID
      join silver_<env>.ebs_apps.mtl_category_sets MCS on MIC.CATEGORY_SET_ID = MCS.CATEGORY_SET_ID
    where
      MC.SEGMENT1 LIKE '%PÇS%'
      AND MSI.SEGMENT1 LIKE '%Z0'
      and msi.organization_ID = 91
  ) o471515
WHERE
  (o412285.ITEM = o471515.segment1)
GROUP BY
  REPLACE(REPLACE(o412285.CNPJ, '.', ''), '.', ''),
  o471515.MC_DESCRIPTION,
  o471515.PLANEJADOR,
  o471515.CATEGORIA_PRECO,
  o412285.CNPJ,
  o412285.ESTADO,
  o412285.GRUPO_GE,
  o412285.ITEM,
  o412285.NOME_CLIENTE,
  o412285.NOTA_FISCAL,
  o412285.NUMERO_ORDEM,
  o412285.PRIORIDADE_ENTREGA,
  o412285.REGIAO,
  o412285.SUB_REGIAO,
  o412285.TIPO,
  o412285.TIPO_ORG,
  o412285.CIDADE,
  o412285.PL,
  o412285.VOLUME,
  o412285.TIPO_FRETE,
  o412285.VL_FCP,
  o412285.TIPO_FISCAL_ITEM
