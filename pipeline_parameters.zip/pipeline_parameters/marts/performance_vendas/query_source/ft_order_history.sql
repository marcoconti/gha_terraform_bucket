SELECT b.DT_DATA_PEDIDO,
    REGEXP_REPLACE(b.DS_CNPJ, '[./-]', '') AS DS_CNPJ,
    b.NR_REG,
    b.NR_NUMERO_ORDEM,
    b.NM_NOME_CLIENTE,
    b.TP_TIPO_FRETE,
    b.DS_GRUPO_GE,
    b.NR_ORDER_NUMBER,
    b.NR_LINE_NUMBER,
    b.NR_SHIPMENT_NUMBER,
    b.DT_DATA_SEL,
    b.PLANEJADOR,
    b.MIDDLE_GROUP_NAME,
    b.CATEGORIA_DE_PRECO,
    b.CD_ITEM,
    b.TIPO_FISCAL_ITEM,
    b.ID_CALENDARIO,
    b.QT_BO,
    b.QT_AWAITING_PICKING,
    b.QT_PICKING,
    b.QT_CREDIT_RETENTION,
    b.VL_BO,
    b.VL_AWAITING_PICKING,
    b.VL_PICKING,
    b.VL_CREDIT_RETENTION,
    b.CD_FLOW_STATUS_CODE,
    b.DS_STATUS,
    b.DS_PRIORIDADE_ENTREGA,
    b.DS_ESTADO,
 
    -- Campos da tabela HIST adicionados via LEFT JOIN
    h.DT_PED AS DT_DATA_PEDIDO_HIST,
    h.DT_FAT AS DT_DATA_FAT_HIST,
    h.VL_ITEM AS VL_ITEM_HIST,
    h.DS_PRIORIDADE AS DS_PRIORIDADE_HIST,
 
    -- Categoria
    CASE 
        WHEN b.PLANEJADOR = 'ACN COLLEC' THEN 'BLU COLLECTION'
        WHEN b.PLANEJADOR = 'ACN PITICA' THEN 'MARVEL'
        WHEN b.MIDDLE_GROUP_NAME IN ('Material Promocional', 'Souvenir', 'Vestuario') THEN 'APPAREL'
        WHEN b.MIDDLE_GROUP_NAME = 'ACCESSORIES' THEN 'BOLT-ON'
        WHEN regexp_replace(regexp_replace(b.CATEGORIA_DE_PRECO, '\\..*', ''), 'SENSITIVE', 'CAPTIVE') = 'YAMALUBE' AND b.CD_ITEM LIKE '90790BB%' THEN 'YAMALUBE NTC'
        WHEN regexp_replace(regexp_replace(b.CATEGORIA_DE_PRECO, '\\..*', ''), 'SENSITIVE', 'CAPTIVE') = 'YAMALUBE' THEN 'YAMALUBE MC'
        WHEN regexp_replace(regexp_replace(b.CATEGORIA_DE_PRECO, '\\..*', ''), 'SENSITIVE', 'CAPTIVE') = 'YAMALUBECARE' THEN 'YAMALUBE CARE'
        WHEN b.TIPO_FISCAL_ITEM = 'PN' THEN 'MARINE'
        ELSE regexp_replace(regexp_replace(b.CATEGORIA_DE_PRECO, '\\..*', ''), 'SENSITIVE', 'CAPTIVE')
    END AS Categoria,
 
    -- Categoria_Entrega
    CASE 
        WHEN b.DS_ESTADO = 'EX' THEN 'EXPORT'
        WHEN b.DS_PRIORIDADE_ENTREGA LIKE '%RECALL%' THEN 'RECALL'
        WHEN b.DS_CNPJ IN (
            '47.458.153/0001-40', '62.934.252/0001-45', '04.817.052/0001-06',  
            '04.817.052/0002-97', '10.427.061/0001-93', '10.371.492/0001-85',  
            '06.225.970/0001-71', '48.150.163/0001-87', '09.553.151/0001-41',  
            '26.278.985/0003-77', '04.817.052/0004-59', '62.934.252/0006-50'
        ) THEN 'INTERCOMPANY'
        WHEN b.DS_PRIORIDADE_ENTREGA = 'YAL PC' THEN 'YAL'
        WHEN b.DS_PRIORIDADE_ENTREGA = 'eCommerce' THEN 'BLU STORE'
        WHEN b.DS_PRIORIDADE_ENTREGA LIKE '%Funcionario%' THEN 'EMPLOYEE'
        WHEN b.DS_SUB_REGIAO IS NOT NULL AND TRIM(b.DS_SUB_REGIAO) <> '' THEN 'DEALER'
        ELSE 'OTHER'
    END AS Categoria_Entrega,
 
    -- Agregações
    SUM(b.QT_PEDIDO) AS QT_PEDIDO,
    SUM(b.VL_PEDIDO) AS VL_PEDIDO,
    SUM(b.QT_BO + b.QT_AWAITING_PICKING + b.QT_PICKING + b.QT_CREDIT_RETENTION) AS QT_ITEM,
    SUM(b.VL_BO + b.VL_AWAITING_PICKING + b.VL_PICKING + b.VL_CREDIT_RETENTION) AS VL_ITEM
 
  FROM gold_<env>.pecas_planejamento_vendas.ft_carteira b
  LEFT JOIN gold_<env>.pecas_planejamento_vendas.ft_hist_mes h
    ON b.CD_ITEM = h.CD_ITEM
 
  LEFT JOIN gold_<env>.corporativo.dm_calendario c 
    ON b.ID_CALENDARIO = c.ID_CALENDARIO
 
 WHERE (c.NR_ANO * 100 + c.NR_MES) >= (year(current_date - interval 13 month) * 100 + month(current_date - interval 13 month)
) 
GROUP BY b.DT_DATA_PEDIDO,
    REGEXP_REPLACE(b.DS_CNPJ, '[./-]', ''),
    b.NR_REG,
    b.NR_NUMERO_ORDEM,
    b.NM_NOME_CLIENTE,
    b.TP_TIPO_FRETE,
    b.DS_GRUPO_GE,
    b.NR_ORDER_NUMBER,
    b.NR_LINE_NUMBER,
    b.NR_SHIPMENT_NUMBER,
    b.DT_DATA_SEL,
    b.PLANEJADOR,
    b.MIDDLE_GROUP_NAME,
    b.CATEGORIA_DE_PRECO,
    b.CD_ITEM,
    b.TIPO_FISCAL_ITEM,
    b.ID_CALENDARIO,
    b.QT_BO,
    b.QT_AWAITING_PICKING,
    b.QT_PICKING,
    b.QT_CREDIT_RETENTION,
    b.VL_BO,
    b.VL_AWAITING_PICKING,
    b.VL_PICKING,
    b.VL_CREDIT_RETENTION,
    b.CD_FLOW_STATUS_CODE,
    b.DS_STATUS,
    b.DS_PRIORIDADE_ENTREGA,
    b.DS_ESTADO,
 
    -- Categoria e Categoria_Entrega
    CASE 
        WHEN b.PLANEJADOR = 'ACN COLLEC' THEN 'BLU COLLECTION'
        WHEN b.PLANEJADOR = 'ACN PITICA' THEN 'MARVEL'
        WHEN b.MIDDLE_GROUP_NAME IN ('Material Promocional', 'Souvenir', 'Vestuario') THEN 'APPAREL'
        WHEN b.MIDDLE_GROUP_NAME = 'ACCESSORIES' THEN 'BOLT-ON'
        WHEN regexp_replace(regexp_replace(b.CATEGORIA_DE_PRECO, '\\..*', ''), 'SENSITIVE', 'CAPTIVE') = 'YAMALUBE' AND b.CD_ITEM LIKE '90790BB%' THEN 'YAMALUBE NTC'
        WHEN regexp_replace(regexp_replace(b.CATEGORIA_DE_PRECO, '\\..*', ''), 'SENSITIVE', 'CAPTIVE') = 'YAMALUBE' THEN 'YAMALUBE MC'
        WHEN regexp_replace(regexp_replace(b.CATEGORIA_DE_PRECO, '\\..*', ''), 'SENSITIVE', 'CAPTIVE') = 'YAMALUBECARE' THEN 'YAMALUBE CARE'
        WHEN b.TIPO_FISCAL_ITEM = 'PN' THEN 'MARINE'
        ELSE regexp_replace(regexp_replace(b.CATEGORIA_DE_PRECO, '\\..*', ''), 'SENSITIVE', 'CAPTIVE')
    END,
 
    CASE 
        WHEN b.DS_ESTADO = 'EX' THEN 'EXPORT'
        WHEN b.DS_PRIORIDADE_ENTREGA LIKE '%RECALL%' THEN 'RECALL'
        WHEN b.DS_CNPJ IN (
            '47.458.153/0001-40', '62.934.252/0001-45', '04.817.052/0001-06',  
            '04.817.052/0002-97', '10.427.061/0001-93', '10.371.492/0001-85',  
            '06.225.970/0001-71', '48.150.163/0001-87', '09.553.151/0001-41',  
            '26.278.985/0003-77', '04.817.052/0004-59', '62.934.252/0006-50'
        ) THEN 'INTERCOMPANY'
        WHEN b.DS_PRIORIDADE_ENTREGA = 'YAL PC' THEN 'YAL'
        WHEN b.DS_PRIORIDADE_ENTREGA = 'eCommerce' THEN 'BLU STORE'
        WHEN b.DS_PRIORIDADE_ENTREGA LIKE '%Funcionario%' THEN 'EMPLOYEE'
        WHEN b.DS_SUB_REGIAO IS NOT NULL AND TRIM(b.DS_SUB_REGIAO) <> '' THEN 'DEALER'
        ELSE 'OTHER'
    END,
 
    -- Adiciona colunas da tabela h no GROUP BY
    h.DT_PED,
    h.DT_FAT,
    h.VL_ITEM,
    h.DS_PRIORIDADE