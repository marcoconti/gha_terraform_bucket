# Databricks notebook source
# DBTITLE 1,Import de libs
from delta.tables import *
import os
from datetime import datetime

# COMMAND ----------

# DBTITLE 1,Criação de método para otimizar delta table
def optimize_delta_table(table_name):
    """
        @param: IN table_path
        Run optimization commands and old snapshots
        Full load
    """
    deltaTable = DeltaTable.forName(spark, table_name)
    deltaTable.vacuum()
    deltaTable.optimize().executeCompaction()
    print('Delta table optimized.') 

# COMMAND ----------

# DBTITLE 1,Definição de variáveis
# Ambiente
env = os.environ.get("DATABRICKS_ENV")
env = env.lower()

# Catalogo, Schema e Nome da tabela
param_catalogo_gold = f"gold_{env}"
param_schema = "pecas_planejamento_vendas"
param_nome_tabela_gold = 'demonstrativo_pecas_pendentes'

print(f"Tabela: {param_catalogo_gold}.{param_schema}.{param_nome_tabela_gold}")

# COMMAND ----------

# DBTITLE 1,Filtrar tabelas grandes - no máximo dados de 3 anos atrás
tables = ["mtl_item_categories_v"
         ,"oe_order_headers_all"
         ,"oe_order_holds_all"
         ,"oe_order_lines_all"
         ,"wsh_deliverables_v"
         ,"wsh_delivery_details"]

catalog_schema_table = f"silver_{env}.ebs_apps"

# 3 years ago
ano = datetime.now().year - 3

for table in tables:
    query_filter = f"""Select * from {catalog_schema_table}.{table} where cast(_year as integer) >= {ano}"""
    df = spark.sql(query_filter)
    table_name = f"temp_{table}"
    df.createOrReplaceTempView(table_name)

# COMMAND ----------

# DBTITLE 1,Criar a query principal unindo as tabelas da camada Silver
df_demonstrativo_pecas_pendentes = spark.sql(
       f"""
        with grupo_ge 
        (
        SELECT 
        party.PARTY_ID ID_PARTY
        ,T.CUSTOMER_NUMBER ||' - '|| T.CUSTOMER_NAME     grupo

        FROM       silver_{env}.ebs_apps.HZ_CUST_ACCT_RELATE_ALL      REL
        INNER JOIN silver_{env}.ebs_apps.HZ_CUST_ACCOUNTS             CUST
                ON REL.RELATED_CUST_ACCOUNT_ID = CUST.CUST_ACCOUNT_ID
        INNER JOIN silver_{env}.ebs_apps.HZ_PARTIES                   PARTY
                ON CUST.PARTY_ID = PARTY.PARTY_ID
        INNER JOIN silver_{env}.ebs_apps.AR_LOOKUPS                   L
                ON L.LOOKUP_CODE = REL.RELATIONSHIP_TYPE
        INNER JOIN silver_{env}.ebs_apps.YM_RA_CUSTOMERS_V            T
                ON REL.CUST_ACCOUNT_ID = T.CUSTOMER_ID
        INNER JOIN silver_{env}.ebs_apps.YM_RA_CUSTOMERS_V           V
                ON PARTY.PARTY_ID = V.PARTY_ID
        WHERE 
        REL.ORG_ID = 85
        AND L.LOOKUP_TYPE = 'RELATIONSHIP_TYPE'
        AND REL.STATUS = 'A'
        AND REL.CUST_ACCT_RELATE_ID > 0
        and T.CUSTOMER_NUMBER  like 'GE%'
        ),prioridade_entrega
        (
        select 
        flv.LOOKUP_CODE as CD_LOOKUP_CODE
        ,flv.MEANING as prioridade_entrega
        from silver_{env}.ebs_applsys.fnd_lookup_types     flt 
        inner join silver_{env}.ebs_apps.fnd_lookup_values flv 
                on flt.LOOKUP_TYPE = flv.LOOKUP_TYPE 
                and flt.APPLICATION_ID = flv.VIEW_APPLICATION_ID
        Where flv.LANGUAGE = 'PTB'
        and flv.SOURCE_LANG = 'PTB'
        and flt.LOOKUP_TYPE = 'SHIPMENT_PRIORITY'                
        And flv.ENABLED_FLAG = 'Y'
        ),tipo
        (
        select 
        ffvt.FLEX_VALUE_MEANING
        ,ffvt.DESCRIPTION        ri_transaction
        from silver_{env}.ebs_apps.fnd_flex_values_tl ffvt 
        inner join silver_{env}.ebs_apps.fnd_flex_values ffv 
                on ffv.FLEX_VALUE_ID = ffvt.FLEX_VALUE_ID
        inner join silver_{env}.ebs_apps.fnd_flex_value_sets ffvs 
                on ffv.FLEX_VALUE_SET_ID = ffvs.FLEX_VALUE_SET_ID
        where   ffv.ENABLED_FLAG = 'Y'                
        and ffvt.LANGUAGE = 'PTB'                
        and ffvs.FLEX_VALUE_SET_NAME = 'YM_AR_TIPO_CLIENTE'
        ),tipo_fiscal_item
        (
        select 
        msi.INVENTORY_ITEM_ID ID_INVENTORY_ITEM
        ,msi.GLOBAL_ATTRIBUTE4 TIPO_FISCAL_ITEM
        from       silver_{env}.ebs_apps.mtl_system_items_b msi 
        inner join silver_{env}.ebs_apps.mtl_planners       mp 
                on  msi.PLANNER_CODE = mp.PLANNER_CODE 
                and  msi.ORGANIZATION_ID = mp.ORGANIZATION_ID
        where 
        msi.ORGANIZATION_ID = 91
        ),categoria_gps
        (
        select 
        micat.INVENTORY_ITEM_ID ID_INVENTORY_ITEM
        ,micat.CATEGORY_CONCAT_SEGS categoria_gps
        from temp_mtl_item_categories_v micat
        left join silver_{env}.ebs_apps.mtl_categories_v mc 
                on mc.CATEGORY_ID = micat.CATEGORY_ID
        where micat.CATEGORY_SET_NAME = 'Categoria GPS Japão'
        and   micat.ORGANIZATION_ID = 91
        )

        select 
                distinct
                1                                                    reg
                ,oh.order_number                                  numero_ordem
                ,rc.CUSTOMER_NAME                                 nome_cliente
                ,decode(ol.FOB_POINT_CODE,'SEL','Vendedor',
                                                'CIF','Vendedor',
                                                'BUY','Comprador',
                                                'FOB','Comprador',
                                                'FCA','Exportação',
                                                'CPT','Exportação',
                                                'CIP','Exportação')   tipo_frete
                ,grupo_ge.grupo                                    grupo_ge
                ,oh.order_number                                   order_number
                ,ol.LINE_NUMBER                                    NR_LINE_NUMBER
                ,ol.SHIPMENT_NUMBER                                NR_SHIPMENT_NUMBER
                ,oh.ordered_date                                   data_sel
                ,oh.creation_date                                  data_pedido    
                ,oh.flow_status_code                               status
                ,ol.ORDERED_ITEM                                   item    
                ,wdd.REQUESTED_QUANTITY                            qt_pedido
                ,ol.UNIT_SELLING_PRICE * wdd.REQUESTED_QUANTITY vl_pedido
                ,case 
                        when ohh.HEADER_ID is not null 
                        then 0 
                        else decode(nvl(wda.RELEASED_STATUS, ' '),'B',nvl(wdd.REQUESTED_QUANTITY, 0),0) 
                end                                                 qt_bo
                ,case 
                        when ohh.HEADER_ID is not null 
                        then 0 
                        else decode(nvl(wda.RELEASED_STATUS, ' '),'B',nvl(wdd.REQUESTED_QUANTITY, 0),0) * ol.UNIT_SELLING_PRICE 
                end                                                 vl_bo
                ,case 
                        when ohh.HEADER_ID is not null then 0 
                        else decode(nvl(wda.RELEASED_STATUS, ' '),'R',nvl(wdd.REQUESTED_QUANTITY, 0),0) 
                end                                                 qt_ae
                ,case 
                        when ohh.HEADER_ID is not null 
                        then 0 
                        else decode(nvl(wda.RELEASED_STATUS, ' '),'R',nvl(wdd.REQUESTED_QUANTITY, 0),0) * ol.UNIT_SELLING_PRICE 
                end                                                 vl_ae
                ,decode(nvl(wda.RELEASED_STATUS, ' '),'Y',nvl(wdd.REQUESTED_QUANTITY, 0),0) + decode(nvl(wda.RELEASED_STATUS, ' '),
                                                        'S',nvl(wdd.REQUESTED_QUANTITY, 0),0) 
                                                                qt_sep
                ,(decode(nvl(wda.RELEASED_STATUS, ' '),'Y',nvl(wdd.REQUESTED_QUANTITY, 0),0) * ol.UNIT_SELLING_PRICE) + (decode(nvl(wda.RELEASED_STATUS, ' '),
                                                        'S',nvl(wdd.REQUESTED_QUANTITY, 0),0) * ol.UNIT_SELLING_PRICE) 
                                                                vl_sep
                ,decode(ohh.HEADER_ID, null, 0, decode(ohh.HOLD_RELEASE_ID,null,nvl(wdd.REQUESTED_QUANTITY, 0),0)) qt_ret 
                ,decode(ohh.HEADER_ID, null, 0, decode(ohh.HOLD_RELEASE_ID,null,nvl(wdd.REQUESTED_QUANTITY, 0),0)) * ol.UNIT_SELLING_PRICE vl_ret
                ,decode(raa.global_attribute3,null,null,substr(lpad(raa.global_attribute3, 9, 0), 2, 2) || '.' || 
                                                        substr(lpad(raa.global_attribute3, 9, 0), 4, 3) || '.' || 
                                                        substr(lpad(raa.global_attribute3, 9, 0), 7, 3) || '/' || 
                                                                raa.global_attribute4               || '-' || 
                                                                raa.global_attribute5 
                        )                                              CNPJ
                ,raa.city                                           cidade
                ,raa.state                                          estado
                ,rt.segment1                                        Regiao
                ,rt.segment2                                        Sub_regiao
                ,flv.prioridade_entrega
                ,rc.CUSTOMER_TYPE                                   Tipo_Org
                ,ffvt.ri_transaction                                   TIPO
                ,msi.TIPO_FISCAL_ITEM
                ,micat.categoria_gps
                ,ol.FLOW_STATUS_CODE CD_FLOW_STATUS_CODE
                ,wdd.VOLUME NR_VOLUME
                ,month(oh.creation_date)                            MONTH
                ,year(oh.creation_date)                             YEAR                                          

                from       temp_oe_order_headers_all              oh
                inner join temp_oe_order_lines_all      ol 
                        on oh.header_id = ol.header_id
                inner join silver_{env}.ebs_apps.ar_customers            rc 
                        on oh.sold_to_org_id = rc.CUSTOMER_id
                inner join silver_{env}.ebs_apps.ym_ra_site_uses_v       rsua 
                        on oh.invoice_to_org_id = rsua.site_use_id
                inner join silver_{env}.ebs_apps.ym_ra_addresses_v       raa 
                        on rsua.address_id = raa.address_id
                inner join silver_{env}.ebs_apps.oe_transaction_types_tl ott 
                        on oh.order_type_id = ott.TRANSACTION_TYPE_ID
                inner join silver_{env}.ebs_apps.hz_party_sites          ps 
                        on raa.party_site_id = PS.PARTY_SITE_ID
                left join prioridade_entrega                              flv
                        on nvl(OL.SHIPMENT_PRIORITY_CODE, OH.shipment_priority_code) = flv.CD_LOOKUP_CODE  
                left join grupo_ge
                        on raa.PARTY_ID = grupo_ge.ID_PARTY
                left join tipo                                            ffvt
                        on PS.ATTRIBUTE3 = ffvt.FLEX_VALUE_MEANING
                left join tipo_fiscal_item                                msi
                        on ol.INVENTORY_ITEM_ID = msi.ID_INVENTORY_ITEM 
                left join categoria_gps                                   micat
                        on ol.INVENTORY_ITEM_ID = micat.ID_INVENTORY_ITEM  
                left join temp_oe_order_holds_all                 ohh 
                on ohh.HEADER_ID = oh.header_id
                and ohh.ORG_ID = oh.org_id
                and nvl(ohh.RELEASED_FLAG, 'N') = 'N'
                left join temp_wsh_delivery_details               wdd 
                on wdd.SOURCE_LINE_ID = ol.LINE_ID
                left join temp_wsh_deliverables_v                 wda 
                on wda.DELIVERY_DETAIL_ID = wdd.DELIVERY_DETAIL_ID
                left join silver_{env}.ebs_apps.ra_territories           rt 
                on rt.territory_id = rsua.territory_id
        where nvl(wda.RELEASED_STATUS, ' ') <> 'C'
        and  ott.LANGUAGE = 'PTB' 
        and  ol.ordered_item like '%Z0'
        and  OH.flow_status_code = 'BOOKED' 
        and  ol.FLOW_STATUS_CODE NOT IN('ENTERED', 'CLOSED', 'CANCELLED')
        and  ott.NAME in ('YMB VD PECAS CONCES','YMB VD EXPORTACAO PECAS','YMB VD PECAS CONSUM','YMB VD CONSUM NFCE')
        """)

df_demonstrativo_pecas_pendentes.createOrReplaceTempView("temp_tb_demonstrativo_pecas_pendentes")

# COMMAND ----------

# DBTITLE 1,Converter datatypes e renomear colunas para a camada Gold
query_cast_rename_cols = \
    """ Select cast(reg as integer) as NR_REG
            ,cast(numero_ordem as string) as NR_NUMERO_ORDEM
            ,nome_cliente as NM_NOME_CLIENTE
            ,tipo_frete as TP_TIPO_FRETE
            ,grupo_ge as DS_GRUPO_GE
            ,order_number as NR_ORDER_NUMBER
            ,cast(nr_line_number as integer) as NR_LINE_NUMBER
            ,cast(nr_shipment_number as integer) as NR_SHIPMENT_NUMBER 
            ,cast(data_sel as timestamp) as DT_DATA_SEL
            ,cast(data_pedido as timestamp) as DT_DATA_PEDIDO
            ,status as DS_STATUS
            ,item as DS_ITEM
            ,cast(qt_pedido as integer) as QT_PEDIDO
            ,vl_pedido as VL_PEDIDO
            ,qt_bo as QT_BO
            ,vl_bo as VL_BO
            ,qt_ae as QT_AE
            ,vl_ae as VL_AE
            ,qt_sep as QT_SEP
            ,vl_sep as VL_SEP
            ,qt_ret as QT_RET
            ,vl_ret as VL_RET
            ,cnpj as DS_CNPJ
            ,cidade as DS_CIDADE
            ,estado as DS_ESTADO
            ,Regiao as DS_REGIAO
            ,Sub_regiao as DS_SUB_REGIAO
            ,prioridade_entrega as DS_PRIORIDADE_ENTREGA
            ,tipo_org as TP_TIPO_ORG
            ,tipo as TP_TIPO
            ,tipo_fiscal_item as TP_TIPO_FISCAL_ITEM
            ,categoria_gps as DS_CATEGORIA_GPS
            ,cd_flow_status_code as CD_FLOW_STATUS_CODE 
            ,nr_volume as NR_VOLUME
            ,month 
            ,year
        from temp_tb_demonstrativo_pecas_pendentes 
    """

df_write_demonstrativo_pecas_pendentes = spark.sql(query_cast_rename_cols)

# COMMAND ----------

# DBTITLE 1,Persistir dados na tabela da camada Gold
table = f"{param_catalogo_gold}.{param_schema}.{param_nome_tabela_gold}"
print(f"Escrevendo a tabela {table}")

(
    df_write_demonstrativo_pecas_pendentes
    .write
    .format("delta")
    .mode("overwrite")
    .partitionBy("year", "month")
    .option("overwriteSchema", "true")
    .saveAsTable(table)
)

# optimization Gold layer
optimize_delta_table(table)

