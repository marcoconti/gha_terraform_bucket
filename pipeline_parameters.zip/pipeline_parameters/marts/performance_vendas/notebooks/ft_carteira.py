# COMMAND ----------
import pyspark.sql.functions as F
import requests
import tempfile
import os

from pyspark.sql.functions import col
from io import StringIO
from pyspark.sql.types import IntegerType,BooleanType,DateType,LongType,StringType

# COMMAND ----------
# Ambiente
env = os.environ.get("DATABRICKS_ENV").lower()

# Catalogo, Schema e Nome da tabela
param_catalogo_gold = f"gold_{env}"
param_schema = "pecas_planejamento_vendas"
param_nome_tabela_gold = 'ft_carteira'

print(f"Tabela: {param_catalogo_gold}.{param_schema}.{param_nome_tabela_gold}")

# COMMAND ----------
df_2098 = spark.table(f"gold_{env}.pecas_planejamento_vendas.demonstrativo_pecas_pendentes")
df_yamaha = spark.table(f"silver_{env}.ext_perfomance.cadastro_yamaha")
df_litros = spark.table(f"silver_{env}.ext_perfomance.litros_yamalube")
df_dolar = spark.table(f"silver_{env}.banco_central.valor_dolar")
df_rpt_75 = spark.table(f"gold_{env}.corporativo.item_planejamento_inventario")

# COMMAND ----------
df_2098 = (
    df_2098
    .drop('TP_TIPO_FISCAL_ITEM')  
    .withColumn('DS_CATEGORIA_GPS', F.regexp_replace(F.col('DS_CATEGORIA_GPS'), "\\.Y", ""))
    .withColumn('DS_CATEGORIA_GPS', F.regexp_replace(F.col('DS_CATEGORIA_GPS'), "\\.N", ""))
    .withColumn('DS_CATEGORIA_GPS', F.regexp_replace(F.col('DS_CATEGORIA_GPS'), "SENSITIVE", "CAPTIVE"))
    .withColumnRenamed("QT_BO", "QT_BO")
    .withColumnRenamed("VL_BO", "VL_BO")
    .withColumnRenamed("QT_AE", "QT_AWAITING_PICKING")
    .withColumnRenamed("VL_AE", "VL_AWAITING_PICKING")
    .withColumnRenamed("QT_SEP", "QT_PICKING")
    .withColumnRenamed("VL_SEP", "VL_PICKING")
    .withColumnRenamed("QT_RET", "QT_CREDIT_RETENTION")
    .withColumnRenamed("VL_RET", "VL_CREDIT_RETENTION")
    .withColumn("DT_DATA_PEDIDO", F.date_format(F.col("DT_DATA_PEDIDO"), "yyyy-MM-dd"))
    .withColumn("ID_CALENDARIO", F.date_format(F.col("DT_DATA_PEDIDO"), "yyyyMMdd"))
)

# COMMAND ----------
df_rpt_75 = df_rpt_75.withColumnRenamed("ITEM", "CD_ITEM")
df_2098 = df_2098.withColumnRenamed("DS_ITEM", "CD_ITEM")

df_final = (
    df_2098
    .join(
        df_rpt_75.select(

            col("CD_ITEM"),  # Renomeando para corresponder ao campo de junção
            "PLANEJADOR",
            "MIDDLE_GROUP_NAME",
            "CATEGORIA_DE_PRECO",
            "TIPO_FISCAL_ITEM"
        ),
        on="CD_ITEM",
        how="left"
    )
)

# COMMAND ----------
table = f"{param_catalogo_gold}.{param_schema}.{param_nome_tabela_gold}"
print(f"Escrevendo a tabela {table}")

(
    df_final
    .write
    .format("delta")
    .mode("overwrite")
    .partitionBy("year", "month")
    .option("overwriteSchema", "true")
    .saveAsTable(table)
)


