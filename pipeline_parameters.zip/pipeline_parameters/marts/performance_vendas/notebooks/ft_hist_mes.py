# Databricks notebook source
# MAGIC %md
# MAGIC - `Criado por:`  Malco Alves
# MAGIC - `Data Criação:` 13-03-2025
# MAGIC - `Atualizado por:` Malco Alves 
# MAGIC - `Data Atualização:` 19-05-2025

# COMMAND ----------

# MAGIC %md ### Import bibliotecas

# COMMAND ----------

import pyspark.sql.functions as F
import requests
import tempfile
import os
from delta.tables import *

from io import StringIO
from pyspark.sql.types import IntegerType,BooleanType,DateType,LongType,StringType
from pyspark.sql.functions import col

# COMMAND ----------

# MAGIC %md ### Método de otimização

# COMMAND ----------

def optimize_delta_table(table_path):
    """
        @param: IN table_path
        Run optimization commands and old snapshots
        Full load
    """
    deltaTable = DeltaTable.forPath(spark, table_path)
    deltaTable.vacuum()
    deltaTable.optimize().executeCompaction()
    print('Delta table optimized.') 

def get_env():
    return os.environ.get("DATABRICKS_ENV")

# COMMAND ----------

# MAGIC %md ### Variáveis

# COMMAND ----------


env = get_env()
param_catalogo_gold = f"gold_{env}"
param_schema = "pecas_planejamento_vendas"
param_nome_tabela_gold = 'ft_hist_mes'

env = os.environ.get("DATABRICKS_ENV").lower()

# COMMAND ----------

# MAGIC %md ### Leitura tabelas

# COMMAND ----------

df_2098   = spark.table(f'gold_{env}.pecas_planejamento_vendas.relatorio_2098') 
df_yamaha = spark.table(f'silver_{env}.ext_perfomance.cadastro_yamaha') 
df_litros = spark.table(f'silver_{env}.ext_perfomance.litros_yamalube')
df_rpt_75 = spark.table(f'gold_{env}.corporativo.item_planejamento_inventario')

# COMMAND ----------

df_hist_mes = (
    df_2098
    .filter((F.col('PRIORIDADE_ENTREGA') != 'CANCELAMENTO') & (F.col('QT_FATURADO') != 0))
    .drop('REGIAO','TIPO','NOME_CLIENTE','CNPJ/CPF','CIDADE',
          'TIPO_ORG','GRUPO_GE','QT_PEDIDO','VL_PEDIDO','QT_BO',
          'VL_BO','QT_AE','VL_AE','QT_SEP','VL_SEP',
          'QT_RET','VL_RET','QT_CANC','VL_CANC','VL_FATURADO',
          'VL_IPI','VL_SEM_IPI','VL_SEM_ICMS_ST','VL_ICMS_ST','VL_FCP',
          'QT_DEVOLVIDO','VL_DEVOLVIDO','FRETE','SEGURO','CATEGORIA',
          'PLANEJADOR','PL','VOLUME','TIPO_FRETE','PEDIDO',
          'TIPO_FISCAL_ITEM')
    .withColumn('CATEGORIA_PRECO', F.regexp_replace(F.col('CATEGORIA_PRECO'), "\\.Y",""))
    .withColumn('CATEGORIA_PRECO', F.regexp_replace(F.col('CATEGORIA_PRECO'), "\\.N",""))
    .withColumn('CNPJ', F.regexp_replace(F.col('CNPJ'), "/",""))
    .withColumn('CNPJ', F.regexp_replace(F.col('CNPJ'), "-",""))
    .withColumn('CATEGORIA_PRECO', F.regexp_replace(F.col('CATEGORIA_PRECO'), "SENSITIVE","CAPTIVE"))
)

# COMMAND ----------

df_hist_mes = (
    df_hist_mes.alias('a')
    .join(df_litros.alias('b'), [F.col('a.ITEM') == F.col('b.ITEM')], how='left')
    .withColumn('VOLUME', F.when(F.col('b.VOLUME').isNull(), F.lit(1)).otherwise(F.col('b.VOLUME')))
    .withColumn('QT_ITEM', F.col('a.QT_FATURADO') * F.col('VOLUME'))
    .withColumn('DS_ITEM', F.col('a.ITEM'))
    .drop('ITEM','DESCRIÇÃO','CLASSE','Coluna1','Coluna2')
)

# COMMAND ----------

df_yamaha = (df_yamaha.withColumnRenamed("cnpj", "CD_YAMAHA")
             .withColumnRenamed("razao_social", "DS_YAMAHA"))

df_hist_mes = (
    df_hist_mes.alias('a')
    .join(df_yamaha.alias('c'), [F.col('a.CNPJ') == F.col('c.CD_YAMAHA')], how='left')
    .withColumn('DS_YAMAHA', F.col('c.DS_YAMAHA'))
    .withColumnRenamed('CNPJ', 'DEALER_CNPJ')
    .withColumn("Personalizar", F.when(F.col("ESTADO") == "EX", "EXPORT")
                                .when(F.col("PRIORIDADE_ENTREGA").contains("RECALL"), "RECALL")
                                .when(F.col("DS_YAMAHA").isNotNull(), "INTERCOMPANY") 
                                .when(F.col("PRIORIDADE_ENTREGA") == "YAL PC", "YAL")  
                                .when(F.col("PRIORIDADE_ENTREGA") == "eCommerce", "BLU STORE") 
                                .when(F.col("PRIORIDADE_ENTREGA") == "Funcionario", "EMPLOYEE")  
                                .when((F.col("SUB_REGIAO").isNotNull()) & (F.col("SUB_REGIAO") != "") &  (F.col("SUB_REGIAO") != " "), "DEALER" )
                                .otherwise("OTHER"))
    .drop('QT_FATURADO', 'CATEGORIA_PRECO', 'NOTA_FISCAL', 'VOLUME', 'DS_YAMAHA', 'CD_YAMAHA','DS_SALES_ORDER')    
    .select('DEALER_CNPJ', 'DS_ITEM', 'Personalizar', 'DATA_PEDIDO', 'DATA_FATURAMENTO', 'QT_ITEM', 'PRIORIDADE_ENTREGA', 'VL_LIQUIDO', 'SUB_REGIAO', 'ESTADO')
    .withColumnRenamed('DEALER_CNPJ','CD_DEALER')
    .withColumnRenamed('DS_ITEM',('CD_ITEM'))
    .withColumnRenamed('Personalizar',('DS_CANAL'))
    .withColumnRenamed('DATA_PEDIDO',('DT_PED'))
    .withColumnRenamed('DATA_FATURAMENTO',('DT_FAT'))
    .withColumnRenamed('PRIORIDADE_ENTREGA',('DS_PRIORIDADE'))
    .withColumnRenamed('VL_LIQUIDO',('VL_ITEM'))
    .withColumnRenamed('SUB_REGIAO',('DS_SUB_REGIAO'))
    .withColumnRenamed('ESTADO',('DS_ESTADO'))
)

# COMMAND ----------

df_rpt_75 = df_rpt_75.withColumnRenamed("ITEM", "CD_ITEM")

# COMMAND ----------

# .withColumn('ID_CALENDARIO', F.year('DT_PED') * 10000 + F.month('DT_PED') * 100 + F.day('DT_PED'))

# Realiza o join entre os dataframes
df_hist_mes = (
    df_hist_mes
    .withColumn("CD_DEALER", F.when(F.col("CD_DEALER") == "4561957001130", "14024658000652").otherwise(F.col("CD_DEALER")))
    .withColumn('ID_CALENDARIO', F.date_format(F.col('DT_PED'), 'yyyyMMdd').cast('int'))
    .filter(F.col("DS_PRIORIDADE") != "")
    .filter(F.col("DT_FAT").isNotNull())
    .join(df_rpt_75.select(
        "CD_ITEM", 
        "CATEGORIA_DE_PRECO", 
        "MIDDLE_GROUP_NAME", 
        "TIPO_FISCAL_ITEM", 
        "PLANEJADOR"
    ), on="CD_ITEM", how="left")
)

# COMMAND ----------

df_final = df_hist_mes.withColumn("year", F.year("DT_PED")).withColumn("month", F.month("DT_PED"))

# COMMAND ----------

table = f"{param_catalogo_gold}.{param_schema}.{param_nome_tabela_gold}"
print(f"Escrevendo a tabela {table}")

(
    df_final
    .write
    .format("delta")
    .mode("overwrite")
    .partitionBy("year", "month")
    .option("overwriteSchema", "true")
    .saveAsTable(table)
)