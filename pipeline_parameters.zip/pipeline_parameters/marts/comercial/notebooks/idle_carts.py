# Databricks notebook source
# Tabela criada a partir dos dados de carrinho abandonado de origem do SQL Server

# COMMAND ----------

# Criado por Vinicius Geada em 07/08/25
# Atualizado por 

# COMMAND ----------

# MAGIC %md
# MAGIC ### Imports

# COMMAND ----------

# Importação das bibliotecas necessárias para a execução do código
import os
from os import getenv
from pyspark.sql.functions import *
from delta.tables import *
from pyspark.sql.types import *

# COMMAND ----------

# MAGIC %md
# MAGIC ### Variables

# COMMAND ----------

# Get env values
env = os.environ.get("DATABRICKS_ENV")
env = env.lower()

# COMMAND ----------

# Lineage
param_schema_silver = 'genki_dama_marketplace_occ'
param_schema_gold = 'comercial_planejamento_comercial'
silver_catalog = f'silver_{env}'
gold_catalog = f'gold_{env}'

# Nome da tabela
param_nome_tabela = 'idle_carts'

# COMMAND ----------

# MAGIC %md
# MAGIC ### Reading the table in the Silver layer

# COMMAND ----------

df_gold = spark.read.table(f'{silver_catalog}.{param_schema_silver}.{param_nome_tabela}')

# COMMAND ----------

# MAGIC %md
# MAGIC ### Rename columns to uppercase

# COMMAND ----------

df_gold = df_gold.toDF(*[col.upper() for col in df_gold.columns])

# COMMAND ----------

# MAGIC %md
# MAGIC ### Writing Gold

# COMMAND ----------

(
    df_gold
    .write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f'{gold_catalog}.{param_schema_gold}.{param_nome_tabela}')
)
