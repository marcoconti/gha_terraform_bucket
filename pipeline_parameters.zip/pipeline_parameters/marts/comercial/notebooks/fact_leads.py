# Databricks notebook source
# Tabela criada a partir da query vw_pcom_fact_leads, visando obter maior performance na consulta dos dados

# COMMAND ----------

# Criado por Vinicius Geada em 22/04/25
# Atualizado por Vinicius Geada em 06/08/25

# COMMAND ----------

# MAGIC %md
# MAGIC ### Imports

# COMMAND ----------

# Importação das bibliotecas necessárias para a execução do código
import os
from os import getenv
from pyspark.sql.functions import *
from delta.tables import *
from pyspark.sql.types import *

# COMMAND ----------

# MAGIC %md
# MAGIC ### Variables

# COMMAND ----------

# Get env values
env = os.environ.get("DATABRICKS_ENV")
env = env.lower()

# COMMAND ----------

# Lineage
param_schema = 'comercial_planejamento_comercial'
gold_catalog = f'gold_{env}'

# Nome da tabela
param_nome_tabela = 'fact_leads'

# COMMAND ----------

# MAGIC %md
# MAGIC ### Code

# COMMAND ----------

# ========================================================================
# Nome da Consulta: vw_fact_leads
# Descrição: Listagem de leads e análises quanto à conversão.
# Autor: Rubens Martins Junior / Aline Alves Arantes
# Área: Planejamento Comercial / Inteligência de Mercado / CRM
# Data de Criação: 2023-10-06
# Última Modificação: 2025-04-17
# Banco de Dados: s_ymdb_gold
# Tabela(s) envolvida(s): 
#    - tb_corp_dm_unidade_negocio
#    - tb_corp_dm_cliente
#    - tb_marketing_lifetime_customer_ft_revisao
#    - tb_marketing_lifetime_customer_ft_inove_lead
#    - tb_marketing_lifetime_customer_ft_lead
# ========================================================================

df_fact_leads = spark.sql(f"""

WITH  

 BU AS (
  SELECT DISTINCT 
    ID_UNIDADE_NEGOCIO,   
    NM_INOVE_EMPRESA,  
    DC_INOVE_CNPJ        
  FROM gold_{env}.corporativo.dm_unidade_negocio
 )

 ,PRODUTO AS (
 SELECT DISTINCT 
  ID_FUT_PRODUTO_YAMAHA_LEADS,
  NM_FUT_PRODUTO
 FROM gold_{env}.corporativo.dm_produto_comercial
 )

 ,CONTACT AS (
 SELECT DISTINCT
    UPPER(ID_CONTATO)                               AS CONTACT_ID  
 ,   UPPER(NM_NOME_COMPLETO)                         AS FULLNAME 
 ,   LOWER(CASE 
      WHEN DS_EMAIL1 IS NULL 
        THEN COALESCE(DS_EMAIL2, DS_EMAIL3)  
      ELSE DS_EMAIL1 
    END)                                            AS EMAILADDRESS  
 ,   REPLACE(
            REPLACE(
                    REPLACE(
                            REPLACE(NR_TELEFONE_CELULAR, '(', '')
                    , ')', '')
            , '-', '')
    , ' ', '')                                      AS MOBILEPHONE  
 ,   NM_ENDERECO1_CIDADE                             AS CITY  
 ,   TRIM(CASE  WHEN DS_ENDERECO1_ESTADO = '100000006'           THEN 'DF'
          WHEN DS_ENDERECO1_ESTADO = '100000007'                THEN 'ES'
          WHEN DS_ENDERECO1_ESTADO = '100000003'                THEN 'AP'
          WHEN DS_ENDERECO1_ESTADO = '100000009'                THEN 'MA'
          WHEN DS_ENDERECO1_ESTADO = '100000015'                THEN 'PE'
          WHEN DS_ENDERECO1_ESTADO = '100000013'                THEN 'PA'
          WHEN DS_ENDERECO1_ESTADO = '100000002'                THEN 'AM'
          WHEN DS_ENDERECO1_ESTADO = '100000012'                THEN 'MT'
          WHEN DS_ENDERECO1_ESTADO = '100000000'                THEN 'AC'
          WHEN DS_ENDERECO1_ESTADO = '100000026'                THEN 'SP'
          WHEN DS_ENDERECO1_ESTADO = '100000004'                THEN 'BA'
          WHEN DS_ENDERECO1_ESTADO = '100000024'                THEN 'SC'
          WHEN DS_ENDERECO1_ESTADO = '100000027'                THEN 'TO'
          WHEN DS_ENDERECO1_ESTADO = '100000022'                THEN 'RR'
          WHEN DS_ENDERECO1_ESTADO = '100000005'                THEN 'CE'
          WHEN DS_ENDERECO1_ESTADO = '100000011'                THEN 'MS'
          WHEN DS_ENDERECO1_ESTADO = '100000001'                THEN 'AL'
          WHEN DS_ENDERECO1_ESTADO = '100000018'                THEN 'PR'
          WHEN DS_ENDERECO1_ESTADO = '100000014'                THEN 'PB'
          WHEN DS_ENDERECO1_ESTADO = '100000021'                THEN 'RO'
          WHEN DS_ENDERECO1_ESTADO = '100000016'                THEN 'PI'
          WHEN DS_ENDERECO1_ESTADO = '100000025'                THEN 'SE'
          WHEN DS_ENDERECO1_ESTADO = '100000010'                THEN 'MG'
          WHEN DS_ENDERECO1_ESTADO = '100000008'                THEN 'GO'
          WHEN DS_ENDERECO1_ESTADO = '100000020'                THEN 'RN'
          WHEN DS_ENDERECO1_ESTADO = '100000019'                THEN 'RJ'
          WHEN DS_ENDERECO1_ESTADO = '100000017'                THEN 'RS'
          WHEN DS_ENDERECO1_ESTADO = 'ACRE'                     THEN 'AC'
          WHEN DS_ENDERECO1_ESTADO = 'ALAGOAS'                  THEN 'AL'
          WHEN DS_ENDERECO1_ESTADO = 'AMAZONAS'                 THEN 'AM'
          WHEN DS_ENDERECO1_ESTADO = 'AMAPA'                    THEN 'AP'
          WHEN DS_ENDERECO1_ESTADO = 'BAHIA'                    THEN 'BA'
          WHEN DS_ENDERECO1_ESTADO = 'CEARA'                    THEN 'CE'
          WHEN DS_ENDERECO1_ESTADO = 'GOIÁS'                    THEN 'GO'
          WHEN DS_ENDERECO1_ESTADO = 'ESPÍRITO SANTO'           THEN 'ES'   
          WHEN DS_ENDERECO1_ESTADO = 'MARANHÃO'                 THEN 'MA'       
          WHEN DS_ENDERECO1_ESTADO = 'MATO GROSSO'              THEN 'MT'
          WHEN DS_ENDERECO1_ESTADO = 'CEARÁ'                    THEN 'CE'
          WHEN DS_ENDERECO1_ESTADO = 'CEARA'                    THEN 'CE'
          WHEN DS_ENDERECO1_ESTADO = 'MOTO GROSSO DO SUL'       THEN 'MS'
          WHEN DS_ENDERECO1_ESTADO = 'MINAS GERAIS'             THEN 'MG'
          WHEN DS_ENDERECO1_ESTADO = 'PARÁ'                     THEN 'PA'
          WHEN DS_ENDERECO1_ESTADO = 'PARANÁ'                   THEN 'PR'
          WHEN DS_ENDERECO1_ESTADO = 'PARANA'                   THEN 'PR'
          WHEN DS_ENDERECO1_ESTADO = 'PIAUI'                    THEN 'PI'
          WHEN DS_ENDERECO1_ESTADO = 'PIAUÍ'                    THEN 'PI'
          WHEN DS_ENDERECO1_ESTADO = 'PARAÍBA'                  THEN 'PB'
          WHEN DS_ENDERECO1_ESTADO = 'PERNAMBUCO'               THEN 'PE'
          WHEN DS_ENDERECO1_ESTADO = 'RIO DE JANEIRO'           THEN 'RJ'
          WHEN DS_ENDERECO1_ESTADO = 'RIO GRANDE DO NORTE'      THEN 'RN'
          WHEN DS_ENDERECO1_ESTADO = 'RIO GRANDE DO SUL'        THEN 'RS'
          WHEN DS_ENDERECO1_ESTADO = 'RONDÔNIA'                 THEN 'RO'
          WHEN DS_ENDERECO1_ESTADO = 'RORAIMA'                  THEN 'RR'
          WHEN DS_ENDERECO1_ESTADO = 'SÃO PAULO'                THEN 'SP'
          WHEN DS_ENDERECO1_ESTADO = 'SAO PAULO'                THEN 'SP'
          WHEN DS_ENDERECO1_ESTADO = 'SÃ'                       THEN 'SP'
          WHEN DS_ENDERECO1_ESTADO = 'SERGIPE'                  THEN 'SE'
          WHEN DS_ENDERECO1_ESTADO = 'SALVADOR'                 THEN 'BA'
          WHEN DS_ENDERECO1_ESTADO = 'SANTA CATARINA'           THEN 'SC'
          WHEN DS_ENDERECO1_ESTADO = 'VINHEDO'                  THEN 'SP'
          WHEN DS_ENDERECO1_ESTADO = 'TOCANTINS'                THEN 'TO'
          WHEN DS_ENDERECO1_ESTADO = '0'                        THEN NULL
        
        ELSE DS_ENDERECO1_ESTADO     END)           AS STATE  
 ,   CASE 
        WHEN LENGTH(REPLACE(
                            REPLACE(
                                    REPLACE(DC_YMDB_CPF, '.', '')
                            , '-', '')
            , '/')) <= 11 
        THEN RIGHT(CONCAT('00000000000', REPLACE(
                                                  REPLACE(
                                                            REPLACE(DC_YMDB_CPF, '.', '')
                                                  , '-', '')
                                         , '/')), 11)
        ELSE  RIGHT(CONCAT('00000000000000', REPLACE(
                                                      REPLACE(
                                                              REPLACE(DC_YMDB_CPF, '.', '')
                                                      , '-', '')
                                              , '/')), 14)
    END                                               AS CPF  
  FROM gold_{env}.corporativo.dm_cliente
 )

 ,NF_VENDA AS (
 SELECT DISTINCT
     DT_NF_CONCESS
 ,    NR_CNPJ                                        AS CNPJ_REVISAO
 ,    NR_DESTINATARIO_CNPJ_CPF                       AS CPF_CLIENTE
 ,    NR_CHASSI_COMPLETO                             AS NR_YMDB_CHASSICOMPLETO
 ,    DS_DESCRICAO                                   AS PRODUTO_NF
 ,    LEFT(
        CONCAT('00000000',REPLACE(REPLACE(NR_CEP,'-',''),'-','') )
    ,8)                                             AS NR_CEP
 ,    CD_PRODUTO
 ,    NR_NF_YAMAHA
 ,    SUM(QT_QUANT)                                  AS QT_QUANT
 ,    SUM(VL_PRODUTO_CONCESSIONARIA)                 AS VL_PRODUTO_CONCESSIONARIA
 FROM gold_{env}.comercial_planejamento_comercial.notas_concessionarias
 WHERE DATEDIFF(YEAR,CURRENT_DATE(),DT_NF_CONCESS) <= 3
      AND LEFT(NR_CHASSI_COMPLETO, 3) IN ('9C6','JYA')
 GROUP BY 1,2,3,4,5,6,7,8
 )

 ,LEAD_CLOSE AS (
 SELECT DISTINCT 
    ID_CONTACTID
 ,   UPPER(A.id_inove_lead)                          AS LEAD_ID   
 ,   CASE WHEN A.inove_lossreason = 714810004 THEN 'Test Ride Indisponível' 
         WHEN A.inove_lossreason = 100000002 THEN 'Cliente Ausente'
         WHEN A.inove_lossreason = 714810010 THEN 'Desistência'
         WHEN A.inove_lossreason = 714810012 THEN 'Desistência'
         WHEN A.inove_lossreason = 714810006 THEN 'Financeiro'
         WHEN A.inove_lossreason = 714810008 THEN 'Financeiro'
         WHEN A.inove_lossreason = 714810007 THEN 'Financeiro'
         WHEN A.inove_lossreason = 100000001 THEN 'Estoque'
         WHEN A.inove_lossreason = 714810002 THEN 'Erro Cadastro'
         WHEN A.inove_lossreason = 714810011 THEN 'Financeiro'
         WHEN A.inove_lossreason = 714810003 THEN 'Estoque'
         WHEN A.inove_lossreason = 714810001 THEN 'Cliente Ausente'
         WHEN A.inove_lossreason = 714810005 THEN 'Desistência'
         WHEN A.inove_lossreason = 714810000 THEN 'Cliente Ausente'
         WHEN A.inove_lossreason = 714810009 THEN 'Desistência'
         WHEN A.inove_lossreason = 100000000 THEN 'Erro Cadastro'
    END                                             AS grupolossreason
 ,   B.CPF                                           AS cpf 
 FROM gold_{env}.comercial_planejamento_comercial.ft_inove_lead  A
  LEFT JOIN (
    SELECT DISTINCT 
      CONTACT_ID,
      CPF  
    FROM CONTACT
  ) B
    ON UPPER(a.ID_CONTACTID) = UPPER(b.CONTACT_ID)
 )

 ,CCY AS (
 SELECT DISTINCT
 NM_ABREVIADO_EMPRESA,
 RIGHT(CONCAT('00000000000000',DC_CNPJ_SEM_PONTUACAO),14) AS NR_CNPJ_SEM_PONTUACAO_AJ,
 NM_GRUPO
 FROM gold_{env}.corporativo.dm_concessionaria
 )


 ,INTERESSE_LEAD AS (
 SELECT DISTINCT 
    INTE.ID_CONTACTID                                                         AS CONTACT_ID  
 ,   CAST(DATE_ADD(HOUR, -3, INTE.dt_createdon_sysuser) AS DATE)               AS CREATEDON 
 ,   DATE_FORMAT(dt_modifiedon_sysuser, 'yyyy-MM-dd HH:mm:ss')                 AS MODIFIEDON
 ,   CAST(DATE_ADD(HOUR, -3, INTE.dt_createdon_sysuser) AS DATE)               AS DATA_LEAD
 ,   EXTRACT(HOUR FROM DATE_ADD(HOUR, -3, INTE.dt_createdon_sysuser))          AS HORA  
 ,   UPPER(PD.NM_FUT_PRODUTO)                                                  AS PRODUCT_NAME      
 ,   INTE.DS_STATUSCODE_NAME                                                   AS STATUS_CODE_NAME  
 ,   IFNULL(INTE.fut_pl_origem,1)                                              AS ORIGEM
 ,   RIGHT(CONCAT('00000000000000', BU.DC_INOVE_CNPJ), 14)                     AS CNPJCONCESSIONARIACCY   
 ,   CASE WHEN LENGTH(REPLACE(REPLACE(REPLACE(IFNULL(CT.cpf,INTE.fut_st_cepclientepotencial),'-',''),'.',''),'/','')) <= 11
            THEN RIGHT(CONCAT('00000000000',REPLACE(REPLACE(REPLACE(IFNULL(CT.cpf,INTE.fut_st_cepclientepotencial),'-',''),'.',''),'/','')),11)
         ELSE RIGHT(CONCAT('00000000000000',REPLACE(REPLACE(REPLACE(IFNULL(CT.cpf,INTE.fut_st_cepclientepotencial),'-',''),'.',''),'/','')),14)
    END                                                                       AS CPF_CLIENTEPOTENCIAL   

 ,   CASE WHEN LENGTH(REPLACE(REPLACE(REPLACE(COALESCE(IFNULL(LC.cpf,INTE.fut_st_cpfdocomprador),CPF_CLIENTEPOTENCIAL),'-',''),'.',''),'/','')) <= 11
            THEN RIGHT(CONCAT('00000000000',REPLACE(REPLACE(REPLACE(COALESCE(IFNULL(LC.cpf,INTE.fut_st_cpfdocomprador),CPF_CLIENTEPOTENCIAL),'-',''),'.',''),'/','')),11)
         ELSE RIGHT(CONCAT('00000000000000',REPLACE(REPLACE(REPLACE(COALESCE(IFNULL(LC.cpf,INTE.fut_st_cpfdocomprador),CPF_CLIENTEPOTENCIAL),'-',''),'.',''),'/','')),14)
    END                                                                       AS CPF_LEAD,  

    CAST(INTE.inove_firstcontacttime AS INTEGER)                              AS TEMPOATENDIMENTO,  
    CASE 
      WHEN UPPER(INTE.ds_statuscode_name) IN ('LEAD DISPONÍVEL', 'AGUARDANDO CONTATO') 
        THEN 'NÃO ATENDIDO'
      ELSE 'ATENDIDO' 
    END                                                                       AS FLAG_ATENDIDO,  
    COALESCE(CAST(INTE.cr638_possuimotocicletaeteminteresseemnegociar AS STRING), 'false') 
                                                                              AS INTERESSE_NEGOCIA,  
    COALESCE(UPPER(INTE.cr638_marcamotocicleta), 'N/A')                       AS MARCA_NEGOCIA_DEPARA,  
    CASE WHEN COALESCE(UPPER(INTE.cr638_modelodamotocicleta), 'N/A') LIKE '%YAMAHA%' THEN 'YAMAHA' 
         WHEN COALESCE(UPPER(INTE.cr638_modelodamotocicleta), 'N/A') LIKE '%HONDA%' THEN 'HONDA'  
         ELSE 'OUTROS'           END                                          AS MODELO_NEGOCIA,  
    CASE WHEN INTE.fut_st_player IS NULL											 
				THEN 'ORGÂNICO' 														 
			  WHEN  LOWER(INTE.fut_st_player) LIKE '%facebook%' 
			  	OR  LOWER(INTE.fut_st_player) LIKE '%meta%' 
			  	OR  LOWER(INTE.fut_st_player) LIKE '%instagram%'							    THEN 'META'															 
			  WHEN  LOWER(INTE.fut_st_player) LIKE '%google%'							        THEN 'GOOGLE'	
			   WHEN LOWER(INTE.fut_st_player) LIKE '%site%'							          THEN 'SITE' 
			  WHEN  LOWER(INTE.fut_st_player) LIKE '%tiktok%'							        THEN 'TIKTOK'
			  WHEN  LOWER(INTE.fut_st_player) LIKE '%linkin%'							        THEN 'OUTROS'
			  WHEN  LOWER(INTE.fut_st_player) LIKE '%responsys%'							    THEN 'OUTROS'
			  WHEN  LOWER(INTE.fut_st_player) LIKE '%mobills%'							      THEN 'OUTROS'
			  WHEN  LOWER(INTE.fut_st_player) LIKE '%criteo%'							        THEN 'OUTROS'
			  WHEN  LOWER(INTE.fut_st_player) LIKE '%webmotors%'							    THEN 'WEBMOTORS'
			   ELSE 'OUTROS' END										 	                            AS CANAL,	
    CASE WHEN LEFT(SUBSTRING(UPPER(fut_st_canalplayer),CHARINDEX('YH',UPPER(fut_st_canalplayer)),7),2) = 'YH' 
				THEN SUBSTRING(UPPER(fut_st_canalplayer),CHARINDEX('YH',UPPER(fut_st_canalplayer)),7)
				ELSE NULL END 												                              AS CAMPANHA,			
    INTE.fut_st_canalplayer                                                 AS CANAL_PLAYER,  
    INTE.ymdb_tcaenviada                                                    AS TCA_ENVIO,  
    CAST(INTE.ymdb_dataenviotca AS DATE)                                    AS DATA_TCA,  
    LC.grupolossreason                                                      AS LD_LOSS_REASON,
    INTE.fut_interessedoleadid                                              AS LEAD,
    INTE.ds_fut_st_pacmobile                                                AS DS_FUT_ST_PACMOBILE,
    LEFT(CONCAT('00000000',REPLACE(REPLACE(INTE.fut_st_cep,'-',''),'-','')),8)
                                                                            AS DS_FUT_ST_CEP,
    CASE  WHEN fut_pl_estado = '100000006' THEN 'DF'
          WHEN fut_pl_estado = '100000007' THEN 'ES'
          WHEN fut_pl_estado = '100000003' THEN 'AP'
          WHEN fut_pl_estado = '100000009' THEN 'MA'
          WHEN fut_pl_estado = '100000015' THEN 'PE'
          WHEN fut_pl_estado = '100000013' THEN 'PA'
          WHEN fut_pl_estado = '100000002' THEN 'AM'
          WHEN fut_pl_estado = '100000012' THEN 'MT'
          WHEN fut_pl_estado = '100000000' THEN 'AC'
          WHEN fut_pl_estado = '100000026' THEN 'SP'
          WHEN fut_pl_estado = '100000004' THEN 'BA'
          WHEN fut_pl_estado = '100000024' THEN 'SC'
          WHEN fut_pl_estado = '100000027' THEN 'TO'
          WHEN fut_pl_estado = '100000022' THEN 'RR'
          WHEN fut_pl_estado = '100000005' THEN 'CE'
          WHEN fut_pl_estado = '100000011' THEN 'MS'
          WHEN fut_pl_estado = '100000001' THEN 'AL'
          WHEN fut_pl_estado = '100000018' THEN 'PR'
          WHEN fut_pl_estado = '100000014' THEN 'PB'
          WHEN fut_pl_estado = '100000021' THEN 'RO'
          WHEN fut_pl_estado = '100000016' THEN 'PI'
          WHEN fut_pl_estado = '100000025' THEN 'SE'
          WHEN fut_pl_estado = '100000010' THEN 'MG'
          WHEN fut_pl_estado = '100000008' THEN 'GO'
          WHEN fut_pl_estado = '100000020' THEN 'RN'
          WHEN fut_pl_estado = '100000019' THEN 'RJ'
          WHEN fut_pl_estado = '100000017' THEN 'RS'
          WHEN fut_pl_estado = '0' THEN NULL
        ELSE fut_pl_estado     END                                         AS NR_FUT_PL_ESTADO,
    UPPER(fut_st_cidade)                                                   AS DS_FUT_CIDADE  
  FROM gold_{env}.comercial_planejamento_comercial.ft_lead AS INTE
  LEFT JOIN (SELECT DISTINCT 
              CONTACT_ID,
              CPF  
            FROM CONTACT) CT
    ON UPPER(CT.CONTACT_ID) = UPPER(INTE.id_contactid)
  LEFT JOIN BU 
    ON INTE.id__businessunitid_value = BU.ID_UNIDADE_NEGOCIO  
  LEFT JOIN LEAD_CLOSE LC
    ON UPPER(INTE.fut_interessedoleadid) = UPPER(LC.LEAD_ID)  
  LEFT JOIN PRODUTO PD
    ON UPPER(PD.ID_FUT_PRODUTO_YAMAHA_LEADS) = UPPER(INTE.ds_fut_lk_produto_value)
  WHERE DATEDIFF(YEAR,CURRENT_DATE(),CAST(DATE_ADD(HOUR, -3, INTE.dt_createdon_sysuser) AS DATE)) <= 3

 ) 

 SELECT DISTINCT
    INTE.* EXCEPT (CONTACT_ID,DS_FUT_ST_CEP,DS_FUT_CIDADE,NR_FUT_PL_ESTADO)
 ,   TRIM(COALESCE(NR_FUT_PL_ESTADO,CT.STATE))                             AS UF
 ,   COALESCE(INTE.DS_FUT_CIDADE,CT.CITY)                                  AS DS_CIDADE
 ,   CT.* EXCEPT (CONTACT_ID, CPF, STATE, CITY) 
 ,   REV.*
 ,   CASE WHEN REV.DT_NF_CONCESS IS NOT NULL THEN 'CONVERTIDO' ELSE 'NÃO CONVERTIDO' END AS TIPO_LEAD
 ,   DATEDIFF(DAY,INTE.CREATEDON,REV.DT_NF_CONCESS)                                      AS TEMPO_CONVERSAO
 ,   CL.NM_GRUPO                                                                         AS GRUPO_LEAD
 ,   CN.NM_GRUPO                                                                         AS GRUPO_NF

  FROM INTERESSE_LEAD INTE
  LEFT JOIN NF_VENDA REV
    ON UPPER(INTE.CPF_LEAD) = UPPER(REV.CPF_CLIENTE)  
    AND CAST(INTE.CREATEDON AS DATE) <= CAST(DT_NF_CONCESS AS DATE)
  LEFT JOIN CONTACT CT
    ON UPPER(CT.CONTACT_ID) = UPPER(INTE.CONTACT_ID)
  LEFT JOIN CCY CL
    ON CL.NR_CNPJ_SEM_PONTUACAO_AJ = INTE.CNPJCONCESSIONARIACCY
  LEFT JOIN CCY CN
    ON CN.NR_CNPJ_SEM_PONTUACAO_AJ = REV.CNPJ_REVISAO

""")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Writing Gold

# COMMAND ----------

(
    df_fact_leads
    .write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f'{gold_catalog}.{param_schema}.{param_nome_tabela}')
)
