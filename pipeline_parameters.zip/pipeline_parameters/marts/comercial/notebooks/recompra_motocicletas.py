# Databricks notebook source
# Tabela criada a partir da query vw_pcom_fact_recompra_motocicletas, visando obter maior performance na consulta dos dados

# COMMAND ----------

# Criado por Vinicius Geada em 22/04/25
# Atualizado por Vinicius Geada em 06/08/25

# COMMAND ----------

# MAGIC %md
# MAGIC ### Imports

# COMMAND ----------

# Importação das bibliotecas necessárias para a execução do código
import os
from os import getenv
from pyspark.sql.functions import *
from delta.tables import *
from pyspark.sql.types import *

# COMMAND ----------

# MAGIC %md
# MAGIC ### Variables

# COMMAND ----------

# Get env values
env = os.environ.get("DATABRICKS_ENV")
env = env.lower()

# COMMAND ----------

# Lineage
param_schema = 'comercial_planejamento_comercial'
gold_catalog = f'gold_{env}'

# Nome da tabela
param_nome_tabela = 'recompra_motocicletas'

# COMMAND ----------

# MAGIC %md
# MAGIC ### Code

# COMMAND ----------

# ========================================================================================================
# == Nome da Consulta: vw_fact_recompra_motocicletas                                                    ==
# == Descrição: Listagem de clientes de motocicletas que realizaram recompras em um período específico  ==
# == Autor: Rubens Martins Junior                                                                       ==
# == Área: Planejamento Comercial / Inteligência de Mercado / CRM                                       ==
# == Data de Criação: 2024-12-05                                                                        ==
# == Última Modificação: 2025-04-03                                                                     ==
# == Banco de Dados: s_ymdb_gold                                                                        ==
# == Tabela(s) envolvida(s): tb_marketing_lifetime_customer_notas_concessionarias                       ==
# ========================================================================================================

df_recompra_motocicletas = spark.sql(f"""

WITH  

BASE_XML AS (
SELECT DISTINCT
     DT_NF_CONCESS
,    NR_DESTINATARIO_CNPJ_CPF
,    CASE WHEN LEN(NR_DESTINATARIO_CNPJ_CPF) <= 11 
            THEN 'CPF' ELSE 'CNPJ'          END   AS TP_CLIENTE
,    NR_CNPJ
,    NR_CHASSI_COMPLETO
,    DS_DESCRICAO
,    NR_CEP
,    CD_PRODUTO
,    NR_NF_YAMAHA
,    SUM(QT_QUANT)                                AS QT_QUANT
,    SUM(VL_PRODUTO_CONCESSIONARIA)               AS VL_PRODUTO_CONCESSIONARIA
FROM gold_{env}.comercial_planejamento_comercial.notas_concessionarias
WHERE DT_NF_CONCESS >= '2016-01-01'                                                  -- registros a partir de 2012
      AND LEFT(NR_CHASSI_COMPLETO, 3) IN ('9C6','JYA')                               -- somente motocicletas
    --AND LEN(NR_DESTINATARIO_CNPJ_CPF) <= 11                                        -- somente CPF
GROUP BY 1,2,3,4,5,6,7,8,9
)

,NOTAS_XML AS (                                                                     -- Análise das datas de compras por cliente, agrupada por CPF e ordenado por data 
SELECT DISTINCT
     DT_NF_CONCESS
,    NR_DESTINATARIO_CNPJ_CPF
,    DENSE_RANK()                  OVER (PARTITION BY NR_DESTINATARIO_CNPJ_CPF ORDER BY DT_NF_CONCESS ASC)         AS ROW_NUM               -- ordenação das linhas conforme partição (data da venda)
,    FIRST_VALUE(DT_NF_CONCESS)    OVER (PARTITION BY NR_DESTINATARIO_CNPJ_CPF ORDER BY DT_NF_CONCESS ASC)         AS DT_FIRST_PURCHASE     -- Data da primeira compra, ordenado por data, conforme partição
,    LEAD(DT_NF_CONCESS)           OVER (PARTITION BY NR_DESTINATARIO_CNPJ_CPF ORDER BY DT_NF_CONCESS ASC)         AS DT_NEXT_PURCHASE      -- Data da próxima compra, ordenado por data, conforme partição
,    LAG(DT_NF_CONCESS)            OVER (PARTITION BY NR_DESTINATARIO_CNPJ_CPF ORDER BY DT_NF_CONCESS ASC)         AS DT_PRV_PURCHASE       -- Data da compra anterior
,    LEAD(DS_DESCRICAO)            OVER (PARTITION BY NR_DESTINATARIO_CNPJ_CPF ORDER BY DT_NF_CONCESS ASC)         AS MODELO_RECOMPRA       -- Modelo próxima compra
FROM BASE_XML
)

,REVISOES AS (
SELECT DISTINCT
    YMDB_CPF_CNPJ,
    YMDB_CHASSICOMPLETO,
    MAX(CAST(YMDB_DATAREVISAO AS DATE))  AS LAST_REVISION_DATE,
    COUNT(DISTINCT YMDB_REVISOESID)      AS NR_REVISOES
FROM gold_{env}.comercial_planejamento_comercial.ft_revisao
WHERE CR638_TIPODEREGISTRO <> 'VENDA'
GROUP BY 1,2
)

SELECT DISTINCT
     A.DT_NF_CONCESS
,    A.DT_FIRST_PURCHASE  
,    A.DT_NEXT_PURCHASE
,    A.NR_DESTINATARIO_CNPJ_CPF
,    D.TP_CLIENTE
,    A.ROW_NUM                                       
,    D.CD_PRODUTO
,    D.DS_DESCRICAO                                     AS MODELO_COMPRA
,    A.MODELO_RECOMPRA             
,    D.NR_CHASSI_COMPLETO
,    D.NR_CEP
,    D.NR_NF_YAMAHA
,    D.NR_CNPJ
,    E.QT_QUANT
,    E.VL_PRODUTO_CONCESSIONARIA
-- Cálculos de dias
,    DATE_DIFF(DAY,A.DT_FIRST_PURCHASE,A.DT_NF_CONCESS) AS NR_DAYS_FIRSTPURCHASE        -- Diferença entre a compra e a primeira compra, dias para recomprar após a primeira compra
,    DATE_DIFF(DAY,A.DT_NF_CONCESS,A.DT_NEXT_PURCHASE)  AS NR_DAYS_REPURCHASE           -- Diferença entre a compra e a compra , Dias entre as recompras
,    DATE_DIFF(DAY,A.DT_NF_CONCESS,CURRENT_DATE())      AS NR_DAYS_SINCE_PURCHASE       -- Dias após a última compra, recência
,    DATE_DIFF(DAY,A.DT_FIRST_PURCHASE,CURRENT_DATE())  AS NR_DAYS_SINCE_FIRSTPURCHASE  -- Dias após primeira recompra, tempo como cliente
-- Determinação do caminho de compra

--,    CASE 
--     WHEN A.ROW_NUM = 1 THEN                                                            -- Relativo à primeira compra (se gerou ou não recompra)
--        CASE 
--            WHEN DT_NEXT_PURCHASE IS NULL THEN 'No Repurchase'                          -- Cliente não realizou recompra (compra única)
--            ELSE 'First Purchase'                                                       -- Indica que foi a primeira compra
--        END
--     WHEN A.ROW_NUM = 2 THEN                                                            -- Relativo à primeira Recompra
--        CASE
--            WHEN NR_DAYS_FIRSTPURCHASE <= 365   THEN 'Conversion 365'                   -- Relativo à primeira recompra ter ocorrido no período de 365 dias
--            WHEN NR_DAYS_FIRSTPURCHASE <= 730   THEN 'Conversion 730'                   -- Relativo à primeira recompra ter ocorrido no período de 730 dias
--            WHEN NR_DAYS_FIRSTPURCHASE <= 1095  THEN 'Conversion 1095'                  -- Relativo à primeira recompra ter ocorrido no período de 1095 dias
--            WHEN NR_DAYS_FIRSTPURCHASE <= 1460  THEN 'Conversion 1460'                  -- Relativo à primeira recompra ter ocorrido no período de 1460 dias
--            WHEN NR_DAYS_FIRSTPURCHASE <= 1825  THEN 'Conversion 1825'                  -- Relativo à primeira recompra ter ocorrido no período de 1825 dias
--            ELSE 'Conversion 1825+'                                                     -- Relativo à primeira recompra ter ocorrido no período de 1825+ dias
--        END
--      ELSE 
,    CASE
--          WHEN NR_DAYS_REPURCHASE IS NULL  THEN 'Last Repurchase'                      -- Cliente não realizou recompra (última recompra)
            WHEN NR_DAYS_REPURCHASE IS NULL  THEN 'No Repurchase'                        -- Cliente não realizou recompra (última recompra)
            WHEN NR_DAYS_REPURCHASE <= 365   THEN 'Conversion 365'                       -- Relativo à última recompra ter ocorrido no período de 365 dias
            WHEN NR_DAYS_REPURCHASE <= 730   THEN 'Conversion 730'                       -- Relativo à última recompra ter ocorrido no período de 730 dias
            WHEN NR_DAYS_REPURCHASE <= 1095  THEN 'Conversion 1095'                      -- Relativo à última recompra ter ocorrido no período de 1095 dias
            WHEN NR_DAYS_REPURCHASE <= 1460  THEN 'Conversion 1460'                      -- Relativo à última recompra ter ocorrido no período de 1460 dias
            WHEN NR_DAYS_REPURCHASE <= 1825  THEN 'Conversion 1825'                      -- Relativo à última recompra ter ocorrido no período de 1825 dias
            ELSE 'Conversion 1825+'                                                      -- Relativo à última recompra ter ocorrido no período de 1825+ dias
END                                                     AS PURCHASE_PATH
--,   CASE WHEN A.ROW_NUM = 1 
--          THEN 'Purchase' 
--         ELSE 'Repurchase' END                          AS PURCHASE_TYPE    
,    CASE WHEN COUNT(1) OVER (PARTITION BY A.NR_DESTINATARIO_CNPJ_CPF) > 1             
            THEN 'Repurchase' 
          ELSE 'Purchase' 
  END                                                   AS PURCHASE_TYPE
--,   CASE WHEN NR_DAYS_REPURCHASE IS NULL
--          THEN 'Purchase' 
--         ELSE 'Repurchase' END                          AS PURCHASE_TYPE
,    CASE WHEN A.DT_NEXT_PURCHASE IS NULL
            THEN 'No Repurchase'
          WHEN DATE_DIFF(DAY,A.DT_PRV_PURCHASE,A.DT_NF_CONCESS) <= 60
            THEN 'Suspicious Consume'
          ELSE 'Standard Consume'   END                 AS FL_SUSP_CUSTOMER  
,    F.LAST_REVISION_DATE
,    F.NR_REVISOES  
FROM NOTAS_XML A

-- Join detalhe da compra
LEFT JOIN BASE_XML D
ON A.NR_DESTINATARIO_CNPJ_CPF = D.NR_DESTINATARIO_CNPJ_CPF
AND A.DT_NF_CONCESS = D.DT_NF_CONCESS

-- Join análise quantitativa
LEFT JOIN BASE_XML E
ON D.NR_DESTINATARIO_CNPJ_CPF = E.NR_DESTINATARIO_CNPJ_CPF
AND D.NR_CHASSI_COMPLETO = E.NR_CHASSI_COMPLETO

-- Join Engajamento Revisões
LEFT JOIN REVISOES F
ON F.YMDB_CPF_CNPJ = A.NR_DESTINATARIO_CNPJ_CPF
AND F.YMDB_CHASSICOMPLETO = D.NR_CHASSI_COMPLETO
ORDER BY A.NR_DESTINATARIO_CNPJ_CPF ASC, A.ROW_NUM ASC

""")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Writing Gold

# COMMAND ----------

(
    df_recompra_motocicletas
    .write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f'{gold_catalog}.{param_schema}.{param_nome_tabela}')
)
