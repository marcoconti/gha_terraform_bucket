# Databricks notebook source
# Tabela criada a partir do relatório discoverer YM_2116 - Pedido com Retencoes - Retidos Atual

# COMMAND ----------

# Criado por Vinicius Geada em 26/06/2025
# Atualizado por Vinicius Geda em 11/08/2025

# COMMAND ----------

# MAGIC %md
# MAGIC ### Imports

# COMMAND ----------

# Importação das bibliotecas necessárias para a execução do código
import os
from os import getenv
from pyspark.sql.functions import *
from delta.tables import *
from pyspark.sql.types import *

# COMMAND ----------

# MAGIC %md
# MAGIC ### Variables

# COMMAND ----------

# Get env values
env = os.environ.get("DATABRICKS_ENV")
env = env.lower()

# COMMAND ----------

# Lineage
param_schema_gold = 'comercial_planejamento_comercial'
gold_catalog = f'gold_{env}'

# Nome da tabela
param_nome_tabela = 'pedidos_retencoes_retidos_atual'

# COMMAND ----------

# MAGIC %md
# MAGIC ### Creation of Indicators

# COMMAND ----------

# DBTITLE 1,1 - Retidos
df_retidos = spark.sql(f"""
SELECT DISTINCT
      1                       AS REG,
      OOHO.CREATION_DATE      AS DATA_SELECAO,
      'Retido'                AS SITUACAO,
      OOHO.HOLD_RELEASE_ID    AS ID_LIBERACAO,
      OOLI.FLOW_STATUS_CODE,
      HOU.NAME                AS EMPRESA,
      RT.SEGMENT1             AS REGIAO,
      RT.SEGMENT2             AS SUB_REGIAO,
      HP.PARTY_NAME           AS CLIENTE,
      HL.ADDRESS1||' '||HL.ADDRESS2||' '||HL.ADDRESS3   AS ENDERECO,
      HL.ADDRESS4          AS BAIRRO,
      HL.CITY              AS CIDADE,
      HL.STATE             AS ESTADO,
      OHD.NAME||' - '||OHS.HOLD_COMMENT                 AS RETENCAO,
      OOHE.ORDER_NUMBER                                 AS PEDIDO,
      OOHE.ORDERED_DATE                                 AS DATA_PEDIDO,
      decode(MSIB.ITEM_TYPE,'PCS','PEÇAS','PRIMP','PEÇAS','PRIMP2','PEÇAS',OOLI.ORDERED_ITEM) AS MODELO, --NAO TEM PEÇAS NA TABELA
      OOLI.ORDERED_QUANTITY                                   AS QUANTIDADE,
      (OOLI.UNIT_SELLING_PRICE * OOLI.ORDERED_QUANTITY)       AS VALOR,
      RAT.NAME                                                AS COND_FAT,
      HCSUA.LOCATION                                          AS LOCAL_ENTREGA,
      MC.SEGMENT1                                             AS TIPO_PRODUTO,
      MSIB.SEGMENT1                                           AS PRODUTO,
      MSIB.DESCRIPTION                                        AS DESCR_PRODUTO,
      OHD.HOLD_ID,
      OOHO.CREATION_DATE                                      AS DATA_RETENCAO,
      to_timestamp(OHR.CREATION_DATE)                         AS DATA_LIBERACAO,
      OHR.RELEASE_REASON_CODE                                 AS LIBERACAO,
      CASE 
           WHEN HCASA.GLOBAL_ATTRIBUTE2 = 1 THEN
                HCASA.GLOBAL_ATTRIBUTE3 ||'-'|| HCASA.GLOBAL_ATTRIBUTE5
           ELSE
                HCASA.GLOBAL_ATTRIBUTE3 ||'/' ||HCASA.GLOBAL_ATTRIBUTE4 ||'-'|| HCASA.GLOBAL_ATTRIBUTE5
           END                                                AS CNPJ_CPF,
      OOHO.ORDER_HOLD_ID                                      AS NUMERO_RETENCAO,
      nvl((SELECT MIN(OOHOX.ORDER_HOLD_ID)
            FROM silver_{env}.ebs_apps.oe_order_holds_all OOHOX
            WHERE OOHOX.HEADER_ID = OOHO.HEADER_ID
          ),0)                                                AS PRIMEIRA_RENTECAO

FROM silver_{env}.ebs_apps.oe_order_holds_all ooho
JOIN silver_{env}.ebs_apps.oe_hold_sources_all ohs 
  ON ooho.hold_source_id = ohs.hold_source_id
  AND ooho.org_id = ohs.org_id
JOIN silver_{env}.ebs_apps.hr_organization_units hou 
  ON ooho.org_id = hou.organization_id
JOIN silver_{env}.ebs_apps.oe_hold_definitions ohd  
  ON ohs.hold_id = ohd.hold_id
LEFT JOIN silver_{env}.ebs_apps.oe_hold_releases ohr
  ON ooho.hold_release_id = ohr.hold_release_id
JOIN silver_{env}.ebs_apps.oe_order_headers_all oohe 
  ON ooho.header_id = oohe.header_id
JOIN silver_{env}.ebs_apps.oe_order_lines_all ooli 
  ON ooho.header_id = ooli.header_id
JOIN silver_{env}.ebs_apps.hz_cust_site_uses_all hcsua
  ON oohe.ship_to_org_id = hcsua.site_use_id
JOIN silver_{env}.ebs_apps.hz_cust_acct_sites_all hcasa 
  ON hcsua.cust_acct_site_id = hcasa.cust_acct_site_id
JOIN silver_{env}.ebs_apps.hz_cust_accounts_all hcaa
  ON hcaa.cust_account_id = hcasa.cust_account_id
JOIN silver_{env}.ebs_apps.hz_parties         hp
  ON hp.party_id = hcaa.party_id
JOIN silver_{env}.ebs_apps.hz_party_sites hps 
  ON hcasa.party_site_id = hps.party_site_id
  AND hps.party_id = hp.party_id
JOIN silver_{env}.ebs_apps.hz_locations hl 
  ON hps.location_id = hl.location_id
LEFT JOIN silver_{env}.ebs_apps.hz_cust_profile_amts hcpa
  ON hcpa.site_use_id = hcsua.site_use_id
LEFT JOIN silver_{env}.ebs_apps.ra_territories rt 
  ON rt.territory_id = hcsua.territory_id
JOIN silver_{env}.ebs_apps.mtl_system_items_b msib 
  ON msib.inventory_item_id = ooli.inventory_item_id
  AND msib.organization_id = ooli.ship_from_org_id
JOIN silver_{env}.ebs_apps.ra_terms_tl rat 
  ON rat.term_id = oohe.payment_term_id
JOIN silver_{env}.ebs_apps.mtl_item_categories mic 
  ON msib.inventory_item_id = mic.inventory_item_id
  AND msib.organization_id = mic.organization_id
JOIN silver_{env}.ebs_apps.mtl_category_sets mcs 
  ON mic.category_set_id = mcs.category_set_id
JOIN silver_{env}.ebs_apps.mtl_categories mc 
  ON mic.category_id = mc.category_id
WHERE hcsua.site_use_code = 'SHIP_TO'
  AND ohs.hold_entity_code = 'O'
  AND ooli.flow_status_code NOT IN ('CANCELLED', 'ENTERED')
  AND rat.language = 'PTB'
  AND UPPER(mcs.category_set_name) = 'VENDAS'
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Casting df_retidos

# COMMAND ----------

df_retidos = ( 
    df_retidos
.withColumn("DATA_SELECAO", col("DATA_SELECAO").cast("timestamp"))
.withColumn("PEDIDO", col("PEDIDO").cast("string"))
.withColumn("DATA_PEDIDO", col("DATA_PEDIDO").cast("timestamp"))
.withColumn("HOLD_ID", col("HOLD_ID").cast("string"))
.withColumn("DATA_RETENCAO", col("DATA_RETENCAO").cast("timestamp"))
)

# COMMAND ----------

# DBTITLE 1,2 - Liberados
df_liberados = spark.sql(f"""
SELECT DISTINCT
      2                       AS REG,
      OHR.CREATION_DATE   	  AS DATA_SELECAO,
      'Liberado'              AS SITUACAO,
      OOHO.HOLD_RELEASE_ID    AS ID_LIBERACAO,
      OOLI.FLOW_STATUS_CODE,
      HOU.NAME                AS EMPRESA,
      RT.SEGMENT1             AS REGIAO,
      RT.SEGMENT2             AS SUB_REGIAO,
      HP.PARTY_NAME           AS CLIENTE,
      HL.ADDRESS1||' '||HL.ADDRESS2||' '||HL.ADDRESS3   AS ENDERECO,
      HL.ADDRESS4          AS BAIRRO,
      HL.CITY              AS CIDADE,
      HL.STATE             AS ESTADO,
      OHD.NAME||' - '||OHS.HOLD_COMMENT                 AS RETENCAO,
      OOHE.ORDER_NUMBER                                 AS PEDIDO,
      OOHE.ORDERED_DATE                                 AS DATA_PEDIDO,
      decode(MSIB.ITEM_TYPE,'PCS','PEÇAS','PRIMP','PEÇAS','PRIMP2','PEÇAS',OOLI.ORDERED_ITEM) AS MODELO, --NAO TEM PEÇAS NA TABELA
      OOLI.ORDERED_QUANTITY                                   AS QUANTIDADE,
      (OOLI.UNIT_SELLING_PRICE * OOLI.ORDERED_QUANTITY)       AS VALOR,
      RAT.NAME                                                AS COND_FAT,
      HCSUA.LOCATION                                          AS LOCAL_ENTREGA,
      MC.SEGMENT1                                             AS TIPO_PRODUTO,
      MSIB.SEGMENT1                                           AS PRODUTO,
      MSIB.DESCRIPTION                                        AS DESCR_PRODUTO,
      OHD.HOLD_ID,
      OOHO.CREATION_DATE                                      AS DATA_RETENCAO,
      to_timestamp(OHR.CREATION_DATE)                         AS DATA_LIBERACAO,
      OHR.RELEASE_REASON_CODE                                 AS LIBERACAO,
      CASE 
           WHEN HCASA.GLOBAL_ATTRIBUTE2 = 1 THEN
                HCASA.GLOBAL_ATTRIBUTE3 ||'-'|| HCASA.GLOBAL_ATTRIBUTE5
           ELSE
                HCASA.GLOBAL_ATTRIBUTE3 ||'/' ||HCASA.GLOBAL_ATTRIBUTE4 ||'-'|| HCASA.GLOBAL_ATTRIBUTE5
           END                                                AS CNPJ_CPF,
      OOHO.ORDER_HOLD_ID                                      AS NUMERO_RETENCAO,
      nvl((SELECT MIN(OOHOX.ORDER_HOLD_ID)
            FROM silver_{env}.ebs_apps.oe_order_holds_all OOHOX
            WHERE OOHOX.HEADER_ID = OOHO.HEADER_ID
          ),0)                                                AS PRIMEIRA_RENTECAO

FROM silver_{env}.ebs_apps.oe_order_holds_all ooho
JOIN silver_{env}.ebs_apps.oe_hold_sources_all ohs 
  ON ooho.hold_source_id = ohs.hold_source_id
  AND ooho.org_id = ohs.org_id
JOIN silver_{env}.ebs_apps.hr_organization_units hou 
  ON ooho.org_id = hou.organization_id
JOIN silver_{env}.ebs_apps.oe_hold_definitions ohd  
  ON ohs.hold_id = ohd.hold_id
LEFT JOIN silver_{env}.ebs_apps.oe_hold_releases ohr
  ON ooho.hold_release_id = ohr.hold_release_id
JOIN silver_{env}.ebs_apps.oe_order_headers_all oohe 
  ON ooho.header_id = oohe.header_id
JOIN silver_{env}.ebs_apps.oe_order_lines_all ooli 
  ON ooho.header_id = ooli.header_id
JOIN silver_{env}.ebs_apps.hz_cust_site_uses_all hcsua
  ON oohe.ship_to_org_id = hcsua.site_use_id
JOIN silver_{env}.ebs_apps.hz_cust_acct_sites_all hcasa 
  ON hcsua.cust_acct_site_id = hcasa.cust_acct_site_id
JOIN silver_{env}.ebs_apps.hz_cust_accounts_all hcaa
  ON hcaa.cust_account_id = hcasa.cust_account_id
JOIN silver_{env}.ebs_apps.hz_parties         hp
  ON hp.party_id = hcaa.party_id
JOIN silver_{env}.ebs_apps.hz_party_sites hps 
  ON hcasa.party_site_id = hps.party_site_id
  AND hps.party_id = hp.party_id
JOIN silver_{env}.ebs_apps.hz_locations hl 
  ON hps.location_id = hl.location_id
LEFT JOIN silver_{env}.ebs_apps.hz_cust_profile_amts hcpa
  ON hcpa.site_use_id = hcsua.site_use_id
LEFT JOIN silver_{env}.ebs_apps.ra_territories rt 
  ON rt.territory_id = hcsua.territory_id
JOIN silver_{env}.ebs_apps.mtl_system_items_b msib 
  ON msib.inventory_item_id = ooli.inventory_item_id
  AND msib.organization_id = ooli.ship_from_org_id
JOIN silver_{env}.ebs_apps.ra_terms_tl rat 
  ON rat.term_id = oohe.payment_term_id
JOIN silver_{env}.ebs_apps.mtl_item_categories mic 
  ON msib.inventory_item_id = mic.inventory_item_id
  AND msib.organization_id = mic.organization_id
JOIN silver_{env}.ebs_apps.mtl_category_sets mcs 
  ON mic.category_set_id = mcs.category_set_id
JOIN silver_{env}.ebs_apps.mtl_categories mc 
  ON mic.category_id = mc.category_id
WHERE hcsua.site_use_code = 'SHIP_TO'
  AND ohs.hold_entity_code = 'O'
  AND ooli.flow_status_code NOT IN ('CANCELLED', 'ENTERED')
  AND rat.language = 'PTB'
  AND UPPER(mcs.category_set_name) = 'VENDAS'
  AND ooho.hold_release_id IS NOT NULL
""")  

# COMMAND ----------

# MAGIC %md
# MAGIC ### Casting df_liberados

# COMMAND ----------

df_liberados = ( 
    df_liberados
.withColumn("PEDIDO", col("PEDIDO").cast("string"))
.withColumn("DATA_PEDIDO", col("DATA_PEDIDO").cast("timestamp"))
.withColumn("HOLD_ID", col("HOLD_ID").cast("string"))
.withColumn("DATA_RETENCAO", col("DATA_RETENCAO").cast("timestamp"))
)

# COMMAND ----------

# DBTITLE 1,3 - Faturamentos
df_faturamentos = spark.sql(f"""
SELECT DISTINCT
      3                       								              				         AS REG,
      RCTA.TRX_DATE	          								              				         AS DATA_SELECAO,
      'Faturado'              								              				         AS SITUACAO,
      null                    								              				         AS ID_LIBERACAO,
      null                    								              				         AS FLOW_STATUS_CODE,
      decode(RCTA.ORG_ID,84,'YMB',85,'YMA')             	  							   AS EMPRESA,
      RT.SEGMENT1  	          								                			         AS REGIAO,
      RT.SEGMENT2	          								                			           AS SUB_REGIAO,
      HP.PARTY_NAME	 	      								                			           AS CLIENTE,
      RAA.ADDRESS1||' '||RAA.ADDRESS2||' '||RAA.ADDRESS3     			 				   AS ENDERECO,
      RAA.ADDRESS4          								                			           AS BAIRRO,
      RAA.CITY              								                			           AS CIDADE,
      RAA.STATE             								                			           AS ESTADO,
      ' '                   								                			           AS RETENCAO,
      RCTA.INTERFACE_HEADER_ATTRIBUTE1        	              							 AS PEDIDO,
      RCTA.TRX_DATE                            	              							 AS DATA_PEDIDO,
      decode(MSI.ITEM_TYPE,'PCS','PEÇAS','PRIMP','PEÇAS','PRIMP2','PEÇAS',MSI.ITEM_TYPE) AS MODELO, --NAO TEM PEÇAS NA TABELA
      NVL(RCTLA.QUANTITY_INVOICED,0)              	          							 AS QUANTIDADE,
      NVL(RCTLA.EXTENDED_AMOUNT,0)               	          							   AS VALOR,
      RAT.NAME                                                							 AS COND_FAT,
      HCSUA.LOCATION                               	          							 AS LOCAL_ENTREGA,
      MC.SEGMENT1                                   	      							   AS TIPO_PRODUTO,
      MSI.SEGMENT1                                            							 AS PRODUTO,
      MSI.DESCRIPTION                                         							 AS DESCR_PRODUTO,
      0                                                       							 AS HOLD_ID,
      TO_DATE(NULL,'dd/mm/yyyy')                              							 AS DATA_RETENCAO,
      RCTA.TRX_DATE                                           							 AS DATA_LIBERACAO,
      null                                                    							 AS LIBERACAO,
      CASE 
           WHEN HCAS.GLOBAL_ATTRIBUTE2 = 1 THEN
                HCAS.GLOBAL_ATTRIBUTE3 ||'-'|| HCAS.GLOBAL_ATTRIBUTE5
           ELSE
                HCAS.GLOBAL_ATTRIBUTE3 ||'/' ||HCAS.GLOBAL_ATTRIBUTE4 ||'-'|| HCAS.GLOBAL_ATTRIBUTE5
           END                                                							 AS CNPJ_CPF,
      0                                                       							 AS NUMERO_RETENCAO,
      0                                                       							 AS PRIMEIRA_RENTECAO

FROM silver_{env}.ebs_apps.hz_parties         hp
  JOIN silver_{env}.ebs_apps.hz_cust_accounts hca
    ON hp.party_id = hca.party_id
  JOIN silver_{env}.ebs_apps.ra_customer_trx_all rcta
    ON hca.cust_account_id = rcta.bill_to_customer_id
  JOIN silver_{env}.ebs_apps.hz_cust_site_uses_all hcsua
    ON rcta.bill_to_site_use_id = hcsua.site_use_id
  JOIN silver_{env}.ebs_apps.hz_cust_acct_sites_all hcas
    ON hcas.cust_acct_site_id = hcsua.cust_acct_site_id
  JOIN silver_{env}.ebs_apps.hz_party_sites hps 
	ON hps.party_site_id = hcas.party_site_id
  JOIN silver_{env}.ebs_apps.hz_locations raa
    ON raa.location_id = hps.location_id
  JOIN silver_{env}.ebs_apps.ra_customer_trx_lines_all rctla
    ON rcta.customer_trx_id = rctla.customer_trx_id  
  JOIN silver_{env}.ebs_apps.mtl_system_items_b msi
    ON rctla.inventory_item_id = msi.inventory_item_id
    AND rctla.warehouse_id = msi.organization_id 
  LEFT JOIN silver_{env}.ebs_apps.ra_cust_trx_types_all rctta
    ON rcta.cust_trx_type_id = rctta.cust_trx_type_id
  JOIN silver_{env}.ebs_apps.mtl_item_categories mic
    ON msi.inventory_item_id = mic.inventory_item_id
    AND msi.organization_id = mic.organization_id
  JOIN silver_{env}.ebs_apps.mtl_category_sets mcs
    ON mic.category_set_id = mcs.category_set_id
  JOIN silver_{env}.ebs_apps.mtl_categories mc
    ON mic.category_id = mc.category_id  
  JOIN silver_{env}.ebs_apps.ra_terms rat
    ON rcta.term_id = rat.term_id
  LEFT JOIN silver_{env}.ebs_apps.ra_territories  rt
    ON hcsua.territory_id = rt.territory_id
WHERE rcta.status_trx = 'OP'
  AND rctta.type <> 'CM'
  AND (rctta.attribute13 <> 'S' OR rctta.attribute13 IS NULL)
  AND UPPER(mcs.category_set_name) = 'VENDAS'
  AND nvl(raa.attribute2,'C') NOT IN ('ESC','T','E')
  AND rctla.line_type IN ('LINE')
  AND rcta.cust_trx_type_id != '8432'
  AND rcta.interface_header_attribute1 IS NOT NULL
  AND raa.state <> 'EX'
  AND substr(rcta.interface_header_attribute1,1,3) <> '177'
  AND rat.name NOT LIKE '%REMESSA%'
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Casting df_faturamentos

# COMMAND ----------

df_faturamentos = ( 
    df_faturamentos
.withColumn("ID_LIBERACAO", col("ID_LIBERACAO").cast("string"))
.withColumn("FLOW_STATUS_CODE", col("FLOW_STATUS_CODE").cast("string"))
.withColumn("QUANTIDADE", col("QUANTIDADE").cast("double"))
.withColumn("VALOR", col("VALOR").cast("double"))
.withColumn("HOLD_ID", col("HOLD_ID").cast("string"))
.withColumn("DATA_RETENCAO", col("DATA_RETENCAO").cast("timestamp"))
.withColumn("LIBERACAO", col("LIBERACAO").cast("string"))
.withColumn("NUMERO_RETENCAO", col("NUMERO_RETENCAO").cast("string"))
.withColumn("PRIMEIRA_RENTECAO", col("PRIMEIRA_RENTECAO").cast("string"))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Union of Dataframes

# COMMAND ----------

df_ym_2116_union = (
  df_retidos
  .union(df_liberados)
  .union(df_faturamentos)
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Writing Gold

# COMMAND ----------

(
    df_ym_2116_union
    .write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f'{gold_catalog}.{param_schema_gold}.{param_nome_tabela}')
)
