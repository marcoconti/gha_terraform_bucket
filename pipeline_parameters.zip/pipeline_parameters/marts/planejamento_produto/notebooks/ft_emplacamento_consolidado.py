# Databricks notebook source
# MAGIC %md
# MAGIC #Metadados gerais

# COMMAND ----------

# MAGIC %md
# MAGIC **Criado por**: Bruno Jander
# MAGIC
# MAGIC **Data criação**: 14/01/2025
# MAGIC
# MAGIC **Atualizado por**: Bruno Jander
# MAGIC
# MAGIC **Data atualização**: 15/07/2025
# MAGIC
# MAGIC [comment]: <> (Tem que vir do negócio)
# MAGIC **Descrição do dataset/tabela/view**: Tabela contendo dados históricos de emplacamento de veículos, disponibilizados pela Abraciclo através de FTP.
# MAGIC
# MAGIC [comment]: # (Lineage, nome de domínio, sub-domínio, tipo de agregação, business unit: Tem que vir do negócio)
# MAGIC **Tags**:
# MAGIC
# MAGIC [comment]: # (Tem que vir do negócio)
# MAGIC **Data owner**: 
# MAGIC
# MAGIC [comment]: # (Full/Incremental/Streaming/CDC/etc)
# MAGIC **Tipo de carga**: Full
# MAGIC
# MAGIC [comment]: # (Tem que vir de sistemas)
# MAGIC **Atualização**: Diária

# COMMAND ----------

# MAGIC %md
# MAGIC #### Fontes utilizadas nesse pipeline:
# MAGIC
# MAGIC [comment]: <> (tabelas utilizadas nesse notebook)
# MAGIC
# MAGIC - silver_catalog.planejamento_produto.emplacamento
# MAGIC - silver_catalog.planejamento_produto.emplacamento_historico
# MAGIC - gold_catalog.planejamento_produto.planejamento_produto_emplacamentos_ft_emplacamento_consolidado

# COMMAND ----------

# MAGIC %md
# MAGIC # Configurações Iniciais

# COMMAND ----------

# DBTITLE 1,Importação de bibliotecas
from os import getenv
from pyspark.sql.functions import when, substring, col, concat_ws, year, month
from pyspark.sql.types import DateType, ShortType, IntegerType

# COMMAND ----------

# DBTITLE 1,Variáveis de ambiente
ambiente = getenv("DATABRICKS_ENV").lower()

# COMMAND ----------

# DBTITLE 1,Lineage de diretórios
# <database>/<sistema>/<esquema> ou <external>/<sistema>/<esquema>
# igual ao lineage do pipeline do Informatica
param_lineage_gold = 'planejamento_produto/emplacamentos'
param_schema= "planejamento_produto"
param_schema_silver = "predicao_volume"
silver_catalog = f'silver_{ambiente}'
gold_catalog = f'gold_{ambiente}'

# Nome da tabela
param_nome_tabela = 'ft_emplacamento_consolidado'

# COMMAND ----------

# MAGIC %md
# MAGIC # Silver para Gold

# COMMAND ----------

# DBTITLE 1,Leitura da tabela na camada Silver
df_ft_emplacamento_atual = spark.read.table(f"{silver_catalog}.{param_schema_silver}.emplacamento")
df_ft_emplacamento_historico = spark.read.table(f"{silver_catalog}.{param_schema_silver}.emplacamento_historico")

# COMMAND ----------

# DBTITLE 1,Filtragem da tabela
df_ft_emplacamento_historico = (
    # Ignora dados anteriores a 2008 com data inconsistente
    df_ft_emplacamento_historico
    .filter(col("DT_DATA")
            .rlike("\d{4}-\d{2}-\d{2}"))
)

# COMMAND ----------

# DBTITLE 1,Tratamento de campos
def formatar_data(df, df_dt_col, ano_pos, mes_pos, dia_pos):
    return (
        df
        .withColumn(
            df_dt_col, 
            when(col(df_dt_col) == "00000000", None).otherwise(col(df_dt_col))
        )
        .withColumn(f"{df_dt_col}_ANO", substring(col(df_dt_col), *ano_pos))
        .withColumn(f"{df_dt_col}_MES", substring(col(df_dt_col), *mes_pos))
        .withColumn(f"{df_dt_col}_DIA", substring(col(df_dt_col), *dia_pos))
        .withColumn(df_dt_col, 
                    concat_ws("-", 
                                col(f"{df_dt_col}_ANO"),
                                col(f"{df_dt_col}_MES"),
                                col(f"{df_dt_col}_DIA"))
        )
    )

df_ft_emplacamento_atual = formatar_data(df_ft_emplacamento_atual, "DT_DATA", (1, 4), (5, 2), (7, 2))
df_ft_emplacamento_atual = formatar_data(df_ft_emplacamento_atual, "DT_DI", (5, 4), (3, 2), (1, 2))
df_ft_emplacamento_atual = formatar_data(df_ft_emplacamento_atual, "DT_ATUAL", (1, 4), (5, 2), (7, 2))

# df_ft_emplacamento_historico já vem com DT_DATA formatado
df_ft_emplacamento_historico = formatar_data(df_ft_emplacamento_historico, "DT_DI", (5, 4), (3, 2), (1, 2))
df_ft_emplacamento_historico = formatar_data(df_ft_emplacamento_historico, "DT_ATUAL", (1, 4), (5, 2), (7, 2))

# COMMAND ----------

# DBTITLE 1,Ajuste de nomenclatura
def renomear_colunas(df):
    return (
        df
        .withColumnRenamed("DT_DATA", "DT_EMPLACAMENTO")
        .withColumnRenamed("ID_DOC", "TP_DOC")
        .withColumnRenamed("NM_UF_FAT", "SG_UF_FAT")
        .withColumnRenamed("ID_DOC_PROP", "TP_DOC_PROP")
        .withColumnRenamed("NM_UF", "SG_UF")
        .withColumnRenamed("ID_MUNICIPIO", "CD_MUNICIPIO")
        .withColumnRenamed("ID_MARCA_MODELO", "CD_MARCA_MODELO")
        .withColumnRenamed("ID_TIPO", "CD_TIPO")
        .withColumnRenamed("ID_ESPECIE", "CD_ESPECIE")
        .withColumnRenamed("ID_CARROCERIA", "CD_CARROCERIA")
        .withColumnRenamed("NR_CARROCERIA", "CO_CARROCERIA")
        .withColumnRenamed("ID_COR", "CD_COR")
        .withColumnRenamed("ID_COMBUSTIVEL", "CD_COMBUSTIVEL")
        .withColumnRenamed("VL_LUGARES", "QT_LUGARES")
        .withColumnRenamed("ID_PROC", "CD_PROC")
        .withColumnRenamed("NM_SIT_CHASSI", "CD_SIT_CHASSI")
        .withColumnRenamed("NR_CAIXA_CAMBIO", "CD_CAIXA_CAMBIO")
        .withColumnRenamed("NR_EIXOS", "QT_EIXOS")
        .withColumnRenamed("NM_EIXO_TRASEIRO", "CD_EIXO_TRASEIRO")
        .withColumnRenamed("NM_TERCEIRO_EIXO", "CD_TERCEIRO_EIXO")
        .withColumnRenamed("NR_MOTOR", "CD_MOTOR")
        .withColumnRenamed("ID_MONTAGEM", "CD_MONTAGEM")
        .withColumnRenamed("ID_COD_IMP", "CD_IMP")
        .withColumnRenamed("ID_IMP", "CO_IMP")
        .withColumnRenamed("ID_REST1", "CD_REST1")
        .withColumnRenamed("ID_REST2", "CD_REST2")
        .withColumnRenamed("ID_REST3", "CD_REST3")
        .withColumnRenamed("ID_REST4", "CD_REST4")
        .withColumnRenamed("NM_SITUACAO_VEICULO", "CD_SITUACAO_VEICULO")
        .withColumnRenamed("ID_MONTADORA", "CD_MONTADORA")
    )

df_ft_emplacamento_atual = renomear_colunas(df_ft_emplacamento_atual)
df_ft_emplacamento_historico = renomear_colunas(df_ft_emplacamento_historico)

# COMMAND ----------

# DBTITLE 1,Ajuste de tipagem
def ajustar_tipagem_colunas(df):
    return (
        df
        .withColumn("DT_EMPLACAMENTO", col("DT_EMPLACAMENTO").cast(DateType()))
        .withColumn("NR_ANO_FABR", col("NR_ANO_FABR").cast(ShortType()))
        .withColumn("NR_ANO_MOD", col("NR_ANO_MOD").cast(ShortType()))
        .withColumn("VL_POTENCIA", col("VL_POTENCIA").cast(ShortType()))
        .withColumn("VL_CILINDRADA", col("VL_CILINDRADA").cast(ShortType()))
        .withColumn("QT_LUGARES", col("QT_LUGARES").cast(ShortType()))
        .withColumn("VL_CAP_CARGA", col("VL_CAP_CARGA").cast(IntegerType()))
        .withColumn("VL_PESO_BRUTO", col("VL_PESO_BRUTO").cast(IntegerType()))
        .withColumn("QT_EIXOS", col("QT_EIXOS").cast(ShortType()))
        .withColumn("NR_DI", col("NR_DI").cast(IntegerType()))
        .withColumn("DT_DI", col("DT_DI").cast(DateType()))
        .withColumn("NR_SRF", col("NR_SRF").cast(IntegerType()))
        .withColumn("DT_ATUAL", col("DT_ATUAL").cast(DateType()))
        .withColumn("NR_REST_TRIB", col("NR_REST_TRIB").cast(IntegerType()))
        .withColumn('ANO', year(col('DT_EMPLACAMENTO')).cast(ShortType()))
        .withColumn('MES', month(col('DT_EMPLACAMENTO')).cast(ShortType()))
        )

df_ft_emplacamento_atual = ajustar_tipagem_colunas(df_ft_emplacamento_atual)
df_ft_emplacamento_historico = ajustar_tipagem_colunas(df_ft_emplacamento_historico)

# COMMAND ----------

# DBTITLE 1,União de emplacamentos históricos e atuais
df_ft_emplacamento_final = (
    df_ft_emplacamento_atual.select(
        "DT_EMPLACAMENTO", "CD_CHASSI", "CD_PLACA", "TP_DOC", "CD_CNPJ", "SG_UF_FAT", 
        "TP_DOC_PROP", "SG_UF", "CD_MUNICIPIO", "NR_ANO_FABR", "NR_ANO_MOD",
        "CD_MARCA_MODELO", "CD_TIPO", "CD_ESPECIE", "CD_CARROCERIA", 
        "CO_CARROCERIA", "CD_COR", "CD_COMBUSTIVEL", "VL_POTENCIA", 
        "VL_CILINDRADA", "QT_LUGARES", "VL_CAP_CARGA", "VL_PESO_BRUTO", 
        "CD_CMT", "CD_PROC", "CD_SIT_CHASSI", "CD_CAIXA_CAMBIO", "QT_EIXOS", 
        "CD_EIXO_TRASEIRO", "CD_TERCEIRO_EIXO", "CD_MOTOR", "CD_MONTAGEM", 
        "CD_IMP", "CO_IMP", "NR_DI", "DT_DI", "NR_SRF", "DT_ATUAL", 
        "CD_REST1", "CD_REST2", "CD_REST3", "CD_REST4", "NR_REST_TRIB", 
        "CD_SITUACAO_VEICULO", "CD_MONTADORA", "ANO", "MES"
).union(
    df_ft_emplacamento_historico.select(
        "DT_EMPLACAMENTO", "CD_CHASSI", "CD_PLACA", "TP_DOC", "CD_CNPJ", "SG_UF_FAT", 
        "TP_DOC_PROP", "SG_UF", "CD_MUNICIPIO", "NR_ANO_FABR", "NR_ANO_MOD",
        "CD_MARCA_MODELO", "CD_TIPO", "CD_ESPECIE", "CD_CARROCERIA", 
        "CO_CARROCERIA", "CD_COR", "CD_COMBUSTIVEL", "VL_POTENCIA", 
        "VL_CILINDRADA", "QT_LUGARES", "VL_CAP_CARGA", "VL_PESO_BRUTO", 
        "CD_CMT", "CD_PROC", "CD_SIT_CHASSI", "CD_CAIXA_CAMBIO", "QT_EIXOS", 
        "CD_EIXO_TRASEIRO", "CD_TERCEIRO_EIXO", "CD_MOTOR", "CD_MONTAGEM", 
        "CD_IMP", "CO_IMP", "NR_DI", "DT_DI", "NR_SRF", "DT_ATUAL", 
        "CD_REST1", "CD_REST2", "CD_REST3", "CD_REST4", "NR_REST_TRIB", 
        "CD_SITUACAO_VEICULO", "CD_MONTADORA", "ANO", "MES"
        )
    )
)

# COMMAND ----------

# DBTITLE 1,Gravação da tabela na camada Gold
(
    df_ft_emplacamento_final
    .write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f'{gold_catalog}.{param_schema}.{param_nome_tabela}')
)
