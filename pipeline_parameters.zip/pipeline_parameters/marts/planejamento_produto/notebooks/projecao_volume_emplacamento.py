# Databricks notebook source
# MAGIC %md
# MAGIC #Metadados gerais

# COMMAND ----------

# MAGIC %md
# MAGIC **Criado por**: Pedro Ernesto
# MAGIC
# MAGIC **Data criação**: ?
# MAGIC
# MAGIC **Atualizado por**: Pedro Ernesto
# MAGIC
# MAGIC **Data atualização**: 21/03/2024
# MAGIC
# MAGIC **Atualizado por**: Bruno Jander
# MAGIC
# MAGIC **Data atualização**: 17/07/2025
# MAGIC
# MAGIC [comment]: <> (Tem que vir do negócio)
# MAGIC **Descrição do dataset/tabela/view**: Tabela contendo dados e descrições de emplacamento de veículos (HISTÓRICO, FTP e TRADUTORAS).
# MAGIC
# MAGIC [comment]: # (Lineage, nome de domínio, sub-domínio, tipo de agregação, business unit: Tem que vir do negócio)
# MAGIC **Tags**:
# MAGIC
# MAGIC [comment]: # (Tem que vir do negócio)
# MAGIC **Data owner**: 
# MAGIC
# MAGIC [comment]: # (Full/Incremental/Streaming/CDC/etc)
# MAGIC **Tipo de carga**: Full
# MAGIC
# MAGIC [comment]: # (Tem que vir de sistemas)
# MAGIC **Atualização**: Diária

# COMMAND ----------

# MAGIC %md
# MAGIC #### Fontes utilizadas nesse pipeline:
# MAGIC
# MAGIC [comment]: <> (tabelas utilizadas nesse notebook)
# MAGIC
# MAGIC - silver_catalog.predicao_volume.emplacamento
# MAGIC - silver_catalog.predicao_volume.emplacamento_historico
# MAGIC - silver_catalog.predicao_volume.marca_modelo
# MAGIC - silver_catalog.predicao_volume.municipios
# MAGIC - silver_catalog.predicao_volume.tipos_cores
# MAGIC - silver_catalog.predicao_volume.tipos_combustivel
# MAGIC - silver_catalog.predicao_volume.montadora
# MAGIC - silver_catalog.predicao_volume.tipo_veiculo
# MAGIC - silver_catalog.predicao_volume.especie_veiculo
# MAGIC - silver_catalog.predicao_volume.restricoes
# MAGIC - silver_catalog.predicao_volume.segmentos

# COMMAND ----------

# MAGIC %md
# MAGIC # Configurações Iniciais

# COMMAND ----------

# DBTITLE 1,Importação de bibliotecas
from os import getenv
from pyspark.sql.functions import col

# COMMAND ----------

# DBTITLE 1,Variáveis de ambiente
ambiente = getenv("DATABRICKS_ENV").lower()

# COMMAND ----------

# DBTITLE 1,Lineage de diretórios
# <database>/<sistema>/<esquema> ou <external>/<sistema>/<esquema>
# igual ao lineage do pipeline do Informatica
param_lineage = 'predicao_volume/projecao_volume'
param_schema = "projecao_volume"
silver_catalog = f'silver_{ambiente}'
gold_catalog = f'gold_{ambiente}'

# Nome da tabela
param_nome_tabela = 'projecao_volume_emplacamento'

# COMMAND ----------

# MAGIC %md
# MAGIC # Silver/Gold para Gold

# COMMAND ----------

# DBTITLE 1,Criação do DataFrame
# Construção do DataFrame a partir das tabelas necessárias para a elaboração do relatório.
df_resumo_geral_final = spark.sql(f"""
SELECT 
    replace(DT_DATA, '-', '') DT_DATA,
    CD_CHASSI as DC_CHASSI,
    CD_PLACA as DC_PLACA,
    ID_DOC,
    CD_CNPJ as DC_CNPJ,
    NM_UF_FAT,
    ID_DOC_PROP,
    NM_UF,
    t3.DS_MUNICIPIO,
    t3.DS_UF,
    t3.DS_CIDADES,
    t3.DS_AREA_OPERACIONAL,
    t3.DS_CIDADE_UF,
    t3.QT_POPULACAO,
    t3.DS_LOCALIZACAO,
    t3.DS_ESTRATEGIA,
    NR_ANO_FABR,
    NR_ANO_MOD,
    t2.DS_DESCRICAO as DS_DESCRICAO_MOTO,
    t2.NM_CATEGORIA,
    t2.DS_SEGMENTO_A,
    t2.DS_SEGMENTO_AA,
    t7.NM_DESCRICAO as NM_DESCRICAO_TIPO_VEICULO,
    t8.DS_DESCRICAO as DS_DESCRICAO_ESPECIE,
    ID_CARROCERIA,
    NR_CARROCERIA,
    t4.DS_DESCRICAO as DS_DESCRICAO_COR,
    t5.DS_DESCRICAO as DS_DESCRICAO_COMBUSTIVEL,
    VL_POTENCIA,
    VL_CILINDRADA,
    VL_LUGARES,
    VL_CAP_CARGA,
    VL_PESO_BRUTO,
    CD_CMT,
    ID_PROC,
    NM_SIT_CHASSI,
    NR_CAIXA_CAMBIO,
    NR_EIXOS,
    NM_EIXO_TRASEIRO,
    NM_TERCEIRO_EIXO,
    NR_MOTOR,
    ID_MONTAGEM,
    ID_COD_IMP,
    ID_IMP,
    NR_DI,
    DT_DI,
    NR_SRF,
    DT_ATUAL,
    t9.DS_DESCRICAO as DS_RESTRICAO_1,
    t10.DS_DESCRICAO as DS_RESTRICAO_2,
    t11.DS_DESCRICAO as DS_RESTRICAO_3,
    t12.DS_DESCRICAO as DS_RESTRICAO_4,
    NR_REST_TRIB,
    NM_SITUACAO_VEICULO,
    t6.NM_MONTADORA,
    t6.DS_UF as DS_UF_MONTADORA,
    t13.NM_BRAND,
    t13.NM_SEGMENT_FULL_NEW,
    t13.NM_PPB_CBU,
    t13.NM_FAMILY
FROM 
  (
    (SELECT 
      replace(DT_DATA,'-','') DT_DATA, CD_CHASSI, CD_PLACA, ID_DOC, CD_CNPJ, NM_UF_FAT, ID_DOC_PROP, NM_UF, ID_MUNICIPIO, NR_ANO_FABR, NR_ANO_MOD, ID_MARCA_MODELO, ID_TIPO, ID_ESPECIE, ID_CARROCERIA, NR_CARROCERIA, ID_COR, ID_COMBUSTIVEL, VL_POTENCIA, VL_CILINDRADA, VL_LUGARES, VL_CAP_CARGA, VL_PESO_BRUTO, CD_CMT, ID_PROC, NM_SIT_CHASSI, NR_CAIXA_CAMBIO, NR_EIXOS, NM_EIXO_TRASEIRO, NM_TERCEIRO_EIXO, NR_MOTOR, ID_MONTAGEM, ID_COD_IMP, ID_IMP, NR_DI, DT_DI, NR_SRF, DT_ATUAL, ID_REST1, ID_REST2, ID_REST3, ID_REST4, NR_REST_TRIB, NM_SITUACAO_VEICULO, ID_MONTADORA 
    FROM 
      {silver_catalog}.predicao_volume.emplacamento)
  UNION
    (SELECT 
      replace(DT_DATA,'-','') DT_DATA, CD_CHASSI, CD_PLACA, ID_DOC, CD_CNPJ, NM_UF_FAT, ID_DOC_PROP, NM_UF, ID_MUNICIPIO, NR_ANO_FABR, NR_ANO_MOD, ID_MARCA_MODELO, ID_TIPO, ID_ESPECIE, ID_CARROCERIA, NR_CARROCERIA, ID_COR, ID_COMBUSTIVEL, VL_POTENCIA, VL_CILINDRADA, VL_LUGARES, VL_CAP_CARGA, VL_PESO_BRUTO, CD_CMT, ID_PROC, NM_SIT_CHASSI, NR_CAIXA_CAMBIO, NR_EIXOS, NM_EIXO_TRASEIRO, NM_TERCEIRO_EIXO, NR_MOTOR, ID_MONTAGEM, ID_COD_IMP, ID_IMP, NR_DI, DT_DI, NR_SRF, DT_ATUAL, ID_REST1, ID_REST2, ID_REST3, ID_REST4, NR_REST_TRIB, NM_SITUACAO_VEICULO, ID_MONTADORA 
    FROM 
      {silver_catalog}.predicao_volume.emplacamento_historico)
  ) as tabela_uniao
LEFT JOIN {silver_catalog}.predicao_volume.marca_modelo t2
  ON tabela_uniao.ID_MARCA_MODELO = t2.CD_CODIGO
LEFT JOIN {silver_catalog}.predicao_volume.municipios t3
  ON tabela_uniao.ID_MUNICIPIO = t3.CD_CODIGO_1
LEFT JOIN {silver_catalog}.predicao_volume.tipos_cores t4
  ON cast(tabela_uniao.ID_COR as int) = cast(t4.CD_COD as int)
LEFT JOIN {silver_catalog}.predicao_volume.tipos_combustivel t5
  ON cast(tabela_uniao.ID_COMBUSTIVEL as int) = cast(t5.CD_COD as int)
LEFT JOIN {silver_catalog}.predicao_volume.montadora t6
  ON tabela_uniao.ID_MONTADORA = t6.CD_CODIGO
LEFT JOIN {silver_catalog}.predicao_volume.tipo_veiculo t7
  ON cast(tabela_uniao.ID_TIPO as int) = cast(t7.ID_CODIGO as int)
LEFT JOIN {silver_catalog}.predicao_volume.especie_veiculos t8
  ON cast(tabela_uniao.ID_ESPECIE as  int) = cast(t8.CD_CODIGO as int)
LEFT JOIN {silver_catalog}.predicao_volume.restricoes t9
  ON cast(tabela_uniao.ID_REST1 as int) = cast(t9.CD_COD as int)
LEFT JOIN {silver_catalog}.predicao_volume.restricoes t10
  ON cast(tabela_uniao.ID_REST2 as int) = cast(t10.CD_COD as int)
LEFT JOIN {silver_catalog}.predicao_volume.restricoes t11
  ON cast(tabela_uniao.ID_REST3 as int) = cast(t11.CD_COD as int)
LEFT JOIN {silver_catalog}.predicao_volume.restricoes t12
  ON cast(tabela_uniao.ID_REST4 as int) = cast(t12.CD_COD as int)
LEFT JOIN {silver_catalog}.predicao_volume.segmentos t13
  ON t2.DS_DESCRICAO = t13.NM_MODEL""")

# COMMAND ----------

# DBTITLE 1,Tipagem de Colunas
df_gold_types = df_resumo_geral_final \
    .withColumn('DT_DATA', col('DT_DATA').cast("string")) \
    .withColumn('DC_CHASSI', col('DC_CHASSI').cast("string")) \
    .withColumn('DC_PLACA', col('DC_PLACA').cast("string")) \
    .withColumn('ID_DOC', col('ID_DOC').cast("double"))\
    .withColumn('DC_CNPJ', col('DC_CNPJ').cast("string")) \
    .withColumn('NM_UF_FAT', col('NM_UF_FAT').cast("string")) \
    .withColumn('ID_DOC_PROP', col('ID_DOC_PROP').cast("double")) \
    .withColumn('NM_UF', col('NM_UF').cast("string")) \
    .withColumn('DS_MUNICIPIO', col('DS_MUNICIPIO').cast("string")) \
    .withColumn('DS_UF', col('DS_UF').cast("string")) \
    .withColumn('DS_CIDADES', col('DS_CIDADES').cast("string")) \
    .withColumn('DS_AREA_OPERACIONAL', col('DS_AREA_OPERACIONAL').cast("string")) \
    .withColumn('DS_CIDADE_UF', col('DS_CIDADE_UF').cast("string")) \
    .withColumn('QT_POPULACAO', col('QT_POPULACAO').cast("double")) \
    .withColumn('DS_LOCALIZACAO', col('DS_LOCALIZACAO').cast("string")) \
    .withColumn('DS_ESTRATEGIA', col('DS_ESTRATEGIA').cast("string")) \
    .withColumn('NR_ANO_FABR', col('NR_ANO_FABR').cast("double")) \
    .withColumn('NR_ANO_MOD', col('NR_ANO_MOD').cast("double")) \
    .withColumn('DS_DESCRICAO_MOTO', col('DS_DESCRICAO_MOTO').cast("string")) \
    .withColumn('NM_CATEGORIA', col('NM_CATEGORIA').cast("string")) \
    .withColumn('DS_SEGMENTO_A', col('DS_SEGMENTO_A').cast("string")) \
    .withColumn('DS_SEGMENTO_AA', col('DS_SEGMENTO_AA').cast("string")) \
    .withColumn('NM_DESCRICAO_TIPO_VEICULO', col('NM_DESCRICAO_TIPO_VEICULO').cast("string")) \
    .withColumn('DS_DESCRICAO_ESPECIE', col('DS_DESCRICAO_ESPECIE').cast("string")) \
    .withColumn('ID_CARROCERIA', col('ID_CARROCERIA').cast("double")) \
    .withColumn('NR_CARROCERIA', col('NR_CARROCERIA').cast("string")) \
    .withColumn('DS_DESCRICAO_COR', col('DS_DESCRICAO_COR').cast("string")) \
    .withColumn('DS_DESCRICAO_COMBUSTIVEL', col('DS_DESCRICAO_COMBUSTIVEL').cast("string")) \
    .withColumn('VL_POTENCIA', col('VL_POTENCIA').cast("double")) \
    .withColumn('VL_CILINDRADA', col('VL_CILINDRADA').cast("double")) \
    .withColumn('VL_LUGARES', col('VL_LUGARES').cast("double")) \
    .withColumn('VL_CAP_CARGA', col('VL_CAP_CARGA').cast("double")) \
    .withColumn('VL_PESO_BRUTO', col('VL_PESO_BRUTO').cast("double")) \
    .withColumn('CD_CMT', col('CD_CMT').cast("string")) \
    .withColumn('ID_PROC', col('ID_PROC').cast("double")) \
    .withColumn('NM_SIT_CHASSI', col('NM_SIT_CHASSI').cast("string")) \
    .withColumn('NR_CAIXA_CAMBIO', col('NR_CAIXA_CAMBIO').cast("string")) \
    .withColumn('NR_EIXOS', col('NR_EIXOS').cast("double")) \
    .withColumn('NM_EIXO_TRASEIRO', col('NM_EIXO_TRASEIRO').cast("string")) \
    .withColumn('NM_TERCEIRO_EIXO', col('NM_TERCEIRO_EIXO').cast("string")) \
    .withColumn('NR_MOTOR', col('NR_MOTOR').cast("string")) \
    .withColumn('ID_MONTAGEM', col('ID_MONTAGEM').cast("double")) \
    .withColumn('ID_COD_IMP', col('ID_COD_IMP').cast("string")) \
    .withColumn('ID_IMP', col('ID_IMP').cast("string")) \
    .withColumn('NR_DI', col('NR_DI').cast("string")) \
    .withColumn('DT_DI', col('DT_DI').cast("string")) \
    .withColumn('NR_SRF', col('NR_SRF').cast("string")) \
    .withColumn('DT_ATUAL', col('DT_ATUAL').cast("string")) \
    .withColumn('DS_RESTRICAO_1', col('DS_RESTRICAO_1').cast("string")) \
    .withColumn('DS_RESTRICAO_2', col('DS_RESTRICAO_2').cast("string")) \
    .withColumn('DS_RESTRICAO_3', col('DS_RESTRICAO_3').cast("string")) \
    .withColumn('DS_RESTRICAO_4', col('DS_RESTRICAO_4').cast("string")) \
    .withColumn('NR_REST_TRIB', col('NR_REST_TRIB').cast("string")) \
    .withColumn('NM_SITUACAO_VEICULO', col('NM_SITUACAO_VEICULO').cast("string")) \
    .withColumn('NM_MONTADORA', col('NM_MONTADORA').cast("string")) \
    .withColumn('DS_UF_MONTADORA', col('DS_UF_MONTADORA').cast("string")) \
    .withColumn('NM_BRAND', col('NM_BRAND').cast("string")) \
    .withColumn('NM_SEGMENT_FULL_NEW', col('NM_SEGMENT_FULL_NEW').cast("string")) \
    .withColumn('NM_PPB_CBU', col('NM_PPB_CBU').cast("string")) \
    .withColumn('NM_FAMILY', col('NM_FAMILY').cast("string"))

# COMMAND ----------

# DBTITLE 1,Gravação da tabela na camada Gold
(
    df_gold_types
    .write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f'{gold_catalog}.{param_schema}.{param_nome_tabela}')
)
