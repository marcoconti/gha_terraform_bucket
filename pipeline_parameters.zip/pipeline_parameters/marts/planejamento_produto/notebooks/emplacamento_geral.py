# Databricks notebook source
# MAGIC %md
# MAGIC #Metadados gerais

# COMMAND ----------

# MAGIC %md
# MAGIC **Criado por**: Bruno Jander
# MAGIC
# MAGIC **Data criação**: 14/01/2025
# MAGIC
# MAGIC **Atualizado por**: Bruno Jander
# MAGIC
# MAGIC **Data atualização**: 27/03/2025
# MAGIC
# MAGIC **Atualizado por**: Bruno Jander
# MAGIC
# MAGIC **Data atualização**: 28/03/2025
# MAGIC
# MAGIC **Atualizado por**: Bruno Jander
# MAGIC
# MAGIC **Data atualização**: 31/03/2025
# MAGIC
# MAGIC **Atualizado por**: Bruno Jander
# MAGIC
# MAGIC **Data atualização**: 15/07/2025
# MAGIC
# MAGIC **Atualizado por**: Bruno Jander
# MAGIC
# MAGIC **Data atualização**: 16/07/2025
# MAGIC
# MAGIC [comment]: <> (Tem que vir do negócio)
# MAGIC **Descrição do dataset/tabela/view**: Tabela contendo dados e descrições de emplacamento de veículos.
# MAGIC
# MAGIC [comment]: # (Lineage, nome de domínio, sub-domínio, tipo de agregação, business unit: Tem que vir do negócio)
# MAGIC **Tags**:
# MAGIC
# MAGIC [comment]: # (Tem que vir do negócio)
# MAGIC **Data owner**: 
# MAGIC
# MAGIC [comment]: # (Full/Incremental/Streaming/CDC/etc)
# MAGIC **Tipo de carga**: Full
# MAGIC
# MAGIC [comment]: # (Tem que vir de sistemas)
# MAGIC **Atualização**: Diária

# COMMAND ----------

# MAGIC %md
# MAGIC #### Fontes utilizadas nesse pipeline:
# MAGIC
# MAGIC [comment]: <> (tabelas utilizadas nesse notebook)
# MAGIC
# MAGIC - gold_catalog.corporativo.dm_marca_modelo
# MAGIC - gold_catalog.corporativo.dm_tipos_cores
# MAGIC - gold_catalog.corporativo.dm_tipos_combustivel
# MAGIC - gold_catalog.corporativo.dm_montadora
# MAGIC - gold_catalog.corporativo.dm_tipo_veiculo
# MAGIC - gold_catalog.corporativo.dm_especie_veiculo
# MAGIC - gold_catalog.corporativo.dm_tipos_carrocerias
# MAGIC - gold_catalog.corporativo.dm_tipos_restricoes
# MAGIC - gold_catalog.planejamento_produto.planejamento_produto_emplacamentos_ft_emplacamento_consolidado
# MAGIC - gold_catalog.planejamento_produto.planejamento_produto_emplacamentos_emplacamento_geral

# COMMAND ----------

# MAGIC %md
# MAGIC # Configurações Iniciais

# COMMAND ----------

# DBTITLE 1,Importação de bibliotecas
from os import getenv
from pyspark.sql.functions import col, year, month

# COMMAND ----------

# DBTITLE 1,Variáveis de ambiente
ambiente = getenv("DATABRICKS_ENV").lower()

# COMMAND ----------

# DBTITLE 1,Lineage de diretórios
# <database>/<sistema>/<esquema> ou <external>/<sistema>/<esquema>
# igual ao lineage do pipeline do Informatica
param_lineage_gold = 'planejamento_produto/emplacamentos'
param_schema = "planejamento_produto"
gold_catalog = f'gold_{ambiente}'

# Nome da tabela
param_nome_tabela = 'emplacamento_geral'

# COMMAND ----------

# MAGIC %md
# MAGIC # Gold para Gold

# COMMAND ----------

# DBTITLE 1,Leitura das tabelas na camada Gold
df_ft_emplacamento_consolidado = spark.read.table(f"{gold_catalog}.{param_schema}.ft_emplacamento_consolidado")
df_dm_marca_modelo = spark.read.table(f"{gold_catalog}.corporativo.dm_marca_modelo")
df_dm_tipos_cores = spark.read.table(f"{gold_catalog}.corporativo.dm_tipos_cores")
df_dm_tipos_combustivel = spark.read.table(f"{gold_catalog}.corporativo.dm_tipos_combustivel")
df_dm_montadora = spark.read.table(f"{gold_catalog}.corporativo.dm_montadora")
df_dm_tipo_veiculo = spark.read.table(f"{gold_catalog}.corporativo.dm_tipo_veiculo")
df_dm_especie_veiculo = spark.read.table(f"{gold_catalog}.corporativo.dm_especie_veiculo")
df_dm_tipos_carrocerias = spark.read.table(f"{gold_catalog}.corporativo.dm_tipos_carrocerias")
df_dm_tipos_restricoes = spark.read.table(f"{gold_catalog}.corporativo.dm_tipos_restricoes")

# COMMAND ----------

# DBTITLE 1,Agregação de tabelas tradutoras
df_emplacamentos_e_tradutoras = (
    df_ft_emplacamento_consolidado
    .join(df_dm_marca_modelo, df_ft_emplacamento_consolidado["CD_MARCA_MODELO"] == df_dm_marca_modelo["ID_MARCA_MODELO"], "left")
    .join(df_dm_tipos_cores, df_ft_emplacamento_consolidado["CD_COR"].cast("int") == df_dm_tipos_cores["ID_COR"].cast("int"), "left")
    .join(df_dm_tipos_combustivel, df_ft_emplacamento_consolidado["CD_COMBUSTIVEL"].cast("int") == df_dm_tipos_combustivel["ID_COMBUSTIVEL"].cast("int"), "left")
    .join(df_dm_montadora, df_ft_emplacamento_consolidado["CD_MONTADORA"] == df_dm_montadora["ID_MONTADORA"], "left")
    .join(df_dm_tipo_veiculo, df_ft_emplacamento_consolidado["CD_TIPO"].cast("int") == df_dm_tipo_veiculo["ID_TIPO_VEICULO"].cast("int"), "left")
    .join(df_dm_especie_veiculo, df_ft_emplacamento_consolidado["CD_ESPECIE"].cast("int") == df_dm_especie_veiculo["ID_ESPECIE_VEICULO"].cast("int"), "left")
    .join(df_dm_tipos_carrocerias, df_ft_emplacamento_consolidado["CD_CARROCERIA"] == df_dm_tipos_carrocerias["ID_CARROCERIA"], "left")
    .join(df_dm_tipos_restricoes.alias("t1"), df_ft_emplacamento_consolidado["CD_REST1"].cast("int") == col("t1.ID_RESTRICAO").cast("int"), "left")
    .join(df_dm_tipos_restricoes.alias("t2"), df_ft_emplacamento_consolidado["CD_REST2"].cast("int") == col("t2.ID_RESTRICAO").cast("int"), "left")
    .join(df_dm_tipos_restricoes.alias("t3"), df_ft_emplacamento_consolidado["CD_REST3"].cast("int") == col("t3.ID_RESTRICAO").cast("int"), "left")
    .join(df_dm_tipos_restricoes.alias("t4"), df_ft_emplacamento_consolidado["CD_REST4"].cast("int") == col("t4.ID_RESTRICAO").cast("int"), "left")
)

# COMMAND ----------

# DBTITLE 1,Seleção de campos
df_emplacamentos_e_tradutoras_final = (
    df_emplacamentos_e_tradutoras.select(
        "DT_EMPLACAMENTO","CD_CHASSI", "CD_PLACA", 
        "TP_DOC", "CD_CNPJ", "SG_UF_FAT", 
        "TP_DOC_PROP", "SG_UF", "CD_MUNICIPIO", 
        "NR_ANO_FABR", "NR_ANO_MOD", "DS_MARCA_MODELO", "DS_FABRICACAO",
        "DS_TIPO_VEICULO", "DS_ESPECIE_VEICULO", 
        "DS_CARROCERIA", "CO_CARROCERIA", "DS_COR", "DS_COMBUSTIVEL", 
        "VL_POTENCIA", "VL_CILINDRADA", "QT_LUGARES", "VL_CAP_CARGA", "VL_PESO_BRUTO", 
        "CD_CMT", "CD_PROC", "CD_SIT_CHASSI", "CD_CAIXA_CAMBIO", 
        "QT_EIXOS", "CD_EIXO_TRASEIRO", "CD_TERCEIRO_EIXO", "CD_MOTOR", "CD_MONTAGEM", 
        "CD_IMP", "CO_IMP", "NR_DI", "DT_DI", "NR_SRF", "DT_ATUAL", 
        col("t1.DS_RESTRICAO").alias("DS_RESTRICAO_1"),
        col("t2.DS_RESTRICAO").alias("DS_RESTRICAO_2"),
        col("t3.DS_RESTRICAO").alias("DS_RESTRICAO_3"),
        col("t4.DS_RESTRICAO").alias("DS_RESTRICAO_4"),
        "NR_REST_TRIB", "CD_SITUACAO_VEICULO", "NM_MONTADORA", "CD_COUNTRY_TLD",
        year(col('DT_EMPLACAMENTO')).alias("ANO"), month(col('DT_EMPLACAMENTO')).alias("MES")
    )
)

# COMMAND ----------

# DBTITLE 1,Gravação da tabela na camada Gold
(
    df_emplacamentos_e_tradutoras_final
    .write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f'{gold_catalog}.{param_schema}.{param_nome_tabela}')
)
