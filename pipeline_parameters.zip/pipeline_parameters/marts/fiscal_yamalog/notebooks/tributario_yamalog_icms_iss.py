# Databricks notebook source
# DBTITLE 1,Import de bibliotecas
import os
from pyspark.sql.functions import * 
from pyspark.sql.types import *
from delta.tables import *
from datetime import datetime

# COMMAND ----------

# DBTITLE 1,Criação de método para otimizar delta table
def optimize_delta_table(table_name):
    """
        @param: IN table_path
        Run optimization commands and old snapshots
        Full load
    """
    deltaTable = DeltaTable.forName(spark, table_name)
    deltaTable.vacuum()
    deltaTable.optimize().executeCompaction()
    print('Delta table optimized.') 

# COMMAND ----------

# Ambiente
env = os.environ.get("DATABRICKS_ENV").lower()

# Catalogo, Schema e Nome da tabela
param_catalogo_gold = f"gold_{env}"
param_schema = "fiscal_yamalog"
param_nome_tabela_gold = 'tributario_yamalog_icms_iss'
anoFiltro = (datetime.now().year - 3)

print(f"Tabela: {param_catalogo_gold}.{param_schema}.{param_nome_tabela_gold}")


# COMMAND ----------

ri_df = spark.sql("""  
                    select 
                         RI.SOURCE_CITY_ID, 
                         RI.DESTINATION_CITY_ID, 
                         RI.ICMS_TYPE, 
                         RI.ORGANIZATION_ID, 
                         RI.ENTITY_ID, 
                         RI.INVOICE_TYPE_ID, 
                         RI.INVOICE_ID, 
                         RI.OPERATION_ID
                         from
                            silver_dev.ebs_cll.cll_f189_invoices ri
 """)
ril_df = spark.sql("""
                    select 
                            RIL.ICMS_AMOUNT_RECOVER as ICMS_ARECUPERAR, 
                            RIL.PIS_AMOUNT_RECOVER as PIS, 
                            RIL.ICMS_ST_AMOUNT as ICMS,
                            RIL.COFINS_AMOUNT_RECOVER as COFINS,
                            RIL.TOTAL_AMOUNT as VL_NF,
                            RIL.DESCRIPTION as DESCRICAO, 
                            RIL.ITEM_ID, 
                            RIL.CFO_ID, 
                            RIL.CLASSIFICATION_ID, 
                            RIL.INVOICE_LINE_ID, 
                            RIL.INVOICE_ID
                         from
                            silver_dev.ebs_cll.cll_f189_invoice_lines  RIL
 """)
rit_df = spark.sql("""
                    select 
                            RIT.INVOICE_TYPE_ID,
                            RIT.FISCAL_FLAG
                        from 
                            silver_dev.ebs_cll.cll_f189_invoice_types RIT
                         WHERE 
                            RIT.FISCAL_FLAG = 'Y'
 """)
city_s_df  = spark.sql("""
                    SELECT 
                        c.CITY_ID, 
                        s.STATE_CODE, 
                        c.CITY_CODE, 
                        c.IBGE_CODE
                            FROM    silver_dev.ebs_cll.cll_f189_states s, 
                                    silver_dev.ebs_cll.cll_f189_cities c
                            WHERE  s.STATE_ID = c.STATE_ID
 """)
city_d_df = spark.sql("""
                    SELECT 
                        c.CITY_ID , 
                        s.STATE_CODE, 
                        c.CITY_CODE, 
                        c.IBGE_CODE
                            FROM    silver_dev.ebs_cll.cll_f189_states s,
                                    silver_dev.ebs_cll.cll_f189_cities c
                            WHERE  s.STATE_ID = c.STATE_ID
 """)
rfc_df = spark.sql("""
                    SELECT 
                    RFC.CLASSIFICATION_ID
                    FROM 
                        silver_dev.ebs_cll.cll_f189_fiscal_class as rfc
 """)    
reo_df = spark.sql("""
                    SELECT 
                    to_date(REO.RECEIVE_DATE) as RECEIVE_DATE,
                    Nvl(REO.REVERSION_FLAG, 'x') as REVERSAO,
                    REO.OPERATION_ID,
                    REO.ORGANIZATION_ID + 0 as ORGANIZATION_ID,
                    REO.STATUS as STATUS
                    FROM 
                        silver_dev.ebs_cll.cll_f189_entry_operations as reo
                    WHERE 
                        REO.STATUS = 'COMPLETE'
 """)   
rlc_df  = spark.sql("""
                    SELECT 
                    RLC.LOOKUP_CODE,
                    RLC.LOOKUP_TYPE
                    FROM 
                        silver_dev.ebs_apps.fnd_lookup_values as rlc
                    WHERE   
                        RLC.LOOKUP_TYPE = 'CLL_F189_ICMS_TYPE'
 """)   
rft_df  = spark.sql("""
                    SELECT 
                    RFT.ENTITY_ID,
                    RFT.VENDOR_SITE_ID
                    FROM 
                        silver_dev.ebs_cll.cll_f189_fiscal_entities_all as rft
 """)      
pvs_df  = spark.sql("""
                    SELECT 
                    PVS.VENDOR_SITE_ID,
                    PVS.VENDOR_ID
                    FROM 
                        silver_dev.ebs_apps.ap_supplier_sites_all as pvs
 """)   
pv_df  = spark.sql("""
                    SELECT DISTINCT
                    PV.VENDOR_ID,
                    PV.VENDOR_NAME as FORNECEDOR
                    FROM 
                        silver_dev.ebs_apps.ap_suppliers as pv  
 """)   
msi_df  = spark.sql("""
                    SELECT 
                    MSI.SEGMENT1 as CD_PRODUTO,
                    MSI.INVENTORY_ITEM_ID,
                    MSI.ORGANIZATION_ID,
                    MSI.DESCRIPTION as DS_PRODUTO
                    FROM 
                        silver_dev.ebs_apps.mtl_system_items_b as msi 
 """)   
rfo_df  = spark.sql("""
                    SELECT 
                    RFO.CFO_CODE as CFO_CODE,
                    RFO.CFO_ID
                    FROM 
                        silver_dev.ebs_cll.cll_f189_fiscal_operations as rfo 
                    WHERE 
                        RFO.CFO_CODE != '5907'
 """)        
customers_v_df  = spark.sql("""
                   SELECT   Max(CUSTOMER_NAME) as CUSTOMER_NAME,
                            ENTITY_ID
                   FROM gold_<env>.fiscal_yamalog.tributario_yamalog_cll_f189_customers
                   GROUP BY ENTITY_ID
""")
hou_df  = spark.sql("""
                    SELECT 
                    HOU.NAME as ORGANIZACAO,
                    HOU.ORGANIZATION_ID
                    FROM 
                       gold_<env>.fiscal_yamalog.tributario_yamalog_hr_organization_units as hou
                       where ( hou.NAME LIKE 'YL%' OR hou.NAME LIKE 'L%' ) 
 """)   
org_def_df  = spark.sql("""
                    SELECT  
                        org.ORGANIZATION_ID
                    FROM   
                        silver_dev.ebs_apps.org_organization_definitions as org 
                    WHERE  
                        OPERATING_UNIT = 379
 """)                             

# COMMAND ----------

o2967140_df = ri_df \
    .join(rit_df, ri_df["INVOICE_TYPE_ID"] == rit_df["INVOICE_TYPE_ID"], "inner") \
    .join(ril_df, ri_df["INVOICE_ID"] == ril_df["INVOICE_ID"], "inner") \
    .join(reo_df, ri_df["OPERATION_ID"] == reo_df["OPERATION_ID"], "inner") \
    .join(rfc_df, ril_df["CLASSIFICATION_ID"] == rfc_df["CLASSIFICATION_ID"], "inner") \
    .join(rft_df, ri_df["ENTITY_ID"] == rft_df["ENTITY_ID"], "inner") \
    .join(pvs_df, rft_df["VENDOR_SITE_ID"] == pvs_df["VENDOR_SITE_ID"], "left") \
    .join(pv_df, pvs_df["VENDOR_ID"] == pv_df["VENDOR_ID"], "left") \
    .join(msi_df, ril_df["ITEM_ID"] == msi_df["INVENTORY_ITEM_ID"], "inner") \
    .join(hou_df, (reo_df["ORGANIZATION_ID"] + 0) == hou_df["ORGANIZATION_ID"], "inner") \
    .join(rlc_df, ri_df["ICMS_TYPE"] == rlc_df["LOOKUP_CODE"], "inner") \
    .join(city_s_df, ri_df["SOURCE_CITY_ID"] == city_s_df["CITY_ID"], "left") \
    .join(city_d_df, ri_df["DESTINATION_CITY_ID"] == city_d_df["CITY_ID"], "left")

# COMMAND ----------

sub_df = (o2967140_df
    .join(customers_v_df, o2967140_df["rft.ENTITY_ID"] == customers_v_df["ENTITY_ID"], "left") # 13.462.262
    .join(org_def_df, org_def_df["org.ORGANIZATION_ID"] == o2967140_df["hou.ORGANIZATION_ID"], "inner") # 13.462.262
)

# COMMAND ----------

result = sub_df.select(
         when(sub_df.ORGANIZACAO == 'YL1-MANAUS', '0001')
        .when(sub_df.ORGANIZACAO == 'YL2-JANDIRA', '0002')
        .when(sub_df.ORGANIZACAO == 'YL3-SAO PAULO', '0003')
        .when(sub_df.ORGANIZACAO == 'YL4-BELEM', '0004')
        .when(sub_df.ORGANIZACAO == 'YL5-CURITIBA', '0005')
        .when(sub_df.ORGANIZACAO == 'YL6-CONTAGEM', '0006')
        .when(sub_df.ORGANIZACAO == 'YL7-SANTA RITA', '0007')
        .when(sub_df.ORGANIZACAO == 'YL8-NEROPOLIS', '0008')
        .when(sub_df.ORGANIZACAO == 'YL9-MARAPATA', '0009')
        .when(sub_df.ORGANIZACAO == 'L10-ITAJAI', '0010')
        .when(sub_df.ORGANIZACAO == 'L12-RECIFE', '0012')
        .alias('ID_ORGANIZACAO'),
    sub_df['hou.ORGANIZATION_ID'].alias("ORGANIZACAO_ID_HOU"),
    sub_df.ORGANIZACAO.alias("DS_ORGANIZACAO"),
    sub_df.RECEIVE_DATE.alias("DT_RECEBIMENTO"),
    sub_df.CD_PRODUTO,
    coalesce(sub_df["DS_PRODUTO"], sub_df["DESCRICAO"]).alias('DS_PRODUTO'), 
    coalesce(sub_df["FORNECEDOR"], sub_df["CUSTOMER_NAME"]).alias('DS_FORNECEDOR'),
    sub_df.REVERSAO.alias("DS_REVERSAO"),
    sub_df.STATUS.alias("DS_STATUS"),
    sub_df.ICMS_ARECUPERAR,
    sub_df.PIS,
    sub_df.ICMS,
    sub_df.COFINS,
    year(sub_df["RECEIVE_DATE"]).alias("YEAR"),
    lpad(month(sub_df["RECEIVE_DATE"]), 2, '0').alias("MONTH")
)

# COMMAND ----------

result_grouped = result.groupBy(
    "ID_ORGANIZACAO", "DS_ORGANIZACAO", "DT_RECEBIMENTO", "CD_PRODUTO", "DS_PRODUTO", "DS_FORNECEDOR", "DS_REVERSAO", "DS_STATUS", "YEAR", "MONTH")\
    .agg(
    sum("ICMS_ARECUPERAR").alias("VL_ICMS_ARECUPERAR"),
    sum("PIS").alias("VL_PIS"),
    sum("ICMS").alias("VL_ICMS"),
    sum("COFINS").alias("VL_COFINS")
)
    
#ordenando campos
dfFinal = (
    result_grouped
    .select(
        'ID_ORGANIZACAO'
        ,'DS_ORGANIZACAO'
        ,'DT_RECEBIMENTO'
        ,'CD_PRODUTO'
        ,'DS_PRODUTO'
        ,'DS_FORNECEDOR'
        ,'DS_REVERSAO'
        ,'DS_STATUS'
        ,'VL_ICMS_ARECUPERAR'
        ,'VL_PIS'
        ,'VL_ICMS'
        ,'VL_COFINS'
        ,'YEAR'
        ,'MONTH'
    )
    .filter(f"YEAR >= {anoFiltro}") #2 anos retroativo + ano corrente

)


# COMMAND ----------


table = f"{param_catalogo_gold}.{param_schema}.{param_nome_tabela_gold}"

print(f"Escrevendo a tabela {table}")

(
    dfFinal
    .write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .partitionBy("YEAR","MONTH")
    .saveAsTable(table)
)

# optimization Gold layer
optimize_delta_table(table)
