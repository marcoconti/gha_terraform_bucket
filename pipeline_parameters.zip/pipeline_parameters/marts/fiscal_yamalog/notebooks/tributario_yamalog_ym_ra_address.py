# Databricks notebook source
import os
from pyspark.sql.functions import *
from pyspark.sql.types import *
from delta.tables import *

# COMMAND ----------

def optimize_delta_table(table_name):
    """
        @param: IN table_path
        Run optimization commands and old snapshots
        Full load
    """
    deltaTable = DeltaTable.forName(spark, table_name)
    deltaTable.vacuum()
    deltaTable.optimize().executeCompaction()
    print('Delta table optimized.') 

# COMMAND ----------

# DBTITLE 1,Definição de variáveis
# Ambiente
env = os.environ.get("DATABRICKS_ENV").lower()

# Catalogo, Schema e Nome da tabela
param_catalogo_gold = f"gold_{env}"
param_schema = "fiscal_yamalog"
param_nome_tabela_gold = 'tributario_yamalog_ym_ra_address'

print(f"Tabela: {param_catalogo_gold}.{param_schema}.{param_nome_tabela_gold}")


# COMMAND ----------

df_hz_party_sites = spark.sql("""
    SELECT 
        party_site.PARTY_SITE_ID,
        party_site.PARTY_ID,
        party_site.PARTY_SITE_NUMBER,
        party_site.IDENTIFYING_ADDRESS_FLAG,
        party_site.ADDRESSEE,
        party_site.LOCATION_ID as LOCATION_PARTY_ID
        FROM 
            silver_dev.ebs_apps.hz_party_sites  as party_site
 """)
df_hz_cust_acct_sites_all = spark.sql("""
    SELECT
        acct_site.TERRITORY_ID,
        acct_site.CUST_ACCOUNT_ID,
        acct_site.SERVICE_TERRITORY_ID,
        acct_site.PARTY_SITE_ID as PARTY_SITE_ACCT_ID,
        acct_site.PRIMARY_SPECIALIST_ID,
        acct_site.SECONDARY_SPECIALIST_ID,
        NVL(acct_site.ORG_ID, -99)  as ORG_ACCT_ID,
        acct_site.REQUEST_ID,
        acct_site.PROGRAM_APPLICATION_ID,
        acct_site.PROGRAM_ID,
        acct_site.CUST_ACCT_SITE_ID,
        acct_site.TP_HEADER_ID,
        acct_site.WH_UPDATE_DATE,
        acct_site.LAST_UPDATE_DATE,
        acct_site.LAST_UPDATED_BY,
        acct_site.CREATION_DATE,
        acct_site.LAST_UPDATE_LOGIN,
        acct_site.PROGRAM_UPDATE_DATE,
        acct_site.KEY_ACCOUNT_FLAG,
        acct_site.BILL_TO_FLAG,
        acct_site.MARKET_FLAG,
        acct_site.SHIP_TO_FLAG,
        acct_site.CUSTOMER_CATEGORY_CODE,
        acct_site.STATUS,
        acct_site.ORIG_SYSTEM_REFERENCE,
        acct_site.CREATED_BY,
        acct_site.ATTRIBUTE_CATEGORY,
        acct_site.ATTRIBUTE1,
        acct_site.ATTRIBUTE2,
        acct_site.ATTRIBUTE3,
        acct_site.ATTRIBUTE4,
        acct_site.ATTRIBUTE5,
        acct_site.ATTRIBUTE6,
        acct_site.ATTRIBUTE7,
        acct_site.ATTRIBUTE8,
        acct_site.ATTRIBUTE9,
        acct_site.ATTRIBUTE10,
        acct_site.GLOBAL_ATTRIBUTE1,
        acct_site.GLOBAL_ATTRIBUTE2,
        acct_site.GLOBAL_ATTRIBUTE3,
        acct_site.GLOBAL_ATTRIBUTE4,
        acct_site.GLOBAL_ATTRIBUTE5,
        acct_site.GLOBAL_ATTRIBUTE6,
        acct_site.GLOBAL_ATTRIBUTE7,
        acct_site.GLOBAL_ATTRIBUTE8,
        acct_site.GLOBAL_ATTRIBUTE9,
        acct_site.GLOBAL_ATTRIBUTE10,
        acct_site.GLOBAL_ATTRIBUTE11,
        acct_site.GLOBAL_ATTRIBUTE12,
        acct_site.GLOBAL_ATTRIBUTE13,
        acct_site.GLOBAL_ATTRIBUTE14,
        acct_site.GLOBAL_ATTRIBUTE15,
        acct_site.GLOBAL_ATTRIBUTE16,
        acct_site.GLOBAL_ATTRIBUTE17,
        acct_site.GLOBAL_ATTRIBUTE18,
        acct_site.GLOBAL_ATTRIBUTE19,
        acct_site.GLOBAL_ATTRIBUTE_CATEGORY,
        acct_site.GLOBAL_ATTRIBUTE20,
        acct_site.ECE_TP_LOCATION_CODE,
        acct_site.TERRITORY ,
        acct_site.TRANSLATED_CUSTOMER_NAME,
        acct_site.ADDRESS_TEXT,
        acct_site.ATTRIBUTE16,
        acct_site.ATTRIBUTE17,
        acct_site.ATTRIBUTE18,
        acct_site.ATTRIBUTE19,
        acct_site.ATTRIBUTE20
        FROM 
            silver_dev.ebs_apps.hz_cust_acct_sites_all as acct_site 
 """)
df_hz_locations = spark.sql("""
    SELECT
        loc.ADDRESS_KEY,
        loc.LOCATION_ID,
        loc.ATTRIBUTE11,
        loc.ATTRIBUTE12,
        loc.ATTRIBUTE13,
        loc.ATTRIBUTE14,
        loc.ATTRIBUTE15,
        loc.ADDRESS_STYLE,
        loc.LANGUAGE,
        loc.COUNTRY,
        loc.ADDRESS1,
        loc.ADDRESS2,
        loc.ADDRESS3,
        loc.ADDRESS4,
        loc.CITY,
        loc.POSTAL_CODE,
        loc.STATE,
        loc.PROVINCE,
        loc.COUNTY,
        loc.ADDRESS_LINES_PHONETIC,
        loc.SALES_TAX_GEOCODE,
        loc.SALES_TAX_INSIDE_CITY_LIMITS
        FROM 
            silver_dev.ebs_apps.hz_locations     as      loc
 """)
df_hz_loc_assignments = spark.sql("""
    SELECT
        loc_assign.LOCATION_ID as LOCATION_LOC_ID,
        loc_assign.LOC_ID,
        NVL(loc_assign.ORG_ID, -99) as ORG_ID
        FROM
            silver_dev.ebs_apps.hz_loc_assignments   as   loc_assign
 """)

# COMMAND ----------

# print('df_hz_party_sites.count ',df_hz_party_sites.count()) # 110.682
# print('f_hz_cust_acct_sites_all.count ',df_hz_cust_acct_sites_all.count()) # 64.418
# print('df_hz_locations.count ',df_hz_locations.count()) # 96.872
# print('df_hz_loc_assignments.count ',df_hz_loc_assignments.count()) # 64.401

# COMMAND ----------

df_ym_ra_addresses_v = (
        df_hz_party_sites.alias('pts')
        .join(df_hz_cust_acct_sites_all.alias('act'), 
              col('pts.PARTY_SITE_ID') == col('act.PARTY_SITE_ACCT_ID'),'inner')
        .drop('act.PARTY_SITE_ACCT_ID')
        
        .join(df_hz_locations.alias('loc'), 
              col('loc.LOCATION_ID') == col('pts.LOCATION_PARTY_ID'), 'inner')
        .drop('pts.LOCATION_PARTY_ID')
        
        .join(df_hz_loc_assignments.alias('lca'), 
              (col('act.ORG_ACCT_ID') == col('lca.ORG_ID')) & 
              (col('loc.LOCATION_ID') == col('lca.LOCATION_LOC_ID')), 'inner')
        .drop('lca.LOCATION_LOC_ID')
        .drop('act.ORG_ACCT_ID')
)

# COMMAND ----------

table = f"{param_catalogo_gold}.{param_schema}.{param_nome_tabela_gold}"

print(f"Escrevendo a tabela {table}")

(
    df_ym_ra_addresses_v
    .write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(table)
)

# optimization Gold layer
optimize_delta_table(table)
