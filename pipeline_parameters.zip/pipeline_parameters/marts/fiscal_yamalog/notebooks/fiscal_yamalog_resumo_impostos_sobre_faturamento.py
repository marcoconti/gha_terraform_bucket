# Databricks notebook source
# MAGIC %md
# MAGIC ### Relatorio:  `YM_5522_12 - YBL`
# MAGIC ### Assunto:    `Resumo Dos Impostos sobre Faturamento - Especifico Yamalog (YBL)`
# MAGIC ### Criado Por: `LEEGA`
# MAGIC ### Data:       `19-12-2023`
# MAGIC ### Alterado Por: `Caio Francisco `
# MAGIC ### Data:       `18-08-2025` 

# COMMAND ----------

# DBTITLE 1,Import de bibliotecas
import os
from pyspark.sql.functions import * 
from pyspark.sql.types import *
from delta.tables import *
from datetime import datetime

# COMMAND ----------

# DBTITLE 1,Criação de método para otimizar delta table
def optimize_delta_table(table_name):
    """
        @param: IN table_path
        Run optimization commands and old snapshots
        Full load
    """
    deltaTable = DeltaTable.forName(spark, table_name)
    deltaTable.vacuum()
    deltaTable.optimize().executeCompaction()
    print('Delta table optimized.') 

# COMMAND ----------

# Ambiente
env = os.environ.get("DATABRICKS_ENV").lower()

# Catalogo, Schema e Nome da tabela
param_catalogo_gold = f"gold_{env}"
param_schema = "fiscal_yamalog"
param_nome_tabela_gold = 'fiscal_yamalog_resumo_impostos_sobre_faturamento'
anoFiltro = (datetime.now().year - 3)

print(f"Tabela: {param_catalogo_gold}.{param_schema}.{param_nome_tabela_gold}")


# COMMAND ----------

df_impostos_gerais = spark.sql(f""" 
                               
        SELECT 
          DECODE(RCTA.ORG_ID, 84, 'YMB', 85, 'YMA', 86, 'YAC', 133, 'YCA', 295, 'YEB', 379, 'YBL', 579, 'YA3') ORGANIZACAO ,
          CASE
                    WHEN RCTLA.WAREHOUSE_ID = 90
                    AND       RCTLA.ORG_ID = 85 THEN 'YAF'
                    WHEN RCTLA.WAREHOUSE_ID = 89
                    AND       RCTLA.ORG_ID = 85 THEN 'YA'
                    WHEN RCTLA.WAREHOUSE_ID = 579
                    AND       RCTLA.ORG_ID = 85 THEN 'YA3'
                    WHEN RCTLA.WAREHOUSE_ID = 519
                    AND       RCTLA.ORG_ID = 84 THEN 'YB3'
                    WHEN RCTLA.WAREHOUSE_ID = 659
                    AND       RCTLA.ORG_ID = 84 THEN 'YB4'
                    WHEN RCTLA.WAREHOUSE_ID = 679
                    AND       RCTLA.ORG_ID = 84 THEN 'YB6'
                    WHEN RCTLA.WAREHOUSE_ID = 759
                    AND       RCTLA.ORG_ID = 84 THEN 'YB8'
                    WHEN RCTLA.WAREHOUSE_ID = 739
                    AND       RCTLA.ORG_ID = 85 THEN 'YA5'
                    WHEN RCTLA.WAREHOUSE_ID = 399
                    AND       RCTLA.ORG_ID = 379 THEN 'YAMALOG MANAUS  - 0001'
                    WHEN RCTLA.WAREHOUSE_ID = 419
                    AND       RCTLA.ORG_ID = 379 THEN 'YAMALOG JANDIRA  - 0002'
                    WHEN RCTLA.WAREHOUSE_ID = 439
                    AND       RCTLA.ORG_ID = 379 THEN 'YAMALOG ANHANGUERA - 0003'
                    WHEN RCTLA.WAREHOUSE_ID = 459
                    AND       RCTLA.ORG_ID = 379 THEN 'YAMALOG BELÉM - 0004'
                    WHEN RCTLA.WAREHOUSE_ID = 479
                    AND       RCTLA.ORG_ID = 379 THEN 'YAMALOG SAO JOSE DOS PINHAIS - 0005'
                    WHEN RCTLA.WAREHOUSE_ID = 499
                    AND       RCTLA.ORG_ID = 379 THEN 'YAMALOG CONTAGEM - 0006'
                    WHEN RCTLA.WAREHOUSE_ID = 539
                    AND       RCTLA.ORG_ID = 379 THEN 'YAMALOG SANTA RITA - 0007'
                    WHEN RCTLA.WAREHOUSE_ID = 559
                    AND       RCTLA.ORG_ID = 379 THEN 'YAMALOG NEROPOLIS - 0008'
                    WHEN RCTLA.WAREHOUSE_ID = 599
                    AND       RCTLA.ORG_ID = 379 THEN 'YAMALOG ITAJAÍ  - 0010'
                    WHEN RCTLA.WAREHOUSE_ID = 619
                    AND       RCTLA.ORG_ID = 379 THEN 'YAMALOG MARAPATÁ  - 0009'
                    WHEN RCTLA.WAREHOUSE_ID = 699
                    AND       RCTLA.ORG_ID = 379 THEN 'YAMALOG RECIFE - 0012'
                    WHEN RCTLA.WAREHOUSE_ID = 779
                    AND       RCTLA.ORG_ID = 379 THEN 'YAMALOG CASCAVEL - 0013'
                    WHEN RCTLA.WAREHOUSE_ID = 819
                    AND       RCTLA.ORG_ID = 379 THEN 'YAMALOG FEIRA DE SANTANA - 0014'
                    WHEN RCTLA.WAREHOUSE_ID = 859
                    AND       RCTLA.ORG_ID = 379 THEN 'YAMALOG ITAITINGA - 0015'
                    ELSE DECODE(RCTLA.ORG_ID, 84, 'YB', 85, 'YA', 86, 'YAC', 133, 'YCA', 295, 'YEB', 379, 'YBL' )
          END EMPRESA ,
          RBSA.NAME ,
          MSI.SEGMENT1                                                           COD_PROD ,
          MSI.DESCRIPTION                                                        DESCRI ,
          RCTA.TRX_NUMBER                                                        NOTA ,
          RCTA.TRX_DATE                                                          DATA ,
          DECODE(rcta.status_trx,'VD','Canc','OP','Completa',rcta.status_trx) STATUS ,
          HL.STATE                                                               ESTADO ,
          RCTA.FOB_POINT                                                         FOB ,
          HP.PARTY_NAME                                                          NOME_CLIENTE ,
          HCSUA.FOB_POINT                                                        FOB_POINT ,
          RAT.NAME                                                               CONDPAG ,
          RCTTA.NAME                                                             TRANSACAO_AR ,
          RCTLA.GLOBAL_ATTRIBUTE1                                                CFOP ,
          (DECODE(RCTLA.LINE_TYPE,'LINE',1,0))                                   QTDE ,
          (DECODE(RCTLA.LINE_TYPE,'LINE',(NVL(NVL(RCTLA.UNIT_STANDARD_PRICE, RCTLA.UNIT_SELLING_PRICE),0)-DOUBLE(NVL(REPLACE(RCTLA.ATTRIBUTE10,'.',','),0))-DOUBLE(NVL(REPLACE(RCTLA.ATTRIBUTE11,'.',','),0))))) PRECO_UNITARIO ,
          (DECODE(RCTLA.LINE_TYPE,'LINE',NVL(RCTLA.EXTENDED_AMOUNT,0) ,0))                                                                                                                                                 VALOR_TOTAL ,
          RP.PREVIOUS_CUSTOMER_TRX_ID PREVIOUS_CUSTOMER_TRX_ID ,
          RP.TRX_NUMBER              AV_CREDITO ,
          RP.TRX_DATE                TRX_DATE ,
          CTE.IDE_UF_INI             UF_ORIG ,
          CTE.IDE_MUNICIPIO_INI      CIDADE_ORIG ,
          CTE.IDE_COD_IBGE_MUN_INI   IBGE_ORIG ,
          CTE.IDE_UF_FIM             UF_DEST ,
          CTE.IDE_MUNICIPIO_FIM      CIDADE_DEST ,
          CTE.IDE_COD_IBGE_MUN_FIM   IBGE_DEST ,
          --
          CASE
                    WHEN RCTA.INTERFACE_HEADER_CONTEXT IN ('YBL_CTE_KMM_LINES') THEN CTE.CHAVE
                    ELSE JBCRE.ELECTRONIC_INV_ACCESS_KEY
          END AS CHAVE_ELETRONICA
          --
          ,
          (
                 SELECT SUM(ZZL.TAXABLE_AMT)
                 FROM   silver_{env}.ebs_zx.ZX_LINES ZZL
                 WHERE  ZZL.TRX_LINE_ID = RCTLA.CUSTOMER_TRX_LINE_ID
                 AND    ZZL.TRX_ID = RCTLA.CUSTOMER_TRX_ID
                 AND    ZZL.TAX LIKE 'ICMS%C' ) AS BC_ICMS
          --
          ,
          (
                 SELECT SUM(ZZL.TAX_RATE)
                 FROM   silver_{env}.ebs_zx.ZX_LINES ZZL
                 WHERE  ZZL.TRX_LINE_ID = RCTLA.CUSTOMER_TRX_LINE_ID
                 AND    ZZL.TRX_ID = RCTLA.CUSTOMER_TRX_ID
                 AND    ZZL.TAX LIKE 'ICMS%C' ) ALIQ_ICMS
          --
          ,
          (
                 SELECT SUM(ZZL.TAX_AMT)
                 FROM   silver_{env}.ebs_zx.ZX_LINES ZZL
                 WHERE  ZZL.TRX_LINE_ID = RCTLA.CUSTOMER_TRX_LINE_ID
                 AND    ZZL.TRX_ID = RCTLA.CUSTOMER_TRX_ID
                 AND    ZZL.TAX LIKE 'ICMS%C' ) VL_ICMS
          --
          ,
          (
                 SELECT SUM(ZZL.TAXABLE_AMT)
                 FROM   silver_{env}.ebs_zx.ZX_LINES ZZL
                 WHERE  ZZL.TRX_LINE_ID = RCTLA.CUSTOMER_TRX_LINE_ID
                 AND    ZZL.TRX_ID = RCTLA.CUSTOMER_TRX_ID
                 AND    ZZL.TAX LIKE 'ISS%C' ) BC_ISS
          --
          ,
          (
                 SELECT SUM(ZZL.TAX_RATE)
                 FROM   silver_{env}.ebs_zx.ZX_LINES ZZL
                 WHERE  ZZL.TRX_LINE_ID = RCTLA.CUSTOMER_TRX_LINE_ID
                 AND    ZZL.TRX_ID = RCTLA.CUSTOMER_TRX_ID
                 AND    ZZL.TAX LIKE 'ISS%C' ) ALIQ_ISS
          --
          ,
          (
                 SELECT SUM(ZZL.TAX_AMT)
                 FROM   silver_{env}.ebs_zx.ZX_LINES ZZL
                 WHERE  ZZL.TRX_LINE_ID = RCTLA.CUSTOMER_TRX_LINE_ID
                 AND    ZZL.TRX_ID = RCTLA.CUSTOMER_TRX_ID
                 AND    ZZL.TAX LIKE 'ISS%C' ) VL_ISS
          --
          ,
          (
                 SELECT SUM(ZZL.TAXABLE_AMT)
                 FROM   silver_{env}.ebs_zx.ZX_LINES ZZL
                 WHERE  ZZL.TRX_LINE_ID = RCTLA.CUSTOMER_TRX_LINE_ID
                 AND    ZZL.TRX_ID = RCTLA.CUSTOMER_TRX_ID
                 AND    ZZL.TAX LIKE 'PIS%C' ) BC_PIS
          --
          ,
          (
                 SELECT SUM(ZZL.TAX_RATE)
                 FROM   silver_{env}.ebs_zx.ZX_LINES ZZL
                 WHERE  ZZL.TRX_LINE_ID = RCTLA.CUSTOMER_TRX_LINE_ID
                 AND    ZZL.TRX_ID = RCTLA.CUSTOMER_TRX_ID
                 AND    ZZL.TAX LIKE 'PIS%C' ) ALIQ_PIS
          --
          ,
          (
                 SELECT SUM(ZZL.TAX_AMT)
                 FROM   silver_{env}.ebs_zx.ZX_LINES ZZL
                 WHERE  ZZL.TRX_LINE_ID = RCTLA.CUSTOMER_TRX_LINE_ID
                 AND    ZZL.TRX_ID = RCTLA.CUSTOMER_TRX_ID
                 AND    ZZL.TAX LIKE 'PIS%C' ) VL_PIS
          --
          ,
          (
                 SELECT SUM(ZZL.TAX_RATE)
                 FROM   silver_{env}.ebs_zx.ZX_LINES ZZL
                 WHERE  ZZL.TRX_LINE_ID = RCTLA.CUSTOMER_TRX_LINE_ID
                 AND    ZZL.TRX_ID = RCTLA.CUSTOMER_TRX_ID
                 AND    ZZL.TAX LIKE 'PIS_RET_YBL_D' ) ALIQ_PIS_RET
          --
          ,
          (
                 SELECT SUM(ZZL.TAX_AMT)
                 FROM   silver_{env}.ebs_zx.ZX_LINES ZZL
                 WHERE  ZZL.TRX_LINE_ID = RCTLA.CUSTOMER_TRX_LINE_ID
                 AND    ZZL.TRX_ID = RCTLA.CUSTOMER_TRX_ID
                 AND    ZZL.TAX LIKE 'PIS_RET_YBL_D' ) VL_PIS_RET
          --
          ,
          (
                 SELECT SUM(ZZL.TAXABLE_AMT)
                 FROM   silver_{env}.ebs_zx.ZX_LINES ZZL
                 WHERE  ZZL.TRX_LINE_ID = RCTLA.CUSTOMER_TRX_LINE_ID
                 AND    ZZL.TRX_ID = RCTLA.CUSTOMER_TRX_ID
                 AND    ZZL.TAX LIKE 'COFINS%C' ) BC_COFINS
          --
          ,
          (
                 SELECT SUM(ZZL.TAX_RATE)
                 FROM   silver_{env}.ebs_zx.ZX_LINES ZZL
                 WHERE  ZZL.TRX_LINE_ID = RCTLA.CUSTOMER_TRX_LINE_ID
                 AND    ZZL.TRX_ID = RCTLA.CUSTOMER_TRX_ID
                 AND    ZZL.TAX LIKE 'COFINS%C' ) ALIQ_COFINS
          --
          ,
          (
                 SELECT SUM(ZZL.TAX_AMT)
                 FROM   silver_{env}.ebs_zx.ZX_LINES ZZL
                 WHERE  ZZL.TRX_LINE_ID = RCTLA.CUSTOMER_TRX_LINE_ID
                 AND    ZZL.TRX_ID = RCTLA.CUSTOMER_TRX_ID
                 AND    ZZL.TAX LIKE 'COFINS%C' ) VL_COFINS
          --
          ,
          (
                 SELECT SUM(ZZL.TAX_RATE)
                 FROM   silver_{env}.ebs_zx.ZX_LINES ZZL
                 WHERE  ZZL.TRX_LINE_ID = RCTLA.CUSTOMER_TRX_LINE_ID
                 AND    ZZL.TRX_ID = RCTLA.CUSTOMER_TRX_ID
                 AND    ZZL.TAX LIKE 'COFINS_RET_YBL_D' ) ALIQ_COFINS_RET
          --
          ,
          (
                 SELECT SUM(ZZL.TAX_AMT)
                 FROM   silver_{env}.ebs_zx.ZX_LINES ZZL
                 WHERE  ZZL.TRX_LINE_ID = RCTLA.CUSTOMER_TRX_LINE_ID
                 AND    ZZL.TRX_ID = RCTLA.CUSTOMER_TRX_ID
                 AND    ZZL.TAX LIKE 'COFINS_RET_YBL_D' ) VL_COFINS_RET
          --
          ,
          (
                 SELECT SUM(ZZL.TAX_RATE)
                 FROM   silver_{env}.ebs_zx.ZX_LINES ZZL
                 WHERE  ZZL.TRX_LINE_ID = RCTLA.CUSTOMER_TRX_LINE_ID
                 AND    ZZL.TRX_ID = RCTLA.CUSTOMER_TRX_ID
                 AND    ZZL.TAX LIKE 'IRRF_D' ) ALIQ_IRRF_RET
          --
          ,
          (
                 SELECT SUM(ZZL.TAX_AMT)
                 FROM   silver_{env}.ebs_zx.ZX_LINES ZZL
                 WHERE  ZZL.TRX_LINE_ID = RCTLA.CUSTOMER_TRX_LINE_ID
                 AND    ZZL.TRX_ID = RCTLA.CUSTOMER_TRX_ID
                 AND    ZZL.TAX LIKE 'IRRF_D' ) VL_IRRF_RET
          --
          ,
          (
                 SELECT SUM(ZZL.TAX_RATE)
                 FROM   silver_{env}.ebs_zx.ZX_LINES ZZL
                 WHERE  ZZL.TRX_LINE_ID = RCTLA.CUSTOMER_TRX_LINE_ID
                 AND    ZZL.TRX_ID = RCTLA.CUSTOMER_TRX_ID
                 AND    ZZL.TAX LIKE 'CSLL_D' ) ALIQ_CSLL_RET
          --
          ,
          (
                 SELECT SUM(ZZL.TAX_AMT)
                 FROM   silver_{env}.ebs_zx.ZX_LINES ZZL
                 WHERE  ZZL.TRX_LINE_ID = RCTLA.CUSTOMER_TRX_LINE_ID
                 AND    ZZL.TRX_ID = RCTLA.CUSTOMER_TRX_ID
                 AND    ZZL.TAX LIKE 'CSLL_D' ) VL_CSLL_RET
          --
          ,
          (
                 SELECT SUM(ZZL.TAX_RATE)
                 FROM   silver_{env}.ebs_zx.ZX_LINES ZZL
                 WHERE  ZZL.TRX_LINE_ID = RCTLA.CUSTOMER_TRX_LINE_ID
                 AND    ZZL.TRX_ID = RCTLA.CUSTOMER_TRX_ID
                 AND    ZZL.TAX LIKE 'INSS_D' ) ALIQ_INSS_RET
          --
          ,
          (
                 SELECT SUM(ZZL.TAX_AMT)
                 FROM   silver_{env}.ebs_zx.ZX_LINES ZZL
                 WHERE  ZZL.TRX_LINE_ID = RCTLA.CUSTOMER_TRX_LINE_ID
                 AND    ZZL.TRX_ID = RCTLA.CUSTOMER_TRX_ID
                 AND    ZZL.TAX LIKE 'INSS_D' ) VL_INSS_RET
          ,year(RCTA.TRX_DATE)                  YEAR
          ,month(RCTA.TRX_DATE)                 MONTH
            
FROM            silver_{env}.ebs_apps.HZ_PARTIES HP
INNER JOIN      silver_{env}.ebs_apps.HZ_PARTY_SITES HPS
       ON        HP.PARTY_ID = HPS.PARTY_ID
INNER JOIN      silver_{env}.ebs_apps.HZ_CUST_ACCT_SITES_ALL HCASA
       ON        HPS.PARTY_SITE_ID = HCASA.PARTY_SITE_ID
INNER JOIN      silver_{env}.ebs_apps.HZ_CUST_SITE_USES_ALL HCSUA
       ON        HCSUA.CUST_ACCT_SITE_ID = HCASA.CUST_ACCT_SITE_ID
INNER JOIN      silver_{env}.ebs_apps.HZ_LOCATIONS HL
       ON        HPS.LOCATION_ID = HL.LOCATION_ID
INNER JOIN      silver_{env}.ebs_apps.RA_CUSTOMER_TRX_ALL RCTA
       ON       HCSUA.SITE_USE_ID = RCTA.BILL_TO_SITE_USE_ID
      AND       TRIM(TRANSLATE(RCTA.TRX_NUMBER, '1234567890',NULL)) IS NULL
      AND       RCTA.ORG_ID = 379
      AND       RCTA.COMPLETE_FLAG = 'Y'
      AND       year(RCTA.TRX_DATE) >= {anoFiltro} --2 anos retroativo + ano corrente 
INNER JOIN      silver_{env}.ebs_apps.RA_CUSTOMER_TRX_LINES_ALL RCTLA
       ON RCTA.CUSTOMER_TRX_ID = RCTLA.CUSTOMER_TRX_ID
      AND RCTLA.LINE_TYPE IN ('LINE') 
INNER JOIN      silver_{env}.ebs_ar.RA_CUST_TRX_LINE_GL_DIST_ALL GLD
       ON        GLD.CUSTOMER_TRX_LINE_ID = RCTLA.CUSTOMER_TRX_LINE_ID
INNER JOIN      silver_{env}.ebs_apps.RA_CUST_TRX_TYPES_ALL RCTTA
       ON        RCTA.CUST_TRX_TYPE_ID = RCTTA.CUST_TRX_TYPE_ID
      AND        RCTTA.NAME <> 'FATURA CT-E KMM' 
INNER JOIN      silver_{env}.ebs_apps.MTL_SYSTEM_ITEMS_B MSI
       ON        RCTLA.INVENTORY_ITEM_ID = MSI.INVENTORY_ITEM_ID
       AND       RCTLA.WAREHOUSE_ID = MSI.ORGANIZATION_ID
INNER JOIN      silver_{env}.ebs_apps.RA_TERMS_TL RAT
       ON        RCTA.TERM_ID = RAT.TERM_ID
      AND        RAT.LANGUAGE = 'PTB' 
INNER JOIN      silver_{env}.ebs_apps.RA_BATCH_SOURCES_ALL RBSA
       ON        RCTA.BATCH_SOURCE_ID = RBSA.BATCH_SOURCE_ID
INNER JOIN      silver_{env}.ebs_apps.JL_BR_CUSTOMER_TRX_EXTS JBCRE
       ON        JBCRE.CUSTOMER_TRX_ID = RCTA.CUSTOMER_TRX_ID
LEFT JOIN silver_{env}.ebs_apps.YM_TMS_VW_CONHECIMENTO CTE
       ON        RCTLA.INTERFACE_LINE_ATTRIBUTE2 = CTE.CONTROL_ID
LEFT JOIN silver_{env}.ebs_apps.RA_CUSTOMER_TRX_ALL RP
       ON        RCTA.CUSTOMER_TRX_ID = RP.PREVIOUS_CUSTOMER_TRX_ID      
       
 """)


# COMMAND ----------

# MAGIC %md #### CASTING

# COMMAND ----------

df_impostos_gerais = (
    df_impostos_gerais
    .withColumn('DATA', col('DATA').cast(TimestampType()))
    .withColumn('QTDE', col('QTDE').cast(DoubleType()))
    .withColumn('PRECO_UNITARIO', col('PRECO_UNITARIO').cast(DoubleType()))
    .withColumn('TRX_DATE', col('TRX_DATE').cast(TimestampType()))
)

# COMMAND ----------

# MAGIC %md ### GOLD LAYER WRITING

# COMMAND ----------

table = f"{param_catalogo_gold}.{param_schema}.{param_nome_tabela_gold}"

print(f"Escrevendo a tabela {table}")

(
    df_impostos_gerais
    .write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .partitionBy("YEAR","MONTH")
    .saveAsTable(table)
)

# optimization Gold layer
optimize_delta_table(table)
