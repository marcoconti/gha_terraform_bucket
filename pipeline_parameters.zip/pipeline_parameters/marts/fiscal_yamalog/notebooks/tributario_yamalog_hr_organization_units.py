# Databricks notebook source
import os
from pyspark.sql.functions import *
from pyspark.sql.types import *
from delta.tables import *

# COMMAND ----------

def optimize_delta_table(table_name):
    """
        @param: IN table_path
        Run optimization commands and old snapshots
        Full load
    """
    deltaTable = DeltaTable.forName(spark, table_name)
    deltaTable.vacuum()
    deltaTable.optimize().executeCompaction()
    print('Delta table optimized.') 

# COMMAND ----------

# DBTITLE 1,Definição de variáveis
# Ambiente
env = os.environ.get("DATABRICKS_ENV").lower()

# Catalogo, Schema e Nome da tabela
param_catalogo_gold = f"gold_{env}"
param_schema = "fiscal_yamalog"
param_nome_tabela_gold = 'tributario_yamalog_hr_organization_units'

print(f"Tabela: {param_catalogo_gold}.{param_schema}.{param_nome_tabela_gold}")


# COMMAND ----------

# MAGIC %md ### Variáveis

# COMMAND ----------

hao = spark.table("silver_dev.ebs_apps.hr_all_organization_units")
haotl = spark.table("silver_dev.ebs_apps.hr_all_organization_units_tl")

# COMMAND ----------

# fazendo JOIN entre as tabelas
result = hao.join(haotl, "ORGANIZATION_ID", "inner")

# COMMAND ----------

# Selecionando as colunas
selected = result.select(
    "hr_all_organization_units.ORGANIZATION_ID",
    "hr_all_organization_units.BUSINESS_GROUP_ID",
    "hr_all_organization_units.COST_ALLOCATION_KEYFLEX_ID",
    "hr_all_organization_units.LOCATION_ID",
    "hr_all_organization_units.SOFT_CODING_KEYFLEX_ID",
    "hr_all_organization_units.DATE_FROM",
    "hr_all_organization_units_tl.NAME",
    "hr_all_organization_units_tl.LANGUAGE",
    "hr_all_organization_units.COMMENTS",
    "hr_all_organization_units.DATE_TO",
    "hr_all_organization_units.INTERNAL_EXTERNAL_FLAG",
    "hr_all_organization_units.INTERNAL_ADDRESS_LINE",
    "hr_all_organization_units.TYPE",
    "hr_all_organization_units.REQUEST_ID",
    "hr_all_organization_units.PROGRAM_APPLICATION_ID",
    "hr_all_organization_units.PROGRAM_ID",
    "hr_all_organization_units.PROGRAM_UPDATE_DATE",
    "hr_all_organization_units.ATTRIBUTE_CATEGORY",
    "hr_all_organization_units.ATTRIBUTE1",
    "hr_all_organization_units.ATTRIBUTE2",
    "hr_all_organization_units.ATTRIBUTE3",
    "hr_all_organization_units.ATTRIBUTE4",
    "hr_all_organization_units.ATTRIBUTE5",
    "hr_all_organization_units.ATTRIBUTE6",
    "hr_all_organization_units.ATTRIBUTE7",
    "hr_all_organization_units.ATTRIBUTE8",
    "hr_all_organization_units.ATTRIBUTE9",
    "hr_all_organization_units.ATTRIBUTE10",
    "hr_all_organization_units.ATTRIBUTE11",
    "hr_all_organization_units.ATTRIBUTE12",
    "hr_all_organization_units.ATTRIBUTE13",
    "hr_all_organization_units.ATTRIBUTE14",
    "hr_all_organization_units.ATTRIBUTE15",
    "hr_all_organization_units.ATTRIBUTE16",
    "hr_all_organization_units.ATTRIBUTE17",
    "hr_all_organization_units.ATTRIBUTE18",
    "hr_all_organization_units.ATTRIBUTE19",
    "hr_all_organization_units.ATTRIBUTE20",
    "hr_all_organization_units.LAST_UPDATE_DATE",
    "hr_all_organization_units.LAST_UPDATED_BY",
    "hr_all_organization_units.LAST_UPDATE_LOGIN",
    "hr_all_organization_units.CREATED_BY",
    "hr_all_organization_units.CREATION_DATE",
    "hr_all_organization_units.OBJECT_VERSION_NUMBER",
    "hr_all_organization_units.ATTRIBUTE21",
    "hr_all_organization_units.ATTRIBUTE22",
    "hr_all_organization_units.ATTRIBUTE23",
    "hr_all_organization_units.ATTRIBUTE24",
    "hr_all_organization_units.ATTRIBUTE25",
    "hr_all_organization_units.ATTRIBUTE26",
    "hr_all_organization_units.ATTRIBUTE27",
    "hr_all_organization_units.ATTRIBUTE28",
    "hr_all_organization_units.ATTRIBUTE29",
    "hr_all_organization_units.ATTRIBUTE30"
)

# COMMAND ----------

filtered = selected.filter(selected['LANGUAGE'] == "PTB")
# selected.display()

# COMMAND ----------

table = f"{param_catalogo_gold}.{param_schema}.{param_nome_tabela_gold}"

print(f"Escrevendo a tabela {table}")

(
    filtered
    .write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(table)
)

# optimization Gold layer
optimize_delta_table(table)
