# Databricks notebook source
# DBTITLE 1,Import de bibliotecas
import os
from pyspark.sql.functions import *
from pyspark.sql.types import *
from delta.tables import *

# COMMAND ----------

def optimize_delta_table(table_name):
    """
        @param: IN table_path
        Run optimization commands and old snapshots
        Full load
    """
    deltaTable = DeltaTable.forName(spark, table_name)
    deltaTable.vacuum()
    deltaTable.optimize().executeCompaction()
    print('Delta table optimized.') 

# COMMAND ----------

# DBTITLE 1,Definição de variáveis
# Ambiente
env = os.environ.get("DATABRICKS_ENV").lower()

# Catalogo, Schema e Nome da tabela
param_catalogo_gold = f"gold_{env}"
param_schema = "fiscal_yamalog"
param_nome_tabela_gold = 'tributario_yamalog_cll_f189_customers'

print(f"Tabela: {param_catalogo_gold}.{param_schema}.{param_nome_tabela_gold}")


# COMMAND ----------

df_cll_f189_fiscal_entities_all = spark.sql(""" 
                    select 
                            
                            RFEA.ENTITY_TYPE_LOOKUP_CODE,
                            RFEA.ATTRIBUTE_CATEGORY,
                            RFEA.ATTRIBUTE1,
                            RFEA.ATTRIBUTE2,
                            RFEA.ATTRIBUTE3,
                            RFEA.ATTRIBUTE4,
                            RFEA.ATTRIBUTE5,
                            RFEA.ATTRIBUTE6,
                            RFEA.ATTRIBUTE7,
                            RFEA.ATTRIBUTE8,
                            RFEA.ATTRIBUTE9,
                            RFEA.ATTRIBUTE10,
                            RFEA.ATTRIBUTE11,
                            RFEA.ATTRIBUTE12,
                            RFEA.ATTRIBUTE13,
                            RFEA.ATTRIBUTE14,
                            RFEA.ATTRIBUTE15,
                            RFEA.ATTRIBUTE16,
                            RFEA.ATTRIBUTE17,
                            RFEA.ATTRIBUTE18,
                            RFEA.ATTRIBUTE19,
                            RFEA.ATTRIBUTE20,
                            RFEA.IE,
                            RFEA.INACTIVE_DATE,
                            RFEA.CREATION_DATE,
                            RFEA.LAST_UPDATE_DATE,
                            RFEA.LAST_UPDATE_LOGIN,
                            RFEA.ICMS_REDUCTION_BASE_FLAG,
                            RFEA.BUSINESS_VENDOR_ID,
                            RFEA.STATE_ID as ID_STATE_RFEA ,
                            RFEA.CITY_ID,
                            RFEA.ORG_ID,
                            RFEA.ENTITY_ID,
                            RFEA.CUST_ACCT_SITE_ID,
                            RFEA.DOCUMENT_NUMBER,      
                            RFEA.CREATED_BY,
                            RFEA.LAST_UPDATED_BY,
                            RFEA.DOCUMENT_TYPE
                        from
                            silver_dev.ebs_cll.cll_f189_fiscal_entities_all RFEA
                        where 
                            RFEA.ENTITY_TYPE_LOOKUP_CODE = 'CUSTOMER_SITE'
 """)
df_cll_f189_states = spark.sql(""" 
                    select 
                            RS.NATIONAL_STATE, 
                            RS.FREIGHT_ICMS_TYPE,
                            RS.FREIGHT_ICMS_TAX, 
                            RS.STATE_CODE, 
                            RS.STATE_ID
                         from
                            silver_dev.ebs_cll.cll_f189_states RS
 """)
df_cll_f189_cities = spark.sql(""" 
                                                   select 
                            RCI.ISS_TAX,
                            RCI.ISS_TAX_TYPE,
                            RCI.CITY_CODE, 
                            RCI.CITY_ID as ID_CITY_CITIES
                        from 
                            silver_dev.ebs_cll.cll_f189_cities RCI
 """)
df_cll_f189_business_vendors  = spark.sql(""" 
                    SELECT 
                            RBV.BUSINESS_CODE,
                            RBV.HIGHLIGHT_IPI_FLAG,
                            RBV.INSS_SUBSTITUTE_FLAG,
                            RBV.INSS_TAX,
                            RBV.FUNRURAL_CONTRIBUTOR_FLAG,
                            RBV.FUNRURAL_TAX,
                            RBV.SOCIAL_SECURITY_CONTRIB_TAX,   
                            RBV.GILRAT_TAX,                    
                            RBV.SENAR_TAX,                    
                            RBV.SEST_SENAT_CONTRIBUTOR_FLAG,
                            RBV.SEST_SENAT_TAX,
                            RBV.ICMS_CONTRIBUTOR_FLAG,
                            RBV.IR_VENDOR,
                            RBV.IR_CATEG,
                            RBV.IR_TAX,
                            RBV.SEST_SENAT_INCOME_CODE,
                            RBV.FUNRURAL_INCOME_CODE,
                            RBV.BUSINESS_ID
                            FROM    silver_dev.ebs_cll.cll_f189_business_vendors RBV
 """)
df_hz_cust_acct_sites_all = spark.sql(""" 
                    SELECT 
                            HCAS.STATUS as DS_STATUS_HCAS,
                            HCAS.CUST_ACCOUNT_ID as ID_CUST_ACCOUNT_HCAS,
                            HCAS.PARTY_SITE_ID,
                            HCAS.CUST_ACCT_SITE_ID as ID_CUST_ACCT_SITE_HCAS
                            FROM silver_dev.ebs_apps.hz_cust_acct_sites_all HCAS
 """)
df_hz_cust_accounts = spark.sql(""" 
                    SELECT 
                            HCA.STATUS as DS_STATUS_HCA,
                            HCA.PARTY_ID as ID_PARTY_HCA,
                            HCA.CUST_ACCOUNT_ID
                            FROM  silver_dev.ebs_apps.hz_cust_accounts HCA
 """)
df_hz_party_sites = spark.sql(""" 
                    SELECT 
                            HPS.PARTY_ID as ID_PARTY_HPS, 
                            HPS.PARTY_SITE_ID as ID_PARTY_SITE_HPS,
                            HPS.LOCATION_ID as ID_LOCATION_HPS
                            FROM silver_dev.ebs_apps.hz_party_sites HPS
 """)
df_hz_parties = spark.sql(""" 
                    SELECT 
                            HP.STATUS as DS_STATUS_HP, 
                            HP.PARTY_NAME CUSTOMER_NAME,
                            HP.PARTY_NUMBER CUSTOMER_NUMBER,
                            HP.PARTY_ID
                            FROM
                                silver_dev.ebs_apps.hz_parties as HP
                            where
                                HP.STATUS || '' = 'A'
 """)
df_hz_locations = spark.sql(""" 
                    SELECT 
                            HL.ADDRESS1,
                            HL.ADDRESS2,
                            HL.ADDRESS3,
                            HL.ADDRESS4,
                            HL.LOCATION_ID
                            FROM  silver_dev.ebs_apps.hz_locations HL 
 """) 

# COMMAND ----------

df_cll_f189_customers_v = (df_cll_f189_fiscal_entities_all.alias('RFEA')
    .join(df_cll_f189_states.alias('RS'), col('RFEA.ID_STATE_RFEA') == col('RS.STATE_ID'),'inner').drop('RFEA.ID_STATE_RFEA')
    .join(df_cll_f189_cities.alias('RCI'), col('RFEA.CITY_ID') == col('RCI.ID_CITY_CITIES'),'left').drop('RCI.ID_CITY_CITIES')
    .join(df_cll_f189_business_vendors.alias('RBV'), col('RBV.BUSINESS_ID') == col('RFEA.BUSINESS_VENDOR_ID'),'inner').drop('RBV.BUSINESS_ID')
    .join(df_hz_cust_acct_sites_all.alias('HCAS'), col('RFEA.CUST_ACCT_SITE_ID') == col('HCAS.ID_CUST_ACCT_SITE_HCAS'),'inner').drop('HCAS.ID_CUST_ACCT_SITE_HCAS')
    .join(df_hz_cust_accounts.alias('HCA'), col('HCAS.ID_CUST_ACCOUNT_HCAS') == col('HCA.CUST_ACCOUNT_ID'),'inner').drop('HCAS.ID_CUST_ACCOUNT_HCAS')
    .join(df_hz_party_sites.alias('HPS'), col('HCAS.PARTY_SITE_ID') == col('HPS.ID_PARTY_SITE_HPS'),'left').drop('HPS.ID_PARTY_SITE_HPS')
    .join(df_hz_parties.alias('HP'), col('HPS.ID_PARTY_HPS') == col('HP.PARTY_ID'), 'inner').drop('HPS.ID_PARTY_HPS')
    .join(df_hz_locations.alias('HL'), col('HPS.ID_LOCATION_HPS') == col('HL.LOCATION_ID'), 'inner').drop('HPS.ID_LOCATION_HPS')
)



# COMMAND ----------

# DBTITLE 1,Tipagem de campos
integerCast = (
    'LAST_UPDATE_LOGIN',
    'CREATED_BY',
    'LAST_UPDATED_BY',
    'BUSINESS_VENDOR_ID',
    'BUSINESS_ID',
    'ID_STATE_RFEA',
    'STATE_ID',
    'CITY_ID',
    'ORG_ID',
    'ENTITY_ID',
    'FREIGHT_ICMS_TAX',
    'ISS_TAX',
    'ID_CITY_CITIES'
)


for field in integerCast:
    df_cll_f189_customers_v = df_cll_f189_customers_v.withColumn(field, col(field).cast('int'))
    

# COMMAND ----------

table = f"{param_catalogo_gold}.{param_schema}.{param_nome_tabela_gold}"

print(f"Escrevendo a tabela {table}")

(
    df_cll_f189_customers_v
    .write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(table)
)

# optimization Gold layer
optimize_delta_table(table)
