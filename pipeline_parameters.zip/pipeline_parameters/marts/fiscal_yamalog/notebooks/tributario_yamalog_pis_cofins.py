# Databricks notebook source
# DBTITLE 1,Import de bibliotecas
import os
from pyspark.sql.functions import * 
from pyspark.sql.types import StringType
from delta.tables import *
from datetime import datetime


# COMMAND ----------

# DBTITLE 1,Criação de método para otimizar delta table
def optimize_delta_table(table_name):
    """
        @param: IN table_path
        Run optimization commands and old snapshots
        Full load
    """
    deltaTable = DeltaTable.forName(spark, table_name)
    deltaTable.vacuum()
    deltaTable.optimize().executeCompaction()
    print('Delta table optimized.') 

# COMMAND ----------

# DBTITLE 1,Definição de variáveis
# Ambiente
env = os.environ.get("DATABRICKS_ENV").lower()

# Catalogo, Schema e Nome da tabela
param_catalogo_gold = f"gold_{env}"
param_schema = "fiscal_yamalog"
param_nome_tabela_gold = 'tributario_yamalog_pis_cofins'
anoFiltro = (datetime.now().year - 3)

print(f"Tabela: {param_catalogo_gold}.{param_schema}.{param_nome_tabela_gold}")


# COMMAND ----------

# Carregando as tabelas em DataFrames 
ri = spark.sql("""
                    select 
                    ri.LAST_UPDATED_BY,
                    ri.INVOICE_TYPE_ID as INVOICE_TYPE_ID_RI,
                    ri.INVOICE_ID as INVOICE_ID_RI,
                    ri.OPERATION_ID as OPERATION_ID_RI,
                    ri.ORGANIZATION_ID as ORGANIZATION_ID_RI,
                    ri.ENTITY_ID as ENTITY_ID_RI
                    from
                    silver_dev.ebs_cll.cll_f189_invoices as ri 
""")
rit = spark.sql("""
                    select 
                    rit.INVOICE_TYPE_ID
                    from
                    silver_dev.ebs_cll.cll_f189_invoice_types as rit
""")
ril = spark.sql("""
                    select 
                    ril.CLASSIFICATION_ID as CLASSIFICATION_ID_RIL,
                    ril.TOTAL_AMOUNT,
                    ril.UTILIZATION_ID as UTILIZATION_ID_RIL,
                    ril.INVOICE_ID as INVOICE_ID_RIL,
                    ril.INVOICE_LINE_ID,
                    ril.ORGANIZATION_ID as ORGANIZATION_ID_RIL,
                    ril.DESCRIPTION as DESCRIPTION_RIL,
                    ril.CFO_ID as CFO_ID_RIL,
                    ril.ITEM_ID as ITEM_ID_RIL,
                    ril.AWT_GROUP_ID as AWT_GROUP_ID_RIL
                    from
                    silver_dev.ebs_cll.cll_f189_invoice_lines as ril 
""")
rd = spark.sql("""
                    select 
                    rd.ORGANIZATION_ID as ORGANIZATION_ID_RD,
                    rd.INVOICE_LINE_ID as INVOICE_LINE_ID_RD
                    from
                    silver_dev.ebs_cll.cll_f189_distributions rd
""")
reo = spark.sql(f"""
                    select 
                    to_date(reo.RECEIVE_DATE) as RECEIVE_DATE,
                    Nvl(REO.REVERSION_FLAG, 'x') as REVERSION_FLAG,
                    reo.STATUS,
                    reo.OPERATION_ID as OPERATION_ID_REO,
                    reo.ORGANIZATION_ID as ORGANIZATION_ID_REO,
                    reo.LOCATION_ID as LOCATION_ID_REO
                    from
                    silver_dev.ebs_cll.cll_f189_entry_operations reo
                    where reo.STATUS == "COMPLETE"
                    and  _year >= {anoFiltro} --2 anos retroativo + ano corrente
""")

recu = spark.sql("""
                    select 
                    recu.UTILIZATION_ID
                    from
                    silver_dev.ebs_cll.cll_f189_item_utilizations recu
""")
rfo = spark.sql("""
                    select 
                    rfo.CFO_ID
                    from
                    silver_dev.ebs_cll.cll_f189_fiscal_operations rfo
""")
rfc = spark.sql("""
                    select 
                    rfc.CLASSIFICATION_ID
                    from
                    silver_dev.ebs_cll.cll_f189_fiscal_class rfc
""")
hou = spark.sql("""
                    select 
                    hou.NAME,
                    hou.ORGANIZATION_ID
                    from
                    gold_<env>.fiscal_yamalog.tributario_yamalog_hr_organization_units hou 
                    where ( hou.NAME LIKE 'YL%' OR hou.NAME LIKE 'L%' )
""")
rft = spark.sql("""
                    select 
                    rft.VENDOR_SITE_ID,
                    rft.ENTITY_ID,
                    rft.ADDRESS_ID
                    from
                    silver_dev.ebs_cll.cll_f189_fiscal_entities_all rft
""")
pvs = spark.sql("""
                    select 
                    pvs.VENDOR_ID as VENDOR_ID_PVS,
                    pvs.VENDOR_SITE_ID as VENDOR_SITE_ID_PVS
                    from
                    silver_dev.ebs_apps.ap_supplier_sites_all pvs
""")
pv = spark.sql("""
                    select 
                    pv.VENDOR_NAME,
                    pv.VENDOR_ID
                    from
                    silver_dev.ebs_apps.ap_suppliers pv
""")
msi = spark.sql("""
                    select 
                    msi.SEGMENT1,
                    msi.DESCRIPTION as DS_DESCRIPTION_MSI,
                    msi.INVENTORY_ITEM_ID
                    from
                    silver_dev.ebs_apps.mtl_system_items_b msi
""")
apg = spark.sql("""
                    select 
                    apg.GROUP_ID
                    from
                    silver_dev.ebs_ap.ap_awt_groups apg
""")
fu = spark.sql("""
                    select 
                    fu.USER_ID
                    from
                    silver_dev.ebs_apps.fnd_user fu 
""")
hl = spark.sql("""
                    select 
                    hl.LOCATION_ID
                    from
                    silver_dev.ebs_apps.hr_locations_all hl 
""")
raal = spark.sql("""
                    select 
                    raal.ADDRESSEE,
                    raal.PARTY_ID as PARTY_ID_RAAL
                    from
                    gold_<env>.fiscal_yamalog.tributario_yamalog_ym_ra_address raal
""")
hp = spark.sql("""
                    select 
                    hp.PARTY_NAME,
                    hp.PARTY_ID 
                    from
                    silver_dev.ebs_apps.hz_parties hp
""")     

# COMMAND ----------


joined_data = (ri 
    .join(rit, ri.INVOICE_TYPE_ID_RI == rit.INVOICE_TYPE_ID, "inner")
    .join(ril, ri.INVOICE_ID_RI == ril.INVOICE_ID_RIL, "left")
    .join(reo, (ri.OPERATION_ID_RI == reo.OPERATION_ID_REO) & 
               (ri.ORGANIZATION_ID_RI == reo.ORGANIZATION_ID_REO ), "left")
    .join(rft, ri.ENTITY_ID_RI == rft.ENTITY_ID, "inner")
    .join(pvs, rft.VENDOR_SITE_ID == pvs.VENDOR_SITE_ID_PVS, "left")
    .join(pv, pvs.VENDOR_ID_PVS == pv.VENDOR_ID, "left")
    .join(hou, ri.ORGANIZATION_ID_RI == hou.ORGANIZATION_ID, "inner")
    .join(msi, ril.ITEM_ID_RIL == msi.INVENTORY_ITEM_ID, "left")
    .join(rfo, ril.CFO_ID_RIL == rfo.CFO_ID, "left")
    .join(recu, ril.UTILIZATION_ID_RIL == recu.UTILIZATION_ID, "left")
    .join(apg, ril.AWT_GROUP_ID_RIL == apg.GROUP_ID, "left")
    .join(fu, ri.LAST_UPDATED_BY == fu.USER_ID, "inner")
    .join(rfc, ril.CLASSIFICATION_ID_RIL == rfc.CLASSIFICATION_ID, "inner")
    .join(rd, (ril.ORGANIZATION_ID_RIL == rd.ORGANIZATION_ID_RD) & 
              (ril.INVOICE_LINE_ID == rd.INVOICE_LINE_ID_RD), "left")
    .join(hl, reo.LOCATION_ID_REO == hl.LOCATION_ID, "inner")
    .join(raal, rft.ADDRESS_ID == raal.ADDRESSEE, "left")
    .join(hp, raal.PARTY_ID_RAAL == hp.PARTY_ID, "left")
)
 

# COMMAND ----------

result = joined_data.select(
         when(hou.NAME == 'YL1-MANAUS', '0001')
        .when(hou.NAME == 'YL2-JANDIRA', '0002')
        .when(hou.NAME == 'YL3-SAO PAULO', '0003')
        .when(hou.NAME == 'YL4-BELEM', '0004')
        .when(hou.NAME == 'YL5-CURITIBA', '0005')
        .when(hou.NAME == 'YL6-CONTAGEM', '0006')
        .when(hou.NAME == 'YL7-SANTA RITA', '0007')
        .when(hou.NAME == 'YL8-NEROPOLIS', '0008')
        .when(hou.NAME == 'YL9-MARAPATA', '0009')
        .when(hou.NAME == 'L10-ITAJAI', '0010')
        .when(hou.NAME == 'L12-RECIFE', '0012')
        .alias('ID_ORGANIZACAO'),
    hou.ORGANIZATION_ID.alias("organizacao_id_hou"),
    hou.NAME.alias("DS_ORGANIZACAO"),
    reo.RECEIVE_DATE.alias("DT_RECEBIMENTO"),
    msi.SEGMENT1.alias("CD_PRODUTO"),
    pv.VENDOR_NAME.alias("DS_FORNECEDOR"),
    reo.REVERSION_FLAG.alias("DS_REVERSAO"),
    reo.STATUS.alias("DS_STATUS"),
    hp.PARTY_NAME.alias("NM_NOME_CLIENTE"),
    ril.TOTAL_AMOUNT.alias("VL_TOTAL_AMOUNT"),
    year(joined_data["RECEIVE_DATE"]).alias("YEAR"),
    lpad(month(joined_data["RECEIVE_DATE"]), 2, '0').alias("MONTH"),
    coalesce(joined_data["DS_DESCRIPTION_MSI"], joined_data["DESCRIPTION_RIL"]).alias('DS_PRODUTO')
)

# COMMAND ----------

result_grouped = result.groupBy(
    "ID_ORGANIZACAO",
    "DS_ORGANIZACAO",
    "DT_RECEBIMENTO", 
    "CD_PRODUTO", 
    "DS_PRODUTO", 
    "DS_FORNECEDOR", 
    "DS_REVERSAO", 
    "DS_STATUS", 
    "NM_NOME_CLIENTE"
    ,"YEAR"
    ,"MONTH")\
    .agg(sum("VL_TOTAL_AMOUNT").alias("VL_TOTAL_AMOUNT"))


# COMMAND ----------

# DBTITLE 1,ordenacao de campos
result_grouped = (
    result_grouped
    .select(
        'ID_ORGANIZACAO'
        ,'DS_ORGANIZACAO'
        ,'DT_RECEBIMENTO'
        ,'CD_PRODUTO'
        ,'DS_PRODUTO'
        ,'DS_FORNECEDOR'
        ,'DS_REVERSAO'
        ,'DS_STATUS'
        ,'NM_NOME_CLIENTE'
        ,'VL_TOTAL_AMOUNT'
        ,'YEAR'
        ,'MONTH'        
    )
)

# COMMAND ----------

table = f"{param_catalogo_gold}.{param_schema}.{param_nome_tabela_gold}"

print(f"Escrevendo a tabela {table}")

(
    result_grouped
    .write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .partitionBy("YEAR","MONTH")
    .saveAsTable(table)
)

# optimization Gold layer
optimize_delta_table(table)
