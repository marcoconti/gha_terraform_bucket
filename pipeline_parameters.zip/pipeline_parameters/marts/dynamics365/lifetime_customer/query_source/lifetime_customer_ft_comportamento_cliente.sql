Select ymdb_documentacao as dc_ymdb_documentacao
    ,importsequencenumber
    ,ymdb_id_modelo_moto
    ,ymdb_ds_cpf_nota_fiscal as nr_ymdb_cpf_nota_fiscal
    ,ymdb_documentacao_name
    ,ymdb_chassis as nr_ymdb_chassis
    ,ymdb_id_tipo_da_moto as tp_ymdb_tipo_da_moto
    ,ymdb_nm_years_warranty
    ,versionnumber
    ,modifiedon
    ,ymdb_nm_days_warranty
    ,_ymdb_cliente_value as cd_ymdb_cliente_value
    ,_createdby_value as cd_createdby_value
    ,ymdb_km
    ,ymdb_data_proxima_revisao
    ,ymdb_ds_plate_number as nr_ymdb_plate_number
    ,ymdb_cpf as nr_ymdb_cpf
    ,new_datacadastrogaragem
    ,utcconversiontimezonecode
    ,_owninguser_value as cd_owninguser_value
    ,_modifiedonbehalfby_value as cd_modifiedonbehalfby_value
    ,_ymdb_segundoproprietario_value as cd_ymdb_segundoproprietario_value
    ,ymdb_data_da_compra
    ,ymdb_id_moto
    ,ymdb_primeiroproprietario as nm_ymdb_primeiroproprietario
    ,ymdb_motoid as id_ymdb_motoid
    ,ymdb_datagarantia
    ,_ownerid_value as id_ownerid_value
    ,ymdb_marca
    ,statuscode
    ,ymdb_anofabricao
    ,_createdonbehalfby_value as cd_createdonbehalfby_value
    ,timezoneruleversionnumber
    ,_owningteam_value as cd_owningteam_value
    ,statecode
    ,_modifiedby_value as cd_modifiedby_value
    ,overriddencreatedon
    ,ymdb_anomodelo
    ,_owningbusinessunit_value as cd_owningbusinessunit_value
    ,ymdb_name
    ,ymdb_cor
    ,date_format(new_datacadastrogaragem,'yyyyMMdd') as id_calendario
    ,year(new_datacadastrogaragem) as year
    ,month(new_datacadastrogaragem) as month
    ,day(new_datacadastrogaragem) as day
  from silver_<env>.dynamics_365_sales_lifetime_customer.ymdb_moto