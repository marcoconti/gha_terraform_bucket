# Databricks notebook source
# MAGIC %md - `Criado por:` 
# MAGIC - `Data Criação:`
# MAGIC - `Atualizado por:` Philip Ribeiro 
# MAGIC - `Data Atualização:`21-08-2024
# MAGIC - `Atualizado por:` Marco Conti 
# MAGIC - `Data Atualização:`24-07-2025

# COMMAND ----------

# MAGIC %md ### Import bibliotecas

# COMMAND ----------

import os
import pyspark.sql.functions as F
from pyspark.sql.types import StringType
from delta.tables import *

# COMMAND ----------

spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", "false")

# COMMAND ----------

# MAGIC %md ### Optimization Method

# COMMAND ----------

def optimize_delta_table(table_name):
    """
        @param: IN table_path
        Run optimization commands and old snapshots
        Full load
    """
    deltaTable = DeltaTable.forName(spark, table_name)
    deltaTable.vacuum(24)
    deltaTable.optimize().executeCompaction()
    print('Delta table optimized.') 

def get_env():
    return os.environ.get("DATABRICKS_ENV")

# COMMAND ----------

# MAGIC %md ### Variáveis

# COMMAND ----------

env     = get_env().lower()
catalog = f"gold_{env}"
schema  = "comercial_planejamento_comercial"
table   = "ft_interacao"

# COMMAND ----------

# DBTITLE 1,Tab. ymdb_interacao  - Leitura, rename cols e adição de colunas
drop_cols = ["_odata_etag", "_hash", "_ingestionin"]
df_interacao = \
    (spark.sql(f"""Select * 
                     from silver_{env}.dynamics_365_sales_lifetime_customer.ymdb_interacao""")
          .drop(*drop_cols))

rename_cols = {
    '_ymdb_cliente_value': 'id_contactid'
    ,'versionnumber': 'nr_versionnumber_interacao'
    ,'importsequencenumber': 'nr_importsequencenumber_interacao'
    ,'overriddencreatedon': 'dt_overriddencreatedon_interacao'
    ,'modifiedon': 'dt_modifiedon_interacao'
    ,'statecode': 'cd_statecode_interacao'
    ,'statuscode': 'cd_statuscode_interacao'
    ,'utcconversiontimezonecode': 'cd_utcconversiontimezonecode_interacao'
    ,'createdon': 'dt_createdon_interacao'}

select_exprs = []
select_exprs = [f"{c} as {rename_cols.get(c, c)}" for c in df_interacao.columns ]
df_interacao = df_interacao.selectExpr(*select_exprs)

# Criar coluna
select_exprs = df_interacao.columns

    # "concat(year(ymdb_datadoenvio) * 10000, month(ymdb_datadoenvio) * 100, day(ymdb_datadoenvio)) as id_calendario"


id_calendario = \
    "date_format(ymdb_datadoenvio,'yyyyMMdd') as id_calendario"

select_exprs.append(id_calendario)
df_interacao = df_interacao.selectExpr(select_exprs)

# COMMAND ----------

# DBTITLE 1,Tab. cr638_campanharesponsys- Leitura e rename cols
drop_cols = ["_odata_etag", "_hash", "_ingestionin", "_month", "_year"]
df_cr638_campanharesponsys = \
    (spark.sql(f"""Select * 
                     from silver_{env}.dynamics_365_sales_lifetime_customer.cr638_campanharesponsys""")
          .drop(*drop_cols))
    
rename_cols = \
    {"cr638_iddacampanha": "id_cr638dacampanha"
    ,"cr638_nomedacampanha": "nm_cr638_nomedacampanha"
    ,"cr638_campanharesponsysid": "ds_cr638_campanharesponsysid"
    ,"modifiedon": "dt_modifiedon_cr638_campanharesponsys"
    ,"_modifiedby_value": "ds_modifiedby_value"
    ,"createdon": "dt_createdon_cr638_campanharesponsys"
    ,"_createdby_value": "ds_createdby_value"
    ,"versionnumber": "nr_versionnumber_cr638_campanharesponsys"
    ,"new_tipodecampanha": "tp_new_tipodecampanha"
    ,"ymdb_conteudocampanha": "ds_ymdb_conteudocampanha"
    ,"_owninguser_value": "ds_owninguser_value"
    ,"_ownerid_value": "ds_ownerid_value"
    ,"_modifiedonbehalfby_value": "ds_modifiedonbehalfby_value"
    ,"_owningteam_value": "ds_owningteam_value"
    ,"_owningbusinessunit_value": "ds_owningbusinessunit_value"
    ,"overriddencreatedon": "dt_overriddencreatedon_cr638_campanharesponsys"
    ,"cr638_nomedoprograma": "nm_cr638_nomedoprograma"
    ,"utcconversiontimezonecode": "cd_utcconversiontimezonecode_cr638_campanharesponsys"
    ,"statuscode": "cd_statuscode_cr638_campanharesponsys"
    ,"statecode": "cd_statecode_cr638_campanharesponsys"
    ,"_createdonbehalfby_value": "ds_createdonbehalfby_value"
    ,"timezoneruleversionnumber": "nr_timezoneruleversionnumber_cr638_campanharesponsys"
    ,"importsequencenumber": "nr_importsequencenumber_cr638_campanharesponsys"
    ,"new_tipodecampanha": "tp_new_tipodecampanha"}

select_exprs = []
select_exprs = [f"{c} as {rename_cols.get(c, c)}" for c in df_cr638_campanharesponsys.columns ]
df_cr638_campanharesponsys = df_cr638_campanharesponsys.selectExpr(*select_exprs)


# COMMAND ----------

# MAGIC %md
# MAGIC ### Junção dos DF

# COMMAND ----------

df_interacao = (
    df_interacao
    .join(
        df_cr638_campanharesponsys,
        (df_interacao.ymdb_id_campanha == df_cr638_campanharesponsys.id_cr638dacampanha),
        how='left'
    )
)

# COMMAND ----------

# MAGIC %md ### Writing silver -> gold

# COMMAND ----------

print(f"Persiste os dados do DF na tabela {catalog}.{schema}.{table}", end="")
(
    df_interacao
        .write
        .partitionBy("_year","_month")
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(f"{catalog}.{schema}.{table}")
)
print(" - Concluido com sucesso")

# COMMAND ----------

# optimization Gold layer
optimize_delta_table(f'{catalog}.{schema}.{table}')

# COMMAND ----------

del (df_interacao, df_cr638_campanharesponsys)