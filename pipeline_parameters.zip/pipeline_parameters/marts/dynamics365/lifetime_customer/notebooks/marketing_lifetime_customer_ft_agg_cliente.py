# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC - `Criado por:` 
# MAGIC - `Data Criação:`
# MAGIC - `Atualizado por:` Caio Francisco 
# MAGIC - `Data Atualização:`29-08-2024
# MAGIC - `Atualizado por:` Marco Conti
# MAGIC - `Data Atualização:`28-07-2025

# COMMAND ----------

# MAGIC %md ### Import bibliotecas

# COMMAND ----------

import os
import pyspark.sql.functions as F
from pyspark.sql.types import StringType, DecimalType, DateType, FloatType, IntegerType
from delta.tables import *
from cryptography.fernet import Fernet
from pyspark.sql.window import Window

# COMMAND ----------

spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", "false")

# COMMAND ----------

# MAGIC %md ### Optimization Method

# COMMAND ----------

def optimize_delta_table(table_name):
    """
        @param: IN table_path
        Run optimization commands and old snapshots
        Full load
    """
    deltaTable = DeltaTable.forName(spark, table_name)
    deltaTable.vacuum(24)
    deltaTable.optimize().executeCompaction()
    print('Delta table optimized.') 

def get_env():
    return os.environ.get("DATABRICKS_ENV")

# COMMAND ----------

# MAGIC %md ### Variáveis

# COMMAND ----------

env     = get_env()
catalog = f"gold_{env.lower()}"
schema  = "comercial_planejamento_comercial"
table   = "ft_agg_cliente"


# COMMAND ----------

# MAGIC %md ### Leitura tabelas

# COMMAND ----------

# DBTITLE 1,Seleciona tabelas usadas no processamento
drop_cols  = ["_odata_etag", "_hash", "_ingestionin"]

df_cliente = \
    (spark.sql(f"""Select * from gold_{env}.corporativo.dm_cliente""")
          .drop(*drop_cols))

df_discover = \
    (spark.sql(f"""Select * from silver_{env}.dynamics_365_sales_lifetime_customer.cr638_discover""")
          .drop(*drop_cols))

df_checkin = \
    (spark.sql(f"""Select * from silver_{env}.dynamics_365_sales_lifetime_customer.msevtmgt_checkin""")
          .drop(*drop_cols))

df_revisoes = \
    (spark.sql(f"""Select * from silver_{env}.dynamics_365_sales_lifetime_customer.ymdb_revisoes""")
          .drop(*drop_cols))
df_revisoes = (df_revisoes.withColumn('DT_YMDB_DATAREVISAO', F.col('YMDB_DATAREVISAO').cast(DateType()))
                          .drop('YMDB_DATAREVISAO'))
renames_cols = {"new_tiposervico"       : "TP_NEW_TIPOSERVICO"
               ,"ymdb_valormoto"        : "VL_YMDB_VALORMOTO"
               ,"ymdb_codigocliente"    : "CD_YMDB_CLIENTE_VALUE"
               ,"ymdb_revisoesid"       : "ID_YMDB_REVISOESID"
               ,"ymdb_revisao_numero"   : "NR_YMDB_REVISAO_NUMERO"
               ,"_ymdb_cliente_id_value": "ID_CONTATO"}
select_exprs = []
select_exprs = [f" {c} as {renames_cols.get(c, c)} " for c in df_revisoes.columns ]
df_revisoes = df_revisoes.selectExpr(*select_exprs)

df_registration = \
    (spark.sql(f"""Select * from silver_{env}.dynamics_365_sales_lifetime_customer.msevtmgt_eventregistration""")
          .drop(*drop_cols))

df_salesorder = \
    (spark.sql(f"""Select * from silver_{env}.dynamics_365_sales_lifetime_customer.salesorder""")
          .drop(*drop_cols))

df_orderdetails = \
    (spark.sql(f"""Select * from silver_{env}.dynamics_365_sales_lifetime_customer.salesorderdetail""")
          .drop(*drop_cols))
    
df_lead = \
    (spark.sql(f"""Select * from silver_{env}.dynamics_365_sales_lifetime_customer.fut_interessedolead""")
          .drop(*drop_cols))
    
df_agendamento = \
    (spark.sql(f"""Select * from silver_{env}.dynamics_365_sales_lifetime_customer.ymdb_agendamentoindireto""")
          .drop(*drop_cols))
    
df_interacao = \
    (spark.sql(f"""Select * from silver_{env}.dynamics_365_sales_lifetime_customer.ymdb_interacao""")
          .drop(*drop_cols))
    
df_moto = \
    (spark.sql(f"""Select * from silver_{env}.dynamics_365_sales_lifetime_customer.ymdb_moto""")
          .drop(*drop_cols))

df_ret = \
    (spark.sql(f"""Select * from silver_{env}.dynamics_365_sales_lifetime_customer.ret_campanha""")
          .drop(*drop_cols))

# COMMAND ----------

# DBTITLE 1,Seleção de colunas de clientes
df_cliente = (
    df_cliente.select(
            F.col("ID_CONTATO"),
            F.col("NM_NOME_COMPLETO"),
            F.upper(F.col("DS_EMAIL1")).alias("DS_EMAIL1"),
            F.upper(F.col("DS_EMAIL2")).alias("DS_EMAIL2"),
            F.upper(F.col("DS_EMAIL3")).alias("DS_EMAIL3"),
            F.col("NR_TELEFONE_CELULAR"),
            F.col("DH_YMDB_PRIMEIRO_ACESSO"),
            F.col("NM_GENERO"),
            F.col("NM_ENDERECO1_CIDADE"),
            F.col("DS_ENDERECO1_ESTADO"),
            F.col("NM_ENDERECO2_CIDADE"),
            F.col("DS_ENDERECO2_ESTADO"),
            F.regexp_replace(F.col("DC_YMDB_CPF"), "[^0-9]", "").alias("DC_YMDB_CPF"),
            (F.length(F.col('DC_YMDB_CPF')) == 11).alias("FL_YMDB_CPF_VALIDO")
        )
    )

# COMMAND ----------

# DBTITLE 1,Dataframe de clientes em cache pois é usado diversas vezes
df_cliente = df_cliente.cache()

filtered_customers = df_cliente.filter("FL_YMDB_CPF_VALIDO is True")

# COMMAND ----------

# DBTITLE 1,QT_COMPROU_MOTOS e VL_COMPROU_MOTOS
df_comprou_motos = \
    (filtered_customers.alias('A')
        .join(df_revisoes.filter(F.col('TP_NEW_TIPOSERVICO') == 'ENTREGA')
                         .alias('B')
             ,[F.col('A.ID_CONTATO') == F.col('B.ID_CONTATO')]
             ,'inner')
        .withColumn('VL_YMDB_VALORMOTO', F.col('B.VL_YMDB_VALORMOTO').cast(FloatType()))
        .groupBy(F.col('A.ID_CONTATO'))
            .agg(F.count('B.TP_NEW_TIPOSERVICO').alias('QT_COMPROU_MOTOS')
                ,F.sum('VL_YMDB_VALORMOTO').alias('VL_COMPROU_MOTOS'))
        .select('A.ID_CONTATO', 'QT_COMPROU_MOTOS', 'VL_COMPROU_MOTOS')
)

# COMMAND ----------

# DBTITLE 1,QT_COMPROU_PECAS
df_comprou_pecas = (
    df_cliente.alias('A')
              .join(df_discover.filter(F.col('cr638_tipoproduto') == 'PECA')
                               .alias('C')
                   ,[F.col('A.ID_CONTATO') == F.col('C._cr638_cliente_value')]
                   ,'inner')
               .groupBy(F.col('A.ID_CONTATO'))
                    .agg(F.count('C.cr638_discoverid').alias('QT_COMPROU_PECAS'))
               .select('A.ID_CONTATO','QT_COMPROU_PECAS')
)

# COMMAND ----------

# DBTITLE 1,QT_REVISOES
df_comprou_revisoes = (
    df_cliente.alias('A')
              .join(df_revisoes.filter(F.col('ymdb_revisao_numero') != '-1')
                               .alias('D')
                   ,[F.col('A.ID_CONTATO') == F.col('D.ID_CONTATO')]
                   ,'inner')
              .groupBy(F.col('A.ID_CONTATO'))
                    .agg(F.count('D.ID_YMDB_REVISOESID').alias('QT_REVISOES'))
              .select('A.ID_CONTATO','QT_REVISOES')
)

# COMMAND ----------

# DBTITLE 1,QT_CHECKIN
df_qtd_checkin = (
    df_cliente.alias('A')
              .join(df_checkin.alias('E')
                   ,[F.col('A.ID_CONTATO') == F.col('E._msevtmgt_contact_value')]
                   ,'left')
              .groupBy(F.col('A.ID_CONTATO'))
                .agg(F.count('E.msevtmgt_checkinid').alias('QT_CHECKIN'))
              .select('A.ID_CONTATO','QT_CHECKIN')
)

# COMMAND ----------

# DBTITLE 1,QT_REGISTROS_EM_EVENTOS
df_registros_eventos = (
    df_cliente.alias('A')
              .join(df_registration.alias('F')
                   ,[F.col('A.ID_CONTATO') == F.col('F._msevtmgt_contactid_value')]
                   ,'left')
              .groupBy(F.col('A.ID_CONTATO'))
                .agg(F.count('F.msevtmgt_eventregistrationid').alias('QT_REGISTROS_EM_EVENTOS'))
              .select('A.ID_CONTATO','QT_REGISTROS_EM_EVENTOS')
)

# COMMAND ----------

# DBTITLE 1,NR_YMDB_REVISAO_NUMERO
df_revisoes_tmp = (
    df_revisoes
        .filter(F.col('NR_YMDB_REVISAO_NUMERO') == '-1')
        .groupBy(F.col('CD_YMDB_CLIENTE_VALUE')
                ,F.col('DT_YMDB_DATAREVISAO'))
            .agg(F.count('ID_YMDB_REVISOESID').alias('QT_MOTOS_COMPRADAS'))
)

# COMMAND ----------

# DBTITLE 1,QT_COMPROU_MOTOS_DATAS_DIFERENTES
df_comprou_motos_datas_diferentes = \
    (df_cliente.alias('A')
               .join(df_revisoes_tmp.alias('H')
                    ,[F.col('A.ID_CONTATO') == F.col('H.CD_YMDB_CLIENTE_VALUE')]
                    ,'left')
               .groupBy(F.col('A.ID_CONTATO'))
                    .agg(F.count('H.DT_YMDB_DATAREVISAO').alias('QT_COMPROU_MOTOS_DATAS_DIFERENTES'))
               .select('A.ID_CONTATO','QT_COMPROU_MOTOS_DATAS_DIFERENTES')
)

# COMMAND ----------

# DBTITLE 1,QT_COMPROU_MOTOS_e_PECAS
df_comprou_peca_tmp = \
    (filtered_customers.alias('A')
        .join(df_discover.filter(F.col('cr638_tipoproduto') == 'PECA') # aqui
                         .alias('C')
             ,[F.col('A.ID_CONTATO') == F.col('C._cr638_cliente_value')]
             ,'inner')
    .select('A.ID_CONTATO')
)

df_comprou_moto_tmp = \
    (filtered_customers.alias('A')
        .join(df_revisoes.filter(F.col('TP_NEW_TIPOSERVICO') == 'ENTREGA')
                         .alias('B')
             ,[F.col('A.ID_CONTATO') == F.col('B.ID_CONTATO')]
             ,'inner')
        .select('A.ID_CONTATO')
)

df_comprou_moto_e_peca = (
    df_cliente.alias('A')
    .join(df_comprou_peca_tmp.alias('cus_peca'), [F.col('A.ID_CONTATO') == F.col('cus_peca.ID_CONTATO')], 'inner')
    .join(df_comprou_moto_tmp.alias('cus_rev'), [F.col('cus_peca.ID_CONTATO') == F.col('cus_rev.ID_CONTATO')], 'inner')
    .withColumn('FL_COMPROU_MOTO_E_PECA', F.lit(True))
    .select('A.ID_CONTATO', 'FL_COMPROU_MOTO_E_PECA')
    .dropDuplicates()
)

# COMMAND ----------

# DBTITLE 1,QT_COMPROU_MOTOS e VL_COMPROU_MOTOS - ECOMMERCE
df_comprou_motos_ecommerce = \
    (filtered_customers.alias('A')
        .join(df_salesorder.filter(F.col('ymdb_origem_pedido').isin([100000001, 100000007]))
                           .alias('sal')
             ,[F.col('A.ID_CONTATO') == F.col('sal._customerid_value')]
             ,'inner')
        .join(df_revisoes.filter(F.col('TP_NEW_TIPOSERVICO') == 'ENTREGA')
                         .alias('rev')
             ,[F.col('A.ID_CONTATO') == F.col('rev.ID_CONTATO')]
             ,'inner')
        .withColumn('VL_YMDB_VALORMOTO', F.col('rev.VL_YMDB_VALORMOTO').cast(FloatType()))
        .groupBy(F.col('A.ID_CONTATO'))
            .agg(F.count('rev.TP_NEW_TIPOSERVICO').alias('QT_COMPROU_MOTOS_ECOMMERCE')
                ,F.sum('VL_YMDB_VALORMOTO').alias('VL_COMPROU_MOTOS_ECOMMERCE'))
        .select('A.ID_CONTATO'
               ,'QT_COMPROU_MOTOS_ECOMMERCE'
               ,'VL_COMPROU_MOTOS_ECOMMERCE')
)

# COMMAND ----------

# DBTITLE 1,QT_COMPROU_PECAS e VL_COMPROU_PECAS - ECOMMERCE

df_comprou_pecas_ecommerce = \
    (filtered_customers.alias('A')
        .join(df_salesorder.filter(F.col('ymdb_origem_pedido').isin([100000001, 100000007])).alias('sal')
             ,[F.col('A.ID_CONTATO') == F.col('sal._customerid_value')]
             ,'inner')
        .join(df_discover.filter(F.col('cr638_tipoproduto') == 'PECA').alias('pec')
             ,[F.col('A.ID_CONTATO') == F.col('pec._cr638_cliente_value')]
             ,'inner')
        .withColumn('VL_CR638_VALORDANOTAFISCAL', F.col('pec.cr638_valordanotafiscal').cast(FloatType()))
        .groupBy(F.col('A.ID_CONTATO'))
            .agg(F.count('pec.cr638_tipoproduto').alias('QT_COMPROU_PECAS_ECOMMERCE')
                ,F.sum('VL_CR638_VALORDANOTAFISCAL').alias  ('VL_COMPROU_PECAS_ECOMMERCE'))
        .select('A.ID_CONTATO', 'QT_COMPROU_PECAS_ECOMMERCE', 'VL_COMPROU_PECAS_ECOMMERCE')
)

# COMMAND ----------

# DBTITLE 1,QT_LEAD_ORIGEM_BASE_YAMAHA
df_lead_temp = (
    df_lead
    .withColumn('RANK', F.row_number().over(Window.partitionBy('_inove_contactid_value').orderBy(F.desc('fut_dt_datainicioatendimento'))))
    .filter(F.col('RANK') == 1)
    .select('_inove_contactid_value','fut_dt_datainicioatendimento','RANK')
)

df_lead_origem_base_yamaha = (
    filtered_customers.alias('A')
    .join(F.broadcast(df_lead_temp).alias('lead'), [F.col('A.ID_CONTATO') == F.col('lead._inove_contactid_value')], 'inner')
    .withColumn('FL_LEAD_ORIGEM_BASE_YAMAHA', F.lit(True))
    .select('A.ID_CONTATO', 'FL_LEAD_ORIGEM_BASE_YAMAHA')
)

# COMMAND ----------

# DBTITLE 1,QT_LEAD_ORIGEM_YAMAHA_ULTIMA_ATUALIZACAO
df_lead_origem_yamaha_lastupdate = \
    (filtered_customers.alias('A')
        .join(F.broadcast(df_lead_temp.filter(F.col('fut_dt_datainicioatendimento').isNotNull())).alias('lead')
             ,[F.col('A.ID_CONTATO') == F.col('lead._inove_contactid_value')]
             ,'inner')
        .withColumn('ID_CALENDARIO_ULTIMA_ATUALIZACAO_LEAD'
                   ,F.concat(F.year(F.col('lead.fut_dt_datainicioatendimento')) * 10000,
                             F.month(F.col('lead.fut_dt_datainicioatendimento')) * 100,
                             F.day(F.col('lead.fut_dt_datainicioatendimento'))))
        .select('A.ID_CONTATO', 'ID_CALENDARIO_ULTIMA_ATUALIZACAO_LEAD')
)

# COMMAND ----------

# DBTITLE 1,QT_LEAD_APARECERAM_BASE_XML
df_discover_temp = (
    df_discover
    .withColumn('RANK', F.row_number().over(Window.partitionBy('_cr638_cliente_value').orderBy(F.desc('new_datadoservico'))))
    .filter(F.col('RANK') == 1)
    .select('_cr638_cliente_value','RANK')
)

df_lead_apareceram_base_xml = (
    filtered_customers.alias('A')
    .join(F.broadcast(df_lead_temp).alias('lead'), [F.col('A.ID_CONTATO') == F.col('lead._inove_contactid_value')], 'inner')
    .join(df_discover_temp.alias('pec'), [F.col('A.ID_CONTATO') == F.col('pec._cr638_cliente_value')], 'inner')
    .withColumn('FL_LEAD_APARECERAM_BASE_XML', F.lit(True))
    .select('A.ID_CONTATO', 'FL_LEAD_APARECERAM_BASE_XML')
)

# COMMAND ----------

# DBTITLE 1,QT_LEAD_APARECERAM_BASE_MESMO_MES
df_lead_apareceram_base_mesmo_mes = (
    filtered_customers.alias('A')
    .join(F.broadcast(df_lead_temp).alias('lead'), [F.col('A.ID_CONTATO') == F.col('lead._inove_contactid_value')], 'inner')
    .withColumn('QT_MESES_APARECERAM_LEAD_NA_BASE', (F.months_between(F.col('lead.fut_dt_datainicioatendimento'), F.col('A.DH_YMDB_PRIMEIRO_ACESSO'))))
    .select('A.ID_CONTATO', 'QT_MESES_APARECERAM_LEAD_NA_BASE')
)

# COMMAND ----------

# DBTITLE 1,QT_AGENDARAM_FORAM_OU_NAO_FORAM
df_agendamento_temp = (
    df_agendamento
    .filter(F.col('ymdb_status').isin(['100000002','100000001','100000003']))
    .withColumn('RANK', F.row_number().over(Window.partitionBy('_ymdb_cliente_value').orderBy(F.desc('ymdb_servicedate'))))
    .filter(F.col('RANK') == 1)
    .select('_ymdb_cliente_value','ymdb_status','RANK')
)

df_agendaram_foram_nao_foram = (
    filtered_customers.alias('A')
    .join(F.broadcast(df_agendamento_temp).alias('CT'), [F.col('A.ID_CONTATO') == F.col('CT._ymdb_cliente_value')], 'inner')
    .withColumn('DS_STATUS_AGENDARAM', F.when(F.col('ymdb_status') == '100000001', F.lit('COMPARECEU')).otherwise(F.lit('NAO_COMPARECEU')))
    .select('A.ID_CONTATO', 'DS_STATUS_AGENDARAM')
)

# COMMAND ----------

# DBTITLE 1,QT_AGENDAMENTO
df_qt_agendamentos = (
    filtered_customers.alias('A')
    .join(F.broadcast(df_agendamento).alias('AG'), [F.col('A.ID_CONTATO') == F.col('AG._ymdb_cliente_value')], 'inner')    
    .groupBy(F.col('A.ID_CONTATO')).agg(F.count('AG.ymdb_dataregistro').alias('QT_AGENDAMENTO'))
    .select('A.ID_CONTATO', 'QT_AGENDAMENTO')
)

# COMMAND ----------

# DBTITLE 1,QT_AGENDAMENTO_INDIRETO
df_agendamento_indireto = \
    (filtered_customers.alias('A')
        .join(F.broadcast(df_agendamento.filter(F.col('ymdb_servicetype') == '100000002')).alias('AG')
             ,[F.col('A.ID_CONTATO') == F.col('AG._ymdb_cliente_value')]
             ,'inner')
    .groupBy(F.col('A.ID_CONTATO'))
        .agg(F.count('AG.ymdb_servicetype').alias('QT_AGENDAMENTO_INDIRETO'))
    .select('A.ID_CONTATO', 'QT_AGENDAMENTO_INDIRETO')
)

# COMMAND ----------

# DBTITLE 1,QT_GERARAM_XML_AGENDAMENTO
df_geraram_xml_agendamento = \
    (filtered_customers.alias('A')
        .join(F.broadcast(df_agendamento).alias('AG')
             ,[F.col('A.ID_CONTATO') == F.col('AG._ymdb_cliente_value')]
             ,'inner')
        .join(df_discover.alias('PEC')
             ,[F.col('A.ID_CONTATO') == F.col('PEC._cr638_cliente_value')
              ,(F.date_trunc('day', F.col('AG.ymdb_servicedate')) == F.date_trunc('day', F.col('PEC.new_datadoservico')))]
             ,'inner')
        .groupBy(F.col('A.ID_CONTATO'))
            .agg(F.count('AG.ymdb_servicedate').alias('QT_GERARAM_XML_AGENDAMENTO'))
        .select('A.ID_CONTATO', 'QT_GERARAM_XML_AGENDAMENTO')
)

# COMMAND ----------

# DBTITLE 1,QT_CLIENTES_ABRIU_CAMPANHA
df_cliente_abriu_campanha = (
    filtered_customers.alias('A')
    .join(F.broadcast(df_interacao.filter(F.col('ymdb_atividadelida') == 'true')).alias('IN')
         ,[F.col('A.ID_CONTATO') == F.col('IN._ymdb_cliente_value')]
         ,'inner')
    .withColumn('FL_ABRIU_CAMPANHA', F.lit(True))
    .select('A.ID_CONTATO', 'FL_ABRIU_CAMPANHA')
    .dropDuplicates()
)

# COMMAND ----------

# DBTITLE 1,QT_CLIENTES_QUE_BAIXARAM
df_cliente_que_baixaram = (
    filtered_customers.alias('A')
    .join(F.broadcast(df_moto).alias('MO'), [F.col('A.ID_CONTATO') == F.col('MO._ymdb_cliente_value')], 'inner')
    .withColumn('FL_BAIXOU_APP', F.lit(True))
    .select('A.ID_CONTATO', 'FL_BAIXOU_APP')
)

# COMMAND ----------

# DBTITLE 1,QT_CLIENTES_QUE_RECEBERAM
df_cliente_que_receberam = (
    filtered_customers.alias('A')
        .join(F.broadcast(df_interacao.filter(F.col('ymdb_atividaderecebida') == 'true')).alias('IN')
             ,[F.col('A.ID_CONTATO') == F.col('IN._ymdb_cliente_value')]
            ,'inner')
        .withColumn('FL_RECEBEU', F.lit(True))
        .select('A.ID_CONTATO', 'FL_RECEBEU')
        .dropDuplicates()
)

# COMMAND ----------

# DBTITLE 1,QT_CLIENTES_MENSAGEM_CLICADA
df_cliente_mensagem_clicada = (
    filtered_customers.alias('A')
        .join(F.broadcast(df_interacao.filter(F.col('ymdb_mensagemclicada') == 'true')).alias('IN')
              ,[F.col('A.ID_CONTATO') == F.col('IN._ymdb_cliente_value')]
              ,'inner')
        .withColumn('FL_CLICOU_MENSAGEM', F.lit(True))
        .select('A.ID_CONTATO', 'FL_CLICOU_MENSAGEM')
        .dropDuplicates()
)

# COMMAND ----------

# DBTITLE 1,QT_CLIENTES_QUE_ABRIRAM
df_cliente_que_abriram = (
    filtered_customers.alias('A')
    .join(F.broadcast(df_interacao.filter(F.col('ymdb_atividadelida') == 'true')).alias('IN'), [F.col('A.ID_CONTATO') == F.col('IN._ymdb_cliente_value')], 'inner')
    .withColumn('FL_ABRIU', F.lit(True))
    .select('A.ID_CONTATO', 'FL_ABRIU')
    .dropDuplicates()
)

# COMMAND ----------

# DBTITLE 1,QT_CLIENTES_IMPACTADOS
df_interacao_temp = (
    df_interacao
    .withColumn('RANK', F.row_number().over(Window.partitionBy('_ymdb_cliente_value').orderBy(F.desc('ymdb_datadorecebimento'))))
    .filter(F.col('RANK') == 1)
    .select('_ymdb_cliente_value','ymdb_datadorecebimento','RANK')
)

df_cliente_impactado = (
    df_cliente.alias('A')
        .join(F.broadcast(df_interacao_temp).alias('IN')
             ,[F.col('A.ID_CONTATO') == F.col('IN._ymdb_cliente_value')]
             ,'inner')
        .withColumn('ID_CALENDARIO_CLIENTE_IMPACTADO'
                   ,F.concat(F.year(F.col('IN.ymdb_datadorecebimento')) * 10000
                            ,F.month(F.col('IN.ymdb_datadorecebimento')) * 100
                            ,F.day(F.col('IN.ymdb_datadorecebimento'))))
    .select('A.ID_CONTATO', 'ID_CALENDARIO_CLIENTE_IMPACTADO')
    .dropDuplicates()
)

# COMMAND ----------

# DBTITLE 1,TEMPO_CONTRATO
df_orderdetails_temp = (
    df_orderdetails
        .withColumn('ID_CONTACTID', F.col('_ymdb_cliente_value'))        
        .select('ID_CONTACTID', 'ymdb_chassis')
)

df_tempo_contrato = \
    (df_orderdetails_temp.alias('A')
        .join(F.broadcast(df_ret).alias('B')
             ,[F.col('A.ymdb_chassis') == F.col('B.NR_CHASSI')]
             ,'inner')
        .withColumn('VL_TEMPO_CONTRATO'
                   ,F.when(F.col('B.PRAZO') == '000', F.lit(None)).otherwise(F.col('B.PRAZO').cast(IntegerType())))
        .withColumn('VL_TEMPO_CONTRATO_RESTANTE'
                   ,F.when(F.col('B.DATA_CONTRATO') == '00000000', F.lit(None))
                     .otherwise(F.round(F.months_between(F.add_months(F.to_date('B.DATA_CONTRATO','yyyyMMdd'),'VL_TEMPO_CONTRATO'),F.current_date()))))    
        .select('A.ID_CONTACTID','VL_TEMPO_CONTRATO','VL_TEMPO_CONTRATO_RESTANTE')
)

# COMMAND ----------

# DBTITLE 1,Unificação dos dataframes e seleção de campos
df_contact_final_temp = (
    df_cliente.alias('A')
    .join((df_comprou_motos).alias('B'), [F.col('A.ID_CONTATO') == F.col('B.ID_CONTATO')],'left')
    .join((df_comprou_pecas).alias('C'), [F.col('A.ID_CONTATO') == F.col('C.ID_CONTATO')],'left')
    .join((df_comprou_revisoes).alias('D'), [F.col('A.ID_CONTATO') == F.col('D.ID_CONTATO')],'left')
    .join((df_qtd_checkin).alias('E'), [F.col('A.ID_CONTATO') == F.col('E.ID_CONTATO')],'left')
    .join((df_registros_eventos).alias('F'), [F.col('A.ID_CONTATO') == F.col('F.ID_CONTATO')],'left')
    .join((df_comprou_motos_datas_diferentes).alias('G'), [F.col('A.ID_CONTATO') == F.col('G.ID_CONTATO')],'left')
    .join((df_comprou_moto_e_peca).alias('H'), [F.col('A.ID_CONTATO') == F.col('H.ID_CONTATO')],'left')
    .join((df_comprou_motos_ecommerce).alias('I'), [F.col('A.ID_CONTATO') == F.col('I.ID_CONTATO')],'left')
    .join((df_comprou_pecas_ecommerce).alias('J'), [F.col('A.ID_CONTATO') == F.col('J.ID_CONTATO')],'left')
    .join((df_lead_origem_base_yamaha).alias('K'), [F.col('A.ID_CONTATO') == F.col('K.ID_CONTATO')],'left')
    .join((df_lead_origem_yamaha_lastupdate).alias('L'), [F.col('A.ID_CONTATO') == F.col('L.ID_CONTATO')],'left')
    .join((df_lead_apareceram_base_xml).alias('M'), [F.col('A.ID_CONTATO') == F.col('M.ID_CONTATO')],'left')
    .join((df_lead_apareceram_base_mesmo_mes).alias('N'), [F.col('A.ID_CONTATO') == F.col('N.ID_CONTATO')],'left')
    .join((df_agendaram_foram_nao_foram).alias('O'), [F.col('A.ID_CONTATO') == F.col('O.ID_CONTATO')],'left')
    .join(F.broadcast(df_qt_agendamentos).alias('P'), [F.col('A.ID_CONTATO') == F.col('P.ID_CONTATO')],'left')
    .join((df_agendamento_indireto).alias('Q'), [F.col('A.ID_CONTATO') == F.col('Q.ID_CONTATO')],'left')
    .join((df_geraram_xml_agendamento).alias('R'), [F.col('A.ID_CONTATO') == F.col('R.ID_CONTATO')],'left')
    .join((df_cliente_abriu_campanha).alias('S'), [F.col('A.ID_CONTATO') == F.col('S.ID_CONTATO')],'left')
    .join((df_cliente_que_baixaram).alias('T'), [F.col('A.ID_CONTATO') == F.col('T.ID_CONTATO')],'left')
    .join((df_cliente_que_receberam).alias('U'), [F.col('A.ID_CONTATO') == F.col('U.ID_CONTATO')],'left')
    .join((df_cliente_mensagem_clicada).alias('V'), [F.col('A.ID_CONTATO') == F.col('V.ID_CONTATO')],'left')
    .join((df_cliente_que_abriram).alias('W'), [F.col('A.ID_CONTATO') == F.col('W.ID_CONTATO')],'left')
    .join((df_cliente_impactado).alias('X'), [F.col('A.ID_CONTATO') == F.col('X.ID_CONTATO')],'left')
    .join(F.broadcast(df_tempo_contrato).alias('Y'), [F.col('A.ID_CONTATO') == F.col('Y.ID_CONTACTID')],'left')
    .select('A.*', 
            'B.QT_COMPROU_MOTOS', 
            'B.VL_COMPROU_MOTOS', 
            'C.QT_COMPROU_PECAS', 
            'D.QT_REVISOES', 
            'E.QT_CHECKIN', 
            'F.QT_REGISTROS_EM_EVENTOS', 
            'G.QT_COMPROU_MOTOS_DATAS_DIFERENTES', 
            'H.FL_COMPROU_MOTO_E_PECA', 
            'I.QT_COMPROU_MOTOS_ECOMMERCE', 
            'I.VL_COMPROU_MOTOS_ECOMMERCE', 
            'J.QT_COMPROU_PECAS_ECOMMERCE', 
            'J.VL_COMPROU_PECAS_ECOMMERCE', 
            'K.FL_LEAD_ORIGEM_BASE_YAMAHA', 
            'L.ID_CALENDARIO_ULTIMA_ATUALIZACAO_LEAD', 
            'M.FL_LEAD_APARECERAM_BASE_XML', 
            'N.QT_MESES_APARECERAM_LEAD_NA_BASE', 
            'O.DS_STATUS_AGENDARAM', 
            'P.QT_AGENDAMENTO', 
            'Q.QT_AGENDAMENTO_INDIRETO', 
            'R.QT_GERARAM_XML_AGENDAMENTO',
            'S.FL_ABRIU_CAMPANHA',
            'T.FL_BAIXOU_APP',
            'U.FL_RECEBEU',
            'V.FL_CLICOU_MENSAGEM',
            'W.FL_ABRIU',
            'X.ID_CALENDARIO_CLIENTE_IMPACTADO',
            'Y.VL_TEMPO_CONTRATO',
            'Y.VL_TEMPO_CONTRATO_RESTANTE')
)

# COMMAND ----------

df_contact_final_temp.createOrReplaceTempView('df_contact_final_temp')

query_contact_final = \
    """Select ID_CONTATO
             ,NM_NOME_COMPLETO
             ,DS_EMAIL1
             ,DS_EMAIL2
             ,DS_EMAIL3
             ,NR_TELEFONE_CELULAR
             ,NM_GENERO
             ,NM_ENDERECO1_CIDADE
             ,DS_ENDERECO1_ESTADO
             ,NM_ENDERECO2_CIDADE
             ,DS_ENDERECO2_ESTADO
             ,DC_YMDB_CPF
             ,FL_YMDB_CPF_VALIDO
             ,cast(QT_COMPROU_MOTOS as Integer) as QT_COMPROU_MOTOS
             ,cast(VL_COMPROU_MOTOS as Decimal(16,10)) as VL_COMPROU_MOTOS
             ,cast(QT_COMPROU_PECAS as Integer) as QT_COMPROU_PECAS
             ,cast(QT_REVISOES as Integer) as QT_REVISOES
             ,cast(QT_CHECKIN as Integer) as QT_CHECKIN
             ,cast(QT_REGISTROS_EM_EVENTOS as Integer) as QT_REGISTROS_EM_EVENTOS
             ,cast(QT_COMPROU_MOTOS_DATAS_DIFERENTES as Integer) as QT_COMPROU_MOTOS_DATAS_DIFERENTES
             ,cast(FL_COMPROU_MOTO_E_PECA as Boolean) as FL_COMPROU_MOTO_E_PECA
             ,cast(QT_COMPROU_MOTOS_ECOMMERCE as Integer) as QT_COMPROU_MOTOS_ECOMMERCE
             ,cast(VL_COMPROU_MOTOS_ECOMMERCE as Decimal(16,10)) as VL_COMPROU_MOTOS_ECOMMERCE
             ,cast(QT_COMPROU_PECAS_ECOMMERCE as Integer) as QT_COMPROU_PECAS_ECOMMERCE
             ,cast(VL_COMPROU_PECAS_ECOMMERCE as Decimal(16,10)) as VL_COMPROU_PECAS_ECOMMERCE
             ,cast(FL_LEAD_ORIGEM_BASE_YAMAHA as Boolean) as FL_LEAD_ORIGEM_BASE_YAMAHA
             ,cast(ID_CALENDARIO_ULTIMA_ATUALIZACAO_LEAD as Integer) as ID_CALENDARIO_ULTIMA_ATUALIZACAO_LEAD
             ,cast(FL_LEAD_APARECERAM_BASE_XML as Boolean) as FL_LEAD_APARECERAM_BASE_XML
             ,cast(QT_MESES_APARECERAM_LEAD_NA_BASE as Integer) as QT_MESES_APARECERAM_LEAD_NA_BASE
             ,cast(DS_STATUS_AGENDARAM as String) as DS_STATUS_AGENDARAM
             ,cast(QT_AGENDAMENTO as Integer) as QT_AGENDAMENTO
             ,cast(QT_AGENDAMENTO_INDIRETO as Integer) as QT_AGENDAMENTO_INDIRETO
             ,cast(QT_GERARAM_XML_AGENDAMENTO as Integer) as QT_GERARAM_XML_AGENDAMENTO
             ,cast(FL_BAIXOU_APP as Boolean) as FL_ABRIU_CAMPANHA
             ,cast(FL_RECEBEU as Boolean) as FL_RECEBEU
             ,cast(FL_CLICOU_MENSAGEM as Boolean) as FL_CLICOU_MENSAGEM
             ,cast(FL_ABRIU as Boolean) as FL_ABRIU
             ,cast(ID_CALENDARIO_CLIENTE_IMPACTADO as Integer) as ID_CALENDARIO_CLIENTE_IMPACTADO
             ,cast(VL_TEMPO_CONTRATO as Integer) as VL_TEMPO_CONTRATO
             ,cast(VL_TEMPO_CONTRATO_RESTANTE as Integer) as VL_TEMPO_CONTRATO_RESTANTE
        from df_contact_final_temp
"""

df_contact_final = spark.sql(query_contact_final)

df_contact_final = df_contact_final.dropDuplicates(['ID_CONTATO'])


# COMMAND ----------

# DBTITLE 1,Persistir os dados na camada Gold
print(f"Persiste os dados do DF na tabela {catalog}.{schema}.{table}", end="")
(
    df_contact_final
        .write
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(f"{catalog}.{schema}.{table}")
)
print(" - Concluido com sucesso")

# COMMAND ----------

# DBTITLE 1,Otimização da tabela Gold
# optimization Gold layer
optimize_delta_table(f'{catalog}.{schema}.{table}')

# COMMAND ----------

# DBTITLE 1,Remover o df_cliente da memória
df_cliente.unpersist()