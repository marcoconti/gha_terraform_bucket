# Databricks notebook source
# MAGIC %md ### Import bibliotecas

# COMMAND ----------

import os
from pyspark.sql.functions import *
from pyspark.sql.types import StringType
from delta.tables import *
from pyspark.sql.window import Window

# COMMAND ----------

spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", "false")

# COMMAND ----------

# MAGIC %md ### Optimization Method

# COMMAND ----------

def optimize_delta_table(table_name):
    """
        @param: IN table_path
        Run optimization commands and old snapshots
        Full load
    """
    deltaTable = DeltaTable.forName(spark, table_name)
    deltaTable.vacuum(24)
    deltaTable.optimize().executeCompaction()
    print('Delta table optimized.') 

def get_env():
    return os.environ.get("DATABRICKS_ENV")


# COMMAND ----------

# MAGIC %md ### Variáveis

# COMMAND ----------

env     = get_env()
catalog = f"gold_{env.lower()}"
schema  = "comercial_planejamento_comercial"
table   = "ft_evento"

# COMMAND ----------

# MAGIC %md #### Leitura de tabelas, rename columns, tranformações e criação de colunas

# COMMAND ----------

# DBTITLE 1,Tratamento da tabela msevtmgt_event
# Tabela Mestre

drop_cols = ["_odata_etag", "_hash", "_ingestionin"]
df_event = \
    (spark.sql(f"""Select * 
                     from silver_{env}.dynamics_365_sales_lifetime_customer.msevtmgt_event""")
          .drop(*drop_cols))

renames_cols = \
    {'ymdb_npspesquisaenviada' : 'nr_ymdb_pesquisanpsenviada_event'
    ,'modifiedon' : 'dt_modifiedon_event'
    ,'_owninguser_value' : 'cd_owninguser_value_event'
    ,'_modifiedonbehalfby_value' : 'cd_modifiedonbehalfby_value_event'
    ,'statuscode' : 'cd_statuscode_event'
    ,'_ownerid_value' : 'id_ownerid_value_event'
    ,'timezoneruleversionnumber' : 'nr_timezoneruleversionnumber_event'
    ,'_owningteam_value' : 'cd_owningteam_value_event'
    ,'overriddencreatedon' : 'dt_overriddencreatedon_event'
    ,'_owningbusinessunit_value' : 'cd_owningbusinessunit_value_event'
    ,'createdon' : 'dt_createdon_event'
    ,'_transactioncurrencyid_value' : 'id_transactioncurrencyid_value_event'
    ,'_createdby_value' : 'cd_createdby_value_event'
    ,'statecode' : 'cd_statecode_event'
    ,'versionnumber' : 'nr_versionnumber_event'
    ,'_modifiedby_value' : 'cd_modifiedby_value_event'
    ,'importsequencenumber' : 'nr_importsequencenumber_event'
    ,'exchangerate' : 'nr_exchangerate_event'
    ,'utcconversiontimezonecode' : 'cd_utcconversiontimezonecode_event'
    ,'_createdonbehalfby_value' : 'cd_createdonbehalfby_value_event'}

# Renomear as colunas 
select_exprs = []
select_exprs = [f" {c} as {renames_cols.get(c, c)} " for c in df_event.columns ]
df_event = df_event.selectExpr(*select_exprs)

# Criar colunas
select_exprs = df_event.columns
id_calendario = \
    "date_format(msevtmgt_eventstartdate,'yyyyMMdd') as id_calendario"

select_exprs.append(id_calendario)
df_event = df_event.selectExpr(select_exprs)


# COMMAND ----------

# DBTITLE 1,Tratamento da tabela msevtmgt_eventregistration
drop_cols = ["_odata_etag","_year", "_month", "_hash", "_ingestionin"]
df_registration = \
    (spark.sql(f"""Select * 
                     from silver_{env}.dynamics_365_sales_lifetime_customer.msevtmgt_eventregistration""")
          .drop(*drop_cols))

renames_cols = \
    {'createdon' : 'dt_createdon_registration'
    ,'msevtmgt_name' : 'nm_msevtmgt_name_registration'
    ,'_msevtmgt_eventid_value' : 'id_msevtmgt_eventid_value_registration'
    ,'importsequencenumber' : 'nr_importsequencenumber_registration'
    ,'versionnumber' : 'nr_versionnumber_registration'
    ,'modifiedon' : 'dt_modifiedon_registration'
    ,'_createdby_value' : 'cd_createdby_value'
    ,'utcconversiontimezonecode' : 'cd_utcconversiontimezonecode_registration'
    ,'_owninguser_value' : 'cd_owninguser_value_registration'
    ,'_modifiedonbehalfby_value' : 'cd_modifiedonbehalfby_value_registration'
    ,'statuscode' : 'cd_statuscode_registration'
    ,'_ownerid_value' : 'id_ownerid_value_registration'
    ,'_createdonbehalfby_value' : 'cd_createdonbehalfby_value_registration'
    ,'timezoneruleversionnumber' : 'nr_timezoneruleversionnumber_registration'
    ,'_owningteam_value' : 'cd_owningteam_value_registration'
    ,'_modifiedby_value' : 'cd_modifiedby_value_registration'
    ,'statecode' : 'cd_statecode_registration'
    ,'overriddencreatedon' : 'dt_overriddencreatedon_registration'
    ,'_owningbusinessunit_value' : 'cd_owningbusinessunit_value_registration'}

# Renomear as colunas 
select_exprs =  [ f" {c} as {renames_cols.get(c, c)} " for c in df_registration.columns ]
df_registration = df_registration.selectExpr(*select_exprs)

# Tratamento de colunas 
change_cols = \
    {"ymdb_qual_e_a_marca_da_sua_motocicleta": 
        "upper(trim(ymdb_qual_e_a_marca_da_sua_motocicleta)) as ymdb_qual_e_a_marca_da_sua_motocicleta",
    "ymdb_qual_e_o_modelo_da_sua_motocicleta": 
        "upper(trim(ymdb_qual_e_o_modelo_da_sua_motocicleta)) as ymdb_qual_e_o_modelo_da_sua_motocicleta"
    }
select_exprs = [change_cols.get(c, c) for c in df_registration.columns]
df_registration = df_registration.selectExpr(select_exprs)


# COMMAND ----------

# DBTITLE 1,Tratamento da tabela msevtmgt_pass
drop_cols = ["_odata_etag","_year", "_month", "_hash", "_ingestionin"]
df_pass = \
    (spark.sql(f"""Select * 
                     from silver_{env}.dynamics_365_sales_lifetime_customer.msevtmgt_pass""")
          .drop(*drop_cols))

renames_cols = \
    {'createdon': 'dt_createdon_pass'
    ,'msevtmgt_name': 'nm_msevtmgt_name_pass'
    ,'_msevtmgt_eventid_value': 'id_msevtmgt_eventid_value_pass'
    ,'importsequencenumber': 'nr_importsequencenumber_pass'
    ,'_transactioncurrencyid_value': 'id_transactioncurrencyid_value_pass'
    ,'exchangerate': 'nr_exchangerate_pass'
    ,'versionnumber': 'nr_versionnumber_pass'
    ,'modifiedon': 'dt_modifiedon_pass'
    ,'utcconversiontimezonecode': 'cd_utcconversiontimezonecode_pass'
    ,'statuscode': 'cd_statuscode_pass'
    ,'timezoneruleversionnumber': 'nr_timezoneruleversionnumber_pass'
    ,'statecode': 'cd_statecode_pass'
    ,'overriddencreatedon': 'dt_overriddencreatedon_pass'
    ,'msevtmgt_descriptorsyncstatus': 'ds_msevtmgt_descriptorsyncstatus_pass'}

# Renomear as colunas 
select_exprs =  [ f" {c} as {renames_cols.get(c, c)} " for c in df_pass.columns ]
df_pass = df_pass.selectExpr(*select_exprs)


# COMMAND ----------

# DBTITLE 1,Tratamento da tabela msevtmgt_checkin
drop_cols = ["_odata_etag","_year", "_month", "_hash", "_ingestionin", "ymdb_pesquisanpsenviada"]
df_checkin = \
    (spark.sql(f"""Select * 
                    from silver_{env}.dynamics_365_sales_lifetime_customer.msevtmgt_checkin""")
          .drop(*drop_cols))

renames_cols = \
    {'createdon': 'dt_createdon_checkin'
    ,'msevtmgt_name': 'nm_msevtmgt_name_checkin'
    ,'importsequencenumber': 'nr_importsequencenumber_checkin'
    ,'versionnumber': 'nr_versionnumber_checkin'
    ,'modifiedon': 'dt_modifiedon_checkin'
    ,'_createdby_value': 'cd_createdby_value_checkin'
    ,'utcconversiontimezonecode': 'cd_utcconversiontimezonecode_checkin'
    ,'_owninguser_value': 'cd_owninguser_value_checkin'
    ,'_modifiedonbehalfby_value': 'cd_modifiedonbehalfby_value_checkin'
    ,'statuscode': 'cd_statuscode_checkin'
    ,'_ownerid_value': 'id_ownerid_value_checkin'
    ,'_createdonbehalfby_value': 'cd_createdonbehalfby_value_checkin'
    ,'timezoneruleversionnumber': 'nr_timezoneruleversionnumber_checkin'
    ,'_owningteam_value': 'cd_owningteam_value_checkin'
    ,'statecode': 'cd_statecode_checkin'
    ,'_modifiedby_value': 'cd_modifiedby_value_checkin'
    ,'overriddencreatedon': 'dt_overriddencreatedon_checkin'
    ,'_owningbusinessunit_value': 'cd_owningbusinessunit_value_checkin'
    ,'_msevtmgt_transactioncurrencyid_value': 'id_msevtmgt_transactioncurrencyid_value_checkin'}

# Renomear as colunas 
select_exprs = []
select_exprs = [f" {c} as {renames_cols.get(c, c)} " for c in df_checkin.columns]
df_checkin = df_checkin.selectExpr(*select_exprs)


# COMMAND ----------

drop_cols = ["_odata_etag","_year", "_month", "_hash", "_ingestionin"]

df_revisoes = \
    (spark.sql(f"""Select * 
                   from silver_{env}.dynamics_365_sales_lifetime_customer.ymdb_revisoes""")
          .drop(*drop_cols))

df_discover = \
    (spark.sql(f"""select * 
                     from silver_{env}.dynamics_365_sales_lifetime_customer.cr638_discover""")
          .drop(*drop_cols))

# COMMAND ----------

# MAGIC %md ### Colunas auxiliares indicadores "8. Já se inscreveu em um evento Yamaha?"

# COMMAND ----------

# MAGIC %md #### NR_DIFERENCA_CHECKIN_E_COMPRA_MOTO_DIAS

# COMMAND ----------

df_contatos_compraram_apos_evento = (
    df_checkin
        .alias('checkin')
        .join(
            df_revisoes.alias('revisoes'),
            on=(
                (col('checkin._msevtmgt_contact_value') == col('revisoes._ymdb_cliente_id_value')) &
                (col('revisoes.ymdb_revisao_numero') == '-1')
            ),
            how='left'
        )
        .filter(col('checkin.msevtmgt_checkintime') <= col('revisoes.ymdb_datarevisao')))

# COMMAND ----------

FATOR_CONVERSAO_DIA = (60 * 60 * 24)

windowSpec  = Window.partitionBy("checkin.msevtmgt_checkinid").orderBy(col("revisoes.ymdb_datarevisao"))

df_contatos_compraram_apos_evento = (
    df_checkin
        .alias('checkin')
        .join(
            df_revisoes.alias('revisoes'),
            on=(
                (col('checkin._msevtmgt_contact_value') == col('revisoes._ymdb_cliente_id_value')) &
                (col('revisoes.ymdb_revisao_numero') == '-1')
            ),
            how='left'
        )
        .filter(col('checkin.msevtmgt_checkintime') <= col('revisoes.ymdb_datarevisao'))
        .withColumn('NR_RANK_PROXIMA_COMPRA_APOS_EVENTO', row_number().over(windowSpec))
        .filter(col('NR_RANK_PROXIMA_COMPRA_APOS_EVENTO') == '1')
        .withColumn('NR_DIFERENCA_CHECKIN_E_COMPRA_MOTO_DIAS', 
            round((col("revisoes.ymdb_datarevisao").cast("long") - col('checkin.msevtmgt_checkintime').cast("long")) / FATOR_CONVERSAO_DIA).cast("int")
        )
        .select('msevtmgt_checkinid', 'NR_DIFERENCA_CHECKIN_E_COMPRA_MOTO_DIAS')
)

# COMMAND ----------

df_checkin = (
    df_checkin
        .alias('checkin')
        .join(
            df_contatos_compraram_apos_evento.alias('compraram_apos_avento'),
            on = col('checkin.msevtmgt_checkinid') == col('compraram_apos_avento.msevtmgt_checkinid'),
            how = 'left'
        )
        .select('checkin.*', 'compraram_apos_avento.NR_DIFERENCA_CHECKIN_E_COMPRA_MOTO_DIAS')
)


# COMMAND ----------

# MAGIC %md #### NR_DIFERENCA_CHECKIN_E_COMPRA_PECAS_DIAS

# COMMAND ----------

windowSpec  = Window.partitionBy("checkin.msevtmgt_checkinid").orderBy(col("discover.new_datadoservico"))

df_contatos_compraram_peca_apos_evento = (
    df_checkin
        .alias('checkin')
        .join(
            df_discover.alias('discover'),
            on=(
                (col('checkin._msevtmgt_contact_value') == col('discover._cr638_cliente_value')) &
                (col('discover.cr638_tipoproduto') == 'PECA')
            ),
            how='left'
        )
        .filter(col('checkin.msevtmgt_checkintime') <= col('discover.new_datadoservico'))
        .withColumn('NR_RANK_PROXIMA_COMPRA_APOS_EVENTO', row_number().over(windowSpec))
        .filter(col('NR_RANK_PROXIMA_COMPRA_APOS_EVENTO') == '1')
        .withColumn('NR_DIFERENCA_CHECKIN_E_COMPRA_PECA_DIAS', 
            round((col("discover.new_datadoservico").cast("long") - col('checkin.msevtmgt_checkintime').cast("long")) / FATOR_CONVERSAO_DIA).cast("int")
        )
        .select('checkin.msevtmgt_checkinid', 'NR_DIFERENCA_CHECKIN_E_COMPRA_PECA_DIAS')
)

# COMMAND ----------

df_checkin = (
    df_checkin
        .alias('checkin')
        .join(
            df_contatos_compraram_peca_apos_evento.alias('compraram_peca_apos_avento'),
            on = col('checkin.msevtmgt_checkinid') == col('compraram_peca_apos_avento.msevtmgt_checkinid'),
            how = 'left'
        )
        .select('checkin.*', 'compraram_peca_apos_avento.NR_DIFERENCA_CHECKIN_E_COMPRA_PECA_DIAS')
)

del df_contatos_compraram_peca_apos_evento

# COMMAND ----------

# MAGIC %md ### Geração ft_event

# COMMAND ----------

df_ft_event = (
    df_event.alias('event')
    .join(df_pass.alias('pass')
         ,[col('event.msevtmgt_eventid') == col('pass.id_msevtmgt_eventid_value_pass')]
         ,'left')
    .join(df_registration.alias('registration')
         ,[col('event.msevtmgt_eventid') == col('registration.id_msevtmgt_eventid_value_registration')]
         ,'left')
    .join(df_checkin.alias('checkin')
         ,[col('registration.id_msevtmgt_eventid_value_registration') == col('checkin._msevtmgt_registrationid_value')]
         ,'left')
    
    .withColumnRenamed('_msevtmgt_contactid_value','id_contactid_registration')
    .withColumnRenamed('_msevtmgt_contact_value','id_contactid_checkin')

    .dropDuplicates()
)

# COMMAND ----------

# MAGIC %md ### Writing silver -> gold

# COMMAND ----------

print(f"Persiste os dados do DF na tabela {catalog}.{schema}.{table}", end="")
(
    df_ft_event
    .write
    .partitionBy("_year","_month")
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f"{catalog}.{schema}.{table}")
)
print(" - Concluido com sucesso")

# COMMAND ----------

# optimization Gold layer
optimize_delta_table(f'{catalog}.{schema}.{table}')