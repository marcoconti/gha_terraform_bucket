# Databricks notebook source
# MAGIC %md
# MAGIC - `Criado por:` Caio Francisco 
# MAGIC - `Data Criação:` 04-09-2024
# MAGIC - `Atualizado por:` Marco Conti
# MAGIC - `Data Atualização:` 30-07-2025

# COMMAND ----------

# MAGIC %md
# MAGIC ### importação de bibliotecas

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from delta.tables import *
import os

# COMMAND ----------

spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", "false")

# COMMAND ----------

def optimize_delta_table(table_name):
    """
        @param: IN table_path
        Run optimization commands and old snapshots
        Full load
    """
    deltaTable = DeltaTable.forName(spark, table_name)
    deltaTable.vacuum(24)
    deltaTable.optimize().executeCompaction()
    print('Delta table optimized.') 

def get_env():
    return os.environ.get("DATABRICKS_ENV")

# COMMAND ----------

# MAGIC %md
# MAGIC ### variaveis

# COMMAND ----------

env     = get_env()
catalog = f"gold_{env.lower()}"
schema  = "comercial_planejamento_comercial"
table   = "notas_concessionarias"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Selecao de tabelas e campos

# COMMAND ----------

# 
df_produto = (
    spark.table(f'silver_{env}.autoware_portalweb.produto')
         .select(col('ID_PRODUTO')
                ,col('ID_PRODUTO_CONFIGURACAO')
                ,col('NU_NF_FATURAMENTO').alias("NU_NF_FATURAMENTO")
                ,col('DT_FATURAMENTO')
                ,col('NU_PRODUTO').alias('NR_PRODUTO')
                ,col('CD_MODELO')
                ,col('NM_MODELO')
                ,col('NU_ANO_FABRICACAO').alias('NR_ANO_FABRICACAO')
                ,col('NU_ANO_MODELO').alias('NR_ANO_MODELO')
    )
)

df_registrovenda = (
    spark.table(f'silver_{env}.autoware_portalweb.registrovenda')
         .select(col('ID_PRODUTO')
                ,col('ID_EMPRESA_EXECUTANTE')
                ,col('ID_LAUDO')
                ,col('ID_CLIENTE')
                ,col('NU_NOTA_FISCAL')
                ,col('DT_VENDA')
                ,col('VL_NOTA_FISCAL')
    )
)

df_empresa = (
    spark.table(f'silver_{env}.autoware_portalweb.empresa')
    .select(
        col('ID_EMPRESA'),
        col('NM_EMPRESA'),
        col('NU_CNPJ').alias('NR_CNPJ'),
        col('DS_CIDADE'),
        col('SG_UF'),
        col('CD_AUX1')
    )
)

df_laudo = (
    spark.table(f'silver_{env}.autoware_portalweb.laudo')
         .select(col('ID_LAUDO')
                ,col('IN_CANCELADO').alias("NR_IN_CANCELADO")
    )
)

df_produtoconfiguracao = (
    spark.table(f'silver_{env}.autoware_portalweb.produtoconfiguracao')
         .select(col('ID_PRODUTO_CONFIGURACAO')
                ,col('ID_LINHA')
                ,col('ID_TIPO_PRODUTO')
    )
)

df_linha = (
    spark.table(f'silver_{env}.autoware_portalweb.linha')
         .select(col('ID_LINHA')
                ,col('NM_LINHA')
    )
)

df_cliente = (
    spark.table(f'silver_{env}.autoware_portalweb.cliente')
         .select(col('ID_CLIENTE')
                ,col('NU_DOCUMENTO').alias("NR_DOCUMENTO")
                ,col('NM_CLIENTE')
    )
)

df_clienteatualizacao = (
    spark.table(f'silver_{env}.autoware_portalweb.clienteatualizacao')
         .select(col('ID_CLIENTE')
                ,col('IN_ATUAL').alias("NR_IN_ATUAL")
                ,col('TP_LOGRADOURO')
                ,col('DS_LOGRADOURO')
                ,col('NU_LOGRADOURO').alias("NR_LOGRADOURO")
                ,col('DS_BAIRRO')
                ,col('DS_CIDADE')
                ,col('SG_UF')
                ,col('NU_CEP').alias('NR_CEP')
                ,col('DS_EMAIL')
                ,col('NU_DDD_CELULAR').alias('NR_DDD_CELULAR')
                ,col('NU_TEL_CELULAR').alias('NR_TEL_CELULAR')
    )
)

# COMMAND ----------

# DBTITLE 1,Junta os dataframes e aplica filtro
spark.conf.set("spark.sql.autoBroadcastJoinThreshold", 10 * 1024 * 1024)  # 10 MB

df_join = \
    (df_produto.alias('p')
        .join(df_registrovenda.alias('ra'), col('p.id_produto') == col('ra.id_produto') , how='inner')
        .join(df_empresa.alias('e'), col('ra.id_empresa_executante') == col('e.id_empresa'), how='inner')
        .join(df_laudo.alias('l'), (col('ra.id_laudo') == col('l.id_laudo'))  & (col('l.nr_in_cancelado') == 0) , how='inner')
        .join(df_produtoconfiguracao.alias('pf'),col('pf.id_produto_configuracao') == col('p.id_produto_configuracao'), how='inner')
        .join(df_linha.alias('la'), col('pf.id_linha') == col('la.id_linha'), how='inner')
        .join(df_cliente.alias('c'), col('c.id_cliente') == col('ra.id_cliente'), how='inner')
        .join(df_clienteatualizacao.alias('ca'), (col('ca.id_cliente') == col('c.id_cliente')) & (col('ca.nr_in_atual') == 1) , how='inner'))
    
df_join = df_join.filter(~col('e.nr_cnpj').isin('62934252000145', '04817052000297'))

# COMMAND ----------

# DBTITLE 1,Cria novas colunas e remove caracteres especiais
#caracteres para substituicao
source_chars = 'ÑÁÉÍÓÚÀÈÌÒÙÂÊÎÔÛÃÕÄËÏÖÜÇñáéíóúàèìòùâêîôûãõäëïöüç.-!"\'`#$%().:[/]{}¨+?;ºª°§&´*<>'
target_chars = 'NAEIOUAEIOUAEIOUAOAEIOUCnaeiouaeiouaeiouaoaeiouc'

df_add_columns = \
    (df_join.withColumns({'REGIAO': substring(col('cd_aux1'), 0, 1)
						 ,'DT_FATURAMENTO': col('p.dt_faturamento').cast(DateType()) 
						 ,'DT_VENDA': col('ra.dt_venda').cast(DateType())
						 ,'ENDERECO': translate(concat_ws(' ', col('ca.tp_logradouro'), col('ca.ds_logradouro'), col('ca.nr_logradouro')), source_chars, target_chars)
						 ,'BAIRRO': translate(col('ca.ds_bairro'), source_chars, target_chars)
						 ,'CIDADE': translate(col('ca.ds_cidade'), source_chars, target_chars)
						 ,'UF': translate(col('ca.sg_uf'), source_chars, target_chars)
						 ,'TELEFONE_DEST': concat_ws(' ', col('ca.nr_ddd_celular'), col('ca.nr_tel_celular'))
						 ,'QUANT': lit(1)}))


# COMMAND ----------

# DBTITLE 1,Seleciona os campos que serão persistidos na Gold
df_nf_concessionarias = \
    (df_add_columns
        .select(col('nm_linha').alias('DS_GRUPO_MODELO'),
                col('REGIAO').alias('DS_REGIAO'),
                col('cd_aux1').alias('DS_SUB_REGIAO'),
                col('nm_empresa').alias('NM_CONCESSIONARIA'),
                col('nr_cnpj').alias('NR_CNPJ'),
                col('e.ds_cidade').alias('DS_CIDADE'),
                col('e.sg_uf').alias('SG_UF'),
                col('nu_nf_faturamento').alias('NR_NF_YAMAHA'),
                col('dt_faturamento').alias('DT_NF_YAMAHA'),
                col('nu_nota_fiscal').alias('NR_NF_CONCESS'),
                col('dt_venda').alias('DT_NF_CONCESS'),
                col('nm_cliente').alias('NM_DESTINATARIO'),
                col('nr_documento').alias('NR_DESTINATARIO_CNPJ_CPF'),
                col('endereco').alias('DS_ENDERECO'),
                col('bairro').alias('DS_BAIRRO'),
                col('cidade').alias('DS_CIDADE_2'),
                col('uf').alias('SG_UF2'),
                col('nr_cep').alias('NR_CEP'),
                col('ds_email').alias('DS_EMAIL_DEST'),
                col('telefone_dest').alias('NR_TELEFONE_DEST'),
                col('nr_produto').alias('NR_CHASSI_COMPLETO'),
                col('cd_modelo').alias('CD_PRODUTO'),
                col('nm_modelo').alias('DS_DESCRICAO'),
                col('nr_ano_fabricacao').alias('NR_ANO_FABRICACAO'),
                col('nr_ano_modelo').alias('NR_ANO_MODELO'),
                col('quant').alias('QT_QUANT'),
                col('vl_nota_fiscal').alias('VL_PRODUTO_CONCESSIONARIA'))
        .dropDuplicates())

# COMMAND ----------

# DBTITLE 1,Persiste os dados na Gold
print(f"Persiste os dados do DF na tabela {catalog}.{schema}.{table}", end="")
(
    df_nf_concessionarias
        .write
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(f"{catalog}.{schema}.{table}")
)
print(" - Concluido com sucesso")

# COMMAND ----------

# optimization Gold layer
optimize_delta_table(f'{catalog}.{schema}.{table}')