# Databricks notebook source
# MAGIC %md
# MAGIC - `Criado por:` 
# MAGIC - `Data Criação:`
# MAGIC - `Atualizado por:` Caio Francisco 
# MAGIC - `Data Atualização:`21-08-2024
# MAGIC - `Atualizado por:` Bruno Jander 
# MAGIC - `Data Atualização:`23-06-2025
# MAGIC - `Atualizado por:` Marco Conti 
# MAGIC - `Data Atualização:`24-07-2025

# COMMAND ----------

# MAGIC %md ### Import bibliotecas

# COMMAND ----------

import os
import pyspark.sql.functions as F
from pyspark.sql.types import StringType
from delta.tables import *

# COMMAND ----------

spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", "false")

# COMMAND ----------

# MAGIC %md ### Optimization Method

# COMMAND ----------

def optimize_delta_table(table_name):
    """
        @param: IN table_path
        Run optimization commands and old snapshots
        Full load
    """
    deltaTable = DeltaTable.forName(spark, table_name)
    deltaTable.vacuum(24)
    deltaTable.optimize().executeCompaction()
    print('Delta table optimized.') 

def get_env():
    return os.environ.get("DATABRICKS_ENV")

# COMMAND ----------

# MAGIC %md ### Variáveis

# COMMAND ----------

env     = get_env().lower()
catalog = f"gold_{env}"
schema  = "comercial_planejamento_comercial"
table   = "ft_lead"

# COMMAND ----------

# MAGIC  %md ### Paths

# COMMAND ----------

# MAGIC %md ### Leitura tabelas

# COMMAND ----------

# DBTITLE 1,Lê a tab. fut_interessedolead, renomeia campos e cria novos campos
drop_cols = ["_odata_etag", "_hash", "_ingestionin"]
df_leads = \
    (spark.sql(f"""Select * 
                     from silver_{env}.dynamics_365_sales_lifetime_customer.fut_interessedolead""")
          .drop(*drop_cols))
    
rename_cols = {
    "timezoneruleversionnumber": "nr_timezoneruleversionnumber_interesselead"
    ,"exchangerate": "nr_exchangerate_interesselead"
    ,"overriddencreatedon": "dt_overriddencreatedon_interesselead"
    ,"modifiedon": "dt_modifiedon_interesselead"
    ,"_transactioncurrencyid_value": "id_transactioncurrencyid_value_interesselead"
    ,"processid": "id_processid_interesselead"
    ,"traversedpath": "ds_traversedpath_interesselead"
    ,"versionnumber": "nr_versionnumber_interesselead"
    ,"createdon": "dt_createdon_interesselead"
    ,"importsequencenumber": "nr_importsequencenumber_interesselead"
    ,"utcconversiontimezonecode": "cd_utcconversiontimezonecode_interesselead"
    ,"_ymdb_areadenegocioid_value": "id_ymdb_areadenegocioid_value_interesselead"
    ,"_inove_contactid_value": "id_contactid"}

# Renomear colunas
select_exprs = []
select_exprs = [f"{c} as {rename_cols.get(c, c)}" for c in df_leads.columns ]
df_leads = df_leads.selectExpr(*select_exprs)



# Criar colunas
select_exprs = df_leads.columns
new_columns = \
    ["date_format(fut_dt_datainicioatendimento,'yyyyMMdd') as id_calendario"
    ,"_fut_lk_produto_value as ds_fut_lk_produto_value" 
    ,"_owningbusinessunit_value as cd_owningbusinessunit_value"
    ]

select_exprs += new_columns
df_leads = df_leads.selectExpr(select_exprs)


# COMMAND ----------

df_leads = (
    df_leads.withColumn('ds_statuscode_name'
                       ,F.when(F.col('statuscode') == 1, F.lit('Aguardando Contato'))
                         .when(F.col('statuscode') == 2, F.lit('Fechado Ganho'))
                         .when(F.col('statuscode') == 969830001, F.lit('Agendado'))
                         .when(F.col('statuscode') == 969830002, F.lit('Fechado Perdido'))
                         .when(F.col('statuscode') == 969830003, F.lit('Fechado Ganho'))
                         .when(F.col('statuscode') == 969830004, F.lit('Fechado Perdido'))
                         .when(F.col('statuscode') == 969830005, F.lit('Lead Disponível'))
                         .when(F.col('statuscode') == 969830006, F.lit('Fechado Ganho'))
                         .when(F.col('statuscode') == 969830007, F.lit('Fechado Perdido'))
                         .when(F.col('statuscode') == 969830008, F.lit('Interesse para futuro'))
                         .when(F.col('statuscode') == 969830009, F.lit('Em Negociação'))
                         .when(F.col('statuscode') == 969830010, F.lit('Finalizado Automático')))
)


# COMMAND ----------

drop_cols = ["_odata_etag", "_hash", "_ingestionin", "_month", "_year"]
df_systemUser = \
    (spark.sql(f"""Select * 
                     from silver_{env}.dynamics_365_sales_lifetime_customer.systemuser""")
          .drop(*drop_cols))
    
rename_cols = {
     "ownerid": "id_ownerid"
    ,"defaultfilterspopulated": "ds_defaultfilterspopulated"
    ,"inove_rg": "dc_inove_rg"
    ,"address2_county": "ds_address2_county"
    ,"domainname": "nm_domainname"
    ,"entityimage_timestamp": "nr_entityimage_timestamp"
    ,"address2_telephone3": "ds_address2_telephone3"
    ,"governmentid": "id_governmentid"
    ,"msdyn_owningenvironmentid": "id_msdyn_owningenvironmentid"
    ,"address2_addressid": "id_address2_addressid"
    ,"address2_fax": "ds_address2_fax"
    ,"identityid": "id_identityid"
    ,"middlename": "nm_sysmiddlename"
    ,"defaultodbfoldername": "nm_defaultodbfoldername"
    ,"fut_bit_ouvidoria": "ds_fut_bit_ouvidoria"
    ,"nickname": "nm_sysnickname"
    ,"entityimage": "nr_entityimage"
    ,"deletedstate": "ds_deletedstate_value"
    ,"address2_longitude": "nr_address2_longitude"
    ,"msdyn_agentType": "tp_msdyn_agenttype_value"
    ,"address1_postofficebox": "ds_address1_postofficebox"
    ,"mobilealertemail": "ds_mobilealertemail"
    ,"address1_addressid": "id_address1_addressid"
    ,"applicationiduri": "id_applicationiduri"
    ,"applicationid": "id_applicationid"
    ,"address2_shippingmethodcode": "cd_address2_shippingmethodcode_value"
    ,"address1_name": "nm_address1_name"
    ,"azureactivedirectoryobjectid": "id_azureactivedirectoryobjectid"
    ,"_modifiedonbehalfby_value": "ds__modifiedonbehalfby_value"
    ,"yammeremailaddress": "ds_yammeremailaddress"
    ,"accessmode": "ds_accessmode_value"
    ,"fut_st_macaddress": "ds_fut_st_macaddress"
    ,"yomifullname": "nm_sysyomifullname"
    ,"msdyn_botapplicationid": "id_msdyn_botapplicationid"
    ,"address2_addresstypecode": "cd_address2_addresstypecode_value"
    ,"yomilastname": "nm_sysyomilastname"
    ,"address2_utcoffset": "nr_address2_utcoffset"
    ,"title": "ds_title"
    ,"msdyn_isexpertenabledforswarm": "ds_msdyn_isexpertenabledforswarm"
    ,"disabledreason": "ds_disabledreason"
    ,"systemuserid": "id_systemuserid"
    ,"passportlo": "nr_passportlo"
    ,"address2_telephone1": "ds_address2_telephone1"
    ,"organizationid": "id_organizationid"
    ,"timezoneruleversionnumber": "nr_timezoneruleversionnumber_sysuser"
    ,"msdyn_gdproptout": "ds_msdyn_gdproptout"
    ,"internalemailaddress": "ds_internalemailaddress"
    ,"address2_postalcode": "cd_address2_postalcode"
    ,"exchangerate": "nr_exchangerate_sysuser"
    ,"incomingemaildeliverymethod": "ds_incomingemaildeliverymethod_value"
    ,"_queueid_value": "id__queueid_value"
    ,"address1_stateorprovince": "ds_address1_stateorprovince"
    ,"personalemailaddress": "ds_personalemailaddress"
    ,"preferredemailcode": "cd_preferredemailcode_value"
    ,"_siteid_value": "id__siteid_value"
    ,"inove_cpf": "dc_inove_cpf"
    ,"fullname": "nm_sysfullname"
    ,"jobtitle": "ds_jobtitle"
    ,"outgoingemaildeliverymethod": "ds_outgoingemaildeliverymethod_value"
    ,"msdyn_usertype": "tp_msdyn_usertype_value"
    ,"address1_addresstypecode": "cd_address1_addresstypecode_value"
    ,"isdisabled": "ds_isdisabled"
    ,"address2_latitude": "nr_address2_latitude"
    ,"address1_country": "ds_address1_country"
    ,"userlicensetype": "tp_userlicensetype"
    ,"overriddencreatedon": "dt_overriddencreatedon_sysuser"
    ,"address2_country": "ds_address2_country"
    ,"entityimageid": "id_entityimageid"
    ,"issyncwithdirectory": "ds_issyncwithdirectory"
    ,"address1_shippingmethodcode": "cd_address1_shippingmethodcode_value"
    ,"fut_st_pacmobile": "ds_fut_st_pacmobile"
    ,"address1_city": "ds_address1_city"
    ,"modifiedon": "dt_modifiedon_sysuser"
    ,"caltype": "tp_caltype"
    ,"preferredphonecode": "cd_preferredphonecode_value"
    ,"_territoryid_value": "id__territoryid_value"
    ,"address1_line3": "ds_address1_line3"
    ,"preferredaddresscode": "cd_preferredaddresscode_value"
    ,"address1_postalcode": "cd_address1_postalcode"
    ,"address1_telephone1": "ds_address1_telephone1"
    ,"setupuser": "ds_setupuser"
    ,"stageid": "id_stageid"
    ,"isintegrationuser": "ds_isintegrationuser"
    ,"_parentsystemuserid_value": "id__parentsystemuserid_value"
    ,"_createdby_value": "ds__createdby_value"
    ,"mobilephone": "ds_mobilephone"
    ,"cr638_statususuario": "ds_cr638_statususuario_value"
    ,"_transactioncurrencyid_value": "id__transactioncurrencyid_value"
    ,"_msdyn_defaultpresenceiduser_value": "id__msdyn_defaultpresenceiduser_value"
    ,"cr638_datainativacao": "dt_cr638_datainativacao"
    ,"firstname": "nm_sysfirstname"
    ,"address2_city": "ds_address2_city"
    ,"photourl": "ds_photourl"
    ,"isemailaddressapprovedbyo365admin": "ds_isemailaddressapprovedbyo365admin"
    ,"emailrouteraccessapproval": "ds_emailrouteraccessapproval_value"
    ,"address2_postofficebox": "ds_address2_postofficebox"
    ,"processid": "id_processid_sysuser"
    ,"sharepointemailaddress": "ds_sharepointemailaddress"
    ,"address1_telephone2": "ds_address1_telephone2"
    ,"address1_longitude": "nr_address1_longitude"
    ,"address2_composite": "ds_address2_composite"
    ,"msdyn_botprovider": "ds_msdyn_botprovider_value"
    ,"address1_composite": "ds_address1_composite"
    ,"userpuid": "id_userpuid"
    ,"skills": "ds_skills"
    ,"yammeruserid": "id_yammeruserid"
    ,"islicensed": "ds_islicensed"
    ,"_createdonbehalfby_value": "ds__createdonbehalfby_value"
    ,"lastname": "nm_syslastname"
    ,"msdyn_botsecretkeys": "ds_msdyn_botsecretkeys"
    ,"address2_upszone": "ds_address2_upszone"
    ,"address2_name": "nm_address2_name"
    ,"traversedpath": "ds_traversedpath_sysuser"
    ,"windowsliveid": "id_windowsliveid"
    ,"versionnumber": "nr_versionnumber_sysuser"
    ,"yomifirstname": "nm_sysyomifirstname"
    ,"inove_lastassignmentdate": "dt_inove_lastassignmentdate"
    ,"passporthi": "nr_passporthi"
    ,"address1_county": "ds_address1_county"
    ,"_calendarid_value": "id__calendarid_value"
    ,"displayinserviceviews": "ds_displayinserviceviews"
    ,"_businessunitid_value": "id__businessunitid_value"
    ,"msdyn_bothandle": "ds_msdyn_bothandle"
    ,"employeeid": "id_employeeid"
    ,"createdon": "dt_createdon_sysuser"
    ,"invitestatuscode": "cd_invitestatuscode_value"
    ,"address1_line2": "ds_address1_line2"
    ,"_modifiedby_value": "ds__modifiedby_value"
    ,"importsequencenumber": "nr_importsequencenumber_sysuser"
    ,"inove_address1_line4": "ds_inove_address1_line4"
    ,"cr638_cnpj": "dc_cr638_cnpj"
    ,"utcconversiontimezonecode": "cd_utcconversiontimezonecode_sysuser"
    ,"address1_latitude": "nr_address1_latitude"
    ,"msdyn_gridwrappercontrolfield": "ds_msdyn_gridwrappercontrolfield"
    ,"address1_fax": "ds_address1_fax"
    ,"address2_stateorprovince": "ds_address2_stateorprovince"
    ,"address2_line3": "ds_address2_line3"
    ,"entityimage_url": "ds_entityimage_url"
    ,"msdyn_botdescription": "ds_msdyn_botdescription"
    ,"address1_telephone3": "ds_address1_telephone3"
    ,"address2_line1": "ds_address2_line1"
    ,"yomimiddlename": "nm_sysyomimiddlename"
    ,"_positionid_value": "id__positionid_value"
    ,"azuredeletedon": "dt_azuredeletedon"
    ,"address2_line2": "ds_address2_line2"
    ,"msdyn_capacity": "nr_msdyn_capacity"
    ,"azurestate": "ds_azurestate_value"
    ,"salutation": "ds_salutation"
    ,"address1_line1": "ds_address1_line1"
    ,"msdyn_botendpoint": "ds_msdyn_botendpoint"
    ,"address1_upszone": "ds_address1_upszone"
    ,"_mobileofflineprofileid_value": "id__mobileofflineprofileid_value"
    ,"address1_utcoffset": "nr_address1_utcoffset"
    ,"homephone": "ds_homephone"
    ,"cr638_historicounidadedenegocio": "ds_cr638_historicounidadedenegocio"
    ,"address2_telephone2": "ds_address2_telephone2"
    ,"_ymdb_areadenegocioid_value": "id__ymdb_areadenegocioid_value"
    ,"_defaultmailbox_value": "ds__defaultmailbox_value"
}

select_exprs = []
select_exprs = [f"{c} as {rename_cols.get(c, c)}" for c in df_systemUser.columns ]
df_systemUser = df_systemUser.selectExpr(*select_exprs)

# COMMAND ----------

# MAGIC %md
# MAGIC ### padronização de campos

# COMMAND ----------

# Juncao interessedolead com df_systemUSer
df_leads = (
  df_leads.join(df_systemUser
               ,df_leads._ownerid_value == df_systemUser.id_ownerid
               , how='left')
)

# COMMAND ----------

# MAGIC %md ### Writing silver -> gold

# COMMAND ----------

print(f"Persiste os dados do DF na tabela {catalog}.{schema}.{table}", end="")
(
    df_leads
        .write
        .partitionBy("_year","_month")
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(f"{catalog}.{schema}.{table}")
)
print(" - Concluido com sucesso")

# COMMAND ----------

# optimization Gold layer
optimize_delta_table(f'{catalog}.{schema}.{table}')

# COMMAND ----------

del (df_leads 
    ,df_systemUser)