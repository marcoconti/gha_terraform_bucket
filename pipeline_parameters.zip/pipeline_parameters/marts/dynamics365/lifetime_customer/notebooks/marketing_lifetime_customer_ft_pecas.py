# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC - `Criado por:` 
# MAGIC - `Data Criação:`
# MAGIC - `Atualizado por:` Caio Francisco 
# MAGIC - `Data Atualização:`29-08-2024
# MAGIC - `Atualizado por:` Marco Conti
# MAGIC - `Data Atualização:`28-07-2025

# COMMAND ----------

# MAGIC %md ### Import bibliotecas

# COMMAND ----------

import os
import pyspark.sql.functions as F
from pyspark.sql.types import StringType, DecimalType
from delta.tables import *
from cryptography.fernet import Fernet
from pyspark.sql.window import Window

# COMMAND ----------

spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", "false")

# COMMAND ----------

# MAGIC %md ### Optimization Method

# COMMAND ----------

def optimize_delta_table(table_name):
    """
        @param: IN table_path
        Run optimization commands and old snapshots
        Full load
    """
    deltaTable = DeltaTable.forName(spark, table_name)
    deltaTable.vacuum(24)
    deltaTable.optimize().executeCompaction()
    print('Delta table optimized.') 

def get_env():
    return os.environ.get("DATABRICKS_ENV")

# COMMAND ----------

# MAGIC %md ### Variáveis

# COMMAND ----------

env     = get_env().lower()
catalog = f"gold_{env}"
schema  = "comercial_planejamento_comercial"
table   = "ft_pecas"


# COMMAND ----------

# MAGIC %md ### Leitura tabelas

# COMMAND ----------

# DBTITLE 1,Cabeçalho NF - leitura, rename e criação de colunas
drop_cols  = ["_odata_etag", "_hash", "_ingestionin"]
tab_xml_nf = \
    (spark.sql(f"""Select * 
                     from silver_{env}.psg_ym_int.tab_xml_nf""")
          .drop(*drop_cols))
    
select_exprs = [\
     "cast(lpad(round(cnpj,0), 14, '0') as string) cnpj_pre_format"
     ,"""concat(regexp_extract(cnpj_pre_format, r'(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})', 1), '.'
               ,regexp_extract(cnpj_pre_format, r'(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})', 2), '.'
               ,regexp_extract(cnpj_pre_format, r'(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})', 3), '/'
               ,regexp_extract(cnpj_pre_format, r'(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})', 4), '-'
               ,regexp_extract(cnpj_pre_format, r'(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})', 5)) dc_cnpj
      """
    ,"xml_id id_xml"  
    ,"emitente ds_emitente"
    ,"nota_fiscal nr_nota_fiscal"
    ,"dest_nome nm_dest_nome"
    ,"dest_cep ds_dest_cep"
    ,"dest_cidade ds_dest_cidade"
    ,"dest_estado ds_dest_estado"
    ,"dest_cnpj dc_dest_cnpj"
    ,"serie nr_serie"
    ,"data_nf dt_data_nf"
    ,"vl_icms"
    ,"vl_pis"
    ,"vl_cofins"
    ,"vl_ipi"
    ,"created_date dt_created_date"
    ,"_year"
    ,"_month"]

df_cabecalho_nota_fiscal = \
    (tab_xml_nf.selectExpr(*select_exprs).alias('df_cabecalho_nota_fiscal')
               .drop("cnpj_pre_format"))

# COMMAND ----------

# DBTITLE 1,Tabela: tab_xml_nf_line
drop_cols  = ["_odata_etag", "_hash", "_ingestionin", "_year","_month"]
df_linha_nota_fiscal = \
    (spark.sql(f"""Select xml_id id_xml
                         ,produto cd_produto
                         ,descricao ds_descricao
                         ,unidade ds_unidade
                         ,quantidade qt_quantidade
                         ,vl_unitario 
                         ,vl_produto
                         ,cfop nr_cfop
                         ,tipo_produto tp_tipo_produto 
                     from silver_{env}.psg_ym_int.tab_xml_nf_line""")
          .drop(*drop_cols))

# COMMAND ----------

# DBTITLE 1,Tabela tab_cfop
drop_cols  = ["_odata_etag", "_hash", "_ingestionin", "_year","_month"]
df_tab_cfop = \
    (spark.sql(f"""Select cfop_code cd_cfop_code
                         ,descricao ds_descricao_cfop
                     from silver_{env}.psg_ym_sg.tab_cfop""")
          .drop(*drop_cols))

# COMMAND ----------

# DBTITLE 1,Tabela portalweb_peca
drop_cols  = ["_odata_etag", "_hash", "_ingestionin", "_year","_month"]
df_pecas = \
    (spark.sql(f"""Select cd_peca
                     from silver_{env}.autoware_portalweb.peca""")
          .drop(*drop_cols))

# COMMAND ----------

# DBTITLE 1,Tab. cr638_discover, leitura, rename cols e criação de colunas
drop_cols = ["_odata_etag", "_hash", "_ingestionin", "_year","_month"]
df_discover = \
    (spark.sql(f"""Select * 
                     from silver_{env}.dynamics_365_sales_lifetime_customer.cr638_discover""")
          .drop(*drop_cols))

# Renomear colunas    
rename_cols  = {"_cr638_cliente_value": "id_contactid" }
select_exprs = []
select_exprs = [f"{c} as {rename_cols.get(c, c)}" for c in df_discover.columns ]
df_discover  = df_discover.selectExpr(*select_exprs)

# Criar colunas e fazer cast
fator_conversao_dia = (60 * 60 * 24)
windowspec = Window.partitionBy("id_contactid").orderBy("new_datadoservico")

df_discover = \
    (df_discover.withColumns({'id_calendario': (F.date_format('new_datadoservico', 'yyyyMMdd')).cast('int')
                             ,'vl_cr638_valordanotafiscal':  F.col('cr638_valordanotafiscal').cast(DecimalType(16,10))
                             ,'dt_compra_anterior': F.lag('new_datadoservico', 1).over(windowspec)
                             ,'nr_diferenca_compra_atual_ultima_compra_dias': 
                                 F.round((F.col("new_datadoservico").cast("long") - F.col('dt_compra_anterior').cast("long")) / fator_conversao_dia).cast('int')}
                             )
                .drop('dt_compra_anterior'))

# COMMAND ----------

# MAGIC %md
# MAGIC ## tratamento campos
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #junção dos dataframes

# COMMAND ----------

spark.conf.set("spark.sql.autoBroadcastJoinThreshold", 10 * 1024 * 1024)  # 10 MB

df_pecas = (
    df_cabecalho_nota_fiscal
    .join(df_linha_nota_fiscal, df_cabecalho_nota_fiscal.id_xml == df_linha_nota_fiscal.id_xml, 'inner' )
    .join(df_tab_cfop, df_linha_nota_fiscal.nr_cfop == df_tab_cfop.cd_cfop_code, 'inner' )
    .join(df_pecas, df_linha_nota_fiscal.cd_produto == F.substring(df_pecas.cd_peca, 1, 10), 'inner' )
    .filter('tp_tipo_produto NOT IN ( "MTC", "NTC" )')
    .groupby(
            'dc_cnpj', 
            'ds_emitente', 
            'nr_nota_fiscal',
            'nm_dest_nome', 
            'ds_dest_cep', 
            'ds_dest_cidade',
            'ds_dest_estado',
            'dc_dest_cnpj', 
            'nr_serie', 
            'dt_data_nf', 
            'cd_produto', 
            'ds_descricao', 
            'ds_unidade', 
            'vl_icms', 
            'vl_pis', 
            'vl_cofins', 
            'vl_ipi', 
            'cd_cfop_code', 
            'ds_descricao_cfop', 
            'dt_created_date',
            '_year',
            '_month'
)
.agg( F.sum( F.col('qt_quantidade')).alias('qt_quantidade'),
      F.sum( F.col('vl_unitario')).alias('vl_unitario'),
      F.sum( F.col('vl_produto')).alias('vl_produto'))  
)

# COMMAND ----------

# DBTITLE 1,Retorna colunas na tabela peças com valor Nulo
df_pecas = (
    df_pecas
        .withColumns({'cd_createdonbehalfby_value': F.lit(str(None))
		     	     ,'ds_cr638_serie': F.lit(str(None))
					 ,'ds_cr638_cidade': F.lit(str(None))
				     ,'nr_cr638_notafiscal': F.lit(str(None))
				     ,'cd_statuscode': F.lit(str(None))
				     ,'cd_createdby_value': F.lit(str(None))
				     ,'id_contactid': F.lit(str(None))
				     ,'ds_cr638_mesano': F.lit(str(None))
				     ,'dt_new_datadoservico': F.lit(str(None))
				     ,'cd_owningbusinessunit_value': F.lit(str(None))
				     ,'tp_cr638_tipoproduto': F.lit(str(None))
				     ,'dc_cr638_cpfcnpj': F.lit(str(None))
				     ,'tp_cr638_tipodenota': F.lit(str(None))
				     ,'cd_cr638_unidadedenegocio_value': F.lit(str(None))
				     ,'nr_versionnumber': F.lit(str(None))
				     ,'nr_cr638_numerodeprotocolo': F.lit(str(None))
				     ,'cd_modifiedby_value': F.lit(str(None))
				     ,'id_cr638_xmlid': F.lit(str(None))
				     ,'cd_statecode': F.lit(str(None))
				     ,'vl_cr638_valorrevisao': F.lit(str(None))
				     ,'vl_cr638_valorunitario': F.lit(str(None))
				     ,'nm_cr638_nomeconcessionaria': F.lit(str(None))
				     ,'dt_createdon': F.lit(str(None))
				     ,'dt_new_datadanotafiscal': F.lit(str(None))
				     ,'cd_owninguser_value': F.lit(str(None))
				     ,'nm_cr638_name': F.lit(str(None))
				     ,'ds_cr638_estado': F.lit(str(None))
				     ,'ds_cr638_produto': F.lit(str(None))
				     ,'ds_cr638_estadocliente': F.lit(str(None))
				     ,'vl_cr638_valordanotafiscal': F.lit(str(None))
				     ,'nr_cr638_chassi': F.lit(str(None))
				     ,'dt_cr638_dataderecebimentodoarquivo': F.lit(str(None))
				     ,'ds_exchangerate': F.lit(str(None))
				     ,'vl_new_valorunitario': F.lit(str(None))
				     ,'id_ownerid_value': F.lit(str(None))
				     ,'nr_importsequencenumber': F.lit(str(None))
				     ,'cd_utcconversiontimezonecode': F.lit(str(None))
				     ,'dc_cr638_cnpj': F.lit(str(None))
				     ,'cd_owningteam_value': F.lit(str(None))
				     ,'id_transactioncurrencyid_value': F.lit(str(None))
				     ,'dt_modifiedon': F.lit(str(None))
				     ,'id_cr638_discoverid': F.lit(str(None))
				     ,'nr_new_numeroprotocolo': F.lit(str(None))
				     ,'ds_cr638_softwarehouse': F.lit(str(None))
				     ,'vl_cr638_valorrevisao_base': F.lit(str(None))
				     ,'dt_overriddencreatedon': F.lit(str(None))
				     ,'cd_modifiedonbehalfby_value': F.lit(str(None))
				     ,'ds_cr638_descricao': F.lit(str(None))
				     ,'nr_timezoneruleversionnumber': F.lit(str(None))
				     ,'id_calendario': F.lit(str(None))
				     ,'nr_diferenca_compra_atual_ultima_compra_dias': F.lit(str(None))})
)

# COMMAND ----------

# DBTITLE 1,Retorna colunas na tabela discover com valor Nulo
df_discover = (
    df_discover
		.withColumns({'dc_cnpj': F.lit(str(None))
					 ,'ds_emitente': F.lit(str(None))
					 ,'nr_nota_fiscal': F.lit(str(None))
					 ,'nm_dest_nome': F.lit(str(None))
					 ,'ds_dest_cep': F.lit(str(None))
					 ,'ds_dest_cidade': F.lit(str(None))
					 ,'ds_dest_estado': F.lit(str(None))
					 ,'dc_dest_cnpj': F.lit(str(None))
					 ,'nr_serie': F.lit(str(None))
					 ,'dt_data_nf': F.lit(str(None))
					 ,'cd_produto': F.lit(str(None))
					 ,'ds_descricao': F.lit(str(None))
					 ,'ds_unidade': F.lit(str(None))
					 ,'vl_icms': F.lit(str(None))
					 ,'vl_pis': F.lit(str(None))
					 ,'vl_cofins': F.lit(str(None))
					 ,'vl_ipi': F.lit(str(None))
					 ,'cd_cfop_code': F.lit(str(None))
					 ,'ds_descricao_cfop': F.lit(str(None))
					 ,'dt_created_date': F.lit(str(None))
					 ,'qt_quantidade': F.lit(str(None))
					 ,'vl_unitario': F.lit(str(None))
					 ,'vl_produto': F.lit(str(None))})
)

# COMMAND ----------

df_pecas_full = (
  df_pecas  
  .unionByName(df_discover, allowMissingColumns=True)
)

# COMMAND ----------

# MAGIC %md ### Writing silver -> gold

# COMMAND ----------

print(f"Persiste os dados do DF na tabela {catalog}.{schema}.{table}", end="")
(
    df_pecas_full
        .write
        .partitionBy("_year","_month")
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(f"{catalog}.{schema}.{table}")
)
print(" - Concluido com sucesso")

# COMMAND ----------

# optimization Gold layer
optimize_delta_table(f'{catalog}.{schema}.{table}')

# COMMAND ----------

del (df_discover, df_cabecalho_nota_fiscal, df_linha_nota_fiscal, df_pecas, df_pecas_full)