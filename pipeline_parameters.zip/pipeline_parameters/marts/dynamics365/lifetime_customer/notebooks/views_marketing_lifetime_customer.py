# Databricks notebook source
import os
def get_env():
    env = os.environ.get("DATABRICKS_ENV")
    return env.lower()

# COMMAND ----------

env             = get_env()
catalog         = f"gold_{env}"
schema_silver   = "dynamics_365_sales_lifetime_customer"
schema_gold     = "comercial_planejamento_comercial"

created_views = []

# COMMAND ----------

# DBTITLE 1,View - vw_cliente_evento_checkin
drop_cmd = f"DROP VIEW IF EXISTS {catalog}.{schema_gold}.vw_cliente_evento_checkin"
spark.sql(drop_cmd)

view_name    = f"{catalog}.{schema_gold}.vw_cliente_evento_checkin"
query_view   = \
   f""" CREATE OR REPLACE VIEW {view_name} AS
        select ev.ID_CUSTOMER_CHECKIN,
               ev.NUM_EVENTO as NUM_EVENTOS_CHECKIN,  
               case when ev.num_evento = 1 then '1_evento'
                    when ev.num_evento = 2 then '2_evento'
                    when ev.num_evento = 3 then '3_evento'
                    else 'mais_3_evento' end as QTD_EVENTOS_CHECKIN
          from (select ev.id_contactid_checkin as ID_CUSTOMER_CHECKIN
                      ,count(*) as num_evento
                  from gold_{env}.{schema_gold}.ft_evento as ev
                 where ev.id_contactid_checkin is not null
                 group by ev.id_contactid_checkin
        ) as ev
"""
spark.sql(query_view)
print(view_name)
created_views.append(view_name)

# COMMAND ----------

# DBTITLE 1,View vw_cliente_evento_registro
drop_cmd = f"DROP VIEW IF EXISTS {catalog}.{schema_gold}.vw_cliente_evento_registro"
spark.sql(drop_cmd)

view_name    = f"{catalog}.{schema_gold}.vw_cliente_evento_registro"
query_view   = \
   f""" CREATE OR REPLACE VIEW {view_name} AS
        select ev.ID_CUSTOMER_REGISTRATION,
               ev.num_evento as NUM_EVENTOS_REGISTRATION,  
               case when ev.num_evento = 1 then '1_evento'
                    when ev.num_evento = 2 then '2_evento'
                    when ev.num_evento = 3 then '3_evento'
                    else 'mais_3_evento' end as QTD_EVENTOS_REGISTRATION
          from (select ev.id_contactid_registration as ID_CUSTOMER_REGISTRATION, count(*) as num_evento
                  from gold_{env}.{schema_gold}.ft_evento as ev
                 where ev.id_contactid_registration is not null
                 group by ev.id_contactid_registration
        ) as ev
    """
spark.sql(query_view)
print(view_name)
created_views.append(view_name)

# COMMAND ----------

# DBTITLE 1,View - vw_cliente_comprou_moto_datas_diferentes
drop_cmd = f"DROP VIEW IF EXISTS {catalog}.{schema_gold}.vw_cliente_comprou_moto_datas_diferentes"
spark.sql(drop_cmd)

view_name    = f"{catalog}.{schema_gold}.vw_cliente_comprou_moto_datas_diferentes"
query_view   = \
   f""" CREATE OR REPLACE VIEW {view_name} AS
        Select vt.ID_CONTACT, 
            case when vt.num_vendas = 1 then '1_moto'
                 when vt.num_vendas = 2 then '2_motos'
                 when vt.num_vendas = 3 then '3_motos'
                 when vt.num_vendas = 4 then '4_motos'
                 when vt.num_vendas = 5 then '5_motos'
                 else 'mais_6_motos' end as QTD_MOTOS
          from (Select cus.ID_CONTATO as ID_CONTACT, cal.ID_CALENDARIO, count(*) as num_vendas
                 from gold_{env}.{schema_gold}.ft_revisao as ft 
                inner join gold_{env}.corporativo.dm_calendario as cal on ft.ID_CALENDARIO = cal.ID_CALENDARIO
                inner join gold_{env}.{schema_gold}.ft_agg_cliente as cus on ft.ID_CONTACTID = cus.ID_CONTATO
         where cus.FL_YMDB_CPF_VALIDO = 'true'
           and ft.new_tiposervico = 'ENTREGA'
         group by cus.ID_CONTATO, cal.ID_CALENDARIO) as vt
     """
spark.sql(query_view)
print(view_name)
created_views.append(view_name)

# COMMAND ----------

# DBTITLE 1,Cliente_comprou_moto_datas_diferentes_valores
drop_cmd = f"DROP VIEW IF EXISTS {catalog}.{schema_gold}.vw_cliente_comprou_moto_datas_diferentes_valores"
spark.sql(drop_cmd)

view_name    = f"{catalog}.{schema_gold}.vw_cliente_comprou_moto_datas_diferentes_valores"
query_view   = \
   f""" CREATE OR REPLACE VIEW {view_name} AS
        Select vt.ID_CONTACTID, 
            case when vt.num_vendas = 1 then '1_moto'
                 when vt.num_vendas = 2 then '2_motos'
                 when vt.num_vendas = 3 then '3_motos'
                 when vt.num_vendas = 4 then '4_motos'
                 when vt.num_vendas = 5 then '5_motos'
                 else 'mais_6_motos' end as QTD_MOTOS,
            vt.VALOR
          from (Select cus.ID_CONTATO as ID_CONTACTID, cal.ID_CALENDARIO, sum(ft.ymdb_valormoto) as valor, count(*) as num_vendas
                  from gold_{env}.{schema_gold}.ft_revisao as ft 
                 inner join gold_{env}.corporativo.dm_calendario as cal on ft.ID_CALENDARIO = cal.ID_CALENDARIO
                 inner join gold_{env}.{schema_gold}.ft_agg_cliente as cus on ft.ID_CONTACTID = cus.ID_CONTATO
                 where cus.FL_YMDB_CPF_VALIDO = 'true'
                   and ft.new_tiposervico = 'ENTREGA'
                 group by cus.ID_CONTATO, cal.ID_CALENDARIO) as vt   
    """
spark.sql(query_view)
print(view_name)
created_views.append(view_name)

# COMMAND ----------

# DBTITLE 1,Quantidade total de CPF que não comprou nada
drop_cmd = f"DROP VIEW IF EXISTS {catalog}.{schema_gold}.vw_cliente_nao_comprou_moto_pecas"
spark.sql(drop_cmd)

view_name    = f"{catalog}.{schema_gold}.vw_cliente_nao_comprou_moto_pecas"
query_view   = \
    f"""CREATE OR REPLACE VIEW {view_name} AS
        Select ID_CONTATO as ID_CONTACTID 
          from gold_{env}.{schema_gold}.ft_agg_cliente as cus
         WHERE FL_YMDB_CPF_VALIDO = 'true' 
           and FL_COMPROU_MOTO_E_PECA is null          
    """
spark.sql(query_view)
print(view_name)
created_views.append(view_name)

# COMMAND ----------

# DBTITLE 1,Quantidade de 1°, 2°, 3°, 4° e 5° acima revisões realizadas
drop_cmd = f"DROP VIEW IF EXISTS {catalog}.{schema_gold}.vw_quantidade_revisoes_realizadas"
spark.sql(drop_cmd)

view_name    = f"{catalog}.{schema_gold}.vw_quantidade_revisoes_realizadas"
query_view   = \
    f"""CREATE OR REPLACE VIEW {view_name} AS
        Select qr.ID_CONTACTID, qr.NUM_REVISOES, 
            case when qr.NUM_REVISOES = 1 then '1_revisão'
                 when qr.NUM_REVISOES = 2 then '2_revisão'
                 when qr.NUM_REVISOES = 3 then '3_revisão'
                 when qr.NUM_REVISOES = 4 then '4_revisão'        
                 else 'acima_5_revisões' end as QTD_REVISOES
          from (Select rev.ID_CONTACTID, COUNT(ymdb_idrevisao) as NUM_REVISOES
                  from gold_{env}.{schema_gold}.ft_revisao as rev 
                 inner join gold_{env}.{schema_gold}.ft_agg_cliente as cus on rev.ID_CONTACTID = cus.ID_CONTATO
                WHERE rev.ymdb_revisao_numero <> -1	
                 group by rev.ID_CONTACTID) qr
         where qr.NUM_REVISOES > 0
    """
spark.sql(query_view)
print(view_name)
created_views.append(view_name)

# COMMAND ----------

# DBTITLE 1,Pedidos que não completaram a venda (cancelado/pendente) (por categoria MTC, peças e acessórios)
# Pedidos que não completaram a venda (cancelado/pendente) (por categoria MTC, peças e acessórios)

drop_cmd = f"DROP VIEW IF EXISTS {catalog}.{schema_gold}.vw_quantidade_pedidos_por_categoria_n_completaram"
spark.sql(drop_cmd)

view_name    = f"{catalog}.{schema_gold}.vw_quantidade_pedidos_por_categoria_n_completaram"
query_view   = \
    f"""CREATE OR REPLACE VIEW {view_name} AS
        with depara_produtos 
            (Select ymdb_codigo_do_produto as ID_PRODUTO,
                    ymdb_tipo_produto as TP_YMDB_TIPO_PRODUTO,
                    CASE WHEN TP_YMDB_TIPO_PRODUTO = 100000000 THEN 'MOTOCICLETA'
                         WHEN TP_YMDB_TIPO_PRODUTO = 100000001 THEN 'NAUTICA'
                         WHEN TP_YMDB_TIPO_PRODUTO = 100000002 THEN 'PECAS'
                         WHEN TP_YMDB_TIPO_PRODUTO = 100000003 THEN 'VESTUARIO'
                         WHEN TP_YMDB_TIPO_PRODUTO = 100000004 THEN 'ACESSORIOS'
                         WHEN TP_YMDB_TIPO_PRODUTO = 100000005 THEN 'OUTROS'
                         WHEN TP_YMDB_TIPO_PRODUTO = 100000006 THEN 'PECAS/VESTUARIO'
                    END AS NM_TIPO_PRODUTO
              from silver_{env}.{schema_silver}.salesorderdetail)
        Select cus.ID_CONTATO as ID_CONTACTID,
               sal.NM_STATUS_PEDIDO,
               prd.NM_TIPO_PRODUTO as NM_CATEGORIA,
               count(sal.ymdb_status_pedido) as QT_PEDIDO,
               sum (sal.ymdb_valor_item_base) as VL_PEDIDO
          from gold_{env}.{schema_gold}.ft_agg_cliente as cus
         inner join gold_{env}.{schema_gold}.ft_vendas as sal on cus.ID_CONTATO = sal.ID_CONTACTID
         inner join depara_produtos as prd on sal.id_produto = prd.ID_PRODUTO
         where cus.FL_YMDB_CPF_VALIDO == true
           and sal.ymdb_origem_pedido in (100000001,100000007)	  -- e-commerce
           and sal.ymdb_status_pedido in (100000008,100000009,100000010,100000000,100000001,100000007) 
           and prd.TP_YMDB_TIPO_PRODUTO in (100000004,100000000,100000002)
         group by cus.ID_CONTATO,
                  sal.nm_status_pedido,
                  prd.NM_TIPO_PRODUTO
    """
spark.sql(query_view)
print(view_name)
created_views.append(view_name)

# COMMAND ----------

# DBTITLE 1,Ticket médio * média de compras clientes * média de tempo de retenção
drop_cmd = f"DROP VIEW IF EXISTS {catalog}.{schema_gold}.vw_valor_vitalicio_cliente_ltv"
spark.sql(drop_cmd)

view_name    = f"{catalog}.{schema_gold}.vw_valor_vitalicio_cliente_ltv"
query_view   = \
    f"""CREATE OR REPLACE VIEW {view_name} AS
        Select  CUS.ID_CONTATO as ID_CONTACTID,
                MTC.FIRST_DATA_COMPRA_MOTO,
                MTC.VL_COMPROU_MOTOS as SOMA_VALOR_MOTOS,
                MTC.QT_COMPROU_MOTOS as QT_COMPRAS_MOTOS,
                ACE.LAST_DATA_COMPRA_ACESSORIO,
                ACE.VL_COMPROU_ACESSORIOS as SOMA_VALOR_ACESSORIOS,
                ACE.QT_COMPROU_ACESSORIOS as QT_COMPRAS_ACESSORIOS,
                PEC.LAST_DATA_COMPRA_PECA,
                PEC.VL_COMPROU_PECAS as SOMA_VALOR_PECAS,
                PEC.QT_COMPROU_PECAS as QT_COMPRAS_PECAS,
                ECO.LAST_DATA_COMPRA_ECOMMERCE,
                ECO.VL_COMPROU_ECOMMERCE as SOMA_VALOR_ECOMMERCE,
                ECO.QT_COMPROU_ECOMMERCE as QT_COMPRAS_ECOMMERCE,
                EPA.LAST_DATA_COMPRA_PECA_ACES_ECOMMERCE,
                EPA.VL_COMPROU_PECA_ACES_ECOMMERCE as SOMA_VALOR_PECA_ACES_ECOMMERCE,
                EPA.QT_COMPROU_PECA_ACES_ECOMMERCE as QT_COMPRAS_PECA_ACES_ECOMMERCE,
                EMO.LAST_DATA_COMPRA_MOTO_ECOMMERCE,
                EMO.VL_COMPROU_MOTO_ECOMMERCE as SOMA_VALOR_MOTO_ECOMMERCE,
                EMO.QT_COMPROU_MOTO_ECOMMERCE as QT_COMPRAS_MOTO_ECOMMERCE,
                (NVL(MTC.VL_COMPROU_MOTOS,0)+NVL(ACE.VL_COMPROU_ACESSORIOS,0)+NVL(PEC.VL_COMPROU_PECAS,0)+NVL(ECO.VL_COMPROU_ECOMMERCE,0)+NVL(EPA.VL_COMPROU_PECA_ACES_ECOMMERCE,0)+NVL(EMO.VL_COMPROU_MOTO_ECOMMERCE,0)) as SOMA_VALOR_TOTAL,
                (NVL(MTC.QT_COMPROU_MOTOS,0)+NVL(ACE.QT_COMPROU_ACESSORIOS,0)+NVL(PEC.QT_COMPROU_PECAS,0)+NVL(ECO.QT_COMPROU_ECOMMERCE,0)+NVL(EPA.QT_COMPROU_PECA_ACES_ECOMMERCE,0)+NVL(EMO.QT_COMPROU_MOTO_ECOMMERCE,0)) as QT_COMPRAS_TOTAL,
                DATEDIFF(day,MTC.FIRST_DATA_COMPRA_MOTO, GREATEST((ACE.LAST_DATA_COMPRA_ACESSORIO), (PEC.LAST_DATA_COMPRA_PECA), (ECO.LAST_DATA_COMPRA_ECOMMERCE), (EPA.LAST_DATA_COMPRA_PECA_ACES_ECOMMERCE), (EMO.LAST_DATA_COMPRA_MOTO_ECOMMERCE)))/30/12 as tempo_atividade
          from gold_{env}.{schema_gold}.ft_agg_cliente as cus

          -- Revisões
          left join (Select B._ymdb_cliente_id_value as ID_CONTACTID, 
                            min(B.ymdb_datavenda) as FIRST_DATA_COMPRA_MOTO,
                            max(B.ymdb_datavenda) as LAST_DATA_COMPRA_MOTO, 
                            count(B.new_tiposervico) as QT_COMPROU_MOTOS, 
                            sum(B.ymdb_valormoto) as VL_COMPROU_MOTOS
                        from silver_{env}.{schema_silver}.ymdb_revisoes as B
                        where B.new_tiposervico = 'ENTREGA'
                        group by B._ymdb_cliente_id_value) as MTC 
                on CUS.ID_CONTATO = MTC.ID_CONTACTID
          
          -- Salesorder e Salesorderdetail
          left join (Select B._ymdb_cliente_value as ID_CONTACTID,
                            min(A.ymdb_data_pedido) as FIRST_DATA_COMPRA_ACESSORIO,
                            max(A.ymdb_data_pedido) as LAST_DATA_COMPRA_ACESSORIO,
                            count(B.ymdb_tipo_produto) as QT_COMPROU_ACESSORIOS,
                            sum(B.new_valortotaldopedido) as VL_COMPROU_ACESSORIOS
                        from silver_{env}.{schema_silver}.salesorder as A
                       inner join silver_{env}.{schema_silver}.salesorderdetail as B
                          on A.salesorderid = B._salesorderid_value
                       where B.ymdb_tipo_produto = 100000004
                       group by B._ymdb_cliente_value) as ACE 
                on CUS.ID_CONTATO = ACE.ID_CONTACTID

          -- Discover
          left join (Select B._cr638_cliente_value as ID_CONTACTID,
                            min(B.new_datadanotafiscal) as FIRST_DATA_COMPRA_PECA,
                            max(B.new_datadanotafiscal) as LAST_DATA_COMPRA_PECA,
                            count(B.cr638_tipoproduto) as QT_COMPROU_PECAS, 
                            sum(B.cr638_valordanotafiscal) as VL_COMPROU_PECAS
                        from silver_{env}.{schema_silver}.cr638_discover as B
                        where B.cr638_tipoproduto = 'PECA'
                        group by B._cr638_cliente_value) as PEC 
                on CUS.ID_CONTATO = PEC.ID_CONTACTID

          -- Salesorder
          left join (Select B._customerid_value as ID_CONTACTID ,
                            min(B.ymdb_data_pedido) as FIRST_DATA_COMPRA_ECOMMERCE, 
                            max(B.ymdb_data_pedido) as LAST_DATA_COMPRA_ECOMMERCE, 
                            count(B.ymdb_origem_pedido) as QT_COMPROU_ECOMMERCE, 
                            sum(B.ymdb_valor_total_pedido) as VL_COMPROU_ECOMMERCE
                       from silver_{env}.{schema_silver}.salesorder as B
                      where B.ymdb_origem_pedido in (100000001, 100000007)
                      group by B._customerid_value) as ECO 
                on CUS.ID_CONTATO = ECO.ID_CONTACTID

          -- Salesorder e cr638_discover  
          left join (Select B._customerid_value as ID_CONTACTID ,
                            min(C.new_datadanotafiscal) as FIRST_DATA_COMPRA_PECA_ACES_ECOMMERCE, 
                            max(C.new_datadanotafiscal) as LAST_DATA_COMPRA_PECA_ACES_ECOMMERCE, 
                            count(C.cr638_tipoproduto) as QT_COMPROU_PECA_ACES_ECOMMERCE, 
                            sum(C.cr638_valordanotafiscal) as VL_COMPROU_PECA_ACES_ECOMMERCE
                       from silver_{env}.{schema_silver}.salesorder as B
                       inner join silver_{env}.{schema_silver}.cr638_discover as C

                               on B._customerid_value = C._cr638_cliente_value
                      where B.ymdb_origem_pedido in (100000001, 100000007)
                        and C.cr638_tipoproduto = 'PECA'
                      group by B._customerid_value) as EPA 
                on CUS.ID_CONTATO = EPA.ID_CONTACTID

          -- Salesorder e ymdb_revisoes
          left join (Select B._customerid_value as ID_CONTACTID ,
                            min(C.ymdb_datavenda) as FIRST_DATA_COMPRA_MOTO_ECOMMERCE, 
                            max(C.ymdb_datavenda) as LAST_DATA_COMPRA_MOTO_ECOMMERCE, 
                            count(C.new_tiposervico) as QT_COMPROU_MOTO_ECOMMERCE, 
                            sum(C.ymdb_valormoto) as VL_COMPROU_MOTO_ECOMMERCE
                       from silver_{env}.{schema_silver}.salesorder as B
                       inner join silver_{env}.{schema_silver}.ymdb_revisoes as C
                          on B._customerid_value = C._ymdb_cliente_id_value
                       where B.ymdb_origem_pedido in (100000001, 100000007)
                         and C.new_tiposervico = 'ENTREGA'
                       group by B._customerid_value) as EMO 
                on CUS.ID_CONTATO = EMO.ID_CONTACTID
         where cus.FL_YMDB_CPF_VALIDO = true
    """
spark.sql(query_view)
print(view_name)
created_views.append(view_name)

# COMMAND ----------

# DBTITLE 1,Mensurar a quantidade de impactos por cliente (média mensal)
drop_cmd = f"DROP VIEW IF EXISTS {catalog}.{schema_gold}.vw_quantidade_impacto_mensal"
spark.sql(drop_cmd)

view_name    = f"{catalog}.{schema_gold}.vw_quantidade_impacto_mensal"
query_view   = \
    f"""CREATE OR REPLACE VIEW {view_name} AS
        Select cus.ID_CONTATO as ID_CONTACTID
              ,cus.ID_CALENDARIO_CLIENTE_IMPACTADO
              ,cal.ID_CALENDARIO
              ,cal.NR_ANO as DT_ANO
              ,cal.NM_MES as DT_MES
              ,cal. NR_DIA_MES as DT_DIADOMES
              ,count(*) as QT_IMPACTO_MENSAL
          from gold_{env}.{schema_gold}.ft_agg_cliente as cus
         left join gold_{env}.corporativo.dm_calendario  as cal
            on cus.ID_CALENDARIO_CLIENTE_IMPACTADO = cal.ID_CALENDARIO
         where cus.ID_CALENDARIO_CLIENTE_IMPACTADO is not null
         group by cus.ID_CONTATO, cus.ID_CALENDARIO_CLIENTE_IMPACTADO, cal.ID_CALENDARIO, cal.NR_ANO, cal.NM_MES, cal.NR_DIA_MES
     """

spark.sql(query_view)
print(view_name)
created_views.append(view_name)

# COMMAND ----------

# DBTITLE 1,Listagem de clientes de peças que realizaram recompras em um período específico
# Listagem de clientes de peças que realizaram recompras em um período específico
drop_cmd = f"DROP VIEW IF EXISTS {catalog}.{schema_gold}.vw_comercial_planejamento_comercial_recompra_pecas"
spark.sql(drop_cmd)

view_name    = f"{catalog}.{schema_gold}.vw_comercial_planejamento_comercial_recompra_pecas"
query_view   = \
    f"""CREATE OR REPLACE VIEW {view_name} AS
            WITH BASE_XML AS (SELECT DISTINCT DC_DEST_CNPJ
                                    ,NR_NOTA_FISCAL
                                    ,CAST(DT_DATA_NF AS DATE) AS DT_DATA_NF
                                    ,CD_PRODUTO
                                    ,DS_DESCRICAO
                                    ,SUM(QT_QUANTIDADE) AS QT_QUANTIDADE
                                    ,SUM(VL_UNITARIO) AS VL_UNITARIO
                                FROM gold_{env}.pecas_sell_out.ym_sg_2008
                            WHERE CAST(DT_DATA_NF AS DATE) >= '2016-01-01' 
                            GROUP BY 1,2,3,4,5)
                ,NOTAS_XML AS (SELECT DISTINCT DT_DATA_NF
                                    ,DC_DEST_CNPJ
                                    ,DENSE_RANK() OVER (PARTITION BY DC_DEST_CNPJ ORDER BY DT_DATA_NF ASC) AS ROW_NUM
                                FROM BASE_XML)
            SELECT DISTINCT A.*
                ,B.DT_DATA_NF AS DT_FIRST_SALE
                ,C.DT_DATA_NF AS DT_NEXT_SALE
                ,D.NR_NOTA_FISCAL AS NR_NOTA_FISCAL
                ,D.CD_PRODUTO AS CD_PRODUTO
                ,D.QT_QUANTIDADE AS QT_QUANTIDADE
                ,D.VL_UNITARIO AS VL_UNITARIO
                ,DATE_DIFF(DAY,A.DT_DATA_NF,C.DT_DATA_NF) AS NR_DAYS_REPURCHASE
            FROM NOTAS_XML A
            -- Join para a primeira venda
            LEFT JOIN (SELECT DC_DEST_CNPJ, DT_DATA_NF FROM NOTAS_XML WHERE ROW_NUM = 1) B 
                ON A.DC_DEST_CNPJ = B.DC_DEST_CNPJ
            -- Join para a próxima venda
            LEFT JOIN (SELECT DISTINCT DC_DEST_CNPJ, DT_DATA_NF, ROW_NUM FROM NOTAS_XML) C
                ON A.DC_DEST_CNPJ = C.DC_DEST_CNPJ
            AND A.ROW_NUM = C.ROW_NUM - 1
            -- Join informações da nota
            LEFT JOIN (SELECT DISTINCT  DT_DATA_NF, DC_DEST_CNPJ, NR_NOTA_FISCAL, CD_PRODUTO, QT_QUANTIDADE, VL_UNITARIO FROM BASE_XML) D
                ON A.DC_DEST_CNPJ = D.DC_DEST_CNPJ
            AND A.DT_DATA_NF = D.DT_DATA_NF
     """
spark.sql(query_view)
print(view_name)
created_views.append(view_name)

# COMMAND ----------

# DBTITLE 1,Aprofundar a visão comercial das lojas, garantindo que as metas determinadas para as concessionárias sejam adequadas ao perfil de vendas de cada loja.
# Aprofundar a visão comercial das lojas, garantindo que as metas determinadas para as concessionárias sejam adequadas ao perfil de vendas de cada loja.

drop_cmd = f"DROP VIEW IF EXISTS {catalog}.{schema_gold}.vw_dg_pecas_dealers_potalweb"
spark.sql(drop_cmd)

view_name    = f"{catalog}.{schema_gold}.vw_dg_pecas_dealers_potalweb"
query_view   = \
    f"""CREATE VIEW {view_name} AS 
        SELECT
            c.ID_CAMPANHA,
            c.ID_TIPO_CAMPANHA,
            c.DT_ENTRADA,
            c.ID_PRODUTO,
            pc.NM_MODELO, -- CAMPO DESCRIÇAO -> NM_modelo
            cli.NM_CLIENTE,
            e.NU_CNPJ as NR_CNPJ,
            c.ID_EMPRESA,
            e.NM_COMERCIAL,
            e.SG_UF,
            c.ID_LAUDO,
            c.ID_WORKFLOW,
            c.ID_CLIENTE_RESPONSAVEL,
            c.ID_EMPRESA_EXECUTANTE,
            c.ID_TEMPO_TIPO_CAMP,
            c.ID_PAGAMENTO,
            c.ID_LOTE_PAGAMENTO,
            c.ID_CAMPANHA_MARKETING,
            t.DS_TITULO_INTERNO,
            t.DS_RISCO,
            SUM(c.VL_TOTAL_PECAS) as VL_TOTAL_PECAS,
            SUM(c.VL_TOTAL) as VL_TOTAL,
            SUM(c.VL_TOTAL_TERCEIROS) as VL_TOTAL_TERCEIROS,
            SUM(c.VL_TOTAL_MAODEOBRA) as VL_MAODEOBRA
          from silver_{env}.autoware.portalweb_campanha c
         inner join silver_{env}.autoware.portalweb_produto pc ON c.ID_PRODUTO = pc.ID_PRODUTO
         inner join silver_{env}.autoware.portalweb_tipocampanha  t ON c.ID_TIPO_CAMPANHA = t.ID_TIPO_CAMPANHA
         inner join silver_{env}.autoware.portalweb_empresa e ON c.ID_EMPRESA = e.ID_EMPRESA
         inner join silver_{env}.autoware.portalweb_cliente cli ON c.ID_CLIENTE = cli.ID_CLIENTE
         WHERE c.DT_ENTRADA >= DATE_ADD(current_date(), -3 * 365)
         GROUP BY c.ID_CAMPANHA,
            c.ID_TIPO_CAMPANHA,
            c.DT_ENTRADA,
            c.ID_PRODUTO,
            pc.NM_MODELO, -- CAMPO DESCRIÇAO -> NM_modelo
            cli.NM_CLIENTE,
            e.NU_CNPJ,
            c.ID_EMPRESA,
            e.NM_COMERCIAL,
            e.SG_UF,
            c.ID_LAUDO,
            c.ID_WORKFLOW,
            c.ID_CLIENTE_RESPONSAVEL,
            c.ID_EMPRESA_EXECUTANTE,
            c.ID_TEMPO_TIPO_CAMP,
            c.ID_PAGAMENTO,
            c.ID_LOTE_PAGAMENTO,
            c.ID_CAMPANHA_MARKETING,
            t.DS_TITULO_INTERNO,
            t.DS_RISCO
    """
spark.sql(query_view)
print(view_name)
created_views.append(view_name)

# COMMAND ----------

# DBTITLE 1,Pós-Venda é a etapa do ciclo de vendas focada no atendimento e suporte ao cliente após a compra de um produto. Baseado no Portalweb, em campanhas.
# Pós-Venda é a etapa do ciclo de vendas focada no atendimento e suporte ao cliente após a compra de um produto. Baseado no Portalweb, em campanhas.

drop_cmd = f"DROP VIEW IF EXISTS {catalog}.{schema_gold}.vw_dg_after_sales"
spark.sql(drop_cmd)

view_name    = f"{catalog}.{schema_gold}.vw_dg_after_sales"
query_view   = \
    f"""CREATE VIEW {view_name} AS
            SELECT p.DC_DEST_CNPJ,
                p.DS_EMITENTE,
                p.NR_NOTA_FISCAL,
                p.NM_DEST_NOME,
                p.DS_DEST_CEP,
                p.DS_DEST_CIDADE,
                p.DS_DEST_ESTADO,
                p.NR_SERIE,
                p.DT_DATA_NF,
                p.CD_PRODUTO,
                p.DS_DESCRICAO,
                p.CD_CFOP_CODE,
                p.DS_DESCRICAO_CFOP,
                SUM(p.QT_QUANTIDADE) AS QT_QUANTIDADE,
                SUM(p.VL_UNITARIO) AS VL_UNITARIO,
                SUM(p.VL_ICMS) AS VL_ICMS,
                SUM(p.VL_PIS) AS VL_PIS,
                SUM(p.VL_COFINS) AS VL_COFINS,
                SUM(p.VL_IPI) AS VL_IPI,
                SUM(p.VL_PRODUTO) AS VL_PRODUTO
            from gold_{env}.pecas_sell_out.ym_sg_2008 p
            WHERE p.DT_DATA_NF >= DATE_ADD(current_date(), -2 * 365)
            GROUP BY
                p.DC_DEST_CNPJ,
                p.DS_EMITENTE,
                p.NR_NOTA_FISCAL,
                p.NM_DEST_NOME,
                p.DS_DEST_CEP,
                p.DS_DEST_CIDADE,
                p.DS_DEST_ESTADO,
                p.NR_SERIE,
                p.DT_DATA_NF,
                p.CD_PRODUTO,
                p.DS_DESCRICAO,
                p.CD_CFOP_CODE,
                p.DS_DESCRICAO_CFOP
    """
spark.sql(query_view)
print(view_name)
created_views.append(view_name)

# COMMAND ----------

print(f"{len(created_views)} views criadas:\n")

for v in created_views:
    print(v)
