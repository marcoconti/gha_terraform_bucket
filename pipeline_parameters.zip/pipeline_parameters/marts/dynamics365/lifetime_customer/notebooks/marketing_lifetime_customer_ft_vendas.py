# Databricks notebook source
# MAGIC %md ### Import bibliotecas

# COMMAND ----------

import os
import pyspark.sql.functions as F
from pyspark.sql.types import StringType
from delta.tables import *
from cryptography.fernet import Fernet

# COMMAND ----------

spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", "false")

# COMMAND ----------

# MAGIC %md ### Optimization Method

# COMMAND ----------

def optimize_delta_table(table_name):
    """
        @param: IN table_path
        Run optimization commands and old snapshots
        Full load
    """
    deltaTable = DeltaTable.forName(spark, table_name)
    deltaTable.vacuum(24)
    deltaTable.optimize().executeCompaction()
    print('Delta table optimized.') 

def get_env():
    return os.environ.get("DATABRICKS_ENV")

# COMMAND ----------

# MAGIC %md ### Variáveis

# COMMAND ----------

env     = get_env().lower()
catalog = f"gold_{env}"
schema  = "comercial_planejamento_comercial"
table   = "ft_vendas"


# COMMAND ----------

# MAGIC %md ### Leitura tabelas

# COMMAND ----------

# DBTITLE 1,Tab. salesorder - Leiura, rename cols e criação de nova cols
drop_cols = ["_odata_etag", "_hash", "_ingestionin"]
df_sales = \
    (spark.sql(f"""Select * 
                     from silver_{env}.dynamics_365_sales_lifetime_customer.salesorder""")
          .drop(*drop_cols))
    
rename_cols = {
    "pricingerrorcode": "cd_pricingerrorcode_sales"
    ,"_createdonbehalfby_value": "cd_createdonbehalfby_value_sales"
    ,"shipto_freighttermscode": "cd_shipto_freighttermscode_sales"
    ,"shipto_country": "ds_shipto_country_sales"
    ,"shipto_addressid": "id_shipto_addressid_sales"
    ,"ymdb_tipo_entrega": "tp_ymdb_tipo_entrega_sales"
    ,"skippricecalculation": "vl_skippricecalculation_sales"
    ,"_modifiedonbehalfby_value": "cd_modifiedonbehalfby_value_sales"
    ,"requestdeliveryby": "dt_requestdeliveryby_sales"
    ,"shipto_name": "nm_shipto_name_sales"
    ,"exchangerate": "nr_exchangerate_sales"
    ,"description": "ds_description_sales"
    ,"overriddencreatedon": "dt_overriddencreatedon_sales"
    ,"shipto_city": "ds_shipto_city_sales"
    ,"ymdb_nome_modelo": "nm_ymdb_nome_modelo_sales"
    ,"versionnumber": "nr_versionnumber_sales"
    ,"_createdby_value": "cd_createdby_value_sales"
    ,"shipto_line3": "ds_shipto_line3_sales"
    ,"_modifiedby_value": "cd_modifiedby_value_sales"
    ,"shipto_fax": "ds_shipto_fax_sales"
    ,"_owningteam_value": "cd_owningteam_value_sales"
    ,"willcall": "ds_willcall_sales"
    ,"ymdb_id_pedido_commerce": "id_ymdb_pedido_commerce_sales"
    ,"shipto_contactname": "nm_shipto_contactname_sales"
    ,"shipto_line2": "ds_shipto_line2_sales"
    ,"shipto_stateorprovince": "ds_shipto_stateorprovince_sales"
    ,"utcconversiontimezonecode": "cd_utcconversiontimezonecode_sales"
    ,"_ownerid_value": "id_ownerid_value_sales"
    ,"ymdb_cod_modelo": "cd_ymdb_cod_modelo_sales"
    ,"_transactioncurrencyid_value": "id_transactioncurrencyid_value_sales"
    ,"_owningbusinessunit_value": "cd_owningbusinessunit_value_sales"
    ,"timezoneruleversionnumber": "nr_timezoneruleversionnumber_sales"
    ,"shipto_line1": "ds_shipto_line1_sales"
    ,"modifiedon": "dt_modifiedon_sales"
    ,"_owninguser_value": "cd_owninguser_value_sales"
    ,"importsequencenumber": "nr_importsequencenumber_sales"
    ,"createdon": "dt_createdon_sales"
    ,"ordercreationmethod": "nr_ordercreationmethod_sales"
    ,"shipto_telephone": "ds_shipto_telephone_sales"
}

# Renomear colunas
select_exprs = []
select_exprs = [f"{c} as {rename_cols.get(c, c)}" for c in df_sales.columns ]
df_sales = df_sales.selectExpr(*select_exprs)

# Criar colunas
df_sales = \
    (df_sales.withColumns({'id_calendario': (F.date_format('ymdb_data_pedido', 'yyyyMMdd')).cast('int')
                          ,'id_contactid' : F.col('_customerid_value')}))


# COMMAND ----------

# DBTITLE 1,Sales - Criação do campo nm_status_peido
STATUS_PEDIDO_MAP = {
    '100000000': 'PENDENTE',
    '100000001': 'PENDENTE',
    '100000002': 'APROVADO',
    '100000003': 'APROVADO',
    '100000004': 'APROVADO',
    '100000005': 'APROVADO',
    '100000006': 'APROVADO',
    '100000007': 'CANCELADO',
    '100000008': 'CANCELADO',
    '100000009': 'PENDENTE',
    '100000010': 'PENDENTE'
}

# Transforma os tipos de resolução em um map para usar no withColumn a seguir
mapping_expr = F.create_map([F.lit(x) for kv in STATUS_PEDIDO_MAP.items() for x in kv])

df_sales = \
    (df_sales.withColumn("nm_status_pedido"
                        ,F.coalesce(mapping_expr[F.col("ymdb_status_pedido")]
                                   ,F.lit("NÃO MAPEADO"))))

# COMMAND ----------

# DBTITLE 1,salesorderdetail - Leitura, rename cols, format. e drop cols
 
drop_cols = ["_odata_etag", "_hash", "_ingestionin", "_year", "_month"]
df_salesdetail = \
    (spark.sql(f"""Select * 
                     from silver_{env}.dynamics_365_sales_lifetime_customer.salesorderdetail""")
          .drop(*drop_cols))
    
rename_cols = {
    "shipto_postalcode": "id_cidade"
    ,"ymdb_codigo_do_produto": "id_produto"
    ,"pricingerrorcode": "cd_pricingerrorcode_salesdetail"
    ,"_createdonbehalfby_value": "cd_createdonbehalfby_value_salesdetail"
    ,"shipto_freighttermscode": "cd_shipto_freighttermscode_salesdetail"
    ,"shipto_country": "ds_shipto_country_salesdetail"
    ,"shipto_addressid": "id_shipto_addressid_salesdetail"
    ,"ymdb_tipo_entrega": "tp_ymdb_tipo_entrega_salesdetail"
    ,"skippricecalculation": "vl_skippricecalculation_salesdetail"
    ,"_modifiedonbehalfby_value": "cd_modifiedonbehalfby_value_salesdetail"
    ,"requestdeliveryby": "dt_requestdeliveryby_salesdetail"
    ,"shipto_name": "nm_shipto_name_salesdetail"
    ,"exchangerate": "nr_exchangerate_salesdetail"
    ,"description": "ds_description_salesdetail"
    ,"overriddencreatedon": "dt_overriddencreatedon_salesdetail"
    ,"shipto_city": "ds_shipto_city_salesdetail"
    ,"ymdb_nome_modelo": "nm_ymdb_nome_modelo_salesdetail"
    ,"versionnumber": "nr_versionnumber_salesdetail"
    ,"_createdby_value": "cd_createdby_value_salesdetail"
    ,"shipto_line3": "ds_shipto_line3_salesdetail"
    ,"_modifiedby_value": "cd_modifiedby_value_salesdetail"
    ,"shipto_fax": "ds_shipto_fax_salesdetail"
    ,"_owningteam_value": "cd_owningteam_value_salesdetail"
    ,"willcall": "ds_willcall_salesdetail"
    ,"ymdb_id_pedido_commerce": "id_ymdb_pedido_commerce_salesdetail"
    ,"shipto_contactname": "nm_shipto_contactname_salesdetail"
    ,"shipto_line2": "ds_shipto_line2_salesdetail"
    ,"shipto_stateorprovince": "ds_shipto_stateorprovince_salesdetail"
    ,"utcconversiontimezonecode": "cd_utcconversiontimezonecode_salesdetail"
    ,"_ownerid_value": "id_ownerid_value_salesdetail"
    ,"ymdb_cod_modelo": "cd_ymdb_cod_modelo_salesdetail"
    ,"_transactioncurrencyid_value": "id_transactioncurrencyid_value_salesdetail"
    ,"_owningbusinessunit_value": "cd_owningbusinessunit_value_salesdetail"
    ,"timezoneruleversionnumber": "nr_timezoneruleversionnumber_salesdetail"
    ,"shipto_line1": "ds_shipto_line1_salesdetail"
    ,"modifiedon": "dt_modifiedon_salesdetail"
    ,"_owninguser_value": "cd_owninguser_value_salesdetail"
    ,"importsequencenumber": "nr_importsequencenumber_salesdetail"
    ,"createdon": "dt_createdon_salesdetail"
    ,"ordercreationmethod": "nr_ordercreationmethod_salesdetail"
    ,"ymdb_outrosmotivosdecancelamento": "ds_ymdb_outrosmotivosdecancelamento_salesdetail"
    ,"shipto_telephone": "shipto_telephone_salesdetail"
}

# Renomear colunas
select_exprs = []
select_exprs = [f"{c} as {rename_cols.get(c, c)}" for c in df_salesdetail.columns ]
df_salesdetail = df_salesdetail.selectExpr(*select_exprs)

# Formatar coluna id_cidade
df_salesdetail = \
    (df_salesdetail.withColumn('id_cidade', F.regexp_replace('id_cidade', '-', ''))
                   .withColumn('id_cidade', F.lpad(F.col('id_cidade'), 8, '0')))

# remover colunas
drop_cols = ["productdescription", "producttypecode", "ymdb_tipodepedido"
            ,"ymdb_cnpjconcessionaria", "ymdb_datadefaturamento" ]

df_salesdetail  = df_salesdetail.drop(*drop_cols)

# COMMAND ----------

# DBTITLE 1,Junta os 2 dataframes
df_ft_sales = (
    df_sales.alias('s')
            .join(df_salesdetail.alias('sd')
                 ,(F.col('s.salesorderid') == F.col('sd._salesorderid_value'))
                 ,'inner')
            .drop('sd._salesorderid_value')
            .dropDuplicates()
)

# COMMAND ----------

# MAGIC %md ### Writing silver -> gold

# COMMAND ----------

col_sales       = df_sales.columns
col_salesdetail = df_salesdetail.columns

common = set(col_sales) & set(col_salesdetail)
print(common)
# others = col_sales - common

# ymdb_cnpjconcessionaria', 'ymdb_datadefaturamento', 'shipto_telephone'}


# COMMAND ----------

print(f"Persiste os dados do DF na tabela {catalog}.{schema}.{table}", end="")
(
    df_ft_sales
        .write
        .partitionBy("_year","_month")
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(f"{catalog}.{schema}.{table}")
)
print(" - Concluido com sucesso")

# COMMAND ----------

# optimization Gold layer
optimize_delta_table(f'{catalog}.{schema}.{table}')