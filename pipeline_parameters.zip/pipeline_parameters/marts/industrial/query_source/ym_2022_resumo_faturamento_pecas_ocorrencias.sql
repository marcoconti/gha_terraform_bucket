/*
YM_2022 - relatorio resumo_faturamento_pecas (aba 10 - ocorrencias)
*/

 with QP_LIST_HEADERS_ALL 
 ( 
  /*
    Implementacao da view QP_LIST_HEADERS_ALL 
  */
 SELECT B.LIST_HEADER_ID,
         T.NAME
 FROM SILVER_<env>.EBS_APPS.QP_LIST_HEADERS_TL T
 INNER JOIN SILVER_<env>.EBS_APPS.QP_LIST_HEADERS B
   ON B.LIST_HEADER_ID = T.LIST_HEADER_ID
 WHERE T.LANGUAGE = 'PTB'
 ),

 TABELA_PRECO
 (
  SELECT  OL.LINE_ID,
          QH.NAME 
  FROM        QP_LIST_HEADERS_ALL                     QH 
  INNER JOIN  SILVER_<env>.EBS_APPS.OE_ORDER_LINES_ALL  OL
          ON  OL.PRICE_LIST_ID = QH.LIST_HEADER_ID
 ),

 TABELA_IPI
 (
  SELECT 
      RCTA.CUSTOMER_TRX_ID                ID_NF
    , NVL(RCTLA.TAX_RATE,0)               ALIQ_IPI
    , NVL(RCTLA.EXTENDED_AMOUNT,0)        VAL_IPI
    , RCTLA.LINK_TO_CUST_TRX_LINE_ID      IMPOSTO
  FROM       SILVER_<env>.EBS_APPS.RA_CUSTOMER_TRX_ALL          RCTA
  INNER JOIN SILVER_<env>.EBS_APPS.RA_CUSTOMER_TRX_LINES_ALL    RCTLA 
          ON RCTA.CUSTOMER_TRX_ID = RCTLA.CUSTOMER_TRX_ID
  INNER JOIN SILVER_<env>.EBS_APPS.AR_VAT_TAX_ALL               AVTA 
          ON RCTLA.VAT_TAX_ID = AVTA.VAT_TAX_ID
  WHERE
        RCTA.COMPLETE_FLAG = 'Y'
  AND   RCTA.STATUS_TRX    =  'OP'
  AND   SUBSTR(AVTA.TAX_CODE,1,3) = 'IPI'
  AND   RCTLA.TAX_RATE > 0 
 ),

 TABELA_ICMS
 (
  SELECT 
      RCTA.CUSTOMER_TRX_ID                ID_NF
    , NVL(RCTLA.TAX_RATE,0)               ALIQ_ICMS_ST
    , NVL(RCTLA.EXTENDED_AMOUNT,0)        VAL_ICMS_ST
    , RCTLA.LINK_TO_CUST_TRX_LINE_ID      IMPOSTO
  FROM       SILVER_<env>.EBS_APPS.RA_CUSTOMER_TRX_ALL          RCTA
  INNER JOIN SILVER_<env>.EBS_APPS.RA_CUSTOMER_TRX_LINES_ALL    RCTLA 
          ON RCTA.CUSTOMER_TRX_ID = RCTLA.CUSTOMER_TRX_ID
  INNER JOIN SILVER_<env>.EBS_APPS.AR_VAT_TAX_ALL               AVTA 
          ON RCTLA.VAT_TAX_ID = AVTA.VAT_TAX_ID
  WHERE
        RCTA.COMPLETE_FLAG = 'Y'
  AND   RCTA.STATUS_TRX    =  'OP'
  AND   (SUBSTR(AVTA.TAX_CODE,1,7) = 'ICMS_ST' and SUBSTR(AVTA.TAX_CODE,1,11) != 'ICMS_ST_FCP')
  AND   RCTLA.TAX_RATE > 0 
 ),

 YM_2022_NF
 (
  SELECT 
       RCTA.ORG_ID
      ,OOD.ORGANIZATION_CODE
      ,RCTLA.WAREHOUSE_ID
      ,RCTA.TRX_DATE
      ,RCTA.TRX_NUMBER                                                                                                        NF
      ,RCTA.BILL_TO_CUSTOMER_ID
      ,RCTA.BILL_TO_SITE_USE_ID
      ,RCTLA.INVENTORY_ITEM_ID
      ,RCTTA.DESCRIPTION
      ,RCTLA.DESCRIPTION                                                                                                      DS_PRODUTO
      ,TABELA_PRECO.NAME                                                                                                      TABELA_PRECO
      ,RTT.NAME                                                                                                               COND_PAGTO
      ,RCTLA.SALES_ORDER                                                                                                      PEDIDO
      ,SUM(NVL(RCTLA.QUANTITY_INVOICED,0))                                                                                    QTD_GERAL
      ,SUM(ABS( NVL(RCTLA.EXTENDED_AMOUNT,0) * DECODE(RCTA.INVOICE_CURRENCY_CODE,'BRL',1,NVL(RCTA.EXCHANGE_RATE,1))))         VL_GERAL
      ,SUM(ABS( NVL(RCTLA.EXTENDED_AMOUNT,0) ))                                                                               VL_GERAL_DOLAR                
      ,SUM(NVL(TABELA_IPI.VAL_IPI,0) *DECODE(RCTA.INVOICE_CURRENCY_CODE,'BRL',1,NVL(RCTA.EXCHANGE_RATE,1)))                   VL_IPI
      ,SUM(NVL(TABELA_ICMS.VAL_ICMS_ST,0) * DECODE(RCTA.INVOICE_CURRENCY_CODE,'BRL',1,NVL(RCTA.EXCHANGE_RATE,1)))             VL_ICMS_ST                  
      ,SUM(NVL(TABELA_IPI.VAL_IPI,0))                                                                                         VL_IPI_DOLAR
  FROM       SILVER_<env>.EBS_APPS.RA_CUSTOMER_TRX_ALL          RCTA
  INNER JOIN SILVER_<env>.EBS_APPS.RA_CUSTOMER_TRX_LINES_ALL    RCTLA 
          ON RCTA.CUSTOMER_TRX_ID = RCTLA.CUSTOMER_TRX_ID
  INNER JOIN SILVER_<env>.EBS_APPS.RA_CUST_TRX_TYPES_ALL        RCTTA
          ON RCTA.CUST_TRX_TYPE_ID = RCTTA.CUST_TRX_TYPE_ID
  INNER JOIN SILVER_<env>.EBS_APPS.RA_TERMS_TL                  RTT
          ON RCTA.TERM_ID = RTT.TERM_ID
  INNER JOIN SILVER_<env>.EBS_APPS.ORG_ORGANIZATION_DEFINITIONS OOD
          ON RCTA.ORG_ID = OOD.OPERATING_UNIT
        AND RCTLA.WAREHOUSE_ID = OOD.ORGANIZATION_ID
  LEFT JOIN  TABELA_PRECO
        ON  TABELA_PRECO.LINE_ID = RCTLA.INTERFACE_LINE_ATTRIBUTE6
  LEFT JOIN  TABELA_IPI
        ON  TABELA_IPI.IMPOSTO = RCTLA.CUSTOMER_TRX_LINE_ID   
  LEFT JOIN  TABELA_ICMS
        ON  TABELA_ICMS.IMPOSTO = RCTLA.CUSTOMER_TRX_LINE_ID
  WHERE RCTA.STATUS_TRX              =  'OP'
  AND   RCTLA.LINE_TYPE              = 'LINE'
  AND   RTT.LANGUAGE                 = 'PTB'
  AND   RCTTA.TYPE                  <> 'CM'
  AND   NVL(RCTTA.ATTRIBUTE13,'X')  <> 'S'   
  AND   RCTTA.DESCRIPTION NOT LIKE '%COLIG%'
  AND   (RCTTA.ACCOUNTING_AFFECT_FLAG =  'Y' or RCTTA.ATTRIBUTE15 = 'PCS')
  GROUP BY ALL
 ),

 YM_2022_ITEM
 (
  SELECT  
        MSI.INVENTORY_ITEM_ID,
        MSI.ORGANIZATION_ID,
        MSI.SEGMENT1                                                 MSI_SEGMENT1,
        MSI.DESCRIPTION                                              MSI_DESCRIPTION,
        MC.DESCRIPTION                                               MC_DESCRIPTION,
        MC.SEGMENT1,   
        mc.SEGMENT2, 
       DECODE(MSI.GLOBAL_ATTRIBUTE3,'1','IMP','2','IMP','0','NAC')   ORIGEM_PROD,
       CASE
         WHEN MSI.PLANNER_CODE LIKE 'OLEO%' OR 
              MSI.PLANNER_CODE = 'WURTH' 
          THEN
           'OLEO'
         ELSE
           'PEÇAS'
       END                                                           CATEGORIA,
       MSI.PLANNER_CODE                                              PLANEJADOR
  FROM       SILVER_<env>.EBS_APPS.MTL_SYSTEM_ITEMS_B      MSI
  INNER JOIN SILVER_<env>.EBS_APPS.MTL_ITEM_CATEGORIES     MIC
          ON MSI.INVENTORY_ITEM_ID = MIC.INVENTORY_ITEM_ID
        AND MSI.ORGANIZATION_ID = MIC.ORGANIZATION_ID
  INNER JOIN SILVER_<env>.EBS_APPS.MTL_CATEGORIES          MC
          ON MIC.CATEGORY_ID = MC.CATEGORY_ID
  INNER JOIN SILVER_<env>.EBS_APPS.MTL_CATEGORY_SETS       MCS
          ON MIC.CATEGORY_SET_ID = MCS.CATEGORY_SET_ID
  WHERE MC.SEGMENT1 LIKE '%PÇS%'
 ),

 YM_2022_ORG
 (
  SELECT 
        HOU.ORGANIZATION_ID
      , HOU.NAME                  ORG_NAME
  FROM SILVER_<env>.EBS_APPS.HR_ORGANIZATION_UNITS HOU
 )

 SELECT 
        o131861.MSI_SEGMENT1                       PRODUTO,
        o131861.MSI_DESCRIPTION                    DESCRICAO,
        SUM(NVL(o131844.QTD_GERAL, 0))             QUANTIDADE_TOTAL,
        ROUND(SUM(NVL(NVL(o131844.VL_GERAL, 0)-
                NVL(o131844.VL_IPI, 0)  -
                NVL(o131844.VL_ICMS_ST, 0), 0)),2) VALOR_LIQUIDO,
        COUNT(*)                                   OCORRENCIA,
        o131844.NF                                 NF,
        (o131844.TRX_DATE)                         DATA_NF,
        MONTH(o131844.TRX_DATE)                    MONTH,    
        YEAR(o131844.TRX_DATE)                     YEAR
 FROM       YM_2022_NF                                             o131844
 INNER JOIN YM_2022_ITEM                                           o131861
        ON o131844.WAREHOUSE_ID = o131861.ORGANIZATION_ID
       AND o131844.INVENTORY_ITEM_ID = o131861.INVENTORY_ITEM_ID
 INNER JOIN YM_2022_ORG                                            o131952
        ON o131952.ORGANIZATION_ID = o131844.ORG_ID
 WHERE   o131952.ORG_NAME = 'YMB'
 GROUP BY ALL;