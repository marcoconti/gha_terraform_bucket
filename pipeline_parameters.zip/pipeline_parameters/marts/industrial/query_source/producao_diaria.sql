WITH ProducaoDiaria AS (
    SELECT
        l.id_lancamento,
        l.dat_lancamento,
        l.dat_lancamento_num,
        l.cod_usuario,
        l.vlr_func_direto_variavel AS vlr_fdv,
        l.qtd_func_diretos_fixos   AS qtd_fdf,
        l.vlr_func_dir_tot         AS vlr_fdt,
        l.vlr_func_indireto        AS vlr_fi,
        l.id_turno,
        l.id_workcenter,
        t.cod_turno,
        t.nom_turno,
        w.cod_workcenter,
        w.nom_workcenter,
        w.cod_centro_custo,
        w.nom_setor,
        w.nom_galpao,
        w.id_empresa,
        w.id_setor,
        w.sgl_empresa,
        w.nom_empresa,
        dl.id_dtl_lancamento,
        te.cod_tipo_evento,
        e.cod_evento,
        e.nom_evento,
        i.cod_item,
        di.dsc_item,
        dl.nom_responsavel,
        dl.dat_inicio,
        dl.dat_fim,
        dl.qtd_minuto,
        dl.vlr_eficiencia,
        dl.vlr_rm,
        dl.qtd_aprovada,
        dl.qtd_reprovada,
        dl.obs_lancamento,
        dl.cod_ordem_servico,
        p.nom_problema,
        d.cod_defeito,
        d.nom_defeito,
        d.tpo_defeito,
        r.cod_recurso || ' - ' || r.nom_recurso AS recurso
    FROM silver_<env>.oeeprod_oee.ym_sgpi_tab_lancamento l
    JOIN silver_<env>.oeeprod_oee.ym_sgpi_tab_dtl_lanc dl
      ON dl.id_lancamento = l.id_lancamento
    LEFT JOIN (
        SELECT id_turno, MAX(cod_turno) AS cod_turno, MAX(nom_turno) AS nom_turno
        FROM silver_<env>.ctacsp_ctacs_yma.ym_sgd_tab_turno
        WHERE ind_excluido = 0
        GROUP BY id_turno
    ) t ON t.id_turno = l.id_turno
    LEFT JOIN (
        SELECT 
            w.id_workcenter,
            MAX(w.cod_workcenter) AS cod_workcenter,
            MAX(w.nom_workcenter) AS nom_workcenter,
            MAX(ac.cod_centro_custo) AS cod_centro_custo,
            MAX(ac.nom_setor) AS nom_setor,
            MAX(g.nom_galpao) AS nom_galpao,
            MAX(ac.id_empresa) AS id_empresa,
            MAX(ac.id_setor) AS id_setor,
            MAX(ac.sgl_empresa) AS sgl_empresa,
            MAX(ac.nom_empresa) AS nom_empresa
        FROM silver_<env>.oeeprod_oee.ym_sgpi_tab_workcenter w
        LEFT JOIN silver_<env>.oeeprod_oee.ym_sgpi_vw_area_controle ac 
            ON ac.id_area_controle = w.id_area_controle
        LEFT JOIN silver_<env>.ctacsp_ctacs_yma.ym_sgd_tab_galpao g 
            ON g.id_galpao = w.id_galpao
        WHERE w.ind_excluido = 0
        GROUP BY w.id_workcenter
    ) w ON w.id_workcenter = l.id_workcenter
    LEFT JOIN (
        SELECT id_tipo_evento, MAX(cod_tipo_evento) AS cod_tipo_evento
        FROM silver_<env>.oeeprod_oee.ym_sgpi_tab_tipo_evento
        WHERE ind_excluido = 0
        GROUP BY id_tipo_evento
    ) te ON te.id_tipo_evento = dl.id_tipo_evento
    LEFT JOIN (
        SELECT id_evento, MAX(cod_evento) AS cod_evento, MAX(nom_evento) AS nom_evento
        FROM silver_<env>.oeeprod_oee.ym_sgpi_tab_evento
        WHERE ind_excluido = 0
        GROUP BY id_evento
    ) e ON e.id_evento = dl.id_evento
    LEFT JOIN (
        SELECT id_item, MAX(cod_item) AS cod_item
        FROM silver_<env>.oeeprod_oee.ym_sgpi_tab_item
        GROUP BY id_item
    ) i ON i.id_item = dl.id_item
    LEFT JOIN (
        SELECT id_item, MAX(dsc_item) AS dsc_item
        FROM silver_<env>.oeeprod_oee.ym_sgpi_tab_descricao_item
        WHERE sgl_idioma = 'PT-BR'
        GROUP BY id_item
    ) di ON di.id_item = dl.id_item
    LEFT JOIN (
        SELECT id_problema, MAX(nom_problema) AS nom_problema
        FROM silver_<env>.oeeprod_oee.ym_sgpi_tab_problema
        WHERE ind_excluido = 0
        GROUP BY id_problema
    ) p ON p.id_problema = dl.id_problema
    LEFT JOIN (
        SELECT id_defeito, 
               MAX(cod_defeito) AS cod_defeito, 
               MAX(nom_defeito) AS nom_defeito, 
               MAX(tpo_defeito) AS tpo_defeito
        FROM silver_<env>.oeeprod_oee.ym_sgpi_tab_defeito
        WHERE ind_excluido = 0
        GROUP BY id_defeito
    ) d ON d.id_defeito = dl.id_defeito
    LEFT JOIN (
        SELECT id_recurso, MAX(cod_recurso) AS cod_recurso, MAX(nom_recurso) AS nom_recurso
        FROM silver_<env>.oeeprod_oee.ym_eng_tab_recurso
        WHERE ind_excluido = 0
        GROUP BY id_recurso
    ) r ON r.id_recurso = dl.id_recurso
    WHERE l.ind_excluido = 0 AND dl.ind_excluido = 0
)

SELECT
    CAST(id_lancamento AS STRING)         AS ID_LANCAMENTO,
    CAST(dat_lancamento AS STRING)        AS DT_LANCAMENTO,
    CAST(dat_lancamento_num AS STRING)    AS NR_LANCAMENTO_NUM,
    CAST(cod_usuario AS STRING)           AS CD_USUARIO,
    CAST(vlr_fdv AS DOUBLE)               AS VL_FDV,
    CAST(qtd_fdf AS DOUBLE)               AS QT_FDF,
    CAST(vlr_fdt AS DOUBLE)               AS VL_FDT,
    CAST(vlr_fi AS DOUBLE)                AS VL_FI,
    CAST(id_turno AS STRING)              AS ID_TURNO,
    CAST(id_workcenter AS STRING)         AS ID_WORKCENTER,
    CAST(cod_turno AS STRING)             AS CD_TURNO,
    CAST(nom_turno AS STRING)             AS NM_TURNO,
    CAST(cod_workcenter AS STRING)        AS CD_WORKCENTER,
    CAST(nom_workcenter AS STRING)        AS NM_WORKCENTER,
    CAST(cod_centro_custo AS STRING)      AS CD_CENTRO_CUSTO,
    CAST(nom_setor AS STRING)             AS NM_SETOR,
    CAST(nom_galpao AS STRING)            AS NM_GALPAO,
    CAST(id_empresa AS STRING)            AS ID_EMPRESA,
    CAST(id_setor AS STRING)              AS ID_SETOR,
    CAST(sgl_empresa AS STRING)           AS SG_EMPRESA,
    CAST(nom_empresa AS STRING)           AS NM_EMPRESA,
    CAST(id_dtl_lancamento AS STRING)     AS ID_DTL_LANCAMENTO,
    CAST(cod_tipo_evento AS STRING)       AS CD_TIPO_EVENTO,
    CAST(cod_evento AS STRING)            AS CD_EVENTO,
    CAST(nom_evento AS STRING)            AS NM_EVENTO,
    CAST(cod_item AS STRING)              AS CD_ITEM,
    CAST(dsc_item AS STRING)              AS DSC_ITEM,
    CAST(nom_responsavel AS STRING)       AS NM_RESPONSAVEL,
    CAST(dat_inicio AS STRING)            AS DT_INICIO,
    CAST(dat_fim AS STRING)               AS DT_FIM,
    CAST(qtd_minuto AS DOUBLE)            AS QT_MINUTO,
    CAST(vlr_eficiencia AS DOUBLE)        AS VL_EFICIENCIA,
    CAST(vlr_rm AS DOUBLE)                AS VL_RM,
    CAST(qtd_aprovada AS DOUBLE)          AS QT_APROVADA,
    CAST(qtd_reprovada AS DOUBLE)         AS QT_REPROVADA,
    CAST(obs_lancamento AS STRING)        AS OBS_LANCAMENTO,
    CAST(cod_ordem_servico AS STRING)     AS CD_ORDEM_SERVICO,
    CAST(nom_problema AS STRING)          AS NM_PROBLEMA,
    CAST(cod_defeito AS STRING)           AS CD_DEFECTO,
    CAST(nom_defeito AS STRING)           AS NM_DEFECTO,
    CAST(tpo_defeito AS STRING)           AS TP_DEFECTO,
    CAST(recurso AS STRING)               AS RECURSO 
FROM ProducaoDiaria
WHERE YEAR(CAST(dat_lancamento AS DATE)) >= YEAR(current_date()) - 2