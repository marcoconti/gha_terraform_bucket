# Databricks notebook source
# MAGIC %md
# MAGIC **YM_7007_3_Posicao_Detalhada_do_Inventario_Periodico_por_Categoria - SUB- Inventario**

# COMMAND ----------

# DBTITLE 1,Import bibliotecas
import os
import pyspark.sql.functions as F
from delta.tables import *
from pyspark.sql.window import Window
from datetime import datetime

# COMMAND ----------

# DBTITLE 1,Spark config
spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", "false")

# COMMAND ----------

# DBTITLE 1,Optimization Method
def optimize_delta_table(table_name):
    """
        @param: IN table_path
        Run optimization commands and old snapshots
        Full load
    """
    deltaTable = DeltaTable.forName(spark, table_name)
    deltaTable.vacuum(24)
    deltaTable.optimize().executeCompaction()
    print('Delta table optimized.') 

def get_env():
    return os.environ.get("DATABRICKS_ENV")

# COMMAND ----------

# DBTITLE 1,Variáveis
env     = get_env()
catalog = f"gold_{env.lower()}"
schema  = "industrial_planejamento_controle_producao"
table   = "inventario_categoria_sub_inventario"

# COMMAND ----------

# DBTITLE 1,Get Ingestion Date
data_execucao = datetime.now()

# COMMAND ----------

# DBTITLE 1,Consulta Silver > Gold
sub_inventario = spark.sql(
        f"""
SELECT 
    HLE.NAME AS PESSOA_JURIDICA,
    OOD.ORGANIZATION_CODE AS ORGANIZACAO,
    CPP.PERIOD_NAME AS PERIODO,
    MCK.CONCATENATED_SEGMENTS AS CATEGORIA,
    TRIM(MSI.SEGMENT1) AS ITEM,
    MSI.DESCRIPTION AS DESCRICAO,
    MSI.PRIMARY_UOM_CODE AS UDM,
    NVL(BAS.TOTAL_LAYER_QUANTITY,CPIC.TOTAL_LAYER_QUANTITY) AS QUANTIDADE,
    NVL(BAS.SUBINVENTORY_CODE,'** NAO DEFINIDO') AS SUB_INVENTARIO,
    CPIC.ITEM_COST AS VL_UNITARIO,
    (BAS.TOTAL_LAYER_QUANTITY  * CPIC.ITEM_COST) AS VL_TOTAL,
    CPIC.LAST_UPDATE_DATE AS LAST_UPDATE_DATE,
    YEAR(CPIC.LAST_UPDATE_DATE) AS _year,
    MONTH(CPIC.LAST_UPDATE_DATE) AS _month
FROM silver_{env}.ebs_bom.CST_PAC_ITEM_COSTS CPIC
LEFT JOIN silver_{env}.ebs_apps.CLL_F032_SUBINVENTORY_LAYERS BAS
    ON CPIC.COST_GROUP_ID = BAS.COST_GROUP_ID
    AND CPIC.PAC_PERIOD_ID = BAS.PAC_PERIOD_ID
    AND CPIC.INVENTORY_ITEM_ID = BAS.INVENTORY_ITEM_ID
JOIN silver_{env}.ebs_bom.CST_COST_GROUP_ASSIGNMENTS CCGA
    ON CPIC.COST_GROUP_ID = CCGA.COST_GROUP_ID
JOIN silver_{env}.ebs_bom.CST_PAC_PERIODS CPP
    ON CPIC.PAC_PERIOD_ID = CPP.PAC_PERIOD_ID
JOIN silver_{env}.ebs_apps.HR_LEGAL_ENTITIES HLE
    ON HLE.ORGANIZATION_ID = CPP.LEGAL_ENTITY
JOIN silver_{env}.ebs_apps.ORG_ORGANIZATION_DEFINITIONS OOD
    ON CCGA.ORGANIZATION_ID = OOD.ORGANIZATION_ID
    AND HLE.ORGANIZATION_ID = OOD.LEGAL_ENTITY
    AND HLE.BUSINESS_GROUP_ID = OOD.BUSINESS_GROUP_ID
JOIN silver_{env}.ebs_apps.MTL_ITEM_CATEGORIES MIC
    ON CPIC.INVENTORY_ITEM_ID = MIC.INVENTORY_ITEM_ID
    AND OOD.ORGANIZATION_ID = MIC.ORGANIZATION_ID
JOIN silver_{env}.ebs_apps.MTL_CATEGORIES_KFV MCK
    ON MIC.CATEGORY_ID = MCK.CATEGORY_ID
JOIN silver_{env}.ebs_apps.MTL_SYSTEM_ITEMS_B MSI
    ON CPIC.INVENTORY_ITEM_ID = MSI.INVENTORY_ITEM_ID
    AND OOD.ORGANIZATION_ID = MSI.ORGANIZATION_ID
WHERE MIC.CATEGORY_SET_ID IN (1)
    AND MCK.STRUCTURE_ID IN (101)
    AND CPIC.LAST_UPDATE_DATE >= add_months(current_date(), -36)
        """)

# COMMAND ----------

# DBTITLE 1,Add _ingestionin UTC-3
sub_inventario = sub_inventario.withColumn(
    "_ingestionin",
    F.from_utc_timestamp(F.current_timestamp(), "America/Sao_Paulo"))

# COMMAND ----------

# DBTITLE 1,Writting Gold
print(f"Persiste os dados do DF na tabela {catalog}.{schema}.{table}", end="")
(
    sub_inventario
        .write
        .partitionBy("_year","_month")
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(f"{catalog}.{schema}.{table}")
)
print(" - Concluido com sucesso")
