# Databricks notebook source
# DBTITLE 1,Libs
import os
import pyspark.sql.functions as F
from delta.tables import *

# COMMAND ----------

# DBTITLE 1,Métodos e funções para  o processamentos
def optimize_delta_table(table_name):
    """
        @param: IN table_path
        Run optimization commands and old snapshots
        Full load
    """
    deltaTable = DeltaTable.forName(spark, table_name)
    deltaTable.vacuum(24)
    deltaTable.optimize().executeCompaction()
    print('Delta table optimized.') 

def get_env():
    return os.environ.get("DATABRICKS_ENV")

# COMMAND ----------

# DBTITLE 1,Variáveis
env     = get_env()
catalog = f"gold_{env.lower()}"
schema  = "pecas_sell_out"
table   = "ym_sg_2008"

# COMMAND ----------

regex_CNPJ = r"(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})"

query = \
    f"""Select concat(regexp_extract(cast(lpad(round(cnpj,0), 14, '0') as string), r'{regex_CNPJ}', 1), '.'
                     ,regexp_extract(cast(lpad(round(cnpj,0), 14, '0') as string), r'{regex_CNPJ}', 2), '.'
                     ,regexp_extract(cast(lpad(round(cnpj,0), 14, '0') as string), r'{regex_CNPJ}', 3), '/'
                     ,regexp_extract(cast(lpad(round(cnpj,0), 14, '0') as string), r'{regex_CNPJ}', 4), '-'
                     ,regexp_extract(cast(lpad(round(cnpj,0), 14, '0') as string), r'{regex_CNPJ}', 5)) dc_cnpj,
        A.EMITENTE as DS_EMITENTE,
        A.NOTA_FISCAL as NR_NOTA_FISCAL,
        A.DEST_NOME as NM_DEST_NOME,
        A.DEST_CEP as DS_DEST_CEP,
        A.DEST_CIDADE as DS_DEST_CIDADE,
        A.DEST_ESTADO as DS_DEST_ESTADO,
        A.DEST_CNPJ as DC_DEST_CNPJ,
        A.SERIE as NR_SERIE,
        A.DATA_NF as DT_DATA_NF,
        B.PRODUTO as CD_PRODUTO,
        B.DESCRICAO as DS_DESCRICAO,
        B.UNIDADE as DS_UNIDADE,
        SUM(B.QUANTIDADE) AS QT_QUANTIDADE,
        SUM(B.VL_UNITARIO) AS VL_UNITARIO,
        A.VL_ICMS,
        A.VL_PIS,
        A.VL_COFINS,
        A.VL_IPI,
        SUM(B.VL_PRODUTO) AS VL_PRODUTO,
        C.CFOP_CODE as CD_CFOP_CODE,
        C.DESCRICAO AS DS_DESCRICAO_CFOP,
        A.CREATED_DATE as DT_CREATED_DATE
    FROM silver_{env}.psg_ym_int.tab_xml_nf A
    join silver_{env}.psg_ym_int.tab_xml_nf_line B
        ON A.XML_ID = B.XML_ID
    join silver_{env}.psg_ym_sg.tab_cfop C
        ON B.CFOP = C.CFOP_CODE
    join silver_{env}.autoware.portalweb_peca D
        ON B.PRODUTO = SUBSTRING(D.CD_PECA, 1, 10)
    WHERE B.TIPO_PRODUTO NOT IN ( 'MTC', 'NTC' )
    GROUP BY A.CNPJ, A.EMITENTE, A.NOTA_FISCAL, A.DEST_NOME, A.DEST_CEP, A.DEST_CIDADE, A.DEST_ESTADO
            ,A.DEST_CNPJ, A.SERIE, A.DATA_NF,A.VL_ICMS, A.VL_PIS, A.VL_COFINS, A.VL_IPI, A.CREATED_DATE
            ,B.PRODUTO, B.DESCRICAO, B.UNIDADE
            ,C.CFOP_CODE, C.DESCRICAO
    """
df_ym_sg_2008 = spark.sql(query)

# COMMAND ----------

print(f"Persiste os dados do DF na tabela {catalog}.{schema}.{table}", end="")
(
    df_ym_sg_2008
        .write
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(f"{catalog}.{schema}.{table}")
)
print(" - Concluido com sucesso")

# COMMAND ----------

# optimization Gold layer
optimize_delta_table(f'{catalog}.{schema}.{table}')