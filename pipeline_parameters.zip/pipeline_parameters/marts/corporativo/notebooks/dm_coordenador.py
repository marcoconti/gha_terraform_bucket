# Databricks notebook source
# DBTITLE 1,Import libs
from pyspark.sql.functions import from_utc_timestamp, current_timestamp
from datamax.commons import get_env

# COMMAND ----------

# DBTITLE 1,Variáveis
env     = get_env()
catalog = f"gold_{env.lower()}"
schema  = "corporativo"
table   = "dm_coordenador"

# COMMAND ----------

# DBTITLE 1,Verifica se a tabela já existe, para pegar o maior ID_COORDENADOR
max_id_coordenador = 0
table_exists = False
if spark.catalog.tableExists(f"{catalog}.{schema}.{table}"):
    spark.sql(f"""SELECT MAX(ID_COORDENADOR) max_id_coordenador
                    FROM {catalog}.{schema}.{table}""").createOrReplaceTempView("tmp_max_id_coordenador")
    table_exists = True
else:
    spark.sql(f"""SELECT {max_id_coordenador} max_id_coordenador""").createOrReplaceTempView("tmp_max_id_coordenador")

# COMMAND ----------

# DBTITLE 1,Query para criar o id_coordenador e filtrar já existentes
filter_table_exists = "where 1=1"
# Se a tabela já existir retira os coordenadores já existente.
if table_exists:
    filter_table_exists = \
        f"""where not exists (select 1 
                                from gold_{env}.corporativo.dm_coordenador gc
                               where sc.DS_COORDENADOR = gc.DS_COORDENADOR )"""

query = \
   f""" WITH max_id AS (
            SELECT max_id_coordenador AS max_coordenador
            FROM tmp_max_id_coordenador)
            ,novos_coordenadores AS (
                SELECT DS_COORDENADOR,
                       DENSE_RANK() OVER (ORDER BY DS_COORDENADOR) + max_id.max_coordenador AS ID_COORDENADOR
                  FROM (Select distinct DS_COORDENADOR 
                          from silver_{env}.ext_perfomance.consultor_coordenador sc
                          {filter_table_exists})
            CROSS JOIN max_id
        )
        SELECT ID_COORDENADOR, DS_COORDENADOR
        FROM novos_coordenadores
        """
df_coordenador = spark.sql(query)
df_coordenador = df_coordenador.withColumn("_ingestionin", from_utc_timestamp(current_timestamp(), "America/Sao_Paulo"))

# COMMAND ----------

# DBTITLE 1,Persiste os dados na camada Gold
print(f"Persiste os dados do DF na camada {catalog} na tabela {catalog}.{schema}.{table}", end="")
(
    df_coordenador
        .write
        .format("delta")
        .mode("append")
        .saveAsTable(f"{catalog}.{schema}.{table}")
)
print(" - Concluido com sucesso")