# Databricks notebook source
# DBTITLE 1,Import libs
from pyspark.sql.functions import from_utc_timestamp, current_timestamp
from datamax.commons import get_env

# COMMAND ----------

# DBTITLE 1,Variáveis
env     = get_env()
catalog = f"gold_{env.lower()}"
schema  = "corporativo"
table   = "dm_consultor"

# COMMAND ----------

# DBTITLE 1,Verifica se a tabela já existe, para pegar o maior ID_CONSULTOR
max_id_consultor = 0
table_exists = False
if spark.catalog.tableExists(f"{catalog}.{schema}.{table}"):
    spark.sql(f"""SELECT MAX(ID_CONSULTOR) max_id_consultor
                    FROM {catalog}.{schema}.{table}""").createOrReplaceTempView("tmp_max_id_consultor")
    table_exists = True
else:
    spark.sql(f"""SELECT {max_id_consultor} max_id_consultor""").createOrReplaceTempView("tmp_max_id_consultor")

# COMMAND ----------

# DBTITLE 1,Query para criar o id_consutor e filtrar já existentes
filter_table_exists = "where 1=1"
# Se a tabela já existir retira os consultores já existente.
if table_exists:
    filter_table_exists = \
     f"""where not exists (select 1 
                             from gold_{env}.corporativo.dm_consultor gc
                            where sc.DS_CONSULTOR = gc.DS_CONSULTOR )"""

query = \
   f""" WITH max_id AS 
            (SELECT max_id_consultor AS max_consultor
               FROM tmp_max_id_consultor)
           ,novos_consultores AS (
                SELECT DS_CONSULTOR
                      ,DS_COORDENADOR
                      ,DENSE_RANK() OVER (ORDER BY DS_CONSULTOR) + max_id.max_consultor AS ID_CONSULTOR
                FROM (Select distinct DS_CONSULTOR, DS_COORDENADOR
                        from silver_{env}.ext_perfomance.consultor_coordenador sc
                        {filter_table_exists})
            CROSS JOIN max_id
        )
        SELECT ID_CONSULTOR, DS_CONSULTOR, DS_COORDENADOR
        FROM novos_consultores
        """
df_consultor = spark.sql(query)
df_consultor = df_consultor.withColumn("_ingestionin", from_utc_timestamp(current_timestamp(), "America/Sao_Paulo"))

# COMMAND ----------

# DBTITLE 1,Persiste os dados na camada Gold
print(f"Persiste os dados do DF na camada {catalog} na tabela {catalog}.{schema}.{table}", end="")
(
    df_consultor
        .write
        .format("delta")
        .mode("append")
        .saveAsTable(f"{catalog}.{schema}.{table}")
)
print(" - Concluido com sucesso")