# Databricks notebook source
import pyspark.sql.functions as F
import requests
import tempfile
import os

from pyspark.sql.functions import col
from io import StringIO
from pyspark.sql.types import IntegerType,BooleanType,DateType,LongType,StringType


# COMMAND ----------

# DBTITLE 1,Ambiente
env = os.environ.get("DATABRICKS_ENV").lower()

# Catalogo, Schema e Nome da tabela
param_catalogo_gold = f"gold_{env}"
param_schema = "corporativo"
param_nome_tabela_gold = 'item_planejamento_inventario'

print(f"Tabela: {param_catalogo_gold}.{param_schema}.{param_nome_tabela_gold}")

# COMMAND ----------

df_final = spark.sql(f"""
SELECT 
  ITEM,
  STATUS,
  MACRO_PLANEJADOR,
  PLANEJADOR,
  ORIGEM,
  DESCRICAO,
  REFERENCIA_CRUZADA,
  LIG_PED,
  ITEM_INTERCAMBIAVEL,
  GRUPO_DE_REFERENCIA,
  NIVEL_DE_REFERENCIA,
  TIPO_ITEM,
  QTD_VENDA,
  PRECO_DOMESTICO,
  PRECO_RECOLOCACAO,
  PRECO_EXPORTACAO,
  DESCRICAO_INGLES,
  PRICE_ID,
  CUSTO_MEDIO,
  PRECO_FOB,
  MOEDA,
  SPECIAL_PRICE,
  DT_ULT_ENTR,
  VR_ULT_ENTR,
  IPI_ULT_ENTR,
  ICMS_ULT_ENTR,
  AC_VALOR1,
  AC_DATA1,
  AC_VALOR2,
  AC_DATA2,
  AC_VALOR3,
  AC_DATA3,
  CATEGORIA_DE_PRECO,
  LARGE_GROUP,
  LARGE_CODE,
  GPS_MID_CATEG_CODE,
  GPS_MID_CATEG,
  MIDDLE_GROUP_NAME,
  MIDDLE_CODE,
  CATEGORIA_GRUPO,
  CATEGORIA,
  TIPO_FISCAL_ITEM,
  CONTA_CUSTO,
  SEG_NEG_CUSTO,
  CONTA_FAT,
  SEG_NEG_FAT,
  CLASSE_COND_TRANSACAO,
  LAST_UPDATE_DATE,
  year(LAST_UPDATE_DATE) as year,
  month(LAST_UPDATE_DATE) as month
FROM silver_{env}.ebs_ym.inv_tab_itens_cadastrados
""")

# COMMAND ----------

table = f"{param_catalogo_gold}.{param_schema}.{param_nome_tabela_gold}"
print(f"Escrevendo a tabela {table}")

(
    df_final
    .write
    .format("delta")
    .mode("overwrite")
    .partitionBy("year", "month")
    .option("overwriteSchema", "true")
    .saveAsTable(table)
)
