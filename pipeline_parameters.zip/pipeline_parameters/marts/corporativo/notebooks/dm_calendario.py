# Databricks notebook source
# MAGIC %md
# MAGIC # Metadados gerais

# COMMAND ----------

# MAGIC %md
# MAGIC **Criado por**: -
# MAGIC
# MAGIC **Data criação**: -
# MAGIC
# MAGIC **Atualizado por**: Bruno Jander
# MAGIC
# MAGIC **Data atualização**: 22/04/2025
# MAGIC
# MAGIC [comment]: <> (Tem que vir do negócio)
# MAGIC **Descrição do dataset/tabela/view**: Tabela contendo datas de calendário, gerada dinamicamente com exceção de consulta de feriados.
# MAGIC
# MAGIC [comment]: # (Lineage, nome de domínio, sub-domínio, tipo de agregação, business unit: Tem que vir do negócio)
# MAGIC **Tags**:
# MAGIC
# MAGIC [comment]: # (Tem que vir do negócio)
# MAGIC **Data owner**: 
# MAGIC
# MAGIC [comment]: # (Full/Incremental/Streaming/CDC/etc)
# MAGIC **Tipo de carga**: Full
# MAGIC
# MAGIC [comment]: # (Tem que vir de sistemas)
# MAGIC **Atualização**: Diária

# COMMAND ----------

# MAGIC %md
# MAGIC #### Fontes utilizadas nesse pipeline:
# MAGIC
# MAGIC [comment]: <> (tabelas utilizadas nesse notebook)
# MAGIC - s_ymdb_silver.tb_external_performance_vendas_feriados
# MAGIC - s_ymdb_gold.tb_corp_dm_calendario

# COMMAND ----------

# MAGIC %md
# MAGIC # Configurações Iniciais

# COMMAND ----------

# DBTITLE 1,Importação de bibliotecas
import os
from delta.tables import *
from pyspark.sql.functions import col, lit, when, explode, sequence, to_date, create_map, year, month, day, date_format

# COMMAND ----------

def get_env():
    env = os.environ.get("DATABRICKS_ENV")
    return env.lower()

# COMMAND ----------

env = get_env()
gold_catalog = f"gold_{env.lower()}"
schema       = "corporativo"
table        = "dm_calendario"


# COMMAND ----------

# DBTITLE 1,Definição de dicionários mês/semana
# Meses em português
mes_br = {
    1: "Janeiro",
    2: "Fevereiro",
    3: "Marco",
    4: "Abril",
    5: "Maio",
    6: "Junho",
    7: "Julho",
    8: "Agosto",
    9: "Setembro",
    10: "Outubro",
    11: "Novembro",
    12: "Dezembro",
}

# Dia da semana em português
dia_da_semana_br = {
    "Monday": "Segunda-feira",
    "Tuesday": "Terça-feira",
    "Wednesday": "Quarta-feira",
    "Thursday": "Quinta-feira",
    "Friday": "Sexta-feira",
    "Saturday": "Sabado",
    "Sunday": "Domingo",
}

map_col_mes = create_map([lit(x) for i in mes_br.items() for x in i])
map_col_dow = create_map([lit(x) for i in dia_da_semana_br.items() for x in i])

# COMMAND ----------

# MAGIC %md
# MAGIC # Silver para Gold

# COMMAND ----------

# DBTITLE 1,Leitura da tabela na camada Silver
df_feriados_br = spark.table(f"silver_{env}.ext_perfomance.feriados")

# COMMAND ----------

# DBTITLE 1,Ajuste dos feriados
# df_feriados_br = (
#     df_feriados_br
#     .withColumn('ID_CALENDARIO', year('DT_FERIADO')  + month('DT_FERIADO')  + day('DT_FERIADO'))
# )

df_feriados_br = (
    df_feriados_br
    .withColumn('ID_CALENDARIO'
                ,date_format("DT_FERIADO",'yyyyMMdd')))


# COMMAND ----------

# DBTITLE 1,Criação das datas do calendário
# beginDate = "2000-01-01"
# endDate = "2050-12-31"

# (
#     spark.sql
#     (
#         f"select explode(sequence(to_date('{beginDate}'), to_date('{endDate}'), interval 1 day)) as calendarDate"
#     )
#     .createOrReplaceTempView("tmp_tb_dates")
# )

from pyspark.sql.functions import sequence, explode, to_date, lit, expr

beginDate = "2000-01-01"
endDate = "2050-12-31"

df_dates = (
    spark.createDataFrame([(1,)], ["id"])
    .withColumn("calendarDate"
               ,explode(
                    sequence(
                        to_date(lit(beginDate)),
                        to_date(lit(endDate)),
                        expr("INTERVAL 1 DAY")  
                    )
                )
            )
            .drop("id")
        )

df_dates.createOrReplaceTempView("tmp_tb_dates")



# COMMAND ----------

# DBTITLE 1,Criação de campos complementares do calendário
query = \
  """ select
        date_format(calendarDate,'yyyyMMdd') as ID_CALENDARIO,
        calendarDate as Data,
        year(calendarDate) as Ano,
        date_format(calendarDate, 'MMMM') as Mes_EN,
        month(calendarDate) as MesDoAno,
        date_format(calendarDate, 'EEEE') as Dia_EN,
        dayofweek(calendarDate) as DiaDaSemana,
        weekday(calendarDate) + 1 as DiaDaSemanaInicioSegunda,
        case when weekday(calendarDate) < 5 then "DIA DE SEMANA" else "FIM DE SEMANA" end as FlagDiaSemana, 
        dayofmonth(calendarDate) as DiaDoMes, 
        last_day(calendarDate) as FlagUltimoDiaDoMes, 
        dayofyear(calendarDate) as DiaDoAno, 
        weekofyear(calendarDate) as SemanaDoAnoIso, 
        quarter(calendarDate) as TrimestreDoAno
      from
        tmp_tb_dates
"""

df_dm_calendario = spark.sql(query)

# COMMAND ----------

# DBTITLE 1,Ajuste de nomenclatura do calendário
df_dm_calendario = (
    df_dm_calendario
    .select(
        col('ID_CALENDARIO'),
        col('Data').alias('DT_COMPLETA'),
        col('Ano').alias('NR_ANO'),
        col('MesDoAno').alias('NR_MES'),
        map_col_mes[col('MesDoAno')].alias('NM_MES'),
        col('Mes_EN').alias('NM_MES_INGLES'),
        col('DiaDaSemana').alias('NR_DIA_SEMANA'),
        col('DiaDaSemanaInicioSegunda').alias('NR_DIA_SEMANA_ISO'),
        col('DiaDoMes').alias('NR_DIA_MES'),
        col('DiaDoAno').alias('NR_DIA_ANO'),
        map_col_dow[col('Dia_EN')].alias('NM_DIA'),
        col('Dia_EN').alias('NM_DIA_INGLES'),
        col('FlagDiaSemana').alias('FL_TIPO_DIA_SEMANA'),
        col('FlagUltimoDiaDoMes').alias('DT_ULTIMO_DIA_MES'),
        col('SemanaDoAnoIso').alias('NR_SEMANA_ISO'),
        col('TrimestreDoAno').alias('NR_TRIMESTRE')
    )
)

# COMMAND ----------

# DBTITLE 1,Unificação dos dataframes
df_dm_calendario = (
    df_dm_calendario
    .join(df_feriados_br, ['ID_CALENDARIO'], 'left')
    .withColumn('FL_FERIADO_YAMAHA_BR', when(col('DT_FERIADO').isNotNull(), "FERIADO").otherwise("NÃO FERIADO"))
    .drop('DT_FERIADO')
)

df_dm_calendario = df_dm_calendario.dropDuplicates()

# COMMAND ----------

# DBTITLE 1,Gravação da tabela na camada Gold
print(f"Persiste os dados do DF na camada Gold na tabela {gold_catalog}.{schema}.{table}", end="")
(
    df_dm_calendario
        .write
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(f"{gold_catalog}.{schema}.{table}")
)
print(" - Concluido com sucesso")