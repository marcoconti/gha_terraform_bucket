# Databricks notebook source
# Criado por        : Cesar Augusto Lagos Rojas
# Data criação      : 22/08/24
# Atualizado por    : Vinicius Geada
# Data atualização  : 14/08/25

# COMMAND ----------

# DBTITLE 1,Importação de bibliotecas
import os, time
from pyspark.sql.functions import *
import pyspark.sql.functions as F
from os import getenv
# from pyspark.sql.types import *
# from delta.tables import *

# COMMAND ----------

# DBTITLE 1,Variáveis de ambiente
def get_env():
    env = os.environ.get("DATABRICKS_ENV")
    return env.lower()

# COMMAND ----------

# DBTITLE 1,Lineage de diretórios
env = get_env()

# Lineage corporativo
param_schema = 'corporativo'
silver_catalog = f'silver_{env}'
gold_catalog = f'gold_{env}'

# Nome da tabela
param_nome_tabela = 'dm_distribuidor'

# COMMAND ----------

# DBTITLE 1,Leitura das tabelas Silver
df_cadastro =  spark.table(f"{silver_catalog}.ext_perfomance.cadastro_ccy")
df_consultor_coordenador = spark.table(f"{silver_catalog}.ext_perfomance.consultor_coordenador")

# COMMAND ----------

# DBTITLE 1,Tratamentos
df_consultor = (
    df_consultor_coordenador
    .select('DS_CONSULTOR')
    .dropDuplicates()
    .sort([F.col("DS_CONSULTOR")], ascending=True)    
    .withColumn("ID_CONSULTOR", (F.monotonically_increasing_id() + 1))
    .join(df_consultor_coordenador, ["DS_CONSULTOR"], "inner")
    .select("ID_CONSULTOR","DS_CONSULTOR","DS_COORDENADOR")
)

# COMMAND ----------

# DBTITLE 1,Ajuste de nomenclatura
df_cadastro = (
    df_cadastro
    .withColumn("ID_CIDADE", F.regexp_replace(F.col("CEP"),"-", ""))
    .withColumnRenamed("CD_CCY", "ID_DISTRIBUIDOR")
    .withColumnRenamed("CGC", "CD_CNPJ")
    .withColumnRenamed("SUB_REG", "CD_SUB_REGIAO")
    .withColumnRenamed("REGIAO", "CD_REGIAO")
    .withColumnRenamed("GEC", "CD_GEC")
    .withColumnRenamed("GRUPO", "DS_GEC")
    .withColumnRenamed("TIPO", "TP_TIPO")
    .withColumnRenamed("ABREMP", "DS_ABREMP")
    .withColumnRenamed("RAZAO_SOCIAL", "DS_EMPRESA")
    .withColumnRenamed("ENDERECO", "DS_ENDERECO")
    .withColumnRenamed("BAIRRO", "DS_BAIRRO")
    .withColumnRenamed("CIDADE", "DS_CIDADE")
    .withColumnRenamed("UF", "DS_UF")
    .withColumnRenamed("CEP", "DS_CEP")
    .withColumnRenamed("STATUS", "DS_STATUS")
    .withColumnRenamed("DATA_INICIO", "DT_DATA_INICIO")
    .withColumnRenamed("LAT", "DS_LAT")
    .withColumnRenamed("LONG", "DS_LONG")
    .withColumnRenamed("CONSULTOR", "DS_CONSULTOR")
    .withColumn("DS_GEC_ATC",F.when((F.col("DS_GEC") == "DRV") & (F.col("DS_UF") == "PR"), "DVR CURITUVA").otherwise(F.col("DS_GEC")))
)

# COMMAND ----------

df_distribuidor = (
    df_cadastro.alias("a")
    .join(
        df_consultor.alias("b"),
        [F.col("a.DS_CONSULTOR") == F.col("b.DS_CONSULTOR")],
        "left"
    )
    .select(
        "a.ID_DISTRIBUIDOR",
        "a.ID_CIDADE",
        "b.ID_CONSULTOR",
        "a.CD_CNPJ",
        "a.CD_REGIAO",
        "a.CD_SUB_REGIAO",
        "a.CD_GEC",
        "a.DS_GEC",
        "a.DS_GEC_ATC",
        "a.TP_TIPO",
        "a.DS_ABREMP",
        "a.DS_EMPRESA",
        "a.DS_ENDERECO",
        "a.DS_LAT",
        "a.DS_LONG"
    )
    .na.drop(how="all")
)

# COMMAND ----------

# DBTITLE 1,Gravação da tabela na camada Gold
(
    df_distribuidor
        .write
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(f"{gold_catalog}.{param_schema}.{param_nome_tabela}")
)
