# Databricks notebook source
# MAGIC %md
# MAGIC #Metadados gerais

# COMMAND ----------

# MAGIC %md
# MAGIC **Criado por**: -
# MAGIC
# MAGIC **Data criação**: -
# MAGIC
# MAGIC **Atualizado por**: Bruno Jander
# MAGIC
# MAGIC **Data atualização**: 10/04/2025
# MAGIC
# MAGIC [comment]: <> (Tem que vir do negócio)
# MAGIC **Descrição do dataset/tabela/view**: Tabela contendo unidades de negócio, disponibilizada via API do Dynamics 365.
# MAGIC
# MAGIC [comment]: # (Lineage, nome de domínio, sub-domínio, tipo de agregação, business unit: Tem que vir do negócio)
# MAGIC **Tags**:
# MAGIC
# MAGIC [comment]: # (Tem que vir do negócio)
# MAGIC **Data owner**: 
# MAGIC
# MAGIC [comment]: # (Full/Incremental/Streaming/CDC/etc)
# MAGIC **Tipo de carga**: Full
# MAGIC
# MAGIC [comment]: # (Tem que vir de sistemas)
# MAGIC **Atualização**: Diária

# COMMAND ----------

# MAGIC %md
# MAGIC #### Fontes utilizadas nesse pipeline:
# MAGIC
# MAGIC [comment]: <> (tabelas utilizadas nesse notebook)
# MAGIC - silver_catalog.dynamics_365_sales_lifetime_customer.businessunit
# MAGIC - gold_catalog.dm_unidade_negocio

# COMMAND ----------

# MAGIC %md
# MAGIC # Configurações Iniciais

# COMMAND ----------

# DBTITLE 1,Importação de bibliotecas
from os import getenv
from pyspark.sql.functions import regexp_replace, lpad, col
from delta.tables import *

# COMMAND ----------

# DBTITLE 1,Variáveis de ambiente
# Get env values
ambiente = getenv("DATABRICKS_ENV").lower()

# COMMAND ----------

# DBTITLE 1,Lineage de diretórios
# Lineage corporativo
param_schema = 'corporativo'
silver_catalog = f'silver_{ambiente}'
gold_catalog = f'gold_{ambiente}'

# Nome da tabela
param_nome_tabela = 'dm_unidade_negocio'

# COMMAND ----------

# MAGIC %md
# MAGIC #Silver para Gold

# COMMAND ----------

# DBTITLE 1,Leitura da tabela na camada Silver
df_unidade_negocio = spark.read.table(f"{silver_catalog}.dynamics_365_sales_lifetime_customer.businessunit")

# COMMAND ----------

# DBTITLE 1,Tratamento do dataframe
df_unidade_negocio = (
    df_unidade_negocio
    .withColumn('NR_ENDERECO1_CEP', regexp_replace('NR_ENDERECO1_CEP', '-', ''))
    .withColumn('NR_ENDERECO1_CEP', lpad(col('NR_ENDERECO1_CEP'), 8, '0'))
    .drop('DS_ODATA_ETAG')
)

# COMMAND ----------

# DBTITLE 1,Gravação da tabela na camada Gold
(
    df_unidade_negocio
    .write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f'{gold_catalog}.{param_schema}.{param_nome_tabela}')
)
