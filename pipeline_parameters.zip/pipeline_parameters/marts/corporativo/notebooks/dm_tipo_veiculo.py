# Databricks notebook source
# MAGIC %md
# MAGIC #Metadados gerais

# COMMAND ----------

# MAGIC %md
# MAGIC **Criado por**: Bruno Jander
# MAGIC
# MAGIC **Data criação**: 02/01/2025
# MAGIC
# MAGIC **Atualizado por**: Bruno Jander
# MAGIC
# MAGIC **Data atualização**: 10/04/2025
# MAGIC
# MAGIC **Atualizado por**: Bruno Jander
# MAGIC
# MAGIC **Data atualização**: 16/07/2025
# MAGIC
# MAGIC [comment]: <> (Tem que vir do negócio)
# MAGIC **Descrição do dataset/tabela/view**: Tabela contendo tipos de veículos, disponibilizada via manual de usuário DENATRAN do sistema RENAVAM.
# MAGIC
# MAGIC [comment]: # (Lineage, nome de domínio, sub-domínio, tipo de agregação, business unit: Tem que vir do negócio)
# MAGIC **Tags**:
# MAGIC
# MAGIC [comment]: # (Tem que vir do negócio)
# MAGIC **Data owner**: 
# MAGIC
# MAGIC [comment]: # (Full/Incremental/Streaming/CDC/etc)
# MAGIC **Tipo de carga**: Full
# MAGIC
# MAGIC [comment]: # (Tem que vir de sistemas)
# MAGIC **Atualização**: Anual

# COMMAND ----------

# MAGIC %md
# MAGIC #### Fontes utilizadas nesse pipeline:
# MAGIC
# MAGIC [comment]: <> (tabelas utilizadas nesse notebook)
# MAGIC
# MAGIC - silver_catalog.predicao_volume.tipo_veiculo
# MAGIC - gold_catalog.corporativo.dm_tipo_veiculo

# COMMAND ----------

# MAGIC %md
# MAGIC # Configurações Iniciais

# COMMAND ----------

# DBTITLE 1,Importação de bibliotecas
from os import getenv

# COMMAND ----------

# DBTITLE 1,Variáveis de ambiente
ambiente = getenv("DATABRICKS_ENV").lower()

# COMMAND ----------

# DBTITLE 1,Lineage de diretórios
# Lineage corporativo
param_schema = 'corporativo'
silver_catalog = f'silver_{ambiente}'
gold_catalog = f'gold_{ambiente}'

# Nome da tabela
param_nome_tabela = 'dm_tipo_veiculo'

# COMMAND ----------

# MAGIC %md
# MAGIC #SILVER PARA GOLD

# COMMAND ----------

# DBTITLE 1,Leitura da tabela na camada Silver
df_tipo_veiculo = spark.read.table(f"{silver_catalog}.predicao_volume.tipo_veiculo")

# COMMAND ----------

# DBTITLE 1,Ajuste de nomenclatura
df_tipo_veiculo = (
    df_tipo_veiculo
    .withColumnRenamed("ID_CODIGO", "ID_TIPO_VEICULO")
    .withColumnRenamed("NM_DESCRICAO", "DS_TIPO_VEICULO")
)

# COMMAND ----------

# DBTITLE 1,Gravação da tabela na camada Gold
(
    df_tipo_veiculo
    .write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f'{gold_catalog}.{param_schema}.{param_nome_tabela}')
)
