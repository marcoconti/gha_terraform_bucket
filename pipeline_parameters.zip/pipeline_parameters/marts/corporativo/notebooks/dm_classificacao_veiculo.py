# Databricks notebook source
# MAGIC %md
# MAGIC #Metadados gerais

# COMMAND ----------

# MAGIC %md
# MAGIC **Criado por**: Bruno Jander
# MAGIC
# MAGIC **Data criação**: 02/01/2025
# MAGIC
# MAGIC **Atualizado por**: Bruno Jander
# MAGIC
# MAGIC **Data atualização**: 10/04/2025
# MAGIC
# MAGIC **Atualizado por**: Bruno Jander
# MAGIC
# MAGIC **Data atualização**: 16/07/2025
# MAGIC
# MAGIC [comment]: <> (Tem que vir do negócio)
# MAGIC **Descrição do dataset/tabela/view**: Tabela contendo classificação de veículos, disponibilizada via manual de usuário DENATRAN do sistema RENAVAM.
# MAGIC
# MAGIC [comment]: # (Lineage, nome de domínio, sub-domínio, tipo de agregação, business unit: Tem que vir do negócio)
# MAGIC **Tags**:
# MAGIC
# MAGIC [comment]: # (Tem que vir do negócio)
# MAGIC **Data owner**: 
# MAGIC
# MAGIC [comment]: # (Full/Incremental/Streaming/CDC/etc)
# MAGIC **Tipo de carga**: Full
# MAGIC
# MAGIC [comment]: # (Tem que vir de sistemas)
# MAGIC **Atualização**: Anual

# COMMAND ----------

# MAGIC %md
# MAGIC #### Fontes utilizadas nesse pipeline:
# MAGIC
# MAGIC [comment]: <> (tabelas utilizadas nesse notebook)
# MAGIC
# MAGIC - silver_catalog.predicao_volume.classificacao_veiculo
# MAGIC - gold_catalog.corporativo.dm_classificacao_veiculo

# COMMAND ----------

# MAGIC %md
# MAGIC # Configurações Iniciais

# COMMAND ----------

# DBTITLE 1,Importação de bibliotecas
from os import getenv
from pyspark.sql.functions import monotonically_increasing_id, row_number

# COMMAND ----------

# DBTITLE 1,Variáveis de ambiente
ambiente = getenv("DATABRICKS_ENV").lower()

# COMMAND ----------

# DBTITLE 1,Lineage de diretórios
# Lineage corporativo
param_schema = 'corporativo'
silver_catalog = f'silver_{ambiente}'
gold_catalog = f'gold_{ambiente}'

# Nome da tabela
param_nome_tabela = 'dm_classificacao_veiculo'

# COMMAND ----------

# MAGIC %md
# MAGIC #SILVER PARA GOLD

# COMMAND ----------

# DBTITLE 1,Leitura da tabela na camada Silver
df_classificacao_veiculo = spark.read.table(f"{silver_catalog}.predicao_volume.classificacao_veiculo")

# COMMAND ----------

# DBTITLE 1,Ajuste de nomenclatura
df_classificacao_veiculo = (
    df_classificacao_veiculo
    .withColumn("ID_VEICULO", monotonically_increasing_id())
    .withColumnRenamed("CD_CODIGO", "CD_TIPO")
    .withColumnRenamed("DS_DESCRICAO", "DS_TIPO")
    .withColumnRenamed("ID_MARCA", "CD_MARCA")
    .withColumnRenamed("ID_ESPECIE", "CD_ESPECIE")
    .withColumnRenamed("DS_ESPECIE_DESCRICAO", "DS_ESPECIE")
    .withColumnRenamed("ID_CARROCERIA", "CD_CARROCERIA")
    .withColumnRenamed("DS_CARROCERIA_DESCRICAO", "DS_CARROCERIA")
)

# COMMAND ----------

# DBTITLE 1,Gravação da tabela na camada Gold
(
    df_classificacao_veiculo
    .write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f'{gold_catalog}.{param_schema}.{param_nome_tabela}')
)
