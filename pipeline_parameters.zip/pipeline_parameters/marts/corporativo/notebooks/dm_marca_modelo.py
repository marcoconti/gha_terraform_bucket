# Databricks notebook source
# MAGIC %md
# MAGIC #Metadados gerais

# COMMAND ----------

# MAGIC %md
# MAGIC **Criado por**: Bruno Jander
# MAGIC
# MAGIC **Data criação**: 03/01/2025
# MAGIC
# MAGIC **Atualizado por**: Bruno Jander
# MAGIC
# MAGIC **Data atualização**: 27/03/2025
# MAGIC
# MAGIC **Atualizado por**: Bruno Jander
# MAGIC
# MAGIC **Data atualização**: 10/04/2025
# MAGIC
# MAGIC **Atualizado por**: Bruno Jander
# MAGIC
# MAGIC **Data atualização**: 16/07/2025
# MAGIC
# MAGIC [comment]: <> (Tem que vir do negócio)
# MAGIC **Descrição do dataset/tabela/view**: Tabela contendo lista de marcas e modelos de veículos, disponibilizada pela Abraciclo através de FTP.
# MAGIC
# MAGIC [comment]: # (Lineage, nome de domínio, sub-domínio, tipo de agregação, business unit: Tem que vir do negócio)
# MAGIC **Tags**:
# MAGIC
# MAGIC [comment]: # (Tem que vir do negócio)
# MAGIC **Data owner**: 
# MAGIC
# MAGIC [comment]: # (Full/Incremental/Streaming/CDC/etc)
# MAGIC **Tipo de carga**: Full
# MAGIC
# MAGIC [comment]: # (Tem que vir de sistemas)
# MAGIC **Atualização**: Diária

# COMMAND ----------

# MAGIC %md
# MAGIC #### Fontes utilizadas nesse pipeline:
# MAGIC
# MAGIC [comment]: <> (tabelas utilizadas nesse notebook)
# MAGIC
# MAGIC - silver_catalog.predicao_volume.marca_modelo
# MAGIC - gold_catalog.corporativo.dm_marca_modelo

# COMMAND ----------

# MAGIC %md
# MAGIC # Configurações Iniciais

# COMMAND ----------

# DBTITLE 1,Importação de bibliotecas
from os import getenv
from pyspark.sql.functions import split, col, when

# COMMAND ----------

# DBTITLE 1,Variáveis de ambiente
ambiente = getenv("DATABRICKS_ENV").lower()

# COMMAND ----------

# DBTITLE 1,Lineage de diretórios
# Lineage corporativo
param_schema = 'corporativo'
silver_catalog = f'silver_{ambiente}'
gold_catalog = f'gold_{ambiente}'

# Nome da tabela
param_nome_tabela = 'dm_marca_modelo'

# COMMAND ----------

# MAGIC %md
# MAGIC #SILVER PARA GOLD

# COMMAND ----------

# DBTITLE 1,Leitura da tabela na camada Silver
df_marca_modelo = spark.read.table(f"{silver_catalog}.predicao_volume.marca_modelo")

# COMMAND ----------

# DBTITLE 1,Ajuste de nomenclatura
df_marca_modelo = (
    df_marca_modelo
    .withColumnRenamed("CD_CODIGO", "ID_MARCA_MODELO")
    .withColumnRenamed("DS_DESCRICAO", "DS_MARCA_MODELO")
)

# COMMAND ----------

# DBTITLE 1,Criação do dataframe final
df_marca_modelo = (
    df_marca_modelo
    .withColumn("DS_FABRICACAO",
        when((split(col("DS_MARCA_MODELO"),"/", 2).getItem(0)) == "I", "IMPORTADA")
        .when((split(col("DS_MARCA_MODELO"),"/", 2).getItem(0)).startswith("IMP"), "IMPORTADA")
        .otherwise("NACIONAL"))
    .select("ID_MARCA_MODELO", "DS_MARCA_MODELO", "DS_FABRICACAO")
)

# COMMAND ----------

# DBTITLE 1,Gravação da tabela na camada Gold
(
    df_marca_modelo
    .write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f'{gold_catalog}.{param_schema}.{param_nome_tabela}')
)
