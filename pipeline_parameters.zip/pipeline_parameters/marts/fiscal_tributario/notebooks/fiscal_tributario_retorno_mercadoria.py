# Databricks notebook source
# MAGIC %md
# MAGIC ### Relatorio:  `YM_7009`
# MAGIC ### Assunto:    `Retorno de Mercadoria`
# MAGIC ### Criado Por: `Caio Francisco`
# MAGIC ### Data:       `14-08-2025` 

# COMMAND ----------

# DBTITLE 1,Import de bibliotecas
import os
from pyspark.sql.functions import * 
from pyspark.sql.types import *
from delta.tables import *
from datetime import datetime

# COMMAND ----------

# DBTITLE 1,Criação de método para otimizar delta table
def optimize_delta_table(table_name):
    """
        @param: IN table_path
        Run optimization commands and old snapshots
        Full load
    """
    deltaTable = DeltaTable.forName(spark, table_name)
    deltaTable.vacuum()
    deltaTable.optimize().executeCompaction()
    print('Delta table optimized.') 

# COMMAND ----------

# Ambiente
env = os.environ.get("DATABRICKS_ENV").lower()

# Catalogo, Schema e Nome da tabela
param_catalogo_gold = f"gold_{env}"
param_schema = "fiscal_tributario"
param_nome_tabela_gold = 'fiscal_tributario_retorno_mercadoria'
anoFiltro = (datetime.now().year - 3)

print(f"Tabela: {param_catalogo_gold}.{param_schema}.{param_nome_tabela_gold}")


# COMMAND ----------

df_retorno_mercadoria = spark.sql(f""" 
with categoria as (

select mic.category_set_name      conj_categoria
      ,mic.control_level_disp    nivel_controle
      ,mic.segment2              incricao_estadual
      ,mic.segment3              tipo_segmento
      ,msi.organization_id
      ,msi.inventory_item_id

FROM       silver_{env}.ebs_apps.mtl_system_items_b   msi
INNER JOIN silver_{env}.ebs_apps.mtl_item_categories_v     mic
        ON msi.inventory_item_id   = mic.inventory_item_id
       AND msi.organization_id = mic.organization_id
       AND mic.category_set_name = 'Resolucao 16'    
),
local as (
select 
       hrl.location_id
      ,hrl.location_code
from  silver_{env}.ebs_apps.hr_locations_all hrl
),
categoria_custo as (
select mic.category_set_name conj_categoria_custo
      ,CATEGORY_CONCAT_SEGS  cat_custo
      ,msi.organization_id
      ,msi.inventory_item_id

FROM       silver_{env}.ebs_apps.mtl_system_items_b   msi
INNER JOIN silver_{env}.ebs_apps.mtl_item_categories_v     mic
        ON msi.inventory_item_id   = mic.inventory_item_id
       AND msi.organization_id = mic.organization_id
       AND mic.category_set_name = 'Custos' 
),
city as (
SELECT c.city_id
      ,s.state_code
      ,c.city_code
      ,c.ibge_code
FROM       silver_{env}.ebs_cll.cll_f189_states s 
INNER JOIN silver_{env}.ebs_cll.cll_f189_cities c
        ON s.state_id = c.state_id
),
transportador as (
SELECT 
      rfea.entity_id
     ,pv.vendor_name

FROM       silver_{env}.ebs_cll.cll_f189_fiscal_entities_all rfea
INNER JOIN silver_{env}.ebs_apps.ap_supplier_sites_all pvs
        ON pvs.vendor_site_id = rfea.vendor_site_id
INNER JOIN silver_{env}.ebs_apps.ap_suppliers pv
        ON pv.vendor_id = pvs.vendor_id
),
codigo_produto as (
select
      msib.inventory_item_id
     ,msib.organization_id
     ,msib.segment1
from silver_{env}.ebs_apps.mtl_system_items_b msib
),
cliente_yamaha as (
select
      entity_id
     ,customer_name
     ,state_code
     ,city_code
from silver_{env}.ebs_apps.cll_f189_customers_v
),
conta_contabil as (
select 
       rx.organization_id
      ,rx.location_id
      ,rx.operation_id
      ,rx.invoice_line_id
      ,rx.reference

     ,(GCC.SEGMENT1||'-'||GCC.SEGMENT2||'-'||GCC.SEGMENT3||'-'||
       GCC.SEGMENT4||'-'||GCC.SEGMENT5||'-'||GCC.SEGMENT6||'-'||
       GCC.SEGMENT7||'-'||GCC.SEGMENT8||'-'||GCC.SEGMENT9||'-'||
       GCC.SEGMENT10)   conta_contabil                                         

from      silver_{env}.ebs_GL.GL_CODE_COMBINATIONS      GCC
left join silver_{env}.ebs_cll.cll_f189_distributions       rx
      on  rx.CODE_COMBINATION_ID  = GCC.CODE_COMBINATION_ID 
),
utlizacao as (
SELECT
      ritu.utilization_id 
     ,ritu.utilization_code utilizacao
FROM silver_{env}.ebs_cll.cll_f189_item_UTILIZATIONS ritu
),
conta_icms_ipi as 
(
select
      rd.operation_id
     ,rd.reference
     ,gcc.segment3
from       silver_{env}.ebs_cll.cll_f189_distributions  rd
inner join silver_{env}.ebs_gl.gl_code_combinations     gcc
        on rd.code_combination_id = gcc.code_combination_id
),
nf_remessa as (
select 
      rctl.customer_trx_line_id
     ,rcta.trx_number||'-'||rctl.line_number nf_remessa

from       silver_{env}.ebs_apps.ra_customer_trx_all rcta
inner join silver_{env}.ebs_apps.ra_customer_trx_lines_all rctl 
        on rcta.customer_trx_id = rctl.customer_trx_id  
),
nf_remessa_tpa as (
select 

       tret.organization_id
      ,tret.INVOICE_ID
      ,tret.OPERATION_ID
      ,tret.INVOICE_LINE_ID
      ,min(trem.TRX_NUMBER||'-'||rctl.line_number  ||' qt_return='||tret.RETURNED_QUANTITY)  Min_nf_remessa
      ,max(trem.TRX_NUMBER||'-'||rctl.line_number  ||' qt_return='||tret.RETURNED_QUANTITY)  Max_nf_remessa

from       silver_{env}.ebs_apps.ra_customer_trx_lines_all    rctl
inner join silver_{env}.ebs_apps.CLL_F513_TPA_REMIT_CONTROL   trem
        on rctl.CUSTOMER_TRX_ID       = trem.CUSTOMER_TRX_ID
       and rctl.customer_trx_line_id  = trem.customer_trx_line_id
inner join silver_{env}.ebs_apps.CLL_F513_TPA_RETURNS_CONTROL tret
        on  trem.TPA_REMIT_CONTROL_ID  = tret.TPA_REMIT_CONTROL_ID

group by all
),
nf_pai as (
select  rix.invoice_id
       ,rix.invoice_num
from silver_{env}.ebs_cll.cll_f189_invoices rix
),
dpto as (
SELECT 
      FLEX_VALUE_MEANING
     ,DESCRIPTION
FROM silver_{env}.ebs_apps.FND_FLEX_VALUES_VL
WHERE FLEX_VALUE_SET_ID = 1007283
),
nf_origem as (
select rcta.customer_trx_id
      ,rcta.trx_number
from silver_{env}.ebs_apps.ra_customer_trx_all rcta
),
situacao_esp as (
SELECT
     cfi.operation_id  
    ,DECODE(CFIT.ATTRIBUTE4, 'S', '5', '@') IND_SITUACAO_ESP
FROM       silver_{env}.ebs_cll.CLL_F189_INVOICE_TYPES CFIT
INNER JOIN silver_{env}.ebs_cll.cll_f189_INVOICES CFI
        ON CFIT.ORGANIZATION_ID = CFI.ORGANIZATION_ID
       AND CFIT.INVOICE_TYPE_ID = CFI.INVOICE_TYPE_ID
)

SELECT 
       distinct

        hou.NAME                                organizacao
,       ril.invoice_line_id
,       ril.operation_fiscal_type               tipo_op_fiscal
,       RIL.INVOICE_ID
,       hrl.location_code                       local
,      rit.invoice_type_code                    tp_transacao
,      rit.description                          transacao
,      transportador.vendor_name                Transportador
,     RFT.vendor_site_id
,     ri.fiscal_document_model
,     situacao_esp.IND_SITUACAO_ESP
,     RFT.org_id
,     ri.organization_Id
,     round(ril.quantity * ril.unit_price,2)   vl_produto
,      ri.invoice_num                           nr_nf
,      ri.series                                
,      ri.invoice_date                          dt_nf
,      ri.operation_id                          nr_recebimento
,      ym.receive_date                          dt_rec_manaus   
,      fu.description                           nome
,      fu.user_name                             codigo_nome  
,      reo.attribute7
,      ym.document_number  numero_minuta
,      ym.status_code  status_minuta
,      reo.receive_date
,      case

        when reo.organization_id <> 88 then

                  reo.receive_date

        else
              ltrim(rtrim(

replace(replace(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(reo.attribute7,'FEB','FEV'),'SEP','SET'),'APR','ABR'),'MAY','MAI'),'AUG','AGO'),'SEP','SET'),'OCT','OUT'),'DEC','DEZ')

))

 end   dt_sel

,      ltrim(rtrim(

replace(replace(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(reo.attribute7,'FEB','FEV'),'SEP','SET'),'APR','ABR'),'MAY','MAI'),'AUG','AGO'),'SEP','SET'),'OCT','OUT'),'DEC','DEZ')

))                               dt_manaus

,      NVL(ltrim(rtrim(

replace(replace(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(reo.attribute7,'FEB','FEV'),'SEP','SET'),'APR','ABR'),'MAY','MAI'),'AUG','AGO'),'SEP','SET'),'OCT','OUT'),'DEC','DEZ')

)) ,reo.receive_date)           dt_recebimento
,      cast(reo.receive_date as date)            dt_real
,      codigo_produto.segment1 cd_produto
,     categoria.conj_categoria
,     categoria.nivel_controle
,     categoria.incricao_estadual
,     categoria.tipo_segmento          
,     categoria_custo.conj_categoria_custo
,     categoria_custo.cat_custo       
,      msi.global_attribute2                    classe 
,      NVL(MsI.ITEM_TYPE,' ')                  tipo_item
,      nvl(msi.description,ril.description)     produto
,      DECODE(msi.global_attribute3,'1','IMP','0','NAC')  origem
,      rfc.classification_code                            NCM
,      nvl(pv.vendor_name,cliente_yamaha.customer_name ) fornecedor
,      nvl(pvs.state,cliente_yamaha.state_code) estado 
,      nvl(pvs.city,cliente_yamaha.city_code)  cidade
,      nvl( case pvs.global_attribute9
                when '1' then  pvs.global_attribute10 || '-' || pvs.global_attribute12
                when '2' then pvs.global_attribute10 || '/' || pvs.global_attribute11 || '-' || pvs.global_attribute12
           else 
            null
           end,

    rft.document_number) CNPJ_CPF          

, nvl(pvs.global_attribute13, rft.ie) inscr_estadual   
,      rfo.cfo_code
,      ril.operation_fiscal_type                natureza_operacao 
,      ril.quantity                             quantidade
,      ril.icms_base
,      ril.DISCOUNT_AMOUNT                      desconto
,      ril.icms_amount                          icms
,      ril.icms_tax
,      ril.icms_st_base
,      ril.icms_st_amount                       icms_st
,      ril.icms_amount_recover                  icms_arecuperar
,      ril.icms_st_amount_recover               icms_st_arecuperar
,      ril.ipi_amount_recover                   ipi_arecuperar
,      ril.ipi_amount                           ipi
,      ril.ipi_base_amount                      base_ipi --chamado 221649 
,      ril.ipi_tax                              aliquota_ipi --chamado 221649
,      ril.diff_icms_amount                     diferencial_icms
,      ril.uom
,      ril.total_amount                         vl_nf
,      ril.pis_amount_recover                   pis
,      ril.pis_tax_rate                         pis_tx
,      ril.pis_base_amount                      base_pis --chamado 221649
,      ril.cofins_base_amount                   base_cofins -- chamado 221649
,      ril.cofins_tax_rate                      cofins_tax
,      ril.cofins_amount_recover                cofins
,      ril.pis_st_amount                        pis_st
,      ril.cofins_st_amount                     cofins_st
,      ril.importation_pis_amount               pis_importacao
,      ril.importation_cofins_amount            cofins_importacao  
,      ri.fiscal_document_model                 tipo_documento
,      ri.attribute13                           chave_de_acesso
,      ri.attribute20                           chave_de_acesso_dacte
,      ril.pis_st_tax 
,      ril.cofins_st_tax
,      ril.pis_cofins_st_base      
,      ri.ir_amount                             ir
,      ri.iss_amount                            iss           
,      ri.inss_amount                           inss
,      nvl(rx.conta_contabil ,' ')                  conta_contabil      
,      nvl(conta_contabil_icms.conta_contabil ,' ') conta_contabil_icms 
,      nvl(reo.reversion_flag,'x')              reversao
,      ril.icms_amount_recover                        
,      DECODE(instr( rit.description    ,'POPA'),0,
       DECODE(instr( rit.description    ,'MOTOC'),0,
       DECODE(instr( rit.description    ,'PECAS'),0,
       DECODE(instr( rit.description    ,'PEÇAS'),0,
       DECODE(instr( rit.description    ,'VEICULO'),0,
       DECODE(instr( rit.description    ,'QUADRI'),0,' '
       ,'QUADRICICULO')
       ,'VEICULO AQUATICO')
       ,'PECAS')          
       ,'PECAS')  
       ,'MOTOCICLETA')        
       ,'MOTOR POPA') TP_PRODUTO
,ritu.utilizacao
,ril.icms_tax_code
,ril.ipi_tax_code         
,nvl(rd.segment3,' ') conta_icms
, nvl(conta_icms_ipi.segment3,' ') conta_ipi                        
,ri.attribute19                emissao_nf       
,ri.icms_type                    tipo_icms
,nf_origem.trx_number            sped_nf_origem
,reo.reversion_flag       
,nf_remessa.nf_remessa
,case  
       when tret.max_nf_remessa  = tret.Min_nf_remessa  then tret.max_nf_remessa
       when tret.max_nf_remessa <> tret.Min_nf_remessa  then tret.max_nf_remessa || '  /  '|| tret.Min_nf_remessa 
       end nf_remessa_TPA
,rlx.invoice_num nf_pai
,ril.attribute12                                   sped_sit_trib_ipi
,ril.ipi_tributary_code                            ipi_cod
,ril.pis_tributary_code                            pis_cod
,ril.cofins_tributary_code                         cofins_cod
,ril.attribute13                                   sped_sit_trib_cofins
,ril.pis_base_amount pis_base
,ril.cofins_base_amount cofins_base
,ril.pis_tax_rate
,ril.cofins_tax_rate
,dpto.DESCRIPTION DEPTO
,city_s.state_code UF_Orig
,city_s.city_code Cidade_Orig
,ri.source_ibge_city_code IBGE_Orig
,city_d.state_code UF_Dest
,city_d.city_code Cidade_Dest
,ri.destination_ibge_city_code  IBGE_Dest
,nvl(reo.source,'MANUAL')       rigem
,ril.tributary_status_code  CST_ICMS
,ril.ATTRIBUTE10            DESCRICAO_XML
,RIL.ATTRIBUTE20            UNIDADE_XML
,YM.FLEET_TRUCK             FROTA
,YM.SCHEDULE_RECEIVING_DATE PREVISAO_DE_ENTREGA
,nvl(substr(ril.attribute10,1, (instr(RIL.attribute10,';') - 1) ) , ril.item_number) SEQ_ITEM
,year((reo.receive_date)) YEAR
,month((reo.receive_date)) MONTH


FROM       silver_{env}.ebs_cll.cll_f189_INVOICES             ri
INNER JOIN silver_{env}.ebs_cll.cll_f189_INVOICE_TYPES        RIT
        ON ri.invoice_type_id = rit.invoice_type_id
       AND rit.fiscal_flag    = 'Y'
INNER JOIN silver_{env}.ebs_cll.cll_f189_invoice_lines        ril
        ON ri.invoice_id  = ril.invoice_id   

INNER JOIN silver_{env}.ebs_cll.cll_f189_entry_operations     REO
        ON  ri.operation_id     = reo.operation_id
       AND  ri.organization_id  = reo.organization_id
       AND  reo.reversion_flag is null
       AND  reo.status          = 'COMPLETE'

INNER JOIN silver_{env}.ebs_cll.cll_f189_fiscal_operations    rfo
        ON ril.cfo_id  = rfo.cfo_id 

INNER JOIN silver_{env}.ebs_cll.cll_f189_fiscal_entities_all  RFT
        ON ri.entity_id  = RFT.entity_id

INNER JOIN silver_{env}.ebs_apps.hr_organization_units         hou
        ON reo.organization_id + 0  = hou.organization_id

INNER JOIN silver_{env}.ebs_cll.cll_f189_fiscal_class          rfc
        ON ril.classification_id        = rfc.classification_id

LEFT JOIN silver_{env}.ebs_apps.ap_supplier_sites_all          pvs
       ON rft.vendor_site_id  = pvs.vendor_site_id 

LEFT JOIN silver_{env}.ebs_apps.ap_suppliers                   pv
       ON pvs.vendor_id = pv.vendor_id        

LEFT JOIN silver_{env}.ebs_apps.mtl_system_items_b             msi
       ON ril.item_id         = msi.inventory_item_id
      AND ri.organization_id  = msi.organization_id


LEFT JOIN silver_{env}.ebs_apps.ym_cust_bill_of_lading_lines   yml
       ON ril.invoice_line_id  = yml.invoice_line_id

LEFT JOIN silver_{env}.ebs_apps.ym_cust_bill_of_lading         ym
       ON yml.document_id  = ym.document_id

LEFT JOIN silver_{env}.ebs_apps.fnd_user                       fu
       ON ri.created_by = fu.user_id

LEFT JOIN categoria
       ON msi.organization_id   = categoria.organization_id
      AND msi.inventory_item_id = categoria.inventory_item_id

LEFT JOIN categoria_custo
       ON msi.organization_id   = categoria_custo.organization_id
      AND msi.inventory_item_id = categoria_custo.inventory_item_id 
       
LEFT JOIN city                                               city_s
       ON ri.source_city_id = city_s.city_id

LEFT JOIN city                                               city_d
       ON ri.source_city_id = city_d.city_id

LEFT JOIN transportador                                      
       ON ym.entity_id = transportador.entity_id 

LEFT JOIN codigo_produto                                      
       ON ril.item_id = codigo_produto.inventory_item_id
      AND ri.organization_id = codigo_produto.organization_id

LEFT JOIN cliente_yamaha 
       ON rft.entity_id = cliente_yamaha.entity_id 

LEFT JOIN conta_contabil                                     rx
       ON ri.organization_id  = rx.organization_id 
      AND ri.location_id      =  rx.location_id
      AND ri.operation_id     = rx.operation_id 
      AND ril.invoice_line_id = rx.invoice_line_id
      AND rx.reference LIKE 'ITEM%'  

LEFT JOIN conta_contabil                                     conta_contabil_icms
       ON ri.organization_id  = conta_contabil_icms.organization_id 
      AND ri.location_id      =  conta_contabil_icms.location_id
      AND ri.operation_id     = conta_contabil_icms.operation_id 
      AND ril.invoice_line_id = conta_contabil_icms.invoice_line_id
      AND conta_contabil_icms.reference LIKE 'ICMS RECUP%'  

LEFT JOIN utlizacao                                          ritu
       ON ril.utilization_id = ritu.utilization_id  

LEFT JOIN conta_icms_ipi                                     rd
       ON ri.operation_id = rd.operation_id
      AND rd.reference           = 'ICMS A PAGAR'

LEFT JOIN conta_icms_ipi                                     
       ON ri.operation_id = conta_icms_ipi.operation_id
      AND conta_icms_ipi.reference   = 'IPI A PAGAR'

LEFT JOIN nf_remessa
       ON ril.attribute1 = nf_remessa.customer_trx_line_id

LEFT JOIN nf_remessa_tpa                               tret
       ON reo.organization_id = tret.organization_id 
      AND RIL.INVOICE_ID      = tret.INVOICE_ID
      AND ri.operation_id     = tret.OPERATION_ID
      AND ril.invoice_line_id = tret.INVOICE_LINE_ID 

LEFT JOIN nf_pai                                        rlx
       ON ri.invoice_parent_id = rlx.invoice_id

LEFT JOIN dpto
       ON SUBSTR(nvl(rx.conta_contabil, ' '), 5, 6)  = dpto.FLEX_VALUE_MEANING

LEFT JOIN local                                          hrl
       ON reo.location_id = hrl.location_id

LEFT JOIN nf_origem 
       ON ril.attribute14 = nf_origem.customer_trx_id

LEFT JOIN situacao_esp
       ON ri.operation_id = situacao_esp.operation_id 
WHERE 
    year(reo.receive_date) >= {anoFiltro} --2 anos retroativo + ano corrente
 """)


# COMMAND ----------

# MAGIC %md #### CASTING

# COMMAND ----------

prefixo = [
['organizacao', 'ds'],
['tipo_op_fiscal', 'tp'],
['local', 'ds'],
['transacao', 'ds'],
['Transportador', 'ds'],
['fiscal_document_model', 'ds'],
['IND_SITUACAO_ESP', 'ds'],
['series', 'nr'],
['nome', 'nm'],
['codigo_nome', 'cd'],
['attribute7', 'ds'],
['numero_minuta', 'nr'],
['status_minuta', 'ds'],
['receive_date', 'dt'],
['conj_categoria', 'ds'],
['nivel_controle', 'ds'],
['incricao_estadual', 'ds'],
['tipo_segmento', 'tp'],
['conj_categoria_custo', 'ds'],
['cat_custo', 'ds'],
['classe', 'ds'],
['tipo_item', 'tp'],
['produto', 'ds'],
['origem', 'ds'],
['NCM', 'ds'],
['fornecedor', 'ds'],
['estado', 'ds'],
['cidade', 'ds'],
['CNPJ_CPF', 'ds'],
['inscr_estadual', 'ds'],
['cfo_code', 'cd'],
['natureza_operacao', 'ds'],
['quantidade', 'qt'],
['icms_base', 'vl'],
['desconto', 'vl'],
['icms', 'vl'],
['icms_tax', 'vl'],
['icms_st_base', 'vl'],
['icms_st', 'vl'],
['icms_arecuperar', 'vl'],
['icms_st_arecuperar', 'vl'],
['ipi_arecuperar', 'vl'],
['ipi', 'vl'],
['base_ipi', 'vl'],
['aliquota_ipi', 'vl'],
['diferencial_icms', 'vl'],
['uom', 'ds'],
['pis', 'vl'],
['pis_tx', 'vl'],
['base_pis', 'vl'],
['base_cofins', 'vl'],
['cofins_tax', 'vl'],
['cofins', 'vl'],
['pis_st', 'vl'],
['cofins_st', 'vl'],
['pis_importacao', 'vl'],
['cofins_importacao', 'vl'],
['tipo_documento', 'tp'],
['chave_de_acesso', 'ds'],
['chave_de_acesso_dacte', 'ds'],
['pis_st_tax', 'vl'],
['cofins_st_tax', 'vl'],
['pis_cofins_st_base', 'vl'],
['ir', 'vl'],
['iss', 'vl'],
['inss', 'vl'],
['conta_contabil', 'ds'],
['conta_contabil_icms', 'ds'],
['reversao', 'ds'],
['icms_amount_recover', 'vl'],
['utilizacao', 'ds'],
['icms_tax_code', 'cd'],
['ipi_tax_code', 'cd'],
['conta_icms', 'ds'],
['conta_ipi', 'ds'],
['emissao_nf', 'ds'],
['tipo_icms', 'tp'],
['sped_nf_origem', 'ds'],
['reversion_flag', 'fl'],
['nf_remessa', 'ds'],
['nf_remessa_TPA', 'ds'],
['nf_pai', 'nr'],
['sped_sit_trib_ipi', 'ds'],
['ipi_cod', 'cd'],
['pis_cod', 'cd'],
['cofins_cod', 'cd'],
['sped_sit_trib_cofins', 'ds'],
['pis_base', 'vl'],
['cofins_base', 'vl'],
['pis_tax_rate', 'vl'],
['cofins_tax_rate', 'vl'],
['DEPTO', 'ds'],
['UF_Orig', 'ds'],
['Cidade_Orig', 'ds'],
['IBGE_Orig', 'ds'],
['UF_Dest', 'ds'],
['Cidade_Dest', 'ds'],
['IBGE_Dest', 'ds'],
['rigem', 'ds'],
['CST_ICMS', 'ds'],
['DESCRICAO_XML', 'ds'],
['UNIDADE_XML', 'ds'],
['FROTA', 'ds'],
['PREVISAO_DE_ENTREGA', 'dt'],
['SEQ_ITEM', 'ds']
]

tipagens = [
['invoice_line_id', 'integer'],
['INVOICE_ID', 'integer'],
['vendor_site_id', 'integer'],
['org_id', 'integer'],
['organization_Id', 'integer'],
['nr_nf', 'integer'],
['nr_series', 'integer'],
['nr_recebimento', 'integer'],
['dt_sel', 'timestamp'],
['dt_manaus', 'timestamp'],
['dt_recebimento', 'timestamp'],
['dt_real', 'timestamp']

]

#aplica prefixo
for campo in prefixo:
    campoPrefixo = f'{campo[1]}_{campo[0]}'.lower()
    df_retorno_mercadoria = df_retorno_mercadoria.withColumnRenamed(campo[0], campoPrefixo)

#aplica tipagem
for campo in tipagens:
    df_retorno_mercadoria = df_retorno_mercadoria.withColumn(campo[0], col(campo[0]).cast(campo[1]))

#todos os campos em lera maiscula
for campo in df_retorno_mercadoria.columns:
    df_retorno_mercadoria = df_retorno_mercadoria.withColumnRenamed(campo, campo.upper())


# COMMAND ----------

# MAGIC %md ### GOLD LAYER WRITING

# COMMAND ----------

table = f"{param_catalogo_gold}.{param_schema}.{param_nome_tabela_gold}"

print(f"Escrevendo a tabela {table}")

(
    df_retorno_mercadoria
    .write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .partitionBy("YEAR","MONTH")
    .saveAsTable(table)
)

# optimization Gold layer
optimize_delta_table(table)