# Databricks notebook source
# MAGIC %md
# MAGIC ### Relatorio:  `YM_5522_1`
# MAGIC ### Assunto:    `Resumo Dos Impostos sobre Faturamento`
# MAGIC ### Criado Por: `Caio Francisco`
# MAGIC ### Data:       `08-08-2025` 

# COMMAND ----------

# DBTITLE 1,Import de bibliotecas
import os
from pyspark.sql.functions import * 
from pyspark.sql.types import *
from delta.tables import *
from datetime import datetime

# COMMAND ----------

# DBTITLE 1,Criação de método para otimizar delta table
def optimize_delta_table(table_name):
    """
        @param: IN table_path
        Run optimization commands and old snapshots
        Full load
    """
    deltaTable = DeltaTable.forName(spark, table_name)
    deltaTable.vacuum()
    deltaTable.optimize().executeCompaction()
    print('Delta table optimized.') 

# COMMAND ----------

# Ambiente
env = os.environ.get("DATABRICKS_ENV").lower()

# Catalogo, Schema e Nome da tabela
param_catalogo_gold = f"gold_{env}"
param_schema = "fiscal_tributario"
param_nome_tabela_gold = 'fiscal_tributario_resumo_impostos_sobre_faturamento'
anoFiltro = (datetime.now().year - 3)

print(f"Tabela: {param_catalogo_gold}.{param_schema}.{param_nome_tabela_gold}")


# COMMAND ----------

df_resumo_impostos_faturamento = spark.sql(f""" 
with categoria as (
  select 
          mic.category_set_name  conj_categoria,
          mic.control_level_disp nivel_controle,
          mic.segment2           incricao_estadual,
          mic.segment3           tipo_segmento,
          cast(msi.organization_id as integer),
          cast(msi.inventory_item_id as integer)

  FROM        silver_{env}.ebs_apps.mtl_system_items_b msi
  INNER JOIN  silver_{env}.ebs_apps.mtl_item_categories_v mic
          on  cast(msi.inventory_item_id as integer) = mic.inventory_item_id
        and  cast(msi.organization_id as integer) = mic.organization_id
  WHERE 
        mic.category_set_name = 'Resolucao 16'
),
categoria_custo as (
  select 
        mic.category_set_name conj_categoria_custo,
        mic.CATEGORY_CONCAT_SEGS  cat_custo,
        cast(msi.organization_id as integer),
        cast(msi.inventory_item_id as integer)

  FROM        silver_{env}.ebs_apps.mtl_system_items_b msi
  INNER JOIN  silver_{env}.ebs_apps.mtl_item_categories_v mic
          on  cast(msi.inventory_item_id as integer) = mic.inventory_item_id
        and  cast(msi.organization_id as integer) = mic.organization_id
  WHERE 
        mic.category_set_name = 'Custos'
),
ncm as (
    select 
           mic.organization_id
          ,mic.inventory_item_id
          ,mc.segment1

    from       silver_{env}.ebs_apps.mtl_item_categories_v mic
    inner join silver_{env}.ebs_apps.mtl_category_sets_b   mcs
            on mic.category_set_id = mcs.category_set_id
    inner join silver_{env}.ebs_apps.mtl_category_sets_tl  mcst
            on mcst.category_set_id = mcs.category_set_id
    inner join silver_{env}.ebs_apps.mtl_categories_b      mc
            on mc.category_id = mic.category_id
    where 
          mcst.language = 'PTB'
      and  mcst.category_set_name = 'FISCAL_CLASSIFICATION'
      and nvl(date(mc.disable_date), date(now())) >= date(now())  
),
cte_dcre_nota as (
  select 
        customer_trx_line_id
        ,codigo_nf
        ,decode(instr(l.prod_inf_adic, 'DCR'), 0, null, substr(l.prod_inf_adic, instr(l.prod_inf_adic, 'DCR') + 7, 12) ) dcre_nota

  from silver_{env}.ebs_ym.ym_nfe_tab_line l 
),
cte_ncm_nota as (
  select customer_trx_id
        ,customer_trx_line_id
        ,nvl(rctl1.global_attribute2, ' ') ncm_nota
  from silver_{env}.ebs_apps.ra_customer_trx_lines_all  rctl1
  where 
        rctl1.line_type = 'LINE'
),
cte_conta_icms_st as (
  select
        rgl.customer_trx_line_id
      , gcc.segment3
      ,(
          gcc.segment1||'-'||
          gcc.segment2||'-'||
          gcc.segment3||'-'||
          gcc.segment4||'-'||
          gcc.segment5||'-'||
          gcc.segment6||'-'||
          gcc.segment7||'-'||
          gcc.segment8||'-'||
          gcc.segment9||'-'||
          gcc.segment10
        )                      conta_icms_st

  from       silver_{env}.ebs_ar.ra_cust_trx_line_gl_dist_all rgl
  inner join silver_{env}.ebs_gl.gl_code_combinations         gcc
          on rgl.code_combination_id = gcc.code_combination_id 
  where 
        gcc.chart_of_accounts_id = 50261
  ),
cte_lista_preco as (
  select 
        oola.line_id
        ,qtl.name
  from        silver_{env}.ebs_apps.QP_LIST_HEADERS_TL qtl
  inner join  silver_{env}.ebs_apps.oe_order_lines_all oola
          on oola.price_list_id = qtl.list_header_id
  where qtl.language = 'PTB'
),
tipo_cliente as (
  select flvv.FLEX_VALUE
        ,(flvv.FLEX_VALUE || ' - ' || flvv.DESCRIPTION) tipo_cliente
  from silver_{env}.ebs_apps.FND_FLEX_VALUES_VL flvv
  where flvv.FLEX_VALUE_set_ID = 1007363
),
tipo as (
  select flvv.FLEX_VALUE
        ,(flvv.FLEX_VALUE || ' - ' || flvv.DESCRIPTION) tipo
  from silver_{env}.ebs_apps.FND_FLEX_VALUES_VL flvv
  where flvv.FLEX_VALUE_set_ID = 1007364
),
ym_ar_fnc_get_tax as (
  select distinct 
         tax_rate_id
        ,trx_line_id
        ,cast(global_attribute11 as integer)  global_attribute11
  from silver_{env}.ebs_zx.zx_lines
  where application_id = 222 
  and   entity_code = 'TRANSACTIONS'
)

SELECT  DISTINCT
       DECODE(rcta.org_id,
              84,              'YMB',
              85,              'YMA',
              86,              'YAC',
              133,             'YCA',
              295,             'YEB',
              379,             'YBL',
              579,             'YA3') empresa,

       case
       when rctla_line.warehouse_id = 90   and rctla_line.org_id = 85  Then 'YAF' 
       when rctla_line.warehouse_id = 89   and rctla_line.org_id  = 85 Then 'YA'
       when rctla_line.warehouse_id = 579  and rctla_line.org_id  = 85 Then 'YA3'
       when rctla_line.warehouse_id = 519  and rctla_line.org_id = 84  Then 'YB3' 
       when rctla_line.warehouse_id = 659  and rctla_line.org_id = 84  Then 'YB4'
       when rctla_line.warehouse_id = 679  and rctla_line.org_id = 84  Then 'YB6'
       when rctla_line.warehouse_id = 759  and rctla_line.org_id = 84  Then 'YB8'
       when rctla_line.warehouse_id = 739  and rctla_line.org_id = 85  Then 'YA5'
       when rctla_line.warehouse_id = 399  and rctla_line.org_id = 379 Then 'YL1'
       when rctla_line.warehouse_id = 419  and rctla_line.org_id = 379 Then 'YL2'
       when rctla_line.warehouse_id = 439  and rctla_line.org_id = 379 Then 'YL3'
       when rctla_line.warehouse_id = 459  and rctla_line.org_id = 379 Then 'YL4'
       when rctla_line.warehouse_id = 479  and rctla_line.org_id = 379 Then 'YL5'
       when rctla_line.warehouse_id = 499  and rctla_line.org_id = 379 Then 'YL6'
       when rctla_line.warehouse_id = 539  and rctla_line.org_id = 379 Then 'YL7'
       when rctla_line.warehouse_id = 559  and rctla_line.org_id = 379 Then 'YL8'
       when rctla_line.warehouse_id = 599  and rctla_line.org_id = 379 Then 'YL10'
       when rctla_line.warehouse_id = 619  and rctla_line.org_id = 379 Then 'YL9'
       when rctla_line.warehouse_id = 699  and rctla_line.org_id = 379 Then 'YL12'
       when rctla_line.warehouse_id = 779  and rctla_line.org_id = 379 Then 'YL13'
       when rctla_line.warehouse_id = 819  and rctla_line.org_id = 379 Then 'YL14'
       else
       DECODE(rctla_line.org_id,
              84,                 'YB',
              85,                 'YA',
              86,                 'YAC',
              133,                'YCA',
              295,                'YEB',
              379,                'YBL'
              )

       End filial,

       decode(rctla_line.warehouse_id,
              89,              'YA',
              579,             'YA3',
              91,              'YB',
              519,             'YB3',
              92,              'YAC',
              134,             'YCP',
              90,              'YAF',
              399,             'YL1',
              419,             'YL2',
              439,             'YL3',
              459,             'YL4',
              479,             'YL5',
              499,             'YL6',
              539,             'YL7',
              559,             'YL8',
              599,             'YL10',
              619,             'YL9',
              699,             'YL12',
              779,             'YL13',
              819,             'YL14',
              659,             'YB4',
              679,             'YB6',
              739,             'YA5',
              759,             'YB8',
              decode(rctla_line.org_id,
                     84,                     'YB',
                     85,                     'YA',
                     86,                     'YAC',
                     133,                    'YCA',
                     295,                    'YEB',
                     90,                     'YAF',
                     379,                    'YBL'
                     ) 
       ) UNIDADE,
       --rctla.customer_trx_line_id,
       rcta.trx_number nota,
       rbs.attribute2 serie,
       rbs.attribute3 ie_emitente,
       substr(msi.attribute2, 1, 10) dcre,
       l.dcre_nota,

       rcta.trx_DATE data,
       RAA.CITY CIDADE,
       RAA.STATE ESTADO,
       msi.segment1 cod_prod,
       DECODE(msi.global_attribute3,
              '1',   'IMP',
              '2',   'IMP',
              '0',   'NAC',
              '3',   'NAC',
              '4',   'NAC',
              '5',   'NAC',
              '6',   'IMP',
              '7',   'IMP'
       )                                         origem_PROD,
       
       --RCTLA_line.INVENTORY_ITEM_ID,RCTLA_LINE.WAREHOUSE_ID,
-- msi.description, rctla.description,
       nvl(msi.description, rctla.description) produto,  
       categoria.conj_categoria,
       categoria.nivel_controle,
       categoria.incricao_estadual,
       categoria.tipo_segmento,
       categoria_custo.conj_categoria_custo,
       categoria_custo.cat_custo,
       rctla_line.description descricao_nf,
       rctla_line.global_attribute3 origem,
       rctla_line.global_attribute4 origem_nf,
       nvl(ncm.segment1,' ') ncm,
       rctl1.ncm_nota,  
       msi.item_type,
       trim(RCTTA.DESCRIPTION) tipo_transacao,
       rctla_LINE.global_attribute1 CFOP,
       RCTTA.ATTRIBUTE2 NOP,
       NVL(RCTLA_line.EXTENDED_AMOUNT, 0) * nvl(rcta.exchange_rate, 1) vl_total_item,
       flvv.tipo_cliente,
       tipo.tipo,
       HP.PARTY_NAME NOME_CLIENTE,
       decode(RAA.GLOBAL_ATTRIBUTE2, '1', 'P.Fisica', '2', 'P.Juridica') Tipo_pessoa,

       DECODE(RAA.GLOBAL_ATTRIBUTE2, 
              '1',  
              RAA.GLOBAL_ATTRIBUTE3 || RAA.GLOBAL_ATTRIBUTE5,
              '2',
              RAA.GLOBAL_ATTRIBUTE3 || RAA.GLOBAL_ATTRIBUTE4 || RAA.GLOBAL_ATTRIBUTE5,
              RAA.GLOBAL_ATTRIBUTE3 || RAA.GLOBAL_ATTRIBUTE4 || RAA.GLOBAL_ATTRIBUTE5
       )                                                          CNPJ_CPF,
       replace(raa.global_attribute6,'.','')                            inscr_estadual,
       decode(rctla.line_type,                 
              'LINE', decode(rctla.attribute10, 
                            ',',  null,
                            '.',  null,
                            rctla.attribute10
                            ),
              0)                                                       vl_frete,

       decode(rctla.line_type,   
              'LINE', decode(rctla.attribute11,
                            ',',  null,
                            '.',  null,
                            rctla.attribute11
                            ),
              0)                                                       vl_seguro,
       (CASE

       when rctla.line_type = 'TAX' AND
              (VAT.tax_code NOT LIKE 'ICMS_ST%' AND
              VAT.tax_code NOT LIKE 'ICMS_DEST%'AND
              VAT.tax_code not like 'ICMS_PART%' AND
              VAT.tax_code not like 'ICMS_FCP%C') AND
              VAT.tax_code LIKE 'ICMS%C' 
       then
              NVL(RCTLA.TAX_RATE, 0)

       ELSE
       0

       END)                                                           aliq_icms,

       (CASE

       when rctla.line_type = 'TAX' AND
              (VAT.tax_code NOT LIKE 'ICMS_ST%' AND
              VAT.tax_code NOT LIKE 'ICMS_DEST%' AND
              VAT.tax_code not like 'ICMS_PART%' AND
              VAT.tax_code not like 'ICMS_FCP%C') AND 
              VAT.tax_code LIKE 'ICMS%C' 
       then
              NVL(RCTLA.EXTENDED_AMOUNT, 0)
       ELSE
              0

       END)                                                          vl_icms,
       (CASE
       when rctla.line_type = 'TAX' AND
              (
              VAT.tax_code NOT LIKE 'ICMS_ST%'   AND
              VAT.tax_code NOT LIKE 'ICMS_DEST%' AND
              VAT.tax_code not like 'ICMS_PART%' AND
              VAT.tax_code not like 'ICMS_FCP%C'
              )                                    AND 
              VAT.tax_code LIKE 'ICMS%C' 
       THEN
              nvl(tax.global_attribute11, 0)
       ELSE
              0
       END)                                                          vl_base_icms,

       (CASE

       when rctla.line_type = 'TAX'          AND
              (
              (VAT.tax_code LIKE 'ICMS_ST%C' AND VAT.tax_code not like 'ICMS_ST-FCP_%_C') 
                                                 OR
              VAT.tax_code LIKE 'ICMS_DEST%C' 
              ) 
       then
              NVL(RCTLA.TAX_RATE, 0)
       ELSE
       0
       END)                                                           aliq_icms_st,
       (CASE

       when rctla.line_type = 'TAX' AND((VAT.tax_code LIKE 'ICMS_ST%C' and VAT.tax_code not like 'ICMS_ST-FCP_%_C' ) or

              VAT.tax_code LIKE 'ICMS_DEST%C' ) then

       NVL(RCTLA.EXTENDED_AMOUNT, 0)
       ELSE
       0
       END)                                                            vl_icms_st,
       (CASE

       when rctla.line_type = 'TAX' AND((VAT.tax_code LIKE 'ICMS_ST%C' and VAT.tax_code not like 'ICMS_ST-FCP_%_C' ) or

              VAT.tax_code LIKE 'ICMS_DEST%C' ) 
       then
       nvl(rgl.conta_icms_st, 0)

       ELSE
       null

       END)                                                            conta_icms_st,
       (CASE

       when rctla.line_type = 'TAX' AND

              VAT.tax_code  LIKE 'ICMS_PART_ORIG%C' 

       THEN
       nvl(tax.global_attribute11, 0)
       ELSE
       0
       END)                                                            vl_base_icms_part_orig,
       (CASE

       when rctla.line_type = 'TAX' AND vat.tax_code LIKE 'ICMS_PART_ORIG%C' then

       NVL(RCTLA.TAX_RATE, 0)

       ELSE

       0

       END) icms_part_orig,

       (CASE

       when rctla.line_type = 'TAX' AND (VAT.tax_code LIKE 'ICMS_PART_ORIG%C') then

       NVL(RCTLA.EXTENDED_AMOUNT, 0)

       ELSE

       0

       END) vl_icms_part_orig,

       (CASE

       when rctla.line_type = 'TAX' AND VAT.tax_code  LIKE 'ICMS_PART_DEST_%C'
       THEN
       nvl(tax.global_attribute11, 0)
       ELSE
       0
       END) vl_base_icms_part_dest,
       (CASE

       when rctla.line_type = 'TAX' AND VAT.tax_code LIKE 'ICMS_PART_DEST_%C' then nvl(rgl.conta_icms_st,0)
       ELSE
       null

       END) conta_icms_part_dest,

       (CASE

       when rctla.line_type = 'TAX' AND VAT.tax_code  LIKE 'ICMS_FCP%C' THEN nvl(tax.global_attribute11, 0)
       ELSE
       0
       END) vl_base_icms_fcp,

       (CASE

       when rctla.line_type = 'TAX' AND vat.tax_code LIKE 'ICMS_FCP%C'  then  NVL(RCTLA.TAX_RATE, 0)
       ELSE
       0
       END) icms_fcp,
       (CASE

       when rctla.line_type = 'TAX' AND VAT.tax_code LIKE 'ICMS_FCP%C' then NVL(RCTLA.EXTENDED_AMOUNT, 0)
       ELSE
       0
       END) vl_icms_fcp,
       (CASE

       when  rctla.line_type = 'TAX' AND (VAT.tax_code LIKE 'ICMS_FCP%C') then nvl(rgl.conta_icms_st,0)
       ELSE
       null 
       END) conta_icms_fcp,
       (CASE

       when rctla.line_type = 'TAX' AND (VAT.tax_code LIKE 'ICMS_ST%C' or VAT.tax_code LIKE 'ICMS_DEST%C') 
       then nvl(tax.global_attribute11, '0')
       ELSE
       0

       END) vl_base_st,

       (CASE

       when rctla.line_type = 'TAX' AND vat.tax_code LIKE 'REMESSA%C' then

       NVL(RCTLA.EXTENDED_AMOUNT, 0)

       ELSE

       0

       END) vl_icms_rem,

       

       (CASE

       when rctla.line_type = 'TAX' AND

              vat.tax_code LIKE 'DESCONTO_ICMS%C' then

       NVL(RCTLA.EXTENDED_AMOUNT, 0)

       ELSE

       0

       END) vl_icms_desc,

       (CASE

       when rctla.line_type = 'TAX' AND

              (VAT.tax_code LIKE 'PIS_P%C' OR VAT.tax_code LIKE 'PIS_SU%C' OR VAT.tax_code LIKE 'PIS_SERV%TRANSP%C') then

       NVL(RCTLA.EXTENDED_AMOUNT, 0)

       ELSE

       0

       END) vl_pis,

       (CASE

       when rctla.line_type = 'TAX' AND vat.tax_code LIKE 'PIS_ST%C' then

       NVL(RCTLA.EXTENDED_AMOUNT, 0)

       ELSE

       0

       END) vl_pis_st,

       (CASE

       when rctla.line_type = 'TAX' AND vat.tax_code LIKE 'PIS_SERV_PJ%C' then

       NVL(RCTLA.EXTENDED_AMOUNT, 0)

       ELSE

       0

       END) vl_pis_serv_PJ,

       (CASE

       when rctla.line_type = 'TAX' AND (vat.tax_code LIKE 'COFINS_P%C' OR

              VAT.tax_code LIKE 'COFINS_SU%C' or VAT.tax_code LIKE 'COFINS_SERV%TRANSP%C') then

       NVL(RCTLA.EXTENDED_AMOUNT, 0)

       ELSE

       0

       END) vl_cofins,

       (CASE

       when rctla.line_type = 'TAX' AND vat.tax_code LIKE 'COFINS_ST%C' then

       NVL(RCTLA.EXTENDED_AMOUNT, 0)

       ELSE

       0

       END) vl_cofins_st,

       (CASE

       when rctla.line_type = 'TAX' AND vat.tax_code LIKE 'IPI%C' then

       NVL(RCTLA.EXTENDED_AMOUNT, 0)

       ELSE

       0

       END) vl_ipi,

       (CASE

       when rctla.line_type = 'TAX' AND vat.tax_code LIKE 'FTI%C' then

       NVL(RCTLA.EXTENDED_AMOUNT, 0)

       ELSE

       0

       END) vl_fti,

       (CASE

       when rctla.line_type = 'TAX' AND vat.tax_code LIKE 'UEA%C' then

       NVL(RCTLA.EXTENDED_AMOUNT, 0)

       ELSE

       0

       END) vl_uea,

       (CASE

       when rctla.line_type = 'TAX' AND vat.tax_code LIKE 'IPI%C' then

       NVL(RCTLA.TAX_RATE, 0)

       ELSE

       0

       END) aliq_ipi,

       (CASE

       when rctla.line_type = 'TAX' AND vat.tax_code LIKE 'PIS%C' then

       NVL(RCTLA.TAX_RATE, 0)

       ELSE

       0

       END) aliq_pis,

       (CASE

       when rctla.line_type = 'TAX' AND vat.tax_code LIKE 'COFINS%C' then

       NVL(RCTLA.TAX_RATE, 0)

       ELSE

       0

       END) aliq_cofins,

       RCTA.STATUS_TRX status_nf,

       msi.attribute_category || '- Código: ' || msi.attribute3 modelo,

       (CASE

       when rctla.line_type = 'TAX' AND (VAT.tax_code LIKE 'ICMS_OPPJ%D') then nvl(rgl.segment3,       0)

       ELSE
       ' '

       END)                                                       conta_icms,
       (CASE
       when rctla.line_type = 'TAX' AND vat.tax_code LIKE 'IPI%D' then nvl(rgl.segment3,       0)
       ELSE
       '  '
       END)                                                       conta_ipi,
       decode(rcta.fob_point,
              'BUY',   'DESTINATARIO',
              'SEL',   'EMITENTE',
              rcta.interface_header_attribute2
       )                                                    modo_frete,

       vat.tax_code,
       rtl.name                                                   condicao_pagamento,
       cte_lista_preco.name                                       lista_preco,
       rctla_line.uom_code                                        uom,
       (CASE

       when rctla.line_type = 'LINE' then

       (NVL(RCTLA.EXTENDED_AMOUNT, 0)) * nvl(rcta.exchange_rate, 1)

       ELSE

       0

       END) vl_nota,

       (CASE

       when rctla.line_type = 'LINE' and

              nfet.prod_quantidade_com is not null then

       nfet.prod_quantidade_com

       when rctla.line_type = 'LINE' then

       NVL(RCTLA.Quantity_Invoiced, 0)

       ELSE

       0

       END) quantidade,

       (CASE

       when rctla.line_type = 'LINE' then

       (nvl(abs(rctla.gross_extended_amount), abs(rctla.extended_amount)) -
       (nvl(rctla.attribute10, 0)) --    frete_linha
       - (nvl(rctla.attribute11, 0)) --  seguro_linha
       ) * nvl(rcta.exchange_rate, 1)
       ELSE
       0

       END) vl_produto,

       nfet.COFINS_CST,
       nfet.PIS_CST,
       nfet.IPI_CST,
       nfet.ICMS_CST,
       --rctla_line.inventory_item_id,
       jjb.electronic_inv_access_key chave_acesso,
       RCTLA.line_type,
       rctta.attribute12 sit_trib_federal,
       rctta.attribute10 sit_trib_estadual,
       TL.prod_cest      cod_cest,
       msi.Global_Attribute4 tipo_item
       ,cte.ide_uf_ini        UF_Orig
       ,cte.ide_municipio_ini Cidade_Orig
       ,cte.ide_cod_ibge_mun_ini IBGE_Orig
       ,cte.ide_uf_fim           UF_Dest
       ,cte.ide_municipio_fim    Cidade_Dest
       ,cte.ide_cod_ibge_mun_fim IBGE_Dest
       ,msi.unit_weight peso
       ,msi.weight_uom_code und
       ,hca.attribute9 Tipo_Tribut_Faturamento
       ,(CASE
       when rctla.line_type = 'TAX' AND (VAT.tax_code  LIKE 'FCP%ST%C' OR VAT.tax_code  LIKE 'ICMS%ST%FCP%C' 
       OR VAT.tax_code  LIKE '%FECOP_PR%C') 
       THEN 
       nvl(tax.global_attribute11, 0)
       ELSE
       0
       END) vl_base_icms_st_fcp,
       (CASE
       when rctla.line_type = 'TAX' AND (vat.tax_code LIKE 'FCP%ST%C' OR VAT.tax_code LIKE 'ICMS%ST%FCP%C' OR VAT.tax_code  LIKE '%FECOP_PR%C')
       then
       NVL(RCTLA.TAX_RATE, 0)
       ELSE
       0
       END) icms_st_fcp,
       (CASE
       when rctla.line_type = 'TAX' AND (VAT.tax_code LIKE 'FCP%ST%C' OR VAT.tax_code LIKE 'ICMS%ST%FCP%C' OR VAT.tax_code  LIKE '%FECOP_PR%C') 
       then
       NVL(RCTLA.EXTENDED_AMOUNT, 0)
       ELSE
       0
       END) vl_icms_st_fcp,
       (CASE

       when rctla.line_type = 'TAX' AND (VAT.tax_code LIKE 'FCP%ST%C' 
                                   OR   VAT.tax_code LIKE 'ICMS%ST%FCP%C' 
                                   OR   VAT.tax_code LIKE '%FECOP_PR%C') 
       then
       nvl(rgl.conta_icms_st, 0)

       ELSE
       null
       END) conta_icms_st_fcp,
       
       (CASE

       when rctla.line_type = 'LINE' and

              nfet.prod_quantidade_com is not null then

       nfet.prod_quantidade_com

       when rctla.line_type = 'LINE' then

       NVL(RCTLA.Quantity_Invoiced, 0)

       ELSE

       0

       END) qtd_format
,   (CASE
       when rctla.line_type = 'LINE' and
              nfet.PROD_VALOR_DESC is not null then
              nfet.PROD_VALOR_DESC
       ELSE
       0
       END) vl_desc,
       year(rcta.trx_DATE)         YEAR,
       month(rcta.trx_DATE)        MONTH
      -- ,rctla_line.interface_line_attribute6  

FROM        silver_{env}.ebs_apps.HZ_PARTIES                   HP
INNER JOIN  silver_{env}.ebs_apps.HZ_CUST_ACCOUNTS             HCA
       ON  HP.PARTY_ID = HCA.PARTY_ID
INNER JOIN  silver_{env}.ebs_apps.RA_CUSTOMER_TRX_ALL          RCTA
       ON  HCA.CUST_ACCOUNT_ID = RCTA.BILL_TO_CUSTOMER_ID
INNER JOIN  silver_{env}.ebs_apps.HZ_CUST_SITE_USES_ALL        HCSUA
       ON  RCTA.BILL_TO_SITE_USE_ID = HCSUA.SITE_USE_ID
INNER JOIN  silver_{env}.ebs_apps.YM_RA_SITE_USES_V            RSUA
       ON  HCSUA.SITE_USE_ID = RSUA.SITE_USE_ID
INNER JOIN  silver_{env}.ebs_apps.YM_RA_ADDRESSES_V            RAA
       ON  RSUA.ADDRESS_ID = RAA.ADDRESS_ID
INNER JOIN  silver_{env}.ebs_apps.RA_CUSTOMER_TRX_LINES_ALL    RCTLA
       ON  RCTA.CUSTOMER_TRX_ID = RCTLA.CUSTOMER_TRX_ID
       AND  nvl(RCTLA.EXTENDED_AMOUNT, 0) <> 0
INNER JOIN  silver_{env}.ebs_apps.RA_CUST_TRX_TYPES_ALL        RCTTA
       ON  RCTA.CUST_TRX_TYPE_ID = RCTTA.CUST_TRX_TYPE_ID
INNER JOIN  silver_{env}.ebs_apps.RA_CUSTOMER_TRX_LINES_ALL    RCTLA_line
       ON  nvl(rctla.link_to_cust_trx_line_id, 
              rctla.customer_trx_line_id)  = rctla_line.customer_trx_line_id    
INNER JOIN  silver_{env}.ebs_apps.ra_batch_sources_all         rbs
       ON  rbs.batch_source_id = rcta.batch_source_id
INNER JOIN  silver_{env}.ebs_apps.ra_terms_tl                  rtl
       ON  rtl.term_id = rcta.term_id

LEFT JOIN  silver_{env}.ebs_apps.MTL_SYSTEM_ITEMS_B            MSI
       ON RCTLA_line.INVENTORY_ITEM_ID = MSI.INVENTORY_ITEM_ID
       AND RCTLA_LINE.WAREHOUSE_ID = MSI.ORGANIZATION_ID
LEFT JOIN  silver_{env}.ebs_ym.ym_nfe_tab_line                 nfet
       ON rctla.customer_trx_line_id = nfet.customer_trx_line_id
       AND rctla.customer_trx_id      = nfet.codigo_nf
LEFT JOIN  silver_{env}.ebs_apps.ar_vat_tax_all                vat
       ON rctla.vat_tax_id = vat.vat_tax_id
LEFT JOIN  silver_{env}.ebs_apps.jl_br_customer_trx_exts       jjb
       ON  rcta.customer_trx_id = jjb.customer_trx_id
LEFT JOIN  silver_{env}.ebs_apps.ra_territories                rt
       ON  hcsua.territory_id = rt.territory_id
LEFT JOIN  silver_{env}.ebs_apps.ym_tms_vw_conhecimento        cte
       ON  rctla.interface_line_attribute1 = cte.conhecimento_id
       AND  rctla.interface_line_attribute2 = cte.control_id

LEFT JOIN  categoria
       ON msi.organization_id   = categoria.organization_id
       AND msi.inventory_item_id = categoria.inventory_item_id

LEFT JOIN  categoria_custo
       ON msi.organization_id   = categoria_custo.organization_id
       AND msi.inventory_item_id = categoria_custo.inventory_item_id

LEFT JOIN  ncm
       ON  msi.organization_id   = ncm.organization_id
       AND  msi.inventory_item_id = ncm.inventory_item_id


LEFT JOIN cte_dcre_nota                                      l
       ON rcta.customer_trx_id                 = l.codigo_nf
       AND nvl(rctla.link_to_cust_trx_line_id, 
              rctla.customer_trx_line_id)      = l.customer_trx_line_id 
LEFT JOIN cte_ncm_nota                                       rctl1
       ON rcta.customer_trx_id                 = rctl1.customer_trx_id
       AND nvl(rctla.link_to_cust_trx_line_id, 
              rctla.customer_trx_line_id)      = rctl1.customer_trx_line_id
LEFT JOIN tipo_cliente                                       flvv
       ON raa.attribute2 = flvv.FLEX_VALUE
LEFT JOIN tipo                                       
       ON raa.attribute3 = tipo.FLEX_VALUE

LEFT JOIN ym_ar_fnc_get_tax tax
       ON   rctla.link_to_cust_trx_line_id = tax.trx_line_id
AND   rctla.vat_tax_id = tax.tax_rate_id

LEFT JOIN cte_conta_icms_st                                  rgl
       ON rctla.customer_trx_line_id = rgl.customer_trx_line_id

LEFT JOIN cte_lista_preco
       ON rctla_line.interface_line_attribute6 = cte_lista_preco.line_id

LEFT JOIN silver_{env}.ebs_ym.ym_nfe_tab_line               TL
       ON RCTLA_line.CUSTOMER_TRX_LINE_ID = tl.customer_trx_line_id

WHERE 
    year(rcta.trx_DATE) >= {anoFiltro} --2 anos retroativo + ano corrente
--AND month(rcta.trx_DATE) = 1
AND RCTA.STATUS_TRX      = 'OP'
AND RCTA.COMPLETE_FLAG   = 'Y'
AND RCTTA.TYPE           = 'INV'
AND rtl.language         = 'PTB'
AND rctla.line_type     IN ('LINE', 'TAX')
 """)


# COMMAND ----------

# MAGIC %md #### CASTING

# COMMAND ----------

prefixo = [
['empresa',  'ds'],
['filial',  'ds'],
['UNIDADE',  'ds'],
['nota',  'nr'],
['serie',  'nr'],
['ie_emitente',  'ds'],
['dcre',  'ds'],
['dcre_nota',  'ds'],
['data',  'dt'],
['CIDADE',  'ds'],
['ESTADO',  'ds'],
['cod_prod',  'cd'],
['origem_PROD',  'ds'],
['produto',  'ds'],
['conj_categoria',  'ds'],
['nivel_controle',  'ds'],
['incricao_estadual',  'ds'],
['tipo_segmento',  'tp'],
['conj_categoria_custo',  'ds'],
['cat_custo',  'ds'],
['descricao_nf',  'ds'],
['origem',  'ds'],
['origem_nf',  'nr'],
['ncm',  'nr'],
['ncm_nota',  'nr'],
['item_type',  'tp'],
['tipo_transacao',  'tp'],
['CFOP',  'nr'],
['NOP',  'nr'],
['tipo_cliente',  'tp'],
['tipo',  'tp'],
['NOME_CLIENTE',  'nm'],
['Tipo_pessoa',  'tp'],
['CNPJ_CPF',  'ds'],
['inscr_estadual',  'ds'],
['status_nf',  'ds'],
['modelo',  'ds'],
['conta_icms',  'ds'],
['conta_ipi',  'ds'],
['modo_frete',  'ds'],
['tax_code',  'ds'],
['condicao_pagamento',  'ds'],
['lista_preco',  'ds'],
['uom',  'ds'],
['quantidade',  'qt'],
['COFINS_CST',  'ds'],
['PIS_CST',  'ds'],
['IPI_CST',  'ds'],
['ICMS_CST',  'ds'],
['chave_acesso',  'ds'],
['line_type',  'tp'],
['sit_trib_federal',  'nr'],
['sit_trib_estadual',  'nr'],
['cod_cest',  'cd'],
['tipo_item',  'tp'],
['UF_Orig',  'ds'],
['Cidade_Orig',  'ds'],
['IBGE_Orig',  'ds'],
['UF_Dest',  'ds'],
['Cidade_Dest',  'ds'],
['IBGE_Dest',  'ds'],
['peso',  'vl'],
['und',  'ds'],
['Tipo_Tribut_Faturamento',  'tp'],
['conta_icms_st_fcp',  'ds'],
['qtd_format',  'qt']
]

tipagens = [
['nr_nota',  'integer'],
['nr_serie',  'integer'],
['nr_origem_nf',  'integer'],
['nr_ncm',  'integer'],
['nr_ncm_nota',  'integer'],
['nr_CFOP',  'integer'],
['nr_NOP',  'integer'],
['qt_quantidade',  'integer'],
['nr_sit_trib_federal',  'integer'],
['nr_sit_trib_estadual',  'integer'],
['ds_IBGE_Orig',  'string'],
['ds_UF_Dest',  'string'],
['ds_Cidade_Dest',  'string'],
['vl_peso',  'double'],
['vl_icms_st_fcp',  'double']
]

#aplica prefixo
for campo in prefixo:
    campoPrefixo = f'{campo[1]}_{campo[0]}'.lower()
    df_resumo_impostos_faturamento = df_resumo_impostos_faturamento.withColumnRenamed(campo[0], campoPrefixo)

#aplica tipagem
for campo in tipagens:
    df_resumo_impostos_faturamento = df_resumo_impostos_faturamento.withColumn(campo[0], col(campo[0]).cast(campo[1]))

#todos os campos em lera maiscula
for campo in df_resumo_impostos_faturamento.columns:
    df_resumo_impostos_faturamento = df_resumo_impostos_faturamento.withColumnRenamed(campo, campo.upper())


# COMMAND ----------

# MAGIC %md ### GOLD LAYER WRITING

# COMMAND ----------

table = f"{param_catalogo_gold}.{param_schema}.{param_nome_tabela_gold}"

print(f"Escrevendo a tabela {table}")

(
    df_resumo_impostos_faturamento
    .write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .partitionBy("YEAR","MONTH")
    .saveAsTable(table)
)

# optimization Gold layer
optimize_delta_table(table)
