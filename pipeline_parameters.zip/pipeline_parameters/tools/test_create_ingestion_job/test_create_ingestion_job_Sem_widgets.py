# Databricks notebook source
# MAGIC %md
# MAGIC #### Executar teste unitários de criação ou alteração de jobs

# COMMAND ----------

import os, json
from packaging.version import Version

# COMMAND ----------

# DBTITLE 1,Função para pegar a versão recente do create_ing
def get_notebook_create_ingestion_job():
    try:
        folder = os.getcwd().split("/sources/pipeline_parameters/tools/test_create_ingestion_job")[0]
        folder += "/framework/"
        prefix = "create_ingestion_job-"

        matching_files = [
            f for f in os.listdir(folder)
            if os.path.isfile(os.path.join(folder, f)) and f.startswith(prefix)
        ]
        
        # Pega a versão mais recente do notebook que cria os jobs
        latest_version = max(matching_files, key=lambda x: Version(x.split('-')[-1]))
        folder += latest_version

    except Exception as e:
        print(e)
        folder = ""
    return folder

# COMMAND ----------

# DBTITLE 1,Parâmetro para o teste unitário
branch = "feat/modelo_bronze_part_diaria_grupo_1" # Obrigatório

# Nomes dos arquivos YAML a serem filtrados (informe nome e extensão)
files_filter = ["campanha.yaml", "campanhapecarequisicao.yaml", "campanhapecascrap.yaml"] 

print(f"Branch selecionada: {branch}")
print(f"Files filter: {files_filter}")

# COMMAND ----------

# DBTITLE 1,Executa notebook para criação de jobs
notebook_path = get_notebook_create_ingestion_job()

print("Notebook para processamento:")
print(notebook_path)

if notebook_path != "":
    try:
        if branch != "":
            if not isinstance(files_filter,list):
                files_filter = []

            params = {"branch": branch
                     ,"files_filter": str(files_filter) }

            print("Parametros:")
            print(params)
            
            dbutils.notebook.run(notebook_path
                                ,timeout_seconds = 300
                                ,arguments = params)
        else:
            print('Informe a brach a ser processado.')
    except Exception as e:
        print("Falha ao processar parametros")
        print(e)
else:
    print("Não foi possível identificar o notebook de criação de job's")

# COMMAND ----------

# DBTITLE 1,Verificar na tabela de log o status criação/atualização do Job
# MAGIC %sql
# MAGIC Select log_date, log_status, table_name, schedule, job_name, message
# MAGIC   from controls_dev.loads.create_ingestion_job_log log
# MAGIC  where 1=1
# MAGIC    and log_date  >= current_date()
# MAGIC    and user_email = current_user()
# MAGIC  order by log_date desc

# COMMAND ----------


