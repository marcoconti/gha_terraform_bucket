# Databricks notebook source
# MAGIC %md
# MAGIC #### Executar teste isolado de criação do job

# COMMAND ----------

import os, json
from packaging.version import Version

# COMMAND ----------

def get_notebook_create_ingestion_job():
    try:
        folder = os.getcwd().split("/sources/pipeline_parameters/tools/test_create_ingestion_job")[0]
        folder += "/framework/"
        prefix = "create_ingestion_job-"

        matching_files = [
            f for f in os.listdir(folder)
            if os.path.isfile(os.path.join(folder, f)) and f.startswith(prefix)
        ]
        
        # Pega a versão mais recente do notebook que cria os jobs
        latest_version = max(matching_files, key=lambda x: Version(x.split('-')[-1]))
        folder += latest_version

    except Exception as e:
        print(e)
        folder = ""
    return folder

# COMMAND ----------

# DBTITLE 1,Parâmetro para o teste unitário
dbutils.widgets.text(
    name        = "branch",
    defaultValue= "dev",
    label       = "Nome da branch (obrigatório)"
)

dbutils.widgets.text(
    name        = "files_filter",
    defaultValue= "",
    label       = "Files filter (separe por vírgula)"
)

branch = dbutils.widgets.get("branch").strip()
if not branch:
    raise ValueError("O widget 'branch' é obrigatório e não pode ficar vazio.")

files_filter_raw = dbutils.widgets.get("files_filter")

# Converte string → lista, ignorando vazios e espaços
files_filter = [f.strip() for f in files_filter_raw.split(",") if f.strip()] \
            or [] # mantém [] se nada for informado

# — Agora use `branch` e `files_filter` normalmente no notebook —
print(f"Branch selecionada: {branch}")
print(f"Files filter: {files_filter}")

# COMMAND ----------

# DBTITLE 1,Executa notebook para criação de jobs
notebook_path = get_notebook_create_ingestion_job()

print("Notebook para processamento:")
print(notebook_path)

if notebook_path != "":
    try:
        if branch != "":
            if not isinstance(files_filter,list):
                files_filter = []

            params = {"branch": branch
                     ,"files_filter": str(files_filter) }

            print("Parametros:")
            print(params)
            
            dbutils.notebook.run(notebook_path
                                ,timeout_seconds = 300
                                ,arguments = params)
        else:
            print('Informe a brach  a ser processado.')
    except Exception as e:
        print("Falha ao processar parametros")
        print(e)
else:
    print("Não foi possível identificar o notebook de criação de job's")

# COMMAND ----------

# DBTITLE 1,Verificar na tabela de log o status criação/atualização do Job
# MAGIC %sql
# MAGIC Select *
# MAGIC   from controls_dev.loads.create_ingestion_job_log
# MAGIC  where 1=1
# MAGIC    and log_date  >= current_date()
# MAGIC    and user_email = current_user()
# MAGIC  order by log_date desc
