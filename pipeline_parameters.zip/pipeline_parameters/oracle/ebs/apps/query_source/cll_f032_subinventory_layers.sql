/* Foi necessario converter os valores de buy_quantity, make_quantity, issue_quantity, total_layer_quantity, intransit_quantity e total_intransit_quantity para string 
devido ao tamanho maximo do datatype */

SELECT 
subinventory_layer_id
,pac_period_id
,cost_group_id
,inventory_item_id
,organization_id
,subinventory_code
,to_char(buy_quantity) AS buy_quantity
,to_char(make_quantity) AS make_quantity
,to_char(issue_quantity) AS issue_quantity
,to_char(total_layer_quantity) AS total_layer_quantity
,last_update_date
,last_updated_by
,creation_date
,created_by
,request_id
,program_application_id
,program_id
,program_update_date
,last_update_login
,to_char(intransit_quantity) AS intransit_quantity
,to_char(total_intransit_quantity) AS total_intransit_quantity 
FROM apps.cll_f032_subinventory_layers 
WHERE CAST(last_update_date AS DATE) >= ADD_MONTHS(TRUNC(SYSDATE), -24)