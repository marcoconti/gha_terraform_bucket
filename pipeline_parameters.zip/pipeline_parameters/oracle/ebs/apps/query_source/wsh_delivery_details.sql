Select * from apps.wsh_delivery_details
 where last_update_date >= ADD_MONTHS(TRUNC(SYSDATE), -24) 
