select 
cast(BUSINESS_GROUP_ID as INTEGER) as BUSINESS_GROUP_ID
,cast(ORGANIZATION_ID as INTEGER) as ORGANIZATION_ID
,NAME
,DATE_FROM
,DATE_TO
from bronze_<env>.ebs_apps.hr_legal_entities