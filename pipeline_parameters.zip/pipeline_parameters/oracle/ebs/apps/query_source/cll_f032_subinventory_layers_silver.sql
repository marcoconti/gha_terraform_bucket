select
cast(subinventory_layer_id as INTEGER) as subinventory_layer_id
,cast(pac_period_id as INTEGER) as pac_period_id
,cast(cost_group_id as INTEGER) as cost_group_id
,cast(inventory_item_id as INTEGER) as inventory_item_id
,cast(organization_id as INTEGER) as organization_id
,subinventory_code
,buy_quantity
,make_quantity
,issue_quantity
,total_layer_quantity
,last_update_date
,last_updated_by
,creation_date
,created_by
,cast(request_id as INTEGER) as request_id
,cast(program_application_id as INTEGER) as program_application_id
,cast(program_id as INTEGER) as program_id
,program_update_date
,last_update_login
,intransit_quantity
,total_intransit_quantity 
from bronze_<env>.ebs_apps.cll_f032_subinventory_layers