Select *
  from apps.wsh_deliverables_v
 where last_update_date >= ADD_MONTHS(TRUNC(SYSDATE), -1) 
