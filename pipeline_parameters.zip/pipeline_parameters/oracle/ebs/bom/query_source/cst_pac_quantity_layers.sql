SELECT * FROM bom.cst_pac_quantity_layers 
WHERE CAST(last_update_date AS DATE) >= ADD_MONTHS(TRUNC(SYSDATE), -12)