# Databricks notebook source
from pyspark.sql.functions import year, month, day, col
from pyspark.sql.types import DecimalType, StringType, TimestampType
from datetime import datetime, timezone, timedelta, date
from git import Repo
import os, io, json, re

from datamax.commons import get_env
from datamax.date_processing import get_interval_bronze_dates
from datamax.table_infos import get_partitions_columns, get_lasts_partitions

# COMMAND ----------

# DBTITLE 1,Métodos e funções a serem utilizadas no processamento
def create_clone_git_repo(env, branch):
    """
        Cria um clone do repositório Git que será utilizado para carregar arquivos alterados e itens de configuração
    """
    token = dbutils.secrets.get(scope="git-token", key="token").strip()

    repo_path  = f"https://{token}@github.com/YMH-BR/data.git"
    timestamp  = int(datetime.now(timezone(timedelta(hours=-3))).timestamp())
    clone_path = f"/tmp/clone_ymhbr_data_variables_{timestamp}"

    if branch == "":
        branch = env if env == "dev" else "main"

    repo = Repo.clone_from(repo_path, clone_path, branch=branch)
    return repo, clone_path

def rmdir_clone_git_repo(clone_path):
    """
        Remove o diretório temporário usado para clonar o repositório
    """
    try:
        if os.path.exists(clone_path):
            import shutil
            shutil.rmtree(clone_path)
            print("Diretório temp para clone Git repo removido com sucesso")    
    except Exception as e:
        print(e)

def get_rdbms_connection(repo, rdbms, connect_name):
    """
        Cria a string de conexão para os bancos de dados relacionais
        rdbms disponívels Oracle, SQL-Server e MySQL
    """
    try:
        rdbms_drivers = {}
        rdbms_drivers["oracle"]    = "oracle.jdbc.OracleDriver"
        rdbms_drivers["sqlserver"] = "com.microsoft.sqlserver.jdbc.SQLServerDriver"
        rdbms_drivers["mysql"]     = "com.mysql.cj.jdbc.Driver"

        file_path = f"framework/db_connections/cn_{rdbms.replace('-','_').lower()}.json"
        last_commit = next(repo.iter_commits(paths=file_path, max_count=1))

        blob = None
        if last_commit is not None:
            blob = last_commit.tree / file_path
        
        if blob is None:
            print(f"Não foi possível encontrar o arquivo {file_path} no repositório.")
            return {}
        
        with io.BytesIO(blob.data_stream.read()) as f:
            variables = f.read().decode("utf-8")

        json_content = json.loads(variables)
        json_content = [cfg for cfg in json_content if cfg.get("connect_name") == connect_name][0]

        # Monta as infos de conexão de acordo com a necessidade do Framework
        db_connect_framework = {}

        rdbms = rdbms.lower()
        rdbms = re.sub(r'[^a-zA-Z]', '', rdbms)
        db_connect_framework["driver"] = rdbms_drivers[rdbms]

        server = json_content['server']
        port   = json_content['port']
        db     = json_content['database']

        if rdbms == "oracle":
            url = f"jdbc:oracle:thin:@//{server}:{port}/{db}"
        elif rdbms == "sqlserver":
            url = f"jdbc:sqlserver://{server}:{port};databaseName={db};encrypt=false"
        elif rdbms == "mysql":
            url = f"jdbc:mysql://{server}:{port}/{db}"

        db_connect_framework["url"]      = url
        db_connect_framework["user"]     = json_content['username']
        db_connect_framework["password"] = json_content['password']

        return db_connect_framework
    except Exception as e:
        print(f"Não foi possível carregar as configurações de conexão RDBMS do arquivo {file_path}.")
        return {}

def read_oracle(database_config, start_date, end_date, query_source):
    driver   = database_config["driver"]
    url      = database_config["url"]
    user     = database_config['user']

    info_get_pass = database_config['password']
    password      = dbutils.secrets.get(scope = info_get_pass['scope']
                                        ,key   = info_get_pass['secrect'])

    # Completa a query com as datas de filtro
    query_source = query_source.format(start_date=start_date, end_date=end_date) 

    # fetchsize = quantidade de linhas que o Driver traz de cada vez
    df_source = (
        spark.read.format('jdbc') \
            .option("inferSchema", "false")
            .option('driver', driver) \
            .option('url', url) \
            .option('trustServerCertificate', 'true')
            .option('fetchsize', '10000') \
            .option('user', user) \
            .option('password', password) \
            .option('dbtable', f'({query_source}) alias_table') \
            .option('numPartitions', 8) \
            .load()
    )
    return df_source


# COMMAND ----------

# DBTITLE 1,Variáveis
env = get_env()

# Seleciona os dados para conexão com o Oracle
branch = ("dev" if env == "dev" else "main")
clone_git_repo, clone_path  = create_clone_git_repo(env, branch)
db_connections = get_rdbms_connection(clone_git_repo, 'Oracle', 'cn_oracle_pebsn')
rmdir_clone_git_repo(clone_path)

# Tabela de destino
catalog = f"bronze_{env}"
schema  = "ebs_inv"
table   = "mtl_material_transactions"

# COMMAND ----------

# DBTITLE 1,Query a ser executada no Oracle
start_date   = ""
end_date     = ""
query_source = """
        Select to_char(TRANSACTION_ID) as TRANSACTION_ID
                ,LAST_UPDATE_DATE
                ,to_char(LAST_UPDATED_BY) as LAST_UPDATED_BY
                ,to_char(CREATION_DATE) as CREATION_DATE
                ,to_char(CREATED_BY) as CREATED_BY
                ,to_char(LAST_UPDATE_LOGIN) as LAST_UPDATE_LOGIN
                ,to_char(REQUEST_ID) as REQUEST_ID
                ,to_char(PROGRAM_APPLICATION_ID) as PROGRAM_APPLICATION_ID
                ,to_char(PROGRAM_ID) as PROGRAM_ID
                ,to_char(PROGRAM_UPDATE_DATE) as PROGRAM_UPDATE_DATE
                ,to_char(INVENTORY_ITEM_ID) as INVENTORY_ITEM_ID
                ,to_char(REVISION) as REVISION
                ,to_char(ORGANIZATION_ID) as ORGANIZATION_ID
                ,to_char(SUBINVENTORY_CODE) as SUBINVENTORY_CODE
                ,to_char(LOCATOR_ID) as LOCATOR_ID
                ,to_char(TRANSACTION_TYPE_ID) as TRANSACTION_TYPE_ID
                ,to_char(TRANSACTION_ACTION_ID) as TRANSACTION_ACTION_ID
                ,to_char(TRANSACTION_SOURCE_TYPE_ID) as TRANSACTION_SOURCE_TYPE_ID
                ,to_char(TRANSACTION_SOURCE_ID) as TRANSACTION_SOURCE_ID
                ,to_char(TRANSACTION_SOURCE_NAME) as TRANSACTION_SOURCE_NAME
                ,to_char(TRANSACTION_QUANTITY) as TRANSACTION_QUANTITY
                ,to_char(TRANSACTION_UOM) as TRANSACTION_UOM
                ,to_char(PRIMARY_QUANTITY) as PRIMARY_QUANTITY
                ,to_char(TRANSACTION_DATE) as TRANSACTION_DATE
                ,to_char(VARIANCE_AMOUNT) as VARIANCE_AMOUNT
                ,to_char(ACCT_PERIOD_ID) as ACCT_PERIOD_ID
                ,to_char(TRANSACTION_REFERENCE) as TRANSACTION_REFERENCE
                ,to_char(REASON_ID) as REASON_ID
                ,to_char(DISTRIBUTION_ACCOUNT_ID) as DISTRIBUTION_ACCOUNT_ID
                ,to_char(ENCUMBRANCE_ACCOUNT) as ENCUMBRANCE_ACCOUNT
                ,to_char(ENCUMBRANCE_AMOUNT) as ENCUMBRANCE_AMOUNT
                ,to_char(COST_UPDATE_ID) as COST_UPDATE_ID
                ,to_char(COSTED_FLAG) as COSTED_FLAG
                ,to_char(TRANSACTION_GROUP_ID) as TRANSACTION_GROUP_ID
                ,to_char(INVOICED_FLAG) as INVOICED_FLAG
                ,to_char(ACTUAL_COST) as ACTUAL_COST
                ,to_char(TRANSACTION_COST) as TRANSACTION_COST
                ,to_char(PRIOR_COST) as PRIOR_COST
                ,to_char(NEW_COST) as NEW_COST
                ,to_char(CURRENCY_CODE) as CURRENCY_CODE
                ,to_char(CURRENCY_CONVERSION_RATE) as CURRENCY_CONVERSION_RATE
                ,to_char(CURRENCY_CONVERSION_TYPE) as CURRENCY_CONVERSION_TYPE
                ,to_char(CURRENCY_CONVERSION_DATE) as CURRENCY_CONVERSION_DATE
                ,to_char(USSGL_TRANSACTION_CODE) as USSGL_TRANSACTION_CODE
                ,to_char(QUANTITY_ADJUSTED) as QUANTITY_ADJUSTED
                ,to_char(EMPLOYEE_CODE) as EMPLOYEE_CODE
                ,to_char(DEPARTMENT_ID) as DEPARTMENT_ID
                ,to_char(OPERATION_SEQ_NUM) as OPERATION_SEQ_NUM
                ,to_char(MASTER_SCHEDULE_UPDATE_CODE) as MASTER_SCHEDULE_UPDATE_CODE
                ,to_char(RECEIVING_DOCUMENT) as RECEIVING_DOCUMENT
                ,to_char(PICKING_LINE_ID) as PICKING_LINE_ID
                ,to_char(TRX_SOURCE_LINE_ID) as TRX_SOURCE_LINE_ID
                ,to_char(TRX_SOURCE_DELIVERY_ID) as TRX_SOURCE_DELIVERY_ID
                ,to_char(REPETITIVE_LINE_ID) as REPETITIVE_LINE_ID
                ,to_char(PHYSICAL_ADJUSTMENT_ID) as PHYSICAL_ADJUSTMENT_ID
                ,to_char(CYCLE_COUNT_ID) as CYCLE_COUNT_ID
                ,to_char(RMA_LINE_ID) as RMA_LINE_ID
                ,to_char(TRANSFER_TRANSACTION_ID) as TRANSFER_TRANSACTION_ID
                ,to_char(TRANSACTION_SET_ID) as TRANSACTION_SET_ID
                ,to_char(RCV_TRANSACTION_ID) as RCV_TRANSACTION_ID
                ,to_char(MOVE_TRANSACTION_ID) as MOVE_TRANSACTION_ID
                ,to_char(COMPLETION_TRANSACTION_ID) as COMPLETION_TRANSACTION_ID
                ,to_char(SHORTAGE_PROCESS_CODE) as SHORTAGE_PROCESS_CODE
                ,to_char(SOURCE_CODE) as SOURCE_CODE
                ,to_char(SOURCE_LINE_ID) as SOURCE_LINE_ID
                ,to_char(VENDOR_LOT_NUMBER) as VENDOR_LOT_NUMBER
                ,to_char(TRANSFER_ORGANIZATION_ID) as TRANSFER_ORGANIZATION_ID
                ,to_char(TRANSFER_SUBINVENTORY) as TRANSFER_SUBINVENTORY
                ,to_char(TRANSFER_LOCATOR_ID) as TRANSFER_LOCATOR_ID
                ,to_char(SHIPMENT_NUMBER) as SHIPMENT_NUMBER
                ,to_char(TRANSFER_COST) as TRANSFER_COST
                ,to_char(TRANSPORTATION_DIST_ACCOUNT) as TRANSPORTATION_DIST_ACCOUNT
                ,to_char(TRANSPORTATION_COST) as TRANSPORTATION_COST
                ,to_char(TRANSFER_COST_DIST_ACCOUNT) as TRANSFER_COST_DIST_ACCOUNT
                ,to_char(WAYBILL_AIRBILL) as WAYBILL_AIRBILL
                ,to_char(FREIGHT_CODE) as FREIGHT_CODE
                ,to_char(NUMBER_OF_CONTAINERS) as NUMBER_OF_CONTAINERS
                ,to_char(VALUE_CHANGE) as VALUE_CHANGE
                ,to_char(PERCENTAGE_CHANGE) as PERCENTAGE_CHANGE
                ,to_char(ATTRIBUTE_CATEGORY) as ATTRIBUTE_CATEGORY
                ,to_char(ATTRIBUTE1) as ATTRIBUTE1
                ,to_char(ATTRIBUTE2) as ATTRIBUTE2
                ,to_char(ATTRIBUTE3) as ATTRIBUTE3
                ,to_char(ATTRIBUTE4) as ATTRIBUTE4
                ,to_char(ATTRIBUTE5) as ATTRIBUTE5
                ,to_char(ATTRIBUTE6) as ATTRIBUTE6
                ,to_char(ATTRIBUTE7) as ATTRIBUTE7
                ,to_char(ATTRIBUTE8) as ATTRIBUTE8
                ,to_char(ATTRIBUTE9) as ATTRIBUTE9
                ,to_char(ATTRIBUTE10) as ATTRIBUTE10
                ,to_char(ATTRIBUTE11) as ATTRIBUTE11
                ,to_char(ATTRIBUTE12) as ATTRIBUTE12
                ,to_char(ATTRIBUTE13) as ATTRIBUTE13
                ,to_char(ATTRIBUTE14) as ATTRIBUTE14
                ,to_char(ATTRIBUTE15) as ATTRIBUTE15
                ,to_char(MOVEMENT_ID) as MOVEMENT_ID
                ,to_char(TASK_ID) as TASK_ID
                ,to_char(TO_TASK_ID) as TO_TASK_ID
                ,to_char(PROJECT_ID) as PROJECT_ID
                ,to_char(TO_PROJECT_ID) as TO_PROJECT_ID
                ,to_char(SOURCE_PROJECT_ID) as SOURCE_PROJECT_ID
                ,to_char(PA_EXPENDITURE_ORG_ID) as PA_EXPENDITURE_ORG_ID
                ,to_char(SOURCE_TASK_ID) as SOURCE_TASK_ID
                ,to_char(EXPENDITURE_TYPE) as EXPENDITURE_TYPE
                ,to_char(ERROR_CODE) as ERROR_CODE
                ,to_char(ERROR_EXPLANATION) as ERROR_EXPLANATION
                ,to_char(PRIOR_COSTED_QUANTITY) as PRIOR_COSTED_QUANTITY
                ,to_char(TRANSFER_PRIOR_COSTED_QUANTITY) as TRANSFER_PRIOR_COSTED_QUANTITY
                ,to_char(FINAL_COMPLETION_FLAG) as FINAL_COMPLETION_FLAG
                ,to_char(PM_COST_COLLECTED) as PM_COST_COLLECTED
                ,to_char(PM_COST_COLLECTOR_GROUP_ID) as PM_COST_COLLECTOR_GROUP_ID
                ,to_char(SHIPMENT_COSTED) as SHIPMENT_COSTED
                ,to_char(TRANSFER_PERCENTAGE) as TRANSFER_PERCENTAGE
                ,to_char(MATERIAL_ACCOUNT) as MATERIAL_ACCOUNT
                ,to_char(MATERIAL_OVERHEAD_ACCOUNT) as MATERIAL_OVERHEAD_ACCOUNT
                ,to_char(RESOURCE_ACCOUNT) as RESOURCE_ACCOUNT
                ,to_char(OUTSIDE_PROCESSING_ACCOUNT) as OUTSIDE_PROCESSING_ACCOUNT
                ,to_char(OVERHEAD_ACCOUNT) as OVERHEAD_ACCOUNT
                ,to_char(COST_GROUP_ID) as COST_GROUP_ID
                ,to_char(TRANSFER_COST_GROUP_ID) as TRANSFER_COST_GROUP_ID
                ,to_char(FLOW_SCHEDULE) as FLOW_SCHEDULE
                ,to_char(QA_COLLECTION_ID) as QA_COLLECTION_ID
                ,to_char(OVERCOMPLETION_TRANSACTION_QTY) as OVERCOMPLETION_TRANSACTION_QTY
                ,to_char(OVERCOMPLETION_PRIMARY_QTY) as OVERCOMPLETION_PRIMARY_QTY
                ,to_char(OVERCOMPLETION_TRANSACTION_ID) as OVERCOMPLETION_TRANSACTION_ID
                ,to_char(MVT_STAT_STATUS) as MVT_STAT_STATUS
                ,to_char(COMMON_BOM_SEQ_ID) as COMMON_BOM_SEQ_ID
                ,to_char(COMMON_ROUTING_SEQ_ID) as COMMON_ROUTING_SEQ_ID
                ,to_char(ORG_COST_GROUP_ID) as ORG_COST_GROUP_ID
                ,to_char(COST_TYPE_ID) as COST_TYPE_ID
                ,to_char(PERIODIC_PRIMARY_QUANTITY) as PERIODIC_PRIMARY_QUANTITY
                ,to_char(MOVE_ORDER_LINE_ID) as MOVE_ORDER_LINE_ID
                ,to_char(TASK_GROUP_ID) as TASK_GROUP_ID
                ,to_char(PICK_SLIP_NUMBER) as PICK_SLIP_NUMBER
                ,to_char(LPN_ID) as LPN_ID
                ,to_char(TRANSFER_LPN_ID) as TRANSFER_LPN_ID
                ,to_char(PICK_STRATEGY_ID) as PICK_STRATEGY_ID
                ,to_char(PICK_RULE_ID) as PICK_RULE_ID
                ,to_char(PUT_AWAY_STRATEGY_ID) as PUT_AWAY_STRATEGY_ID
                ,to_char(PUT_AWAY_RULE_ID) as PUT_AWAY_RULE_ID
                ,to_char(CONTENT_LPN_ID) as CONTENT_LPN_ID
                ,to_char(PICK_SLIP_DATE) as PICK_SLIP_DATE
                ,to_char(COST_CATEGORY_ID) as COST_CATEGORY_ID
                ,to_char(ORGANIZATION_TYPE) as ORGANIZATION_TYPE
                ,to_char(TRANSFER_ORGANIZATION_TYPE) as TRANSFER_ORGANIZATION_TYPE
                ,to_char(OWNING_ORGANIZATION_ID) as OWNING_ORGANIZATION_ID
                ,to_char(OWNING_TP_TYPE) as OWNING_TP_TYPE
                ,to_char(XFR_OWNING_ORGANIZATION_ID) as XFR_OWNING_ORGANIZATION_ID
                ,to_char(TRANSFER_OWNING_TP_TYPE) as TRANSFER_OWNING_TP_TYPE
                ,to_char(PLANNING_ORGANIZATION_ID) as PLANNING_ORGANIZATION_ID
                ,to_char(PLANNING_TP_TYPE) as PLANNING_TP_TYPE
                ,to_char(XFR_PLANNING_ORGANIZATION_ID) as XFR_PLANNING_ORGANIZATION_ID
                ,to_char(TRANSFER_PLANNING_TP_TYPE) as TRANSFER_PLANNING_TP_TYPE
                ,to_char(SECONDARY_UOM_CODE) as SECONDARY_UOM_CODE
                ,to_char(SECONDARY_TRANSACTION_QUANTITY) as SECONDARY_TRANSACTION_QUANTITY
                ,to_char(TRANSACTION_GROUP_SEQ) as TRANSACTION_GROUP_SEQ
                ,to_char(SHIP_TO_LOCATION_ID) as SHIP_TO_LOCATION_ID
                ,to_char(RESERVATION_ID) as RESERVATION_ID
                ,to_char(TRANSACTION_MODE) as TRANSACTION_MODE
                ,to_char(TRANSACTION_BATCH_ID) as TRANSACTION_BATCH_ID
                ,to_char(TRANSACTION_BATCH_SEQ) as TRANSACTION_BATCH_SEQ
                ,to_char(INTRANSIT_ACCOUNT) as INTRANSIT_ACCOUNT
                ,to_char(FOB_POINT) as FOB_POINT
                ,to_char(PARENT_TRANSACTION_ID) as PARENT_TRANSACTION_ID
                ,to_char(LOGICAL_TRX_TYPE_CODE) as LOGICAL_TRX_TYPE_CODE
                ,to_char(TRX_FLOW_HEADER_ID) as TRX_FLOW_HEADER_ID
                ,to_char(LOGICAL_TRANSACTIONS_CREATED) as LOGICAL_TRANSACTIONS_CREATED
                ,to_char(LOGICAL_TRANSACTION) as LOGICAL_TRANSACTION
                ,to_char(INTERCOMPANY_COST) as INTERCOMPANY_COST
                ,to_char(INTERCOMPANY_PRICING_OPTION) as INTERCOMPANY_PRICING_OPTION
                ,to_char(INTERCOMPANY_CURRENCY_CODE) as INTERCOMPANY_CURRENCY_CODE
                ,to_char(ORIGINAL_TRANSACTION_TEMP_ID) as ORIGINAL_TRANSACTION_TEMP_ID
                ,to_char(TRANSFER_PRICE) as TRANSFER_PRICE
                ,to_char(EXPENSE_ACCOUNT_ID) as EXPENSE_ACCOUNT_ID
                ,to_char(COGS_RECOGNITION_PERCENT) as COGS_RECOGNITION_PERCENT
                ,to_char(SO_ISSUE_ACCOUNT_TYPE) as SO_ISSUE_ACCOUNT_TYPE
                ,to_char(OPM_COSTED_FLAG) as OPM_COSTED_FLAG
                ,to_char(MATERIAL_EXPENSE_ACCOUNT) as MATERIAL_EXPENSE_ACCOUNT
                ,to_char(TRANSACTION_EXTRACTED) as TRANSACTION_EXTRACTED
                ,to_char(XML_DOCUMENT_ID) as XML_DOCUMENT_ID
                ,to_char(MCC_CODE) as MCC_CODE
          from inv.mtl_material_transactions
        where last_update_date between to_date('{start_date}','yyyy-mm-dd') and to_date('{end_date}','yyyy-mm-dd')
  """

# COMMAND ----------

# DBTITLE 1,Seleciona a partição mais recente da tabela e monta o intervalo de processamento
# Recupera a última partição da tbaela 
table_name     = f"{catalog}.{schema}.{table}"
ls_table_parts = get_lasts_partitions(spark, table_name, 1)

# Monta os intervalos a serem processados (processamento mês a mês)
first_day_of_year = False
if len(ls_table_parts) > 0:
    start_date = f"{ls_table_parts[0]._year}-{ls_table_parts[0]._month:02d}-{ls_table_parts[0]._day:02d}"
else:
    start_date = None
    first_day_of_year = True

end_date = date.today().strftime("%Y-%m-%d")
ls_proces_interval = get_interval_bronze_dates(start_date, end_date, 730, first_day_of_year)

# COMMAND ----------

# DBTITLE 1,Executa a leitura do RBMDS e persiste os dados na tabela
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")

for part in ls_proces_interval:
    print(f"Processar período: {part['first_day']} - {part['last_day']}")
    
    start_filter = part['first_day']
    end_filter   = part['last_day']

    if ((start_filter and end_filter) and (start_filter <= end_filter)):
        df_source  = read_oracle(db_connections
                                ,start_filter
                                ,end_filter
                                ,query_source)

        start_run = datetime.now()
        print(f"\tPersiste os dados do DF na tabela {catalog}.{schema}.{table}", end="")

        # Cria a partição e faz cast da coluna LAST_UPDATE_DATE para string
        df_source_write = \
            df_source.withColumns({"_year":  year('LAST_UPDATE_DATE') \
                                  ,"_month": month('LAST_UPDATE_DATE') \
                                  ,"_day":   day('LAST_UPDATE_DATE')
                                  ,'LAST_UPDATE_DATE': col('LAST_UPDATE_DATE').cast('string')})
        
        (
            df_source_write
                .write
                .partitionBy("_year","_month","_day")
                .format("delta")
                .mode("overwrite")
                .saveAsTable(f"{catalog}.{schema}.{table}")
        )

        finish_run = datetime.now()
        print(f" - Concluido com sucesso, em {finish_run-start_run}")

        del(df_source_write)
        del(df_source)
