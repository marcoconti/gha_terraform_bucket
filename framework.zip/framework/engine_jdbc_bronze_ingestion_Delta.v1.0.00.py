# Databricks notebook source
# MAGIC %md
# MAGIC * 2025-07-22 - Marco Conti - Versão 1.0.01
# MAGIC   * Inclusão de tratamento para Formatar o SQL command enviado via query_source e a adição de filtro na query_source
# MAGIC * 2025-07-23 - Marco Conti - Versão 1.0.01
# MAGIC   * Inclusão de função para montar a função de conversão de str para date de direfentes RDBMS (Oracle, MySQL e SQL-Server)
# MAGIC * 2025-07-31 - Marco Conti - Versão 1.0.01
# MAGIC   * Criação de schema caso não exista
# MAGIC * 2025-08-15 - Marco Conti - Versão 2.0.01
# MAGIC   * Mudança para gravação na camada Bronze com partição ano, mês e dia

# COMMAND ----------

# MAGIC %md
# MAGIC ### **Engine JDBC Bronze Ingestion**

# COMMAND ----------

# DBTITLE 1,Carrega as bibliotecas
import sys
import json
import pytz
import os
import re

from datetime import date, datetime, timedelta, timezone
from delta.tables import DeltaTable
from functools import reduce
from pyspark.sql.functions import concat, sha2, col, coalesce, expr, lit, year, month, day, current_timestamp, to_timestamp, from_utc_timestamp, format_string, concat_ws
from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DateType
from delta.tables import DeltaTable
from sqlglot import parse_one, exp
from sqlglot.errors import ParseError

from datamax.commons import get_env
from datamax.table_infos import get_lasts_partitions
from datamax.date_processing import get_interval_bronze_dates

# COMMAND ----------

def sql_format(query_source):
    """
    Formata o sql da query para evitar problemas com palavras chave coladas em colunas, quebras de linhas, etc
    """
    # Fazer o parse da query_source para validar seu conteudo
    try:
        query_source_parse = str(parse_one(query_source))
        # Remove a palavra "as" do alias das tabela, isso não funciona no Oracle
        query_source = \
            re.sub(r"(?i)(FROM|JOIN)\s+([a-zA-Z0-9_.\"]+)\s+AS\s+([a-zA-Z0-9_]+)"
                  ,r"\1 \2 \3"
                  ,query_source
                  )
    except ParseError as pe:
        error = str(pe).replace("'","").replace('"','')
        raise Exception(f"Query com inconsistências: {error}")

    return query_source

def get_date_convert_function(rdbms, date_str):
    """
        Retorna as diferentes maneiras de converter uma string para uma data no rdbms informado
    """
    rdbms = rdbms.replace('-','_').lower()
    
    if rdbms == "oracle":
        return f"to_date('{date_str}','yyyy-mm-dd')" 
    elif rdbms == "sql_server":
        return f"cast('{date_str}' as date)"
    elif rdbms == "mysql":
        return f"str_to_date('{date_str}', '%Y-%m-%d')"

    return date_str

def check_owner(catalog, schema, schema_owner):
    """
    Verfica o owner no schema, caso não seja um owner de sistema ele faz a alteração
    """
    try:
        describe_cmd = f"DESCRIBE DATABASE EXTENDED {catalog}.{schema}"
        schema_infos = spark.sql(describe_cmd).collect()
        current_scheme_owner = [own["database_description_value"] for own in schema_infos if own["database_description_item"] == "Owner"][0]
        # Se o owner do job não for um owner de sistema faz a alteração
        if current_scheme_owner != schema_owner:
            alter_cmd = f"ALTER SCHEMA {catalog}.{schema} OWNER TO `{schema_owner}`"
            spark.sql(alter_cmd)
        return schema_owner
    except Exception as e:
        return schema_owner

def check_grants(catalog, schema, owner):
    """
    Verifica as permissões associadas ao schema, para incluir caso esteja faltando alguma
    """
    try:
        owner_grants_set = \
            {"data-eng-yamaha"   : ["CREATE TABLE","READ VOLUME","WRITE VOLUME"
                                   ,"USE SCHEMA","EXECUTE","REFRESH","MODIFY","SELECT"]
            ,"data-admins-yamaha": ["ALL PRIVILEGES","EXTERNAL USE SCHEMA","MANAGE"]}

        grants_cmd       = f"SHOW GRANTS ON SCHEMA {catalog}.{schema}"
        grants_schema    = spark.sql(grants_cmd).collect()
        ls_grants_schema = [gs["ActionType"] for gs in grants_schema if gs['Principal'] == owner]
        # Separa somente as permissões que estão faltando
        grant_add        = list(set(owner_grants_set[owner]) - set(ls_grants_schema))

        for grant in grant_add:
            grant_cmd = f"GRANT {grant} ON SCHEMA {catalog}.{schema} TO `{owner}`"
            spark.sql(grant_cmd)
    except:
        pass

def create_schema(catalog, schema, schema_owner):
    """
    Caso o schema não exista ele será criado, caso exista ele verifica se o owner é um owner de sistema e verifica as permissões
    """
    try:
        if not spark.catalog.databaseExists(catalog+"."+schema):
            cmd_create = f"CREATE DATABASE IF NOT EXISTS {catalog}.{schema}"
            spark.sql(cmd_create)

        owner = check_owner(catalog, schema, schema_owner)
        check_grants(catalog, schema, owner)
    except:
        pass

    return catalog, schema

# Incluir na DataMax
def replace_columns_caracters(df):
    """
    # Substitui o caracteres no nome das colunas - parâmetro replace_columns = [{"@": "_", "#", "_"}]
    """
    try:
        cols = df.columns
        if isinstance(replace_columns, list):
            for rc in replace_columns:
                for old, new in rc.items():
                    cols = [col.replace(old, new) for col in cols]

            df = df.toDF(*cols)
        return df
    except Exception as e:
        # Interrompe a substituição de colunas se ocorrer error   
        return df
        
# Incluir na DataMax
def replace_columns_name(df):
    """
    # Substitui o nome das colunas - parâmetro columns = [{"old_name": "new_name"}]
    """
    try:
        if isinstance(columns, list):
            for col in columns:
                for old_name, new_name in col.items():
                    df = df.withColumnRenamed(old_name.replace('-', '_'), new_name)
        return df
    except Exception as e:
        # Interrompe a substituição de colunas se ocorrer error
        return df

# Incluir na DataMax
def count_written_rows(table_name):
    rows_written = 0
    try:
        delta_table = DeltaTable.forName(spark, table_name)
        # Pega o histórico e lê a última operação
        last_op = (
            delta_table.history()
            .select("operation", "operationMetrics")
            .orderBy("version", ascending=False)
            .first()
        )
        # Extrai o número de linhas gravadas
        rows_written = int(last_op.asDict()["operationMetrics"].get("numOutputRows", 0))
        return rows_written
    except Exception as e:
        return rows_written
    
from pyspark.sql.types import *

def alter_table_add_columns(df, table_name):
    """
    A partir da comparação entre Dataframe (Origem) e a tabela de destino
    Adiciona colunas novas, caso existam
    """
    try:
        cols_ignore = ['_hash', '_year', '_month', '_day', '_ingestionin']
        table_cols  = [c.name for c in spark.table(table_name).schema if c.name not in cols_ignore]

        for field in df.schema.fields:
            col   = field.name
            dtype = field.dataType

            if ((col not in table_cols) and (col not in cols_ignore)):
                add_col_ddl = ""
                if isinstance(dtype, StringType):
                    sql_type = "STRING"
                elif isinstance(dtype, IntegerType):
                    sql_type = "INT"
                elif isinstance(dtype, LongType):
                    sql_type = "BIGINT"
                elif isinstance(dtype, DoubleType) or isinstance(dtype, FloatType):
                    sql_type = "DOUBLE"
                elif isinstance(dtype, BooleanType):
                    sql_type = "BOOLEAN"
                elif isinstance(dtype, DateType):
                    sql_type = "DATE"
                elif isinstance(dtype, TimestampType):
                    sql_type = "TIMESTAMP"
                elif isinstance(dtype, DecimalType):
                    sql_type = f"DECIMAL({dtype.precision},{dtype.scale})"
                else:
                    sql_type = "STRING" # se não identificar o datatype, cria uma string

                add_col_ddl = f"ALTER TABLE {table_name} ADD COLUMNS ({col} {sql_type});"
                if add_col_ddl != "":
                    spark.sql(add_col_ddl)
    except Exception as e:
        pass

def convert_year_month_to_int(table_name):
    df_table =  spark.table(table_name)
    cols_check = ["_year", "_month"]
    df_raw_year_month = []
    df_raw_year_month = [dfs for dfs in df_table.schema.fields if dfs.name in cols_check and dfs.dataType != IntegerType()]

    if len(df_raw_year_month) > 0:
        df_modified = df_table.withColumns({"_year": col("_year").cast('int')
                                           ,"_month": col("_month").cast('int')})
        # Altera o datatype das colunas _year e _month
        df_modified.write.format("delta") \
                   .mode("overwrite") \
                   .option("overwriteSchema", "true") \
                   .saveAsable(table)


# COMMAND ----------

# DBTITLE 1,Momento de inicio do job
start_job = datetime.now(pytz.timezone('America/Sao_Paulo'))

# COMMAND ----------

# DBTITLE 1,Variáveis
env = get_env()
owner_schema = "data-eng-yamaha" if env == "dev" else "data-admins-yamaha"

# COMMAND ----------

# DBTITLE 1,Cria tabela de logs se não existir
sql = f"""
  create table if not exists controls_{env}.loads.jobs
  (
    job string,
    task string,
    framework string,
    type string,
    mode string,
    start timestamp,
    finish timestamp,
    minutes float,
    pipeline_config string,
    query_source string,
    affected_rows long,
    inserted_rows long,
    updated_rows long,
    deleted_rows long,
    status string,
    partition_date date
    )
  using delta
  partitioned by (partition_date)
"""

spark.sql(sql)

# COMMAND ----------

# DBTITLE 1,Captura nome do job
job_name = dbutils.notebook.entry_point.getDbutils().notebook().getContext().jobName()

# COMMAND ----------

# DBTITLE 1,Captura o framework utilizado
framework = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()

# COMMAND ----------

# DBTITLE 1,Captura os parametros do pipeline
pipeline_parameters = dbutils.widgets.get("pipeline_parameters")

# COMMAND ----------

# DBTITLE 1,Atribui os parametros as configurações
pipeline_settings = json.loads(pipeline_parameters)

# COMMAND ----------

# DBTITLE 1,Parâmetros: task, tipo e modo do pipeline e também o RDBMS
try:
    parameter     = "task_name"
    task_name     = dbutils.widgets.get("task_name")

    parameter     = "pipeline_type"
    pipeline_type = pipeline_settings['pipeline_type']

    parameter     = "pipeline_mode"
    pipeline_mode = pipeline_settings['pipeline_mode']

    parameter     = "rdbms"
    rdbms         = pipeline_settings['rdbms']
except Exception as e:
    error = str(e).replace("'","").replace('"','')
    raise Exception(f"Não foi possível recuperar informações do parâmetro: {parameter} - {error}")

# COMMAND ----------

# DBTITLE 1,Dados do catalogo bronze
try:
    bronze_catalog = pipeline_settings['bronze_catalog']
    bronze_schema = pipeline_settings['bronze_schema']
    bronze_table = pipeline_settings['bronze_table']

    # Verifica se o schema existe, caso não exista cria
    create_schema(bronze_catalog, bronze_schema, owner_schema)
except Exception as e:
    error = str(e).replace("'","").replace('"','')
    raise Exception(f"Não foi possível recuperar informações dos parâmetros para Bronze Table - {error}")

# COMMAND ----------

# DBTITLE 1,Colunas de hash (PK), partição e dias anteriores da carga
try:
    parameter        = "hash_columns"
    hash_columns     = pipeline_settings['hash_columns']

    parameter        = "partition_column"
    partition_column = pipeline_settings['partition_column']
    partition_column = partition_column if partition_column != "" else ""

    parameter        = "days_past"
    days_past        = pipeline_settings['days_past']
except Exception as e:
    error = str(e).replace("'","").replace('"','')
    raise Exception(f"Não foi possível recuperar informações do parâmetro: {parameter} - {error}")

# COMMAND ----------

# DBTITLE 1,Strings que serão substituidas no nome das colunas
try:
    parameter       = "replace_columns"
    replace_columns = pipeline_settings['replace_columns']
    
    parameter       = "columns"
    columns         = pipeline_settings['columns']
except Exception as e:
    error = str(e).replace("'","").replace('"','')
    raise Exception(f"Não foi possível recuperar informações do parâmetro: {parameter} - {error}")

# COMMAND ----------

# DBTITLE 1,Dados de conexão com o banco de dados
try:
    database_settings = pipeline_settings['database_config']
    
    driver            = database_settings['driver']
    url               = database_settings['url']
    user              = database_settings['user']
    info_get_pass     = database_settings['password']
    password          = \
        dbutils.secrets.get(scope = info_get_pass['scope']
                        ,key   = info_get_pass['secrect'])
except Exception as e:
    error = str(e).replace("'","").replace('"','')
    raise Exception(f"Não foi possível recuperar informações para conexão com o banco de dados - {error}")

# COMMAND ----------

# DBTITLE 1,Query do pipeline
try:
    query_source = dbutils.widgets.get("query_source")
    if query_source != "":
        query_source = sql_format(query_source)
except Exception as e:
    error = str(e).replace("'","").replace('"','')
    raise Exception(f"Erro no parâmetro query_source - {error}")

# COMMAND ----------

# DBTITLE 1,Se pipeline for incremental define range de datas
try:
    default_past_day = 730 # 2 Anos - Colocar no arquivo de parametros 

    if (partition_column is not None and partition_column != ''):
        if spark.catalog.tableExists(f'{bronze_catalog}.{bronze_schema}.{bronze_table}'):
            last_table_part = get_lasts_partitions(spark
                                                ,f'{bronze_catalog}.{bronze_schema}.{bronze_table}'
                                                ,partitions_numbers = 1)
        else:
            last_table_part = []

        # Monta os intervalos de datas a serem processadas. 
        # O processamento será mês a mês para não sobrecarregar a origem e também o Cluster Databricks
        first_day_of_year = False
        if len(last_table_part) > 0: # Tabela já existe e já possui partições
            start_date = f"{last_table_part[0]._year}-{last_table_part[0]._month:02d}-{last_table_part[0]._day:02d}"
            days_past  = (date.today() - datetime.strptime(start_date, "%Y-%m-%d").date()).days
        else:
            first_day_of_year = True
            days_past  = max(default_past_day, days_past)
            start_date = (datetime.now() - timedelta(days=days_past)).strftime("%Y-%m-%d")
    else: # FULL
        days_past  = 1
        start_date = (datetime.now() - timedelta(days=days_past)).strftime("%Y-%m-%d")
        first_day_of_year = False

    end_date = date.today().strftime("%Y-%m-%d")
    ls_process_interval = get_interval_bronze_dates(start_date, end_date, days_past, first_day_of_year)
except Exception as e:
    error = str(e).replace("'","").replace('"','')
    raise Exception(f"Não foi calcular os intervalos de processamento - {error}")

# COMMAND ----------

# DBTITLE 1,Monta os filtros para a query e executa a carga do DF para a Tabela Bronze
process_step = ""
try:
    inserted_rows = 0
    ls_part_cols  = []

    print(f"Tabela: {bronze_catalog}.{bronze_schema}.{bronze_table}")
    for interval in ls_process_interval:
        process_step = "Montagem do Filtro para a query"
        if (partition_column is not None and partition_column != ''):
            date_start   = get_date_convert_function(rdbms, interval["first_day"])
            date_end     = get_date_convert_function(rdbms, interval["last_day"])
            where_and    = ' AND ' if 'WHERE' in query_source.upper() else ' WHERE '
            query_filter = f""" {where_and} {partition_column} BETWEEN {date_start} AND {date_end}"""
            query_run    = query_source + query_filter
        else:
            query_run    = query_source 

        read_write_start = datetime.now()
        print(f"\tProcessando o intervalo: {interval['first_day']} - {interval['last_day']} ", end="")

        # Lê o rdbms
        process_step = "Leitura do RDBMS"
        df_source = (
            spark.read.format('jdbc')
                .option('driver', driver)
                .option('url', url)
                .option('trustServerCertificate', 'true')
                .option('fetchsize', '10240')
                .option('user', user)
                .option('password', password)
                .option('dbtable', f'({query_run}) alias_table') \
                .option('numPartitions', 8)
                .load()
        )
        
        # Substitui o nome das colunas - parâmetro replace_columns
        process_step = "Substitui o nome das colunas"
        df_source = replace_columns_name(df_source)

        # Substitui caracteres no nome das colunas - parâmetro column
        process_step = "Substitui caracteres no nome das colunas"
        df_source = replace_columns_caracters(df_source)
        
        # Cria a partição e o registro de data e hora de ingestão
        process_step = "Cria a partição e o registro de data e hora de ingestão"
        if (partition_column is not None and partition_column != ''):
            df_source = df_source.withColumns({'_year' : year(partition_column)
                                              ,'_month': month(partition_column)
                                              ,'_day'  : day(partition_column)
                                              ,"_ingestionin": from_utc_timestamp(current_timestamp(), "America/Sao_Paulo")})
        else:
            df_source = df_source.withColumns({"_year" : lit(start_job.year)
                                              ,"_month": lit(start_job.month)
                                              ,"_day"  : lit(start_job.day)
                                              ,"_ingestionin": from_utc_timestamp(current_timestamp(), "America/Sao_Paulo")})
        
        # Verifica se existe difereça de schema (somente colunas a mais):
        alter_table_add_columns(df_source, f'{bronze_catalog}.{bronze_schema}.{bronze_table}')


        # Equaliza os datatype das colunas _year e _month
        convert_year_month_to_int(f'{bronze_catalog}.{bronze_schema}.{bronze_table}')

        # Persiste o Dataframe na camada Bronze
        process_step = "Persiste o Dataframe na camada Bronze"

        spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic") # Possibilitar o overwrite das partições

        (df_source.write
                  .format('delta')
                  .mode('overwrite')
                  .partitionBy('_year', '_month', '_day')
                  .saveAsTable(f'{bronze_catalog}.{bronze_schema}.{bronze_table}'))

        written_rows      = count_written_rows(f'{bronze_catalog}.{bronze_schema}.{bronze_table}') 
        inserted_rows    += written_rows
        read_write_finish = datetime.now()
        read_write_time   = round(((read_write_finish - read_write_start).total_seconds()), 4)

        print(f"{written_rows} registros persistidos em {read_write_time} segundos")

        del(df_source)
except Exception as e:
    error = str(e).replace("'","").replace('"','')
    raise Exception(f"Não foi realizar o processamento, passo: {process_step} - {error}")

# COMMAND ----------

# DBTITLE 1,Adiciona a execução ao log
try:
    finish_job     = datetime.now(pytz.timezone('America/Sao_Paulo'))
    partition_date = datetime.now(timezone(timedelta(hours=-3))).strftime("%Y-%m-%d")

    affected_rows = inserted_rows
    updated_rows  = 0
    deleted_rows  = 0

    sql = f'''
        INSERT INTO controls_{env}.loads.jobs
        (
            job, task, framework, type, mode, start, finish, minutes, pipeline_config, query_source, affected_rows, inserted_rows, updated_rows, deleted_rows, status, partition_date
        )
        VALUES
        (
            '{job_name}', '{task_name}', '{framework}', '{pipeline_type}', '{pipeline_mode}', '{start_job}', '{finish_job}', {round(((finish_job - start_job).total_seconds() / 60), 4)}, '{pipeline_parameters}', '{query_source.replace("'", "").replace("'", "")}', {affected_rows}, {inserted_rows}, {updated_rows}, {deleted_rows}, 'Success', '{partition_date}'
        )
    '''

    spark.sql(sql)
except Exception as e:
    print(f"Não foi possível registrar a informações de execução do job")

# COMMAND ----------

# DBTITLE 1,Adiciona comentários às colunas de partição e momento da ingestão
try:
    if not (partition_column is None or partition_column == ''):

        #

        sql_update_comments = f"""
            ALTER TABLE {bronze_catalog}.{bronze_schema}.{bronze_table}
            CHANGE COLUMN _year COMMENT 'Coluna contendo o ano utilizado para particionamento'
        """

        spark.sql(sql_update_comments)

        #

        sql_update_comments = f"""
            ALTER TABLE {bronze_catalog}.{bronze_schema}.{bronze_table}
            CHANGE COLUMN _month COMMENT 'Coluna contendo o mês utilizado para particionamento'
        """

        spark.sql(sql_update_comments) 

        sql_update_comments = f"""
            ALTER TABLE {bronze_catalog}.{bronze_schema}.{bronze_table}
            CHANGE COLUMN _day COMMENT 'Coluna contendo o dia utilizado para particionamento'
        """

        spark.sql(sql_update_comments) 

    sql_update_comments = f"""
        ALTER TABLE {bronze_catalog}.{bronze_schema}.{bronze_table}
        CHANGE COLUMN _ingestionin COMMENT 'Coluna contendo o momento da ingestão'
    """

    spark.sql(sql_update_comments)
except Exception as e:
    print(f"Não foi possível adicionar comentário às colunas ")

# COMMAND ----------

# DBTITLE 1,Aplica tags da configuração YAML nas tabelas bronze
try:
    if 'tags' in pipeline_settings and pipeline_settings['tags']:
        tags_list = pipeline_settings['tags']
        
        # Converte lista de tags para formato SQL de propriedades de tabela
        if tags_list:
            tblproperties_list = []
            for tag in tags_list:
                if isinstance(tag, str) and ':' in tag:
                    key, value = tag.split(':', 1)
                    tblproperties_list.append(f"'{key.strip()}' = '{value.strip()}'")
                elif isinstance(tag, dict):
                    for k, v in tag.items():
                        tblproperties_list.append(f"'{k}' = '{v}'")
            
            if tblproperties_list:
                tblproperties_sql = ', '.join(tblproperties_list)
                sql_apply_tags = f"""
                    ALTER TABLE {bronze_catalog}.{bronze_schema}.{bronze_table}
                    SET TBLPROPERTIES ({tblproperties_sql})
                """
                
                try:
                    spark.sql(sql_apply_tags)
                    print(f"Tags aplicadas na tabela {bronze_catalog}.{bronze_schema}.{bronze_table}")
                except Exception as e:
                    print(f"Erro ao aplicar tags na tabela: {str(e)}")
except Exception as e:
    print(f"Não foi possível aplicar as tags na tabela - {str(e)} ")

# COMMAND ----------

# DBTITLE 1,Finaliza engine
print('*** Finalizado ***')