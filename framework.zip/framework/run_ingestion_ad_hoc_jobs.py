# Databricks notebook source
# MAGIC %md
# MAGIC #### Este Notebook será utilizado para executar outros notebooks, AD-HOC, de ingestão.
# MAGIC #### Através dele será possível registrar log de sucesso ou erro na execução.
# MAGIC
# MAGIC * Os logs serão mantidos na tabela controls_dev.loads.jobs
# MAGIC
# MAGIC 2025-07-03 - Marco Conti - Criação
# MAGIC

# COMMAND ----------

from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo

# COMMAND ----------

# DBTITLE 1,Seleciona os parâmetros recebidos
parameters   = dbutils.widgets.getAll()

job_name     = parameters['job_name']
notebook_run = parameters['notebook_run']
notebook_run = "../"+notebook_run
timeout      = parameters['timeout'] if 'timeout' in parameters else "3600"
timeout      = int(timeout)

parameters.pop('job_name')
parameters.pop('notebook_run')
parameters.pop('timeout')

print("job_name:", job_name)
print("notebook_run:", notebook_run)
print(parameters)

# COMMAND ----------

# DBTITLE 1,Método responsável por registrar o log (Sucesso ou Erro)
import os

def get_env():
    env = os.environ.get("DATABRICKS_ENV")
    return env.lower()

def log_register(job, task, type, start, finish, minutes, status):
    try:
        env = get_env()
        remove_chars = "@#$'"
        status = str(status).translate(str.maketrans('', '', remove_chars))
        partition_date = datetime.now(timezone(timedelta(hours=-3))).strftime("%Y-%m-%d")
        insert_cmd = \
           f"""Insert into controls_{env}.loads.jobs(job, task, type, start, finish, minutes, status, partition_date)
               values('{job}', '{task}', '{type}', '{start}', '{finish}', {minutes}, '{status}', '{partition_date}')
            """
        spark.sql(insert_cmd)
    except Exception as e:
        print("Não foi possível registrar log")
        print(e)

# COMMAND ----------

# DBTITLE 1,Executa o notebook, com seus argumentos, recebidos c/ parâmetro
try:
    start_ts = datetime.now() #ZoneInfo("America/Sao_Paulo"))
    
    # Executa o notebook de ingestão
    print("Executa o notebook:\n", notebook_run, "timeout:", timeout)
    dbutils.notebook.run(notebook_run, timeout)
   
    end_ts   = datetime.now() #ZoneInfo("America/Sao_Paulo"))
    run_time = end_ts - start_ts
    status   = "SUCCESS"

except Exception as e:
    status   = f"ERROR:\n{e}"
    end_ts   = datetime.now() #ZoneInfo("America/Sao_Paulo"))
    run_time = end_ts - start_ts

minutes = round((run_time.total_seconds()/60),5)

log_register(job_name
            ,""
            ,'ad-hoc'
            ,start_ts
            ,end_ts
            ,minutes
            ,status)
