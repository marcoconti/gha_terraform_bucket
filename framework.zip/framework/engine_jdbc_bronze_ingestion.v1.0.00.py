# Databricks notebook source
# MAGIC %md
# MAGIC * 2025-07-22 - Marco Conti - Versão 1.0.01
# MAGIC   * Inclusão de tratamento para Formatar o SQL command enviado via query_source e a adição de filtro na query_source
# MAGIC * 2025-07-23 - Marco Conti - Versão 1.0.01
# MAGIC   * Inclusão de função para montar a função de conversão de str para date de direfentes RDBMS (Oracle, MySQL e SQL-Server)
# MAGIC * 2025-07-31 - Marco Conti - Versão 1.0.01
# MAGIC   * Criação de schema caso não exista

# COMMAND ----------

# MAGIC %md
# MAGIC ### **Engine JDBC Bronze Ingestion**

# COMMAND ----------

# DBTITLE 1,Carrega as bibliotecas
import sys
import json
import pytz
import os
import re

from datetime import date, datetime, timedelta, timezone
from delta.tables import DeltaTable
from functools import reduce
from pyspark.sql.functions import concat, sha2, col, coalesce, expr, lit, year, month, current_timestamp, to_timestamp, from_utc_timestamp, format_string, concat_ws
from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DateType
from sqlglot import parse_one, exp
from sqlglot.errors import ParseError

# COMMAND ----------

def get_env():
    return os.environ.get("DATABRICKS_ENV")

def sql_format(query_source):
    """
    Formata o sql da query para evitar problemas com palavras chave coladas em colunas, quebras de linhas, etc
    """
    # Fazer o parse da query_source para validar seu conteudo
    try:
        query_source_parse = str(parse_one(query_source))
        # Remove a palavra "as" do alias das tabela, isso não funciona no Oracle
        query_source = \
            re.sub(r"(?i)(FROM|JOIN)\s+([a-zA-Z0-9_.\"]+)\s+AS\s+([a-zA-Z0-9_]+)"
                  ,r"\1 \2 \3"
                  ,query_source
                  )
    except ParseError as pe:
        error = str(pe.errors).replace("'","").replace('"','')
        raise Exception(f"Query com inconsistências: {error}")

    return query_source

def get_date_convert_function(rdbms, date_str):
    """
        Retorna as diferentes maneiras de converter uma string para uma data no rdbms informado
    """
    rdbms = rdbms.replace('-','_').lower()
    
    if rdbms == "oracle":
        return f"to_date('{date_str}','yyyy-mm-dd')" 
    elif rdbms == "sql_server":
        return f"cast('{date_str}' as date)"
    elif rdbms == "mysql":
        return f"str_to_date('{date_str}', '%Y-%m-%d')"

    return date_str

def check_owner(catalog, schema, schema_owner):
    """
    Verfica o owner no schema, caso não seja um owner de sistema ele faz a alteração
    """
    try:
        describe_cmd = f"DESCRIBE DATABASE EXTENDED {catalog}.{schema}"
        schema_infos = spark.sql(describe_cmd).collect()
        current_scheme_owner = [own["database_description_value"] for own in schema_infos if own["database_description_item"] == "Owner"][0]
        # Se o owner do job não for um owner de sistema faz a alteração
        if current_scheme_owner != schema_owner:
            alter_cmd = f"ALTER SCHEMA {catalog}.{schema} OWNER TO `{schema_owner}`"
            spark.sql(alter_cmd)
        return schema_owner
    except Exception as e:
        return schema_owner

def check_grants(catalog, schema, owner):
    """
    Verifica as permissões associadas ao schema, para incluir caso esteja faltando alguma
    """
    try:
        owner_grants_set = \
            {"data-eng-yamaha"   : ["CREATE TABLE","READ VOLUME","WRITE VOLUME"
                                   ,"USE SCHEMA","EXECUTE","REFRESH","MODIFY","SELECT"]
            ,"data-admins-yamaha": ["ALL PRIVILEGES","EXTERNAL USE SCHEMA","MANAGE"]}

        grants_cmd       = f"SHOW GRANTS ON SCHEMA {catalog}.{schema}"
        grants_schema    = spark.sql(grants_cmd).collect()
        ls_grants_schema = [gs["ActionType"] for gs in grants_schema if gs['Principal'] == owner]
        # Separa somente as permissões que estão faltando
        grant_add        = list(set(owner_grants_set[owner]) - set(ls_grants_schema))

        for grant in grant_add:
            grant_cmd = f"GRANT {grant} ON SCHEMA {catalog}.{schema} TO `{owner}`"
            spark.sql(grant_cmd)
    except:
        pass

def create_schema(catalog, schema, schema_owner):
    """
    Caso o schema não exista ele será criado, caso exista ele verifica se o owner é um owner de sistema e verifica as permissões
    """
    try:
        if not spark.catalog.databaseExists(catalog+"."+schema):
            cmd_create = f"CREATE DATABASE IF NOT EXISTS {catalog}.{schema}"
            spark.sql(cmd_create)

        owner = check_owner(catalog, schema, schema_owner)
        check_grants(catalog, schema, owner)
    except:
        pass

    return catalog, schema

# COMMAND ----------

# DBTITLE 1,Variáveis
env = get_env()
owner_schema = "data-eng-yamaha" if env == "dev" else "data-admins-yamaha"

# COMMAND ----------

# DBTITLE 1,Cria tabela de logs se não existir
sql = f"""
  create table if not exists controls_{env}.loads.jobs
  (
    job string,
    task string,
    framework string,
    type string,
    mode string,
    start timestamp,
    finish timestamp,
    minutes float,
    pipeline_config string,
    query_source string,
    affected_rows long,
    inserted_rows long,
    updated_rows long,
    deleted_rows long,
    status string,
    partition_date date
    )
  using delta
  partitioned by (partition_date)
"""

spark.sql(sql)

# COMMAND ----------

# DBTITLE 1,Captura nome do job
job_name = dbutils.notebook.entry_point.getDbutils().notebook().getContext().jobName()

# COMMAND ----------

# DBTITLE 1,Captura nome da task
task_name = dbutils.widgets.get("task_name")

# COMMAND ----------

# DBTITLE 1,Captura o framework utilizado
framework = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()

# COMMAND ----------

# DBTITLE 1,Captura os parametros do pipeline
pipeline_parameters = dbutils.widgets.get("pipeline_parameters")

# COMMAND ----------

# DBTITLE 1,Momento de inicio do job
start_job = datetime.now(pytz.timezone('America/Sao_Paulo'))

# COMMAND ----------

# DBTITLE 1,Atribui os parametros as configurações
pipeline_settings = json.loads(pipeline_parameters)

# COMMAND ----------

# DBTITLE 1,Parametro do tipo e modo do pipeline
pipeline_type = pipeline_settings['pipeline_type']
pipeline_mode = pipeline_settings['pipeline_mode']

# COMMAND ----------

rdbms = pipeline_settings['rdbms']

# COMMAND ----------

# DBTITLE 1,Dados do catalogo temporario
temporary_catalog = pipeline_settings['temporary_catalog']
temporary_schema = pipeline_settings['temporary_schema']
temporary_table = pipeline_settings['temporary_table']

# Verifica se o schema existe, caso não exista cria
create_schema(temporary_catalog, temporary_schema, owner_schema)

# COMMAND ----------

# DBTITLE 1,Dados do catalogo bronze
bronze_catalog = pipeline_settings['bronze_catalog']
bronze_schema = pipeline_settings['bronze_schema']
bronze_table = pipeline_settings['bronze_table']

# Verifica se o schema existe, caso não exista cria
create_schema(bronze_catalog, bronze_schema, owner_schema)

# COMMAND ----------

# DBTITLE 1,Se primeira carga transforma o pipeline em full e overwrite
if not spark.catalog.tableExists(f'{bronze_catalog}.{bronze_schema}.{bronze_table}'):

    pipeline_type = 'full'
    pipeline_mode = 'overwrite'

# COMMAND ----------

# DBTITLE 1,Colunas que vão entrar na composição do hash
hash_columns = pipeline_settings['hash_columns']

# COMMAND ----------

# DBTITLE 1,Coluna de particionamento
partition_column = pipeline_settings['partition_column']

# COMMAND ----------

# DBTITLE 1,Strings que serão substituidas no nome das colunas
replace_columns = pipeline_settings['replace_columns']

# COMMAND ----------

# DBTITLE 1,Colunas que serão renomeadas
columns = pipeline_settings['columns']

# COMMAND ----------

# DBTITLE 1,Dados de conexão com o banco de dados
database_settings = pipeline_settings['database_config']

# COMMAND ----------

# DBTITLE 1,Dados de conexão com o banco de dados
driver = database_settings['driver']
url = database_settings['url']
user = database_settings['user']
info_get_pass = database_settings['password']
password = dbutils.secrets.get(scope = info_get_pass['scope']
                              ,key   = info_get_pass['secrect'])

# COMMAND ----------

# DBTITLE 1,Dias no passado que o pipeline irá consultar
days_past = pipeline_settings['days_past']

# COMMAND ----------

# DBTITLE 1,Query do pipeline
query_source = dbutils.widgets.get("query_source")
if query_source != "":
    query_source = sql_format(query_source)

# COMMAND ----------

# DBTITLE 1,Se pipeline for incremental define range de datas
if pipeline_type in ['incremental']:

    date_start = (datetime.now() - timedelta(days = days_past)).strftime('%Y-%m-%d')
    date_end = datetime.now().strftime('%Y-%m-%d')


# COMMAND ----------

# DBTITLE 1,Se pipeline incremental atribui range de datas a query
if pipeline_type in ['incremental']:
    if partition_column is not None and partition_column != '':
        date_start    = get_date_convert_function(rdbms, date_start)
        date_end      = get_date_convert_function(rdbms, date_end)
        query_filter  = f"Select * from ({query_source}) aux_table"
        query_filter += f""" WHERE {partition_column} BETWEEN {date_start} AND {date_end} OR {partition_column} IS NULL"""

        query_source  = query_filter

# COMMAND ----------

# DBTITLE 1,Carrega dataframe de origem
df_source = (
    spark.read.format('jdbc') \
        .option('driver', driver) \
        .option('url', url) \
        .option('trustServerCertificate', 'true')
        .option('batchsize', '10240') \
        .option('fetchsize', '10240') \
        .option('user', user) \
        .option('password', password) \
        .option('dbtable', f'({query_source}) alias_table') \
        .option('numPartitions', 8) \
        .load()
)

# COMMAND ----------

# DBTITLE 1,Substitui o nome das colunas - parâmetro replace_columns
cols = df_source.columns
try:
    if isinstance(replace_columns, list):
        for rc in replace_columns:
            for old, new in rc.items():
                cols = [col.replace(old, new) for col in cols]

        df_source = df_source.toDF(*cols)
except Exception as e:
    # Interrompe a substituição de colunas se ocorrer error   
    pass

# COMMAND ----------

# DBTITLE 1,Substitui o nome das colunas - parâmetro column
try:
    if isinstance(columns, list):
        for col in columns:
            for old_name, new_name in col.items():
                df_source = df_source.withColumnRenamed(old_name.replace('-', '_'), new_name)
except Exception as e:
    # Interrompe a substituição de colunas se ocorrer error
    pass

# COMMAND ----------

# DBTITLE 1,Se não informa coluna hash, considera todas
if not (isinstance(hash_columns, list) and (len(hash_columns) > 0)):
    hash_columns = df_source.columns

# COMMAND ----------

# DBTITLE 1,Calcula valor do hash
df_source = df_source.withColumn("_hash", sha2(concat_ws("", *hash_columns), 256))

# COMMAND ----------

# DBTITLE 1,Se conter coluna de partição cria as mesmas
if not (partition_column is None or partition_column == ''):

    df_source = df_source.withColumn('_year', format_string('%04d', year(partition_column)))
    df_source = df_source.withColumn('_month', format_string('%02d', month(partition_column)))

# COMMAND ----------

# DBTITLE 1,Cria coluna do momento da ingestão
df_source = df_source.withColumn("_ingestionin", from_utc_timestamp(current_timestamp(), "America/Sao_Paulo"))

# COMMAND ----------

# DBTITLE 1,Ingere dados na tabela de catalogo na bronze
if pipeline_type in ['full', 'incremental'] and pipeline_mode in ['overwrite', 'append']:

    if not (partition_column is None or partition_column == ''):

        df_source.write.format("delta").mode(f'{pipeline_mode}').partitionBy("_year", "_month").saveAsTable(f'{bronze_catalog}.{bronze_schema}.{bronze_table}')

    else: 

        df_source.write.format("delta").mode(f'{pipeline_mode}').saveAsTable(f'{bronze_catalog}.{bronze_schema}.{bronze_table}')
    
    #

    affected_rows = df_source.count()
    inserted_rows = affected_rows
    updated_rows = 0
    deleted_rows = 0

# COMMAND ----------

# DBTITLE 1,Combina os dados da temporaria (origem) com a bronze (destino)
if pipeline_type in ['full', 'incremental'] and pipeline_mode == 'merge':

    #

    if not (partition_column is None or partition_column == ''):
        
        df_source.write.format("delta").mode(f'overwrite').partitionBy("_year", "_month").saveAsTable(f'{temporary_catalog}.{temporary_schema}.{temporary_table}')

    else:

        df_source.write.format("delta").mode(f'overwrite').saveAsTable(f'{temporary_catalog}.{temporary_schema}.{temporary_table}')

    #

    if pipeline_type == 'full':

        sql = f'''
            MERGE INTO 
                {bronze_catalog}.{bronze_schema}.{bronze_table} AS target
            USING
                {temporary_catalog}.{temporary_schema}.{temporary_table} AS source
            ON
                target._hash = source._hash
            WHEN MATCHED THEN
                UPDATE SET *
            WHEN NOT MATCHED THEN
                INSERT *
            WHEN NOT MATCHED BY SOURCE THEN
                DELETE
        '''
    
    #

    if pipeline_type == 'incremental':

        if not (partition_column is None or partition_column == ''):

            sql = f'''
                MERGE INTO
                    {bronze_catalog}.{bronze_schema}.{bronze_table} AS target
                USING
                    {temporary_catalog}.{temporary_schema}.{temporary_table} AS source 
                ON
                    target._hash = source._hash
                WHEN MATCHED THEN
                    UPDATE SET *
                WHEN NOT MATCHED THEN
                    INSERT *
                WHEN NOT MATCHED BY SOURCE AND target.{partition_column.replace('-', '_')} BETWEEN {date_start} AND {date_end} THEN 
                    DELETE
            '''

        else:

            sql = f'''
                MERGE INTO
                    {bronze_catalog}.{bronze_schema}.{bronze_table} AS target
                USING
                    {temporary_catalog}.{temporary_schema}.{temporary_table} AS source 
                ON
                    target._hash = source._hash
                WHEN MATCHED THEN
                    UPDATE SET *
                WHEN NOT MATCHED THEN
                    INSERT *
                WHEN NOT MATCHED BY SOURCE THEN
                    DELETE
            '''

    #
    print(sql)
    df_result = spark.sql(sql)

    #

    affected_rows = df_result.select('num_affected_rows').head()[0]
    inserted_rows = df_result.select('num_inserted_rows').head()[0]
    updated_rows = df_result.select('num_updated_rows').head()[0]
    deleted_rows = df_result.select('num_deleted_rows').head()[0]

# COMMAND ----------

# DBTITLE 1,Adiciona a execução ao log
finish_job = datetime.now(pytz.timezone('America/Sao_Paulo'))
partition_date = datetime.now(timezone(timedelta(hours=-3))).strftime("%Y-%m-%d")

sql = f'''
    INSERT INTO controls_{env}.loads.jobs
    (
        job, task, framework, type, mode, start, finish, minutes, pipeline_config, query_source, affected_rows, inserted_rows, updated_rows, deleted_rows, status, partition_date
    )
    VALUES
    (
        '{job_name}', '{task_name}', '{framework}', '{pipeline_type}', '{pipeline_mode}', '{start_job}', '{finish_job}', {round(((finish_job - start_job).total_seconds() / 60), 4)}, '{pipeline_parameters}', '{query_source.replace("'", "").replace("'", "")}', {affected_rows}, {inserted_rows}, {updated_rows}, {deleted_rows}, 'Success', '{partition_date}'
    )
'''

spark.sql(sql)

# COMMAND ----------

sql = f'DROP TABLE IF EXISTS {temporary_catalog}.{temporary_schema}.{temporary_table}'

spark.sql(sql)

# COMMAND ----------

sql_update_comments = f"""
    ALTER TABLE {bronze_catalog}.{bronze_schema}.{bronze_table}
    CHANGE COLUMN _hash COMMENT 'Coluna (hash) de identificação unica da linha'
"""

spark.sql(sql_update_comments)

# COMMAND ----------

if not (partition_column is None or partition_column == ''):

    #

    sql_update_comments = f"""
        ALTER TABLE {bronze_catalog}.{bronze_schema}.{bronze_table}
        CHANGE COLUMN _year COMMENT 'Coluna contendo o ano utilizada para particionamento'
    """

    spark.sql(sql_update_comments)

    #

    sql_update_comments = f"""
        ALTER TABLE {bronze_catalog}.{bronze_schema}.{bronze_table}
        CHANGE COLUMN _month COMMENT 'Coluna contendo o mês utilizada para particionamento'
    """

    spark.sql(sql_update_comments) 

# COMMAND ----------

sql_update_comments = f"""
    ALTER TABLE {bronze_catalog}.{bronze_schema}.{bronze_table}
    CHANGE COLUMN _ingestionin COMMENT 'Coluna contendo o momento da ingestão'
"""

spark.sql(sql_update_comments)

# COMMAND ----------

# DBTITLE 1,Aplica tags da configuração YAML nas tabelas bronze
if 'tags' in pipeline_settings and pipeline_settings['tags']:
    tags_list = pipeline_settings['tags']
    
    # Converte lista de tags para formato SQL de propriedades de tabela
    if tags_list:
        tblproperties_list = []
        for tag in tags_list:
            if isinstance(tag, str) and ':' in tag:
                key, value = tag.split(':', 1)
                tblproperties_list.append(f"'{key.strip()}' = '{value.strip()}'")
            elif isinstance(tag, dict):
                for k, v in tag.items():
                    tblproperties_list.append(f"'{k}' = '{v}'")
        
        if tblproperties_list:
            tblproperties_sql = ', '.join(tblproperties_list)
            sql_apply_tags = f"""
                ALTER TABLE {bronze_catalog}.{bronze_schema}.{bronze_table}
                SET TBLPROPERTIES ({tblproperties_sql})
            """
            
            try:
                spark.sql(sql_apply_tags)
                print(f"Tags aplicadas na tabela {bronze_catalog}.{bronze_schema}.{bronze_table}")
            except Exception as e:
                print(f"Erro ao aplicar tags na tabela: {str(e)}")

# COMMAND ----------

# DBTITLE 1,Finaliza engine
print('*** Finalizado ***')
