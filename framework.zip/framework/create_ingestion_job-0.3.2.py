# Databricks notebook source
# MAGIC %md
# MAGIC #### Este Notebook será incluído em um job a ser executado a cada 1 hora
# MAGIC
# MAGIC * Irá verificar no repositório https://github.com/YMH-BR/data/source/pipeline_parameters se existem configurações de ingestões de tabelas aptas para criação ou alteração de jobs, estes jobs irá executar o framework de ingestão.
# MAGIC
# MAGIC * 2025-07-07 - Marco Conti - Versão 0.3.1
# MAGIC   * Mudança no método de leitura de arquivos de workspace para repositório Git
# MAGIC * 2025-07-09 - Weslley - Versão 0.3.1
# MAGIC   * Tratamento nas permissões do job criado ou atualizado
# MAGIC * 2025-07-11 - Marco - Versão 0.3.2
# MAGIC   * Inclusão de ingestão com origem RDBMS (Oracle) via JDBC
# MAGIC * 2025-07-17 - Marco - Versão 0.3.2
# MAGIC   * Inclusão de ingestão com origem RDBMS (SQL-Server e MySQL) via JDBC

# COMMAND ----------

# DBTITLE 1,Importa as lib's necessárias na execução
from datetime import datetime, timezone, timedelta
import requests, json, os, time, yaml, re, io, ast, time
from pathlib import Path
from git import Repo
from zoneinfo import ZoneInfo
import pytz
from pyspark.sql.functions import lit, col, to_date, to_timestamp
from pyspark.sql import Row
from sqlglot import parse_one, exp
from sqlglot.errors import ParseError

# COMMAND ----------

# DBTITLE 1,Verifica se o databricks sdk está instalada
import pkg_resources
import subprocess
import sys

ls_package = ["databricks-sdk"]
for package_name in ls_package:
    try:
        dist = pkg_resources.get_distribution(package_name)
        print(f"'{package_name}' Já está instalada, versão: {dist.version}, {type(dist.version)}")
    except pkg_resources.DistributionNotFound:
        print(f"'{package_name}' Ainda não está instalada, será instalada a seguir...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", f"{package_name}>=0.57.0"])
        dist = pkg_resources.get_distribution(package_name)
        print(f"'{package_name}' Instalada com sucesso, versão: {dist.version}")

from databricks.sdk import WorkspaceClient
from databricks.sdk.service import jobs

# COMMAND ----------

# DBTITLE 1,Prepara o databricks sdk
host = spark.conf.get("spark.databricks.workspaceUrl")
for attempt in range(3):
    try:
        print(f"Conectar no host: {host}", end="")
        wc = WorkspaceClient()
        print(" - Conectado com sucesso")
        break  # success
    except Exception as e:
        print(f" - Falhou, tentar novamente... ({attempt+1}/3)")
        time.sleep(5)
else:
    raise RuntimeError("Não foi possível conecar no workspace")

# COMMAND ----------

# DBTITLE 1,Métodos e funções utilizadas durante a execução
def get_env():
    return os.environ.get("DATABRICKS_ENV")

def create_clone_git_repo(env, branch):
    """
        Cria um clone do repositório Git que será utilizado para carregar arquivos alterados e itens de configuração
    """
    token = dbutils.secrets.get(scope="git-token", key="token").strip()

    repo_path  = f"https://{token}@github.com/YMH-BR/data.git"
    timestamp  = int(datetime.now(timezone(timedelta(hours=-3))).timestamp())
    clone_path = f"/tmp/clone_ymhbr_data_variables_{timestamp}"

    if branch == "":
        branch = env if env == "dev" else "main"

    repo = Repo.clone_from(repo_path, clone_path, branch=branch)
    return repo, clone_path

def rmdir_clone_git_repo(clone_path):
    """
        Remove o diretório temporário usado para clonar o repositório
    """
    try:
        if os.path.exists(clone_path):
            import shutil
            shutil.rmtree(clone_path)
            print("Diretório temp para clone Git repo removido com sucesso")    
    except Exception as e:
        print("Não foi possível excluir a pasta temporaria")

def get_all_job_variables(repo):
    """
        Recupera a última versão do arquivo de configurações
    """
    file_path = "framework/create_ingestion_job_variables.json"
    # Itera sobre os commits que modificaram esse arquivo e retorna a última alteração
    last_commit = next(repo.iter_commits(paths=file_path, max_count=1))

    # Acessa o blob do arquivo na árvore do commit
    blob = None
    if last_commit is not None:
        blob = last_commit.tree / file_path
    
    if blob is None:
        print(f"Não foi possível encontrar o arquivo {file_path} no repositório.")
        return {}
    
    # Lê o conteúdo do arquivo
    with io.BytesIO(blob.data_stream.read()) as f:
        variables = f.read().decode("utf-8")

    json_content = json.loads(variables)    
    return json_content

def get_job_variables(job_variables, *keys):
    """
        Seleciona, na lista de variáveis de configuração, os valores da variável informada
    """    
    try:
        value = job_variables
        for key in keys:
            value = value[key]
        return value
    except Exception as e:
        print(f"Variavel: {keys[0]} não encontrada")
        return ""

def get_rdbms_connection(repo, rdbms, connect_name):
    """
        Cria a string de conexão para os bancos de dados relacionais
        rdbms disponívels Oracle, SQL-Server e MySQL
    """
    try:
        rdbms_drivers = {}
        rdbms_drivers["oracle"]    = "oracle.jdbc.OracleDriver"
        rdbms_drivers["sqlserver"] = "com.microsoft.sqlserver.jdbc.SQLServerDriver"
        rdbms_drivers["mysql"]     = "com.mysql.cj.jdbc.Driver"

        file_path = f"framework/db_connections/cn_{rdbms.replace('-','_').lower()}.json"
        last_commit = next(repo.iter_commits(paths=file_path, max_count=1))

        blob = None
        if last_commit is not None:
            blob = last_commit.tree / file_path
        
        if blob is None:
            print(f"Não foi possível encontrar o arquivo {file_path} no repositório.")
            return {}
        
        with io.BytesIO(blob.data_stream.read()) as f:
            variables = f.read().decode("utf-8")

        json_content = json.loads(variables)
        json_content = [cfg for cfg in json_content if cfg.get("connect_name") == connect_name][0]

        # Monta as infos de conexão de acordo com a necessidade do Framework
        db_connect_framework = {}

        rdbms = rdbms.lower()
        rdbms = re.sub(r'[^a-zA-Z]', '', rdbms)
        db_connect_framework["driver"] = rdbms_drivers[rdbms]

        server = json_content['server']
        port   = json_content['port']
        db     = json_content['database']

        if rdbms == "oracle":
            url = f"jdbc:oracle:thin:@//{server}:{port}/{db}"
        elif rdbms == "sqlserver":
            url = f"jdbc:sqlserver://{server}:{port};databaseName={db};encrypt=false"
        elif rdbms == "mysql":
            url = f"jdbc:mysql://{server}:{port}/{db}"

        db_connect_framework["url"]      = url
        db_connect_framework["user"]     = json_content['username']
        db_connect_framework["password"] = json_content['password']

        return db_connect_framework
    except Exception as e:
        print(f"Não foi possível carregar as configurações de conexão RDBMS do arquivo {file_path}.")
        return {}

def log_register(log_data):
    """
        Registra log (sucesso ou erro) do processo de criação ou atualização dos jobs
    """
    # gera um id randomico
    def gen_id():
        timestamp = time.time()
        randon_number = (int(timestamp) ^ (int(timestamp) << 1)) % 10000000000
        return randon_number

    env = get_env()
    current_datetime = datetime.now(timezone(timedelta(hours=-3)))
    current_datetime = current_datetime.strftime("%Y-%m-%d %H:%M:%S")
    table = f"controls_{env}.loads.create_ingestion_job_log"
    log_id = gen_id()

    try:
        user_email = user = spark.sql("Select current_user()").collect()[0][0]
    except Exception as e:
        user_email = ""

    try:
        # Cria relação de chaves
        insert_clause = f"log_id,log_date,user_email,"
        cols_ins = ",".join( [i[0] for i in log_data.items()])
        insert_clause += cols_ins

        # Cria a relação de valores
        insert_values = f"{log_id}, '{current_datetime}', '{user_email}', "
        clear_None = [i[1] if i[1] is not None else "" for i in log_data.items()]
        for i in clear_None:
            if isinstance(i, str):
                insert_values += f"'{i}'"+","
                insert_values.replace("'","''")
            else:
                insert_values += f"{i}"+","
        insert_values = insert_values[:-1]

        # transforma as str de chave e valor em listas
        insert_clause  = [k for k in insert_clause.split(',')]
        insert_values  = list(ast.literal_eval("[" + insert_values + "]"))
        dict_key_value = dict(zip(insert_clause, insert_values))

        df_write = spark.createDataFrame([Row(**dict_key_value)])

        partition_date = datetime.now(timezone(timedelta(hours=-3))).strftime("%Y-%m-%d")
        df_write       = df_write.withColumn("partition_date", to_date(lit(partition_date),"yyyy-MM-dd"))
        df_write       = df_write.withColumn("log_date", to_timestamp(col('log_date')))

        df_write.write.partitionBy("partition_date").format("delta").mode("append").saveAsTable(table)

    except Exception as e:
        print("Não foi possível registar o log")

    return log_id

def normalize_list(value=None):
    """
        Normaliza as lista em um único padrão, independente do tipo da entrada
    """
    if value is None:
        return []   
    if isinstance(value, list):
        return [v for v in value if isinstance(v, (str, dict))]
    elif isinstance(value, str):
        value = value.strip()
        try:
            if isinstance( ast.literal_eval(value) , list):
                return ast.literal_eval(value)
        except:
            return []
        return [value] if value else []
    elif isinstance(value, dict):
        return [value]
    else:
        return []

def read_sql_files(repo, file_path, file_name):
    """
        Ler o arquivo SQL, utilizados na ingestão, do repositório git
    """
    try:
        if ((file_path and str(file_path).strip()) and \
            (file_name and str(file_name).strip())):

            file_path = os.path.dirname(file_path) + f"/query_source/{file_name}"
            
            # Itera sobre os commits que modificaram esse arquivo e retorna a última alteração
            last_commit = next(repo.iter_commits(paths = file_path, max_count = 1))
            
            # Acessa o blob do arquivo na árvore do commit
            blob = None
            if last_commit is not None:
                blob = last_commit.tree / file_path
            
            if blob is None:
                print(f"Não foi possível encontrar o arquivo {file_path} no repositório.")
                return {}

            # Lê o conteúdo do arquivo
            with io.BytesIO(blob.data_stream.read()) as f:
                sql_content = f.read().decode("utf-8")

            sql_content = sql_content.replace("<env>", get_env().lower())

            return sql_content
        else:
            ""
    except Exception as e:
        print(f"read_sql_files - Erro ao ler o arquivo {file_path}")
        return ""

def get_last_changed_files(repo, check_updates_interval, files_filter):
    """
        Lista todos os arquivos *.sql e *.yaml (pipeline_parameters e table schema) no repositório:
        https://github.com/YMH-BR/data/sources/pipeline_parameters
    """
    # Define o tempo limite
    since_time = datetime.now(ZoneInfo("America/Sao_Paulo")) - timedelta(hours=check_updates_interval)
    
    # Recupera os commits recentes ou, se files_filter informado, o último commit
    recent_commits = list(repo.iter_commits(since=since_time.isoformat()))

    exclude_folders = {"ad-hoc", "glue", "tools"}
    changed_files = {}
    for commit in recent_commits:
        commit_time = commit.committed_datetime
        for file_path in commit.stats.files.keys():
            path_sep = os.path.normpath(os.path.dirname(file_path)).split(os.sep)
            exec_file = True if len([f for f in path_sep if f in exclude_folders]) == 0 else False
            if ((".yaml" in file_path) and (exec_file)):
                if file_path not in changed_files or changed_files[file_path]["time"] < commit_time:
                    changed_files[file_path] = {
                        "commit": commit,
                        "time": commit_time
                    }
    
    modified_files = []
    for file_path, info in changed_files.items():
        try:
            blob = repo.head.commit.tree / file_path
            content = blob.data_stream.read().decode("utf-8")

            commit_datetime = \
                info['time'].astimezone(pytz.timezone("America/Sao_Paulo")).strftime("%Y-%m-%d %H:%M:%S")
            modified_files.append((file_path
                                  ,commit_datetime
                                  ,yaml.safe_load(content)))
        except Exception as e:
            continue

    latest_files_ret = modified_files

    if len(files_filter) > 0:
        latest_files_ret = [f for f in modified_files if Path(f[0]).name in files_filter]
    
    return latest_files_ret

def get_table_job_name(data):
    """
        Baseado no tipo de ingestão (Padrão, ad-hoc ou rdbms), monta o nome do Job
    """
    layers = ["landing", "bronze", "silver", "gold"]
    rdbms_options = ["Oracle", "SQL-Server", "MySQL"]
    filtered = [{key:value} for key, value in data.items() if key in layers]

    rec   = 0
    rdbms = ""
    if "origin" in filtered[rec][next(iter(filtered[rec]))]["source"]: # é ad-hoc
        source = filtered[rec][next(iter(filtered[rec]))]["source"]["origin"]
         # Muda para a próxima ou última camada, pois no caso de ad-hoc, o target é onde está o schema e tabela de destino
        rec    = len(filtered) - 1
    else:
        if filtered[rec][next(iter(filtered[rec]))]["source"]["catalog"] in rdbms_options:
            rdbms    = "rdbms"
            source   = filtered[rec][next(iter(filtered[rec]))]["source"]["catalog"]
        else:
            source   = filtered[rec][next(iter(filtered[rec]))]["source"]["schema"]
        rec    = len(filtered) - 1

    schema   = filtered[rec][next(iter(filtered[rec]))]["target"]["schema"]
    table    = filtered[rec][next(iter(filtered[rec]))]["target"]["table"]

    if source == schema:
        job = f"pipeline_{rdbms}_{schema}_{table}".replace("/", "_").replace("-", "_").lower()
    else:
        job = f"pipeline_{rdbms}_{source}_{schema}_{table}".replace("/", "_").replace("-", "_").lower()

    job_name   = re.sub(r'_+', '_', job)
    table_name = schema + "_" + table 

    return table_name, job_name

def check_layers(pipeline_parameter):
    """
        Verifica se as camadas estão corretas, com os campos preenchidos e as dependências corretas
    """
    default_layer_fill = \
        {"ad-hoc": {
            "source": {
                "origin"             : "required",
                "notebook_name"      : "required",
                "notebook_parameters": "optional"
                },
            "target": {
                "catalog": "required",
                "schema" : "required",
                "table"  : "required"
                }
            }
        ,"others": {
            "source": {
                "catalog": "required",
                "schema" : "required",
                "table"  : "required"
                },
            "target": {
                "catalog": "required",
                "schema" : "required",
                "table"  : "required"
                }
            }
        }
        # Incluir tratamento para RDBMS

    # Separa as camadas que estão no arquivo de config e as ordena
    layers_config = [d for d in pipeline_parameter if d in ("landing", "bronze", "silver", "gold")]
    standard_order = {0: "landing", 1: "bronze", 2: "silver", 3: "gold"}
    standard_order_ = list(standard_order.values())
    layers_ordered = sorted(layers_config, key=lambda x: standard_order_.index(x))

    layer_compl = []
    for layer in layers_config:
        aux_dict = pipeline_parameter[layer]

        default_layer_fill_filter = "others"
        if "origin" in aux_dict["source"]:
            if aux_dict["source"]["origin"] == "ad-hoc":
                default_layer_fill_filter = "ad-hoc"

        for sct_tgt, sct_tgt_dict in default_layer_fill[default_layer_fill_filter].items():
            count = 0
            count_req = 0
            if sct_tgt in aux_dict:
                for key, value in sct_tgt_dict.items():
                    if value == "required":
                        count_req += 1
                        count     += 1 if key in aux_dict[sct_tgt] and \
                                        (aux_dict[sct_tgt][key] != "" and \
                                        aux_dict[sct_tgt][key] is not None)  \
                                    else 0
                layer_tuple = (layer, sct_tgt, count_req, count)
                layer_compl.append(layer_tuple)

    layers_error = [l[0] for l in layer_compl if l[2] != l[3]]
    return len(layers_error), layers_ordered if len(layers_error) == 0 else layers_error

def get_job_status(job_id):
    try:
        runs = list(wc.jobs.list_runs(job_id=job_id, limit=1))
        life_cycle_state = ""
        if runs:
            latest_run = runs[0]
            life_cycle_state = latest_run.state.life_cycle_state.name
        return life_cycle_state
    except Exception as e:
        return ""

def get_job_id_by_name(job_name):
    try:
        matching_jobs = [job for job in wc.jobs.list() if job.settings.name == job_name]
        job_id = None
        job_status = None
        if matching_jobs:
            job_id = matching_jobs[0].job_id
            job_status = get_job_status(job_id)
        return job_id, job_status
    except Exception as e:
        return job_id, job_status

def create_job_tasks(env, job_name, repo
                    ,notebook_engine_path_bronze, notebook_engine_path_others, notebook_engine_jdbc_bronze
                    ,databricks_cluster_id, layers_run, param, path_config_json):
    """
        Baseado nos arquivos de parametros YAML (<tabela>.yaml), monta as tasks que serão usadas para criar ou atualizar os jobs
    """    
    try:
        rdbms_options = ["Oracle", "SQL-Server", "MySQL"]

        pipeline_parameters = {}
        pipeline_parameters_header = {}

        timeout = param["timeout"] if ("timeout" in param and (param["timeout"] is not None or param["timeout"] != "")) \
                                 else 3600

        pipeline_parameters_footer = {}
        pipeline_parameters_footer["days_past"]       = param["days_past"] if "days_past" in param else ""
        pipeline_parameters_footer["replace_columns"] = normalize_list(param["replace_columns"]) if "replace_columns" in param else []
        pipeline_parameters_footer["columns"]         = normalize_list(param["columns"]) if "columns" in param else []

        job_tasks = []
        for rec_l, layer in enumerate(layers_run):

            if "origin" in param[layer]["source"]:
                origin = param[layer]["source"]["origin"]
            else:
                origin = ""

            if ((layer == "landing") or (origin == "ad-hoc" )): # Notebooks ad-hoc
                notebook_name = param[layer]["source"]["notebook_name"]
                split_path    = path_config_json.find("source")
                notebook_path = path_config_json[split_path:]
                notebook_path = os.path.dirname(notebook_path)+ "/notebooks/" +notebook_name
                notebook_path_run_ingestion = "framework/run_ingestion_ad_hoc_jobs"
                
                depends_task = []
                if rec_l > 0:
                    depends_task = [jobs.TaskDependency(task_key=layers_run[(rec_l-1)])]

                task = jobs.Task(
                            task_key = layer,
                            depends_on = depends_task,
                            existing_cluster_id = f"{databricks_cluster_id}",
                            notebook_task = jobs.NotebookTask(
                                notebook_path   = f"{notebook_path_run_ingestion}",
                                source          = jobs.Source("GIT"),
                                base_parameters = {"job_name": f"{job_name}"
                                                  ,"notebook_run": f"{notebook_path}"
                                                  ,"timeout": timeout}))
                job_tasks.append(task)

            else:
                task_param = {}
                task_param["temporary_catalog"] = "temporary_"+env
                task_param["temporary_schema"]  = param[layer]["target"]["schema"]
                task_param["temporary_table"]   = param[layer]["target"]["table"]
                
                pipeline_parameters_header['pipeline_type'] = param[layer]['pipeline_type']
                pipeline_parameters_header['pipeline_mode'] = param[layer]['pipeline_mode']
                pipeline_parameters_header['rdbms']         = param[layer]['source']['catalog']

                # Troca os nomes dos atributos do dict devido a necessidades do Framework
                for ind, src_tgt in enumerate(["source", "target"]):
                    # Sai do loop caso seja uma ingestão rdbms pois o Framework só precisa do atributo bronze 
                    if param[layer]['source']['catalog'] in rdbms_options:
                        task_param["bronze_catalog"] = param[layer]["target"]['catalog']+"_"+env
                        task_param["bronze_schema"]  = param[layer]["target"]['schema']
                        task_param["bronze_table"]   = param[layer]["target"]['table']
                        break
                    else:
                        aux_layer = src_tgt
                        if ((layer == "bronze") and (src_tgt == "source" )):
                            aux_layer = "landing"
                        elif ((layer == "bronze") and (src_tgt == "target")):
                            aux_layer = "bronze"

                        task_param[f"{aux_layer}_catalog"] = param[layer][src_tgt]['catalog']+"_"+env
                        task_param[f"{aux_layer}_schema"]  = param[layer][src_tgt]['schema']
                        task_param[f"{aux_layer}_table"]   = param[layer][src_tgt]['table']

                # Trata as colunas hash_columns partition_column
                task_param["hash_columns"] = normalize_list(param[layer]["hash_columns"])
                
                task_param["partition_column"] = \
                    param[layer]["partition_column"] if param[layer]["partition_column"] else ""

                # Junta as partes dos parametros a serem enviados ao JOB
                pipeline_parameters = pipeline_parameters_header.copy()
                pipeline_parameters.update(task_param)

                # Identifica se existe algum arquivo SQL a ser utilizado
                query_source = ""
                query_source_file_name = \
                    param[layer]['query_source_file_name'] if 'query_source_file_name' in param[layer] else ""
                
                if (query_source_file_name != "" and query_source_file_name is not None):
                    query_source = read_sql_files(repo, path_config_json, query_source_file_name)

                # Se a query_source não estiver preenchida monta uma query pois o FrameWork necessita de uma query para o processamento
                if query_source == "":
                    if layer in ("bronze"):
                        if (param[layer]['source']["catalog"] in rdbms_options):
                            query_source = ""
                            table_name = param['bronze']['source']['schema'] + '.' + \
                                         param['bronze']['source']['table']
                            query_source = f"Select * from {table_name}"
                    elif layer in ("silver", "gold"):
                        table_name = param[layer]['source']['catalog'] + '_' + env + '.' + \
                                     param[layer]['source']['schema']  + '.' + \
                                     param[layer]['source']['table']
                        query_source = f"Select * from {table_name}"
                    else:
                        pass
                    
                # Fazer o parse da query_source para validar seu conteudo
                if query_source != "":
                    try:
                        query_source = parse_one(query_source)
                    except ParseError as pe:
                        error = str(pe.errors).replace("'","").replace('"','')
                        raise Exception(f"Query ({query_source_file_name}) com inconsistências: {error}")

                # Se a camada for um RDBMS, monta as infos para conexão com o banco de dados
                if (param[layer]['source']['catalog'] in rdbms_options):
                    db_connect_framework = \
                        get_rdbms_connection(repo
                                            ,param[layer]['source']['catalog']
                                            ,param['bronze']['source']['connect_name'])
                    pipeline_parameters["database_config"] = db_connect_framework
                    
                # Add infos final aos parametros
                pipeline_parameters.update(pipeline_parameters_footer)

                # Nomeia a task de acordo com a origem e destino dos dados            
                if (param[layer]['source']['catalog'] in rdbms_options): # É um banco relacional
                    task_name = f"{param[layer]['source']['catalog']}_{layer}"
                else:
                    task_name = "landing_bronze" if layer == "bronze"  \
                                               else "bronze_silver" if layer == "silver" \
                                                                  else "silver_gold"

                # Escolhe o framework a ser utilizado para processamento dos dados
                if layer in ("silver", "gold"):
                    notebook_engine_path = notebook_engine_path_others
                else:
                    if (param[layer]['source']['catalog'] in rdbms_options):
                        notebook_engine_path = notebook_engine_jdbc_bronze
                    else:
                        notebook_engine_path = notebook_engine_path_bronze
                
                # Notebook que irá rodar o framework e regitrar logs
                notebook_path_run_ingestion = "framework/run_ingestion_jobs"

                depends_task = []
                if rec_l > 0:
                    depends_task = [jobs.TaskDependency(task_key=layers_run[(rec_l-1)])]
                
                task = jobs.Task(task_key = layer,
                                 depends_on = depends_task,
                                 existing_cluster_id = f"{databricks_cluster_id}",
                                 notebook_task = jobs.NotebookTask(
                                    notebook_path = f"{notebook_path_run_ingestion}",
                                    source = jobs.Source("GIT"),
                                    base_parameters = {"job_name": f"{job_name}"
                                                      ,"notebook_run": f"framework/{notebook_engine_path}"
                                                      ,"timeout": timeout
                                                      ,"task_name": task_name
                                                      ,"pipeline_parameters": json.dumps(pipeline_parameters)
                                                      ,"query_source": str(query_source)}))

                job_tasks.append(task)

        return 0, job_tasks
    except Exception as e:
        return str(e)[0:300], []
    return job_tasks

def transfer_job_ownership(wc, env: str, job_id: int):
    """
    Substitui TODAS as permissões do job:
      • NEW_OWNER ⇒ IS_OWNER
      • grupo do ambiente ⇒ CAN_MANAGE
    Não preserva o old owner.
    """
    if env not in ENV_GROUP_MAP:
        raise ValueError(f"Ambiente '{env}' inválido "
                         f"(opções: {', '.join(ENV_GROUP_MAP)})")

    acl = [
        jobs.JobAccessControlRequest(
            user_name       = NEW_OWNER,
            permission_level= jobs.JobPermissionLevel.IS_OWNER
        ),
        jobs.JobAccessControlRequest(
            group_name      = ENV_GROUP_MAP[env],
            permission_level= jobs.JobPermissionLevel.CAN_MANAGE
        )
    ]

    try:
        if hasattr(wc.jobs, "replace_permissions"):
            wc.jobs.replace_permissions(job_id=job_id,
                                        access_control_list=acl)
        else:
            wc.api_client.do(
                "PUT",
                f"/api/2.0/permissions/jobs/{job_id}",
                body={"access_control_list": [a.as_dict() for a in acl]}
            )

        print(
            f"   - Ownership do job {job_id} transferido para '{NEW_OWNER}' "
            f"e grupo '{ENV_GROUP_MAP[env]}' recebeu CAN_MANAGE."
        )

    except Exception as e:
        raise RuntimeError(
            f"   - Falha ao transferir ownership do job {job_id}: {e}"
        )


# COMMAND ----------

# DBTITLE 1,Verifica parâmetros para teste unitários
env = get_env().lower()

parameters = dbutils.widgets.getAll()

branch = dbutils.widgets.get('branch') if (any('branch' in key for key in parameters)) else env
try:
    files_filter = normalize_list(dbutils.widgets.get('files_filter')) \
                        if (any('files_filter' in key for key in parameters)) \
                        else []
except Exception as e:
    files_filter = []

print(f"Branch específica: {branch}" if branch != "" else "" )
print(f"Filtrar arquivos: {files_filter}")

# COMMAND ----------

# DBTITLE 1,Definição de variáveis
# Se a branch foi enviada via parametro então ela será usada, caso contrario define a branch de acordo com o ambiente
git_branch = branch if branch != "" else ("dev" if env == "dev" else "main")

# Clona o repositório Git para recuperar arquivos alterados e arquivo de configuração
clone_git_repo, clone_path  = create_clone_git_repo(env, branch)

job_variables               = get_all_job_variables(clone_git_repo)
notebook_engine_path_bronze = get_job_variables(job_variables, "notebook_engine_path_bronze", env.upper())
notebook_engine_path_others = get_job_variables(job_variables, "notebook_engine_path_others", env.upper())
notebook_engine_jdbc_bronze = get_job_variables(job_variables, "notebook_engine_jdbc_bronze", env.upper())
databricks_cluster_id       = get_job_variables(job_variables, "databricks_cluster_id", env.upper())
check_updates_interval      = get_job_variables(job_variables, "check_updates_interval", env.upper())

NEW_OWNER = "ymdb.servicoawsgit@yamaha-motor.com.br"

ENV_GROUP_MAP = {
    "dev":     "data-eng-yamaha",
    "prod":    "data-admins-yamaha"
}

print("Variáveis:"
     ,'\nenv: ', env
     ,'\nnotebook_engine_path_bronze: ', notebook_engine_path_bronze
     ,'\nnotebook_engine_path_others: ', notebook_engine_path_others
     ,'\nnotebook_engine_jdbc_bronze: ', notebook_engine_jdbc_bronze
     ,'\ndatabricks_cluster_id:       ', databricks_cluster_id
     ,'\ncheck_updates_interval:      ', check_updates_interval)

# COMMAND ----------

# DBTITLE 1,Validar parâmetros e Criação ou Atualização dos job's
results = get_last_changed_files(clone_git_repo, check_updates_interval, files_filter)

created_jobs = []
updated_jobs = []
error_jobs   = []

print(f"{len(results)} Arquivo(s) a serem processados:\n" if len(results) > 0 else "Não há arquivos para processar")

for file in results:
    print(f" - {file[0]}")
    json_config_parameters = {}

    table_param = file[2] # Separa o conteudo yaml para processamento

    # Verifica se as camadas(landing, bronze, silver e gold) estão preenchidas corretamente
    layers_error, layers_run = check_layers(table_param)

    if ((layers_error == 0) and (len(layers_run))) > 0:
        print("   - Camadas a serem processadas:", layers_run)

        # Prepara o nome da tabela e job baseado na primeira camada configurada
        table_name, job_name =  get_table_job_name(table_param)

        job_id, job_status = get_job_id_by_name(job_name)

        # NÃO Atualiza o job se ele estiver em execução
        if job_status not in ["RUNNING", "PENDING", "QUEUED"]:
            # Monta as task para o job a ser criado ao atualizado
            error_job_tasks = ""
            job_tasks = []
            error_job_tasks, job_tasks = \
                create_job_tasks(env, job_name, clone_git_repo
                                ,notebook_engine_path_bronze, notebook_engine_path_others, notebook_engine_jdbc_bronze
                                ,databricks_cluster_id, layers_run, table_param, file[0])

            if len(job_tasks) > 0:
                # Monta o source (repositório Git) do Job
                git_source = \
                    jobs.GitSource(git_url      = "https://github.com/YMH-BR/data"
                                  ,git_provider = jobs.GitProvider.GIT_HUB
                                  ,git_branch   = git_branch)

                # Monta o agendamento do Job
                schedule = table_param['schedule']['quartz_cron']
                pause_status = jobs.PauseStatus.PAUSED if ((table_param['schedule']['paused']) or (env == "dev")) \
                                                     else jobs.PauseStatus.UNPAUSED
                job_schedule = jobs.CronSchedule(quartz_cron_expression = f"{schedule}"
                                                ,timezone_id            = "UTC"
                                                ,pause_status           = pause_status)

                # Inicio o processo de atualização ou criação do job
                try:
                    status = 'success'
                    if job_id: # Atualiza o job
                        try:
                            new_settings = \
                                jobs.JobSettings(name       = job_name
                                                ,git_source = git_source
                                                ,schedule   = job_schedule
                                                ,tasks      = job_tasks)
                            
                            ret = wc.jobs.update(job_id       = job_id
                                                ,new_settings = new_settings)
                            action = "Atualizado"
                            updated_jobs.append(job_name)

                            # Faz a transferência do owner do job para o usuário de serviço Yamaha
                            transfer_job_ownership(wc, env, job_id)

                        except Exception as e:
                            status = 'error'                            
                            error_jobs.append(job_name)
                            msg_error = f"Erro ao atualizar o job {job_name} - {str(e)[0:100]}"
                    else: # Cria o Job
                        try:
                            create_response = wc.jobs.create(name       = job_name
                                                            ,git_source = git_source
                                                            ,schedule   = job_schedule
                                                            ,tasks      = job_tasks)
                            job_id = create_response.job_id
                            action = "Criado"
                            created_jobs.append(job_name)

                            # Faz a transferência do owner do job para o usuário de serviço Yamaha
                            transfer_job_ownership(wc, env, job_id)
                            
                        except Exception as e:
                            status = 'error'
                            error_jobs.append(job_name)
                            msg_error = f"Erro ao criar o job {job_name} - {str(e)[0:100]}"

                    # Registra o log da criação ou atualização do job
                    log_data = {"log_status": status
                               ,"ingest_config_file": file[0]
                               ,"table_name": table_name
                               ,"schedule": schedule
                               ,"message": f"Job {job_id} - {job_name} - {action} com sucesso" if status == 'success' else msg_error
                               ,"job_id": str(job_id)
                               ,"job_name": job_name}
                    log_id = log_register(log_data)
                except Exception as e:
                    error_jobs.append(job_name)
                    log_data = {"log_status": "error"
                               ,"ingest_config_file": file[0]
                               ,"table_name": table_name
                               ,"message": f"Erro na criação/atualização do Job {job_id} {job_name} - {str(e)[0:100]}"
                               ,"job_id": str(job_id)
                               ,"job_name": job_name}
                    log_id = log_register(log_data)
            else:
                error_jobs.append(job_name)
                log_data = {"log_status": "error"
                            ,"ingest_config_file": file[0]
                            ,"table_name": table_name
                            ,"message": f"Erro na criação da task {job_id} {job_name} - {error_job_tasks}"
                            ,"job_id": str(job_id)
                            ,"job_name": job_name}
                log_id = log_register(log_data)    
    else:
        log_data = {"log_status": "error"
                   ,"ingest_config_file": file[0]
                   ,"message": f"Camadas: {layers_run} com inconsistência no preenchimento"}
        error_jobs.append(file[0])
        log_id = log_register(log_data)

print("\n","-"*100)
print(f" Data e hora: {datetime.now(ZoneInfo('America/Sao_Paulo')).strftime('%Y-%m-%d %H:%M:%S')}")

if len(created_jobs) > 0:
    print("-"*100)
    print(f"{len(created_jobs)} job(s) criado(s):")
    for j in created_jobs:
        print("\t", j)

if len(updated_jobs) > 0:
    print("\n", "-"*100)
    print(f" {len(updated_jobs)} job(s) atualizado(s):")
    for j in updated_jobs:
        print("\t", j)

if len(error_jobs) > 0:
    print("\n", "-"*100)
    print(f"{len(error_jobs)} job(s) ou arqs. yaml de config. com erro, consulta a tabela de log (controls_dev.loads.create_ingestion_job_log):")
    for j in error_jobs:
        print("\t", j)

# COMMAND ----------

# DBTITLE 1,Remove o diretório temporário do git clone
rmdir_clone_git_repo(clone_path)
