# Databricks notebook source
# MAGIC %md
# MAGIC #### Este Notebook será utilizado para criar job's de ingestão AD-HOC, aqueles que tem condições específicas.
# MAGIC
# MAGIC * 2025-07-03 - Marco Conti - Versão 0.1.0
# MAGIC * 2025-07-03 - Marco Conti - Versão 0.1.1 - Alteração para ler arquivos do Repositório GitHub
# MAGIC
# MAGIC A fazer:
# MAGIC - Incluir, no método create_job_tasks, tratamento de parametros contidos do arquvos .yaml

# COMMAND ----------

# DBTITLE 1,Import libs usadas no processamento
from datetime import datetime, timezone, timedelta
import requests, json, os, time, yaml, re, io, ast
from pathlib import Path
from git import Repo
from zoneinfo import ZoneInfo

# COMMAND ----------

# DBTITLE 1,Verifica se a lib sdk está instalada no clustes
import pkg_resources
import subprocess
import sys

ls_package = ["databricks-sdk"]
for package_name in ls_package:
    try:
        dist = pkg_resources.get_distribution(package_name)
        print(f"'{package_name}' Já está instalada, versão: {dist.version}, {type(dist.version)}")
    except pkg_resources.DistributionNotFound:
        print(f"'{package_name}' Ainda não está instalada, será instalada a seguir...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", f"{package_name}>=0.57.0"])
        dist = pkg_resources.get_distribution(package_name)
        print(f"'{package_name}' Instalada com sucesso, versão: {dist.version}")

from databricks.sdk import WorkspaceClient
from databricks.sdk.service import jobs

# COMMAND ----------

# DBTITLE 1,Cria conexão com o workspace
host = spark.conf.get("spark.databricks.workspaceUrl")
wc = WorkspaceClient(host=host)

# COMMAND ----------

# DBTITLE 1,Métodos e funções utilizado durante o processamento
def get_env():
    return os.environ.get("DATABRICKS_ENV")

def create_clone_git_repo(env, branch):
    token = dbutils.secrets.get(scope="git-token", key="token").strip()

    repo_path  = f"https://{token}@github.com/YMH-BR/data.git"
    timestamp  = int(datetime.now(timezone(timedelta(hours=-3))).timestamp())
    clone_path = f"/tmp/clone_ymhbr_data_variables_{timestamp}"
    file_path  = "framework/create_ingestion_job_variables.json"
    if branch == "":
        branch = env if env == "dev" else "main"

    repo = Repo.clone_from(repo_path, clone_path, branch=branch)
    return repo, clone_path

def rmdir_clone_git_repo(clone_path):
    # remove o diretório temporário usado para clonar o repositório
    try:
        if os.path.exists(clone_path):
            import shutil
            shutil.rmtree(clone_path)
            print("Diretório temp para clone Git repo removido com sucesso")    
    except Exception as e:
        print("Não foi possível excluir a pasta temporaria")

def get_all_job_variables(repo):
    file_path = "framework/create_ingestion_job_variables.json"
    # Itera sobre os commits que modificaram esse arquivo e retorna a última alteração
    last_commit = next(repo.iter_commits(paths=file_path, max_count=1))

    # Acessa o blob do arquivo na árvore do commit
    blob = None
    if last_commit is not None:
        blob = last_commit.tree / file_path
    
    if blob is None:
        print(f"Não foi possível encontrar o arquivo {file_path} no repositório.")
        return {}
    
    # Lê o conteúdo do arquivo
    with io.BytesIO(blob.data_stream.read()) as f:
        variables = f.read().decode("utf-8")

    json_content = json.loads(variables)    
    return json_content

def get_job_variables(job_variables, *keys):
    try:
        value = job_variables
        for key in keys:
            value = value[key]
        return value
    except Exception as e:
        print(f"Variavel: {keys[0]} não encontrada")
        return ""

def log_register(log_data):
    def gen_id():
        timestamp = time.time()
        randon_number = (int(timestamp) ^ (int(timestamp) << 1)) % 10000000000
        return randon_number
    
    env = get_env()
    current_datetime = datetime.now(timezone(timedelta(hours=-3)))
    current_datetime = current_datetime.strftime("%Y-%m-%d %H:%M:%S")
    table = f"controls_{env}.loads.create_ingestion_job_log"
    log_id = gen_id()
    try:
        user_email = user = spark.sql("Select current_user()").collect()[0][0]
    except Exception as e:
        user_email = ""

    for rec in range(2):
        erro = ""
        if rec == 1:
            prefix = "Não foi possível caregar os dados do atributo:"
            log_data["pipeline_parameters"] = f"{prefix} pipeline_parameters - {erro}"
            log_data["job_settings"] = f"{prefix} job_settings - {erro}"
        try:
            insert_clause = f"Insert into {table}(log_id, log_date, user_email, "
            cols_ins = ",".join( [i[0] for i in log_data.items()])+")"
            insert_clause += cols_ins

            insert_values = f"Values({log_id}, '{current_datetime}', '{user_email}', "
            clear_None = [i[1] if i[1] is not None else "" for i in log_data.items()]

            for i in clear_None:
                if isinstance(i, str):
                    insert_values += f"'{i}'"+","
                    insert_values.replace("'","''")
                else:
                    insert_values += f"{i}"+","
            insert_values = insert_values[:-1]+")"

            dml_cmd = f"""{insert_clause} {insert_values}"""
            spark.sql(dml_cmd)
            break
        except Exception as e:
            pass          
    return log_id

def normalize_list(raw_str) -> list[str]:
    if not raw_str or raw_str.strip() == "":
        return []
    try:
        result = json.loads(raw_str)
    except json.JSONDecodeError:
        try:
            result = ast.literal_eval(raw_str)
        except (ValueError, SyntaxError):
            return []
    except Exception as e:
        return []

    if isinstance(result, list):
        return [str(item) for item in result]

    return []

def get_last_changed_files(repo, check_updates_interval, files_filter):
    # Define o tempo limite
    since_time = datetime.now(ZoneInfo("America/Sao_Paulo")) - timedelta(hours=check_updates_interval)

    # Recupera os commits recentes
    recent_commits = list(repo.iter_commits(since=since_time.isoformat()))

    # Pesquisa os arquivos modificados
    modified_files = []
    for commit in recent_commits:
        for file in commit.stats.files:

            # Verificar se os notebook foram alterados (arquivos .py que estão na pasta /notebook)

            # Retorna somente os arquivos .yaml que estão sob a pasta ad-hoc
            if ((".yaml" in file) and ("ad-hoc" in file)):
                # Seleciona o conteúdo do arquivo                
                blob = commit.tree / file
                with io.BytesIO(blob.data_stream.read()) as f:
                    conteudo = f.read().decode("utf-8")

                modified_files.append((file
                                      ,commit.committed_datetime.replace(tzinfo=None)
                                      ,yaml.safe_load(conteudo)))

    latest_files = {}
    for path, dt, config in modified_files:
        if path not in latest_files or dt > latest_files[path][0]:
            latest_files[path] = (dt, config)

    latest_files_ret = [(path, dt, config) for path, (dt, config) in latest_files.items()]

    if len(files_filter) > 0:
        latest_files_ret = [f for f in latest_files_ret if Path(f[0]).name in files_filter]

    return latest_files_ret

def get_job_status(job_id):
    try:
        runs = list(wc.jobs.list_runs(job_id=job_id, limit=1))
        life_cycle_state = ""
        if runs:
            latest_run = runs[0]
            life_cycle_state = latest_run.state.life_cycle_state.name
        return life_cycle_state
    except Exception as e:
        return ""

def get_job_id_by_name(job_name):
    try:
        matching_jobs = [job for job in wc.jobs.list() if job.settings.name == job_name]
        job_id = None
        job_status = None
        if matching_jobs:
            job_id = matching_jobs[0].job_id
            job_status = get_job_status(job_id)
        return job_id, job_status
    except Exception as e:
        return job_id, job_status
    
def create_job_tasks(job_name, file_path, notebook_name, databricks_cluster_id, timeout):
    env = get_env().lower()
    job_tasks = []
    split_path = file_path.find("source")
    notebook_path = file_path[split_path:]
    notebook_path = os.path.dirname(notebook_path)+ "/notebooks/" +notebook_name
    notebook_path_run_ingestion = "framework/run_ingestion_ad_hoc_jobs"

    try:
        task = jobs.Task(
                    task_key = job_name,
                    depends_on = [],
                    existing_cluster_id = f"{databricks_cluster_id}",
                    notebook_task = jobs.NotebookTask(
                        notebook_path   = f"{notebook_path_run_ingestion}",
                        source          = jobs.Source("GIT"),
                        base_parameters = {"job_name": f"{job_name}"
                                          ,"notebook_run": f"{notebook_path}"
                                          ,"timeout": timeout}))
        job_tasks.append(task)
        return job_tasks
    except Exception as ex:
        return job_tasks

# COMMAND ----------

# DBTITLE 1,Verifica parâmetros para teste unitários
env = get_env().lower()

parameters = dbutils.widgets.getAll()

branch = dbutils.widgets.get('branch') if (any('branch' in key for key in parameters)) else env
try:
    files_filter = normalize_list(dbutils.widgets.get('files_filter')) \
                        if (any('files_filter' in key for key in parameters)) \
                        else []
except:
    files_filter = []

print(f"Branch específica: {branch}" if branch != "" else "" )
print(f"Filtrar arquivos: {files_filter}" if len(files_filter) > 0 else "" )

# COMMAND ----------

# DBTITLE 1,Definição de variáveis
# Se a branch foi enviada via parametro então ela será usada, caso contrario define a branch de acordo com o ambiente
git_branch             = branch if branch != "" else ("dev" if env == "dev" else "main")

# Clona o repositório  Git para recuperar arquivos alterados e arquivo de configuração
clone_git_repo, \
clone_path             = create_clone_git_repo(env, branch)

job_variables          = get_all_job_variables(clone_git_repo)
databricks_cluster_id  = get_job_variables(job_variables, "databricks_cluster_id", env.upper())
check_updates_interval = get_job_variables(job_variables, "check_updates_interval", env.upper())

print("Variáveis:"
     ,'\n', f"env: {env}"
     ,'\n', f"databricks_cluster_id: {databricks_cluster_id}"
     ,'\n', f"check_updates_interval: {check_updates_interval}")

# COMMAND ----------

# DBTITLE 1,Validações e início da criação/alteração dos jobs
results = get_last_changed_files(clone_git_repo, check_updates_interval, files_filter)

count_created = 0
count_updated = 0
count_error   = 0

print(f"Processar {len(results)} arquivo(s):\n" if len(results) > 0 else "Não há arquivos para processar")

for file in results:
    print("\t", f"{file[0]}")

    ad_hoc_job_param = file[2] # Separa o conteudo yaml para processamento

    if ad_hoc_job_param:
        schema     = ad_hoc_job_param["target"]["schema"]
        table_name = ad_hoc_job_param["target"]["table"]
        job_name   = "pipeline_s3_"+schema+"_"+table_name
        timeout    = ad_hoc_job_param["timeout"] if "timeout" in ad_hoc_job_param else 3600

        job_id, job_status = get_job_id_by_name(job_name)

        if job_status not in ["RUNNING", "PENDING", "QUEUED"]:
            # Monta a task para criação do Job
            job_tasks = \
                create_job_tasks(job_name
                                ,file[0]
                                ,ad_hoc_job_param["notebook_name"]
                                ,databricks_cluster_id
                                ,timeout)
            
            if len(job_tasks) > 0:
                # Monta o source (repositório Git) do Job
                git_source = \
                    jobs.GitSource(git_url      = "https://github.com/YMH-BR/data",
                                   git_provider = jobs.GitProvider.GIT_HUB,
                                   git_branch   = git_branch)

                # Monta o agendamento do Job
                schedule = ad_hoc_job_param['schedule']['quartz_cron']
                pause_status = \
                    jobs.PauseStatus.PAUSED if ((ad_hoc_job_param['schedule']['paused']) or (env == "dev")) \
                                          else jobs.PauseStatus.UNPAUSED
                job_schedule = jobs.CronSchedule(quartz_cron_expression = f"{schedule}"
                                                ,timezone_id            = "UTC"
                                                ,pause_status           = pause_status)
                
                # Inicio do processo de atualização ou criação do job
                try:
                    status = 'success'
                    if job_id: # Atualiza o job
                        try:
                            new_settings = \
                                jobs.JobSettings(name       = job_name
                                                ,git_source = git_source
                                                ,schedule   = job_schedule
                                                ,tasks      = job_tasks)
                            
                            ret = wc.jobs.update(job_id       = job_id
                                                ,new_settings = new_settings)
                            
                            action = "Atualizado"
                            count_updated += 1
                        except Exception as e:
                            status = 'error'                            
                            count_error += 1
                            msg_error = f"Erro ao atualizar o job {job_name} - {str(e)[0:100]}"
                    else: # Cria o Job
                        try:
                            create_response = wc.jobs.create(name       = job_name
                                                            ,git_source = git_source
                                                            ,schedule   = job_schedule
                                                            ,tasks      = job_tasks )
                            
                            job_id = create_response.job_id
                            action = "Criado"
                            count_created += 1
                        except Exception as e:
                            status = 'error'
                            count_error += 1
                            msg_error = f"Erro ao criar o job {job_name} - {str(e)[0:100]}"
                    
                    # Registra o log da criação ou atualização do job
                    log_data = {"log_status": status
                               ,"ingest_config_file": file[0]
                               ,"table_name": table_name
                               ,"schedule": schedule
                               ,"message": f"Job {job_id} - {job_name} - {action} com sucesso" if status == 'success' else msg_error
                               ,"job_id": job_id
                               ,"job_name": job_name}
                    log_id = log_register(log_data)
                except Exception as e:
                    log_data = {"log_status": "error"
                               ,"ingest_config_file": file[0]
                               ,"table_name": table_name
                               ,"message": f"Erro na criação/atualização do Job {job_id} {job_name} - {str(e)[0:100]}"
                               ,"job_id": job_id
                               ,"job_name": job_name}
                    log_id = log_register(log_data)

print(f"\n{count_created} jobs criados, {count_updated} jobs atualizados, {count_error} jobs com erros")

# COMMAND ----------

# Remove o diretório temporário do git clone
rmdir_clone_git_repo(clone_path)
