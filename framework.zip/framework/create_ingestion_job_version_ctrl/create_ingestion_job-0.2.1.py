# Databricks notebook source
# MAGIC %md
# MAGIC #### Este Notebook será incluído em um job a ser executado a cada 1 hora
# MAGIC
# MAGIC * Irá verificar no repositório https://github.com/YMH-BR/data/source/pipeline_parameters se existem configurações de ingestões de tabelas aptas para criação ou alteração de jobs, estes jobs irá executar o framework de ingestão.
# MAGIC
# MAGIC 2025-06-23 - Marco Conti - Versão 0.2.0
# MAGIC   - Mudanção no formato do arquivo de parametros de json para yaml
# MAGIC   - Inclusão de opção para execução isolada (path ou path+file )
# MAGIC   
# MAGIC 2025-06-26 - Marco Conti - Versão 0.2.1
# MAGIC   - Correção na execução via notebook de testes de unitários

# COMMAND ----------

# DBTITLE 1,Importa as lib's necessárias na execução
from datetime import datetime, timezone, timedelta
import requests, json, os, time, yaml
from pathlib import Path

# COMMAND ----------

# DBTITLE 1,Verifica se o databricks sdk está instalada
import pkg_resources
import subprocess
import sys

ls_package = ["databricks-sdk"]
for package_name in ls_package:
    try:
        dist = pkg_resources.get_distribution(package_name)
        print(f"'{package_name}' Já está instalada, versão: {dist.version}, {type(dist.version)}")
    except pkg_resources.DistributionNotFound:
        print(f"'{package_name}' Ainda não está instalada, será instalada a seguir...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", f"{package_name}>=0.57.0"])
        dist = pkg_resources.get_distribution(package_name)
        print(f"'{package_name}' Instalada com sucesso, versão: {dist.version}")

from databricks.sdk import WorkspaceClient
from databricks.sdk.service import jobs

# COMMAND ----------

# DBTITLE 1,Prepara o databricks sdk
DATABRICKS_HOST = dbutils.secrets.get("data-eng-workflow-scope", "DATABRICKS_HOST")
DATABRICKS_CLIENT_ID = dbutils.secrets.get("data-eng-workflow-scope", "DATABRICKS_CLIENT_ID")
DATABRICKS_CLIENT_SECRET = dbutils.secrets.get("data-eng-workflow-scope", "DATABRICKS_CLIENT_SECRET")
pat_token = dbutils.secrets.get("data-eng-workflow-scope", "pat_token")

wc = WorkspaceClient(host=DATABRICKS_HOST
                    ,token=pat_token
                    ,auth_type="pat")

# COMMAND ----------

# DBTITLE 1,Métodos e funções utilizadas durante a execução
def get_env():
    return os.environ.get("DATABRICKS_ENV")

def get_job_variables(variable):
    env = get_env()
    if env == None:
        print("Não foi possível identificar o ambiente")
        return ""

    path = "/Workspace/Repos/YMH-BR/data/framework/create_ingestion_job_variables.json"

    ret_variable = ""
    try:
        with open(path) as json_file:
            create_ingestion_job_variables = json.load(json_file)
    except Exception as e:
        print(f"Não foi possível ler o arquivo de variáveis {path}, erro: \n {str(e)[0:100]}")
    
    try:
        ret_variable = \
            create_ingestion_job_variables[variable] if (type(create_ingestion_job_variables[variable]) == str) \
                                                   else create_ingestion_job_variables[variable][env]
    except Exception as e:
        print(f"Variavel: {variable} não encontrada")
        return ""

    return ret_variable

"""
    Metodo para registrar log's durante o processamento
    o resultado pode ser consultado na tabela: controls_dev.loads.create_ingestion_job_log
"""
def log_register(log_data):
    def gen_id():
        timestamp = time.time()
        randon_number = (int(timestamp) ^ (int(timestamp) << 1)) % 10000000000
        return randon_number
    
    env = get_env()
    current_datetime = datetime.now(timezone(timedelta(hours=-3)))
    current_datetime = current_datetime.strftime("%Y-%m-%d %H:%M:%S")
    table = f"controls_{env}.loads.create_ingestion_job_log"
    log_id = gen_id()

    for rec in range(2):
        erro = ""
        if rec == 1:
            prefix = "Não foi possível caregar os dados do atributo:"
            log_data["pipeline_parameters"] = f"{prefix} pipeline_parameters - {erro}"
            log_data["job_settings"] = f"{prefix} job_settings - {erro}"
        try:
            insert_clause = f"Insert into {table}(log_id, log_date, "
            cols_ins = ",".join( [i[0] for i in log_data.items()])+")"
            insert_clause += cols_ins

            insert_values = f"Values({log_id}, '{current_datetime}',"
            clear_None = [i[1] if i[1] is not None else "" for i in log_data.items()]

            for i in clear_None:
                if isinstance(i, str):
                    insert_values += f"'{i}'"+","
                    insert_values.replace("'","''")
                else:
                    insert_values += f"{i}"+","
            insert_values = insert_values[:-1]+")"

            dml_cmd = f"""{insert_clause} {insert_values}"""
            spark.sql(dml_cmd)
            break
        except Exception as e:
            pass          
    return log_id

"""
    Metodo responsável por ler o arquivos SQL e retornar seu conteúdo 
"""
def read_sql_files(path, file_name):
    sql = ""
    path_ = path+"/" if path[-1] != "/" else path
    try:
        if (file_name != ""):
            sql_path = f"{os.path.dirname(path_)}/query_source/{file_name}"
            with open(sql_path) as file:
                sql = file.read()
    except Exception as e:
        pass
    return sql

"""
    Lista todos os arquivos *.sql e *.yaml (pipeline_parameters e table schema) no repositório:
    https://github.com/YMH-BR/data/sources/pipeline_parameters
"""
def find_all_files_updated(base_path, target_filename):
    try:
        matches = []
        for root, dirs, files in os.walk(base_path):
            if 'tools' not in root:
                for file in files:
                    if (file.endswith(target_filename)):
                        file_path = os.path.join(root, file)
                        last_modification_time = os.path.getmtime(file_path)
                        last_modification_date = datetime.fromtimestamp(last_modification_time).strftime('%Y-%m-%d %H:%M:%S')
                        matches.append((file_path, last_modification_date))
        return matches
    except Exception as e:
        print(f"Nenhum arquivo de configuração foi encontrado - {str(e)[0:100]}")
        return matches
    
"""
    Verifica os arquivos que foram alterados para então criar ou atualizar os jobs
"""
def check_updated_files(base_path, check_current_datetime):
    check_updates_interval = int(get_job_variables("check_updates_interval"))
        
    path = Path(base_path)
    if path.suffix:
        check_files_ext = [path.name]
        base_path = path.parent
    else:
        check_files_ext = [".sql", ".yaml"]

    current_datetime = datetime.now(timezone(timedelta(hours=-check_updates_interval)))
    current_datetime = current_datetime.strftime("%Y-%m-%d %H:%M:%S")
    updated_files = []
    filtered_files = []
    for file_ext in check_files_ext:
        results = find_all_files_updated(base_path, file_ext)
        if len(results) > 0:
            if check_current_datetime:
                filtered_files = [f[0] for f in results if f[1] >= current_datetime]
            else:
                filtered_files = [f[0] for f in results] 

            if len(filtered_files) > 0:
                updated_files.append(filtered_files)
            
    # Se arquivos sql foram alterados, selecionar o yaml correspondente
    ret_updated_sql_files = list(set(item for sublist in updated_files for item in sublist if item.endswith(".sql")))
    if len(ret_updated_sql_files) > 0:
        for sql_file in ret_updated_sql_files:
            results_yaml_by_sql = find_all_files_updated(sql_file.split('query_source/')[0], ".yaml")
            for yaml_file in results_yaml_by_sql:
                with open(yaml_file[0], 'r') as file:
                    data = yaml.safe_load(file)
                if sql_file.split('query_source/')[1] in json.dumps(data):
                    updated_files.append(yaml_file[0])

    ret_updated_yaml_files = list(set(item for sublist in updated_files for item in sublist if item.endswith(".yaml")))
    ret_updated_files = ret_updated_yaml_files

    return ret_updated_files
    
"""
    Verifica as dependências entre os layers, isso é importante para garantir que os jobs sejam criados na ordem correta
"""
def check_layers_dependencies(layers_ls):
    dependencies = {
        "bronze": "landing",
        "silver": "bronze",
        "gold": "silver"
    }
    layer_dict = {item["layer"]: item["count"] for item in layers_ls}
    for dependent, required in dependencies.items():
        if layer_dict.get(dependent, 0) > 0 and layer_dict.get(required, 0) == 0:
            return False # Dependências falharam
    return True # Dependêncis Ok

"""
    Verifica se as camadas estão corretas, com os campos preenchidos e as dependências estão corretas
"""
def check_layers(pipeline_parameter):
    try:
        layers_check = ["landing", "bronze", "silver", "gold"]
        attrs_check = ["catalog", "schema", "table"]
        layers_ls = []
        for layer in layers_check:
            count = 0
            layer_dict = {}
            if layer in ["silver", "gold"]:
                for key, value in pipeline_parameter[layer].items(): # Verifica nas pastas source e target
                    if key in ['source', 'target']:
                        for attr in attrs_check:
                            if attr in value:
                                if value[attr]:
                                    count += 1
            else:
                for attr in attrs_check:
                    if attr in pipeline_parameter[layer]:
                        count += 1

            layer_dict["layer"] = layer
            layer_dict["count"] = count
            layers_ls.append(layer_dict)

        # Verifica se as dependencias do layers estão corretas
        ret_check_dep = check_layers_dependencies(layers_ls)
        
        # Monta a lista de camadas a serem processadas
        layers_run = []
        if ret_check_dep:
            check_layers_run = \
                [{"layer": l['layer']
                 ,"count": l['count']
                 ,"run": ( ( True if (l["count"] % len(attrs_check)) == 0 else False) if l["count"] > 0 else False) } for l in layers_ls]
            layers_run = [clr['layer'] for clr in check_layers_run if (clr['layer'] in ("bronze", "silver", "gold") and clr["run"])]
    except Exception as e:
        layers_run = []
    
    return layers_run


def get_job_status(job_id):
    try:
        runs = list(wc.jobs.list_runs(job_id=job_id, limit=1))
        life_cycle_state = ""
        if runs:
            latest_run = runs[0]
            life_cycle_state = latest_run.state.life_cycle_state.name
        return life_cycle_state
    except Exception as e:
        return ""

def get_job_id_by_name(job_name):
    try:
        matching_jobs = [job for job in wc.jobs.list() if job.settings.name == job_name]
        job_id = None
        job_status = None
        if matching_jobs:
            job_id = matching_jobs[0].job_id
            job_status = get_job_status(job_id)
        return job_id, job_status
    except Exception as e:
        return job_id, job_status

"""
    Baseado nos arquivos de parametros YAML (<tabela>.yaml), monta as tasks que serão usadas para criar ou atualizar os jobs
"""
def create_job_tasks(env, notebook_engine_path_bronze, notebook_engine_path_others
                    ,databricks_cluster_id, layers_run, param, path_config_json):
    try:
        pipeline_parameters = {}

        pipeline_parameters_header = {}
        pipeline_parameters_header['pipeline_type'] = param['pipeline_type']
        pipeline_parameters_header['pipeline_mode'] = param['pipeline_mode']
        pipeline_parameters_header['rdbms']         = param['rdbms']

        pipeline_parameters_footer = {}
        pipeline_parameters_footer["days_past"]       = param["days_past"]
        pipeline_parameters_footer['replace_columns'] = param['replace_columns']
        pipeline_parameters_footer['columns']         = param['columns']

        job_tasks = []
        for rec_l, layer in enumerate(layers_run):
            task_param = {}
            task_param["temporary_catalog"] = "temporary_"+env
            task_param["temporary_schema"]  = param["bronze"]['schema'] if layers_run[0] == 'bronze' else param["silver"]['schema'] 
            task_param["temporary_table"]   = param["bronze"]['table']  if layers_run[0] == 'bronze' else param["silver"]['table'] 

            if layer == 'bronze':
                for ind, aux_layer in enumerate(["landing", "bronze"]):
                    if ind == 0:
                        job_name = param[aux_layer]['schema'] + param[aux_layer]['table']
                    
                    task_param[f"{aux_layer}_catalog"] = param[aux_layer]['catalog']+"_"+env
                    task_param[f"{aux_layer}_schema"]  = param[aux_layer]['schema']
                    task_param[f"{aux_layer}_table"]   = param[aux_layer]['table']
            else:
                for ind, aux_layer in enumerate(["source", "target"]):
                    if ind == 0:
                        job_name = param[layer][aux_layer]['schema'] + param[layer][aux_layer]['table']
                    
                    task_param[f"{aux_layer}_catalog"] = param[layer][aux_layer]['catalog']+"_"+env
                    task_param[f"{aux_layer}_schema"]  = param[layer][aux_layer]['schema']
                    task_param[f"{aux_layer}_table"]   = param[layer][aux_layer]['table']
            
            if ((not param[layer]["hash_columns"]) or (param[layer]["hash_columns"] is None)):
                task_param["hash_columns"] = []
            else:
                task_param["hash_columns"] = param[layer]["hash_columns"]
            
            task_param["partition_column"] = param[layer]["partition_column"]

            # Identifica se existe algum arquivo SQL a ser utilizado
            query_source = ""
            query_source_file_name = param[layer]['query_source_file_name'] if 'query_source_file_name' in param[layer] else ""
            if query_source_file_name != "":
                query_source = read_sql_files(path_config_json, query_source_file_name)

            # Se a query_source não estiver preenchida monta uma query com a tabela Source pois o FrameWork necessita para o processamento
            if query_source == "":
                if ((layer in ("silver", "gold")) and 
                    (param['pipeline_type'] == "incremental") and 
                    (param[layer]["partition_column"])):
                    table = param[layer]['source']['catalog']+"_"+env+"."+param[layer]['source']['schema']+"."+param[layer]['source']['table']
                    query_source = f"Select * from {table}"
                else:
                    query_source = ""
            
            # Junta as partes dos parametros a serem enviados ao JOB
            pipeline_parameters = pipeline_parameters_header.copy()
            pipeline_parameters.update(task_param)
            pipeline_parameters.update(pipeline_parameters_footer)
            
            # Cria a lista de task's a serem utilizadas na criação ou atualização do JOb
            task_name = "landing_bronze" if layer == "bronze" else "bronze_silver" if layer == "silver" else "silver_gold"
            notebook_engine_path = notebook_engine_path_bronze if layer == "bronze" else notebook_engine_path_others

            depends_task = []
            if rec_l > 0:
                depends_task = [jobs.TaskDependency(task_key=layers_run[(rec_l-1)])]

            task = jobs.Task(
                        task_key = layer,
                        depends_on = depends_task,
                        existing_cluster_id = f"{databricks_cluster_id}",
                        notebook_task = jobs.NotebookTask(
                            notebook_path = f"{notebook_engine_path}",
                            base_parameters = {"task_name": task_name
                                              ,"pipeline_parameters": json.dumps(pipeline_parameters)
                                              ,"query_source": str(query_source)},
                            source=jobs.Source.WORKSPACE
                        )
                )
            job_tasks.append(task)
        return job_tasks
    except Exception as e:
        print(f"create_job_tasks: \n {e}")
        return []
    return job_tasks

# COMMAND ----------

# DBTITLE 1,Definição de variáveis
notebook_engine_path_bronze = get_job_variables("notebook_engine_path_bronze")
notebook_engine_path_others = get_job_variables("notebook_engine_path_others")
base_path                   = get_job_variables("base_path")
config_ingestao_filename    = get_job_variables("config_ingestao_filename")
databricks_cluster_id       = get_job_variables("databricks_cluster_id")
env                         = get_env().lower()
check_updates_interval      = get_job_variables("check_updates_interval")

print("Variáveis:"
     ,'\n', notebook_engine_path_bronze
     ,'\n', notebook_engine_path_others
     ,'\n', base_path
     ,'\n', config_ingestao_filename
     ,'\n', databricks_cluster_id
     ,'\n', env
     ,'\n', check_updates_interval)

# COMMAND ----------

# DBTITLE 1,Verifica se parâmetros para processamento específico foram passados
parameters = dbutils.widgets.getAll()
espec_source_path = dbutils.widgets.get('espec_source_path') if (any('espec_source_path' in key for key in parameters)) else ""

print(f"Path específico: {espec_source_path}" if espec_source_path != "" else "" )

# COMMAND ----------

# DBTITLE 1,Validações de parâmetros e Execução da criação ou atualização dos job
if espec_source_path != "":
    results = check_updated_files(espec_source_path, True) 
else:
    results = check_updated_files(base_path, True) # Verfica arquivos alterados antes da quantidade de horas do parametro check_updates_interval

count_created = 0
count_updated = 0
count_error = 0

print("Processar arquivo(s):\n" if len(results) > 0 else "Não há arquivos para processar")

for file in results:
    print("\t", f"{file}")
    json_config_parameters = {}
    # Verifica se o arquivo de parametrizações (YAML) existe e está consistente
    try:
        with open(file) as yaml_file:
            table_param = yaml.safe_load(yaml_file)
    except yaml.YAMLError as e:
        msg_error = f"Arquivo {file} com formato inválido, erro: {str(e)[0:100]}"
        log_data = {"log_status": "error", "ingest_config_file": file,  "message": msg_error}
        log_id = log_register(log_data)
    except Exception as e:
        msg_error = f"Não foi possível ler o arquivo {file}, erro: \n {str(e)[0:100]}"
        log_data = {"log_status": "error", "ingest_config_file": file,  "message": msg_error}
        log_id = log_register(log_data)

    # Verifica se as camadas estão preenchidas corretamente
    layers_run = check_layers(table_param)

    if len(layers_run) > 0:
        schema_table = table_param["landing"]["schema"]+table_param["landing"]["table"]
        job_name = str(schema_table.replace("/","_").replace("full","")[1:(len(schema_table)-1)]).rstrip("_")
        job_name = "pipeline_"+job_name
        table_name = table_param[layers_run[0]]['table'] if layers_run[0] == 'bronze' else table_param[layers_run[0]]["source"]['table']

        job_id, job_status = get_job_id_by_name(job_name)

        # NÃO Atualiza o job se ele estiver em execução
        if job_status not in ["RUNNING", "PENDING", "QUEUED"]:
            # Monta as task para o job a ser criado ao atualizado
            job_tasks = create_job_tasks(env, notebook_engine_path_bronze, notebook_engine_path_others
                                        ,databricks_cluster_id, layers_run, table_param, file)

            # Monta o agendamento do Job
            schedule = table_param['schedule']['quartz_cron']
            pause_status = jobs.PauseStatus.PAUSED if ((table_param['schedule']['paused']) or (env == "dev")) \
                                                 else jobs.PauseStatus.UNPAUSED
            job_schedule = jobs.CronSchedule(quartz_cron_expression = f"{schedule}"
                                            ,timezone_id            = "UTC"
                                            ,pause_status           = pause_status)

            # Inicio o processo de atualização ou criação do job
            try:
                status = 'success'
                if job_id: # Atualiza o job
                    try:
                        new_settings = \
                            jobs.JobSettings(name     = job_name
                                            ,schedule = job_schedule
                                            ,tasks    = job_tasks)
                        
                        ret = wc.jobs.update(job_id       = job_id
                                            ,new_settings = new_settings)
                        action = "Atualizado"
                        count_updated += 1
                    except Exception as e:
                        status = 'error'                            
                        count_error += 1
                        msg_error = f"Erro ao atualizar o job {job_name} - {str(e)[0:100]}"
                else: # Cria o Job
                    try:
                        create_response = wc.jobs.create(name     = job_name
                                                        ,schedule = job_schedule
                                                        ,tasks    = job_tasks )
                        job_id = create_response.job_id
                        action = "Criado"
                        count_created += 1
                    except Exception as e:
                        status = 'error'
                        count_error += 1
                        msg_error = f"Erro ao criar o job {job_name} - {str(e)[0:100]}"
                
                # Registra o log da criação ou atualização do job
                log_data = {"log_status": status
                           ,"ingest_config_file": file
                           ,"table_name": table_name
                           ,"schedule": schedule
                           ,"message": f"Job {job_id} - {job_name} - {action} com sucesso" if status == 'success' else msg_error
                           ,"job_id": job_id
                           ,"job_name": job_name}
                log_id = log_register(log_data)
            except Exception as e:
                log_data = {"log_status": "error"
                           ,"ingest_config_file": file
                           ,"table_name": table_name
                           ,"message": f"Erro na criação/atualização do Job {job_id} {job_name} - {str(e)[0:100]}"
                           ,"job_id": job_id
                           ,"job_name": job_name}
                log_id = log_register(log_data)
    else:
        count_error += 1
        log_data = {"log_status": "error"
                   ,"ingest_config_file": file
                   ,"message": "Erro no preenchimento nos parametros de camadas (landing, bronze, silver ou gold)"}
        log_id = log_register(log_data)

print(f"\n{count_created} jobs criados, {count_updated} jobs atualizados, {count_error} jobs com erros")