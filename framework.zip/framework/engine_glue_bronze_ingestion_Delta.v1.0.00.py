# Databricks notebook source
# MAGIC %md
# MAGIC * 2025-07-10 - Marco Conti - Versão 1.0.01
# MAGIC   * Modificação nos métodos de tratamento de replace_columns, columns e criação da coluna _hash
# MAGIC * 2025-07-22 - Marco Conti - Versão 1.0.01
# MAGIC   * Inclusão de tratamento para Formatar o SQL command enviado via query_source e a adição de filtro na query_source
# MAGIC * 2025-07-31 - Marco Conti - Versão 1.0.01
# MAGIC   * Criação de schema caso não exista
# MAGIC * 2025-08-18 - Marco Conti - Versão 2.0.01
# MAGIC   * Mudança para gravação na camada Bronze para partição ano, mês e dia

# COMMAND ----------

# MAGIC %md
# MAGIC ### **Engine Glue Bronze Ingestion**

# COMMAND ----------

# DBTITLE 1,Carrega as bibliotecas
import sys
import json
import pytz
import os
import re

from datetime import date, datetime, timedelta, timezone
from delta.tables import DeltaTable
from functools import reduce
from pyspark.sql.functions import concat, sha2, col, coalesce, expr, lit, year, month, day, current_timestamp, to_timestamp, from_utc_timestamp, format_string, when, concat_ws
from pyspark.sql.types import *
from sqlglot import parse_one, exp
from sqlglot.errors import ParseError

from datamax.commons import get_env
from datamax.table_infos import get_lasts_partitions
from datamax.date_processing import get_interval_bronze_dates

# COMMAND ----------

# DBTITLE 1,Métodos e funções utilizados durante o processamento
def sql_format(query_source):
    """
    Formata o sql da query para evitar problemas com palavras chave coladas em colunas, quebras de linhas, etc
    """
    # Fazer o parse da query_source para validar seu conteudo
    try:
        query_source_parse = str(parse_one(query_source))
    except ParseError as pe:
        error = str(pe.errors).replace("'","").replace('"','')
        print(f"Query com inconsistências: {error}")

    return query_source

def check_owner(catalog, schema, schema_owner):
    """
    Verfica o owner no schema, caso não seja um owner de sistema ele faz a alteração
    """
    try:
        describe_cmd = f"DESCRIBE DATABASE EXTENDED {catalog}.{schema}"
        schema_infos = spark.sql(describe_cmd).collect()
        current_scheme_owner = [own["database_description_value"] for own in schema_infos if own["database_description_item"] == "Owner"][0]
        # Se o owner do job não for um owner de sistema faz a alteração
        if current_scheme_owner != schema_owner:
            alter_cmd = f"ALTER SCHEMA {catalog}.{schema} OWNER TO `{schema_owner}`"
            spark.sql(alter_cmd)
        return schema_owner
    except Exception as e:
        return schema_owner

def check_grants(catalog, schema, owner):
    """
    Verifica as permissões associadas ao schema, para incluir caso esteja faltando alguma
    """
    try:
        owner_grants_set = \
            {"data-eng-yamaha"   : ["CREATE TABLE","READ VOLUME","WRITE VOLUME"
                                   ,"USE SCHEMA","EXECUTE","REFRESH","MODIFY","SELECT"]
            ,"data-admins-yamaha": ["ALL PRIVILEGES","EXTERNAL USE SCHEMA","MANAGE"]}

        grants_cmd       = f"SHOW GRANTS ON SCHEMA {catalog}.{schema}"
        grants_schema    = spark.sql(grants_cmd).collect()
        ls_grants_schema = [gs["ActionType"] for gs in grants_schema if gs['Principal'] == owner]
        # Separa somente as permissões que estão faltando
        grant_add        = list(set(owner_grants_set[owner]) - set(ls_grants_schema))

        for grant in grant_add:
            grant_cmd = f"GRANT {grant} ON SCHEMA {catalog}.{schema} TO `{owner}`"
            spark.sql(grant_cmd)
    except:
        pass

def create_schema(catalog, schema, schema_owner):
    """
    Caso o schema não exista ele será criado, caso exista ele verifica se o owner é um owner de sistema e verifica as permissões
    """
    try:
        if not spark.catalog.databaseExists(catalog+"."+schema):
            cmd_create = f"CREATE DATABASE IF NOT EXISTS {catalog}.{schema}"
            spark.sql(cmd_create)

        owner = check_owner(catalog, schema, schema_owner)
        check_grants(catalog, schema, owner)
    except:
        pass

    return catalog, schema

# Incluir na DataMax
def replace_columns_caracters(df):
    """
    # Substitui o caracteres no nome das colunas - parâmetro replace_columns = [{"@": "_", "#", "_"}]
    """
    try:
        cols = df.columns
        if isinstance(replace_columns, list):
            for rc in replace_columns:
                for old, new in rc.items():
                    cols = [col.replace(old, new) for col in cols]

            df = df.toDF(*cols)
        return df
    except Exception as e:
        # Interrompe a substituição de colunas se ocorrer error   
        return df
        
# Incluir na DataMax
def replace_columns_name(df):
    """
    # Substitui o nome das colunas - parâmetro columns = [{"old_name": "new_name"}]
    """
    try:
        if isinstance(columns, list):
            for col in columns:
                for old_name, new_name in col.items():
                    df = df.withColumnRenamed(old_name.replace('-', '_'), new_name)
        return df
    except Exception as e:
        # Interrompe a substituição de colunas se ocorrer error
        return df

# Incluir na DataMax
def count_written_rows(table_name):
    rows_written = 0
    try:
        delta_table = DeltaTable.forName(spark, table_name)
        # Pega o histórico e lê a última operação
        last_op = (
            delta_table.history()
            .select("operation", "operationMetrics")
            .orderBy("version", ascending=False)
            .first()
        )
        # Extrai o número de linhas gravadas
        rows_written = int(last_op.asDict()["operationMetrics"].get("numOutputRows", 0))
        return rows_written
    except Exception as e:
        return rows_written

def list_S3_bucket_partition_names(base_path, ls_part_cols):
    """
    Função irá verificae se o Bucket no S3 está particionado por ano, mês e dia.
    Se sim, irá retornar uma lista com os nomes das "pastas" do Bucket
    """
    def is_partition_folder(folder_name, partition_columns):
        key = folder_name.split('=')[0].upper()
        return key in [col.upper() for col in partition_columns]
    
    def match_partition_key(value, valid_keys):
        value_upper = value.upper()
        for key in valid_keys:
            if key.upper() == value_upper:
                return value
        return None

    global found_file
    global ls_table_parts

    try:
        items = dbutils.fs.ls(base_path)
        for item in items:
            if found_file: # Se chegou no nível de arquivo interrompe a iteração da função
                break 

            if item.isDir():
                if is_partition_folder(item.name, ls_part_cols):
                    # Pega o nome da partição no Bucket
                    part_name = match_partition_key(item.name.split("=")[0], ls_part_cols)
                    ls_table_parts.append(part_name)
                list_S3_bucket_partition_names(item.path, ls_part_cols)
            else:
                found_file = True

        return ls_table_parts
    except Exception as e:
        return []
    
def alter_table_add_columns(df, table_name):
    """
    A partir da comparação entre Dataframe (Origem) e a tabela de destino
    Adiciona colunas novas, caso existam
    """
    try:
        cols_ignore = ['_hash', '_year', '_month', '_day', '_ingestionin']
        table_cols  = [c.name for c in spark.table(table_name).schema if c.name not in cols_ignore]

        for field in df.schema.fields:
            col   = field.name
            dtype = field.dataType

            if ((col not in table_cols) and (col not in cols_ignore)):
                add_col_ddl = ""
                if isinstance(dtype, StringType):
                    sql_type = "STRING"
                elif isinstance(dtype, IntegerType):
                    sql_type = "INT"
                elif isinstance(dtype, LongType):
                    sql_type = "BIGINT"
                elif isinstance(dtype, DoubleType) or isinstance(dtype, FloatType):
                    sql_type = "DOUBLE"
                elif isinstance(dtype, BooleanType):
                    sql_type = "BOOLEAN"
                elif isinstance(dtype, DateType):
                    sql_type = "DATE"
                elif isinstance(dtype, TimestampType):
                    sql_type = "TIMESTAMP"
                elif isinstance(dtype, DecimalType):
                    sql_type = f"DECIMAL({dtype.precision},{dtype.scale})"
                else:
                    sql_type = "STRING" # se não identificar o datatype, cria uma string

                add_col_ddl = f"ALTER TABLE {table_name} ADD COLUMNS ({col} {sql_type});"
                if add_col_ddl != "":
                    spark.sql(add_col_ddl)
    except Exception as e:
        pass

def convert_year_month_to_int(table_name):
    df_table =  spark.table(table_name)
    cols_check = ["_year", "_month"]
    df_raw_year_month = []
    df_raw_year_month = [dfs for dfs in df_table.schema.fields if dfs.name in cols_check and dfs.dataType != IntegerType()]

    if len(df_raw_year_month) > 0:
        df_modified = df_table.withColumns({"_year": col("_year").cast('int')
                                           ,"_month": col("_month").cast('int')})
        # Altera o datatype das colunas _year e _month
        df_modified.write.format("delta") \
                   .mode("overwrite") \
                   .option("overwriteSchema", "true") \
                   .saveAsable(table)


# COMMAND ----------

# DBTITLE 1,Momento de inicio do job
start_job = datetime.now(pytz.timezone('America/Sao_Paulo'))

# COMMAND ----------

# DBTITLE 1,Variáveis
env = get_env()
owner_schema = "data-eng-yamaha" if env == "dev" else "data-admins-yamaha"

# COMMAND ----------

# DBTITLE 1,Cria tabela de logs se não existir

sql = f"""
  create table if not exists controls_{env}.loads.jobs
  (
    job string,
    task string,
    framework string,
    type string,
    mode string,
    start timestamp,
    finish timestamp,
    minutes float,
    pipeline_config string,
    query_source string,
    affected_rows long,
    inserted_rows long,
    updated_rows long,
    deleted_rows long,
    status string,
    partition_date date
    )
  using delta
  partitioned by (partition_date)
"""

spark.sql(sql)

# COMMAND ----------

# DBTITLE 1,Captura nome do job
job_name = dbutils.notebook.entry_point.getDbutils().notebook().getContext().jobName()

# COMMAND ----------

# DBTITLE 1,Captura o framework utilizado
framework = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()

# COMMAND ----------

# DBTITLE 1,Captura os parametros do pipeline
try:
    parameter = "pipeline_parameters"
    pipeline_parameters = dbutils.widgets.get("pipeline_parameters")
    
    parameter = "load - pipeline_parameters"
    pipeline_settings = json.loads(pipeline_parameters)

except Exception as e:
    error = str(e).replace("'","").replace('"','')
    raise Exception(f"Não foi possível recuperar informações do parâmetro: {parameter} - {error}")

# COMMAND ----------

# DBTITLE 1,Lê parms: task_name, pipeline_type e pipeline_mode
try:
    parameter     = "task_name"
    task_name     = dbutils.widgets.get("task_name")

    parameter     = "pipeline_type"
    pipeline_type = pipeline_settings['pipeline_type']

    parameter     = "pipeline_mode"
    pipeline_mode = pipeline_settings['pipeline_mode']

except Exception as e:
    error = str(e).replace("'","").replace('"','')
    raise Exception(f"Não foi possível recuperar informações do parâmetro: {parameter} - {error}")

# COMMAND ----------

# DBTITLE 1,Dados do catalogo - landing
try:
    landing_catalog = pipeline_settings['landing_catalog']
    landing_schema = pipeline_settings['landing_schema']
    landing_table = pipeline_settings['landing_table']

    # Verifica se o schema existe, caso não exista cria
    create_schema(landing_catalog, landing_schema, owner_schema)
except Exception as e:
    error = str(e).replace("'","").replace('"','')
    raise Exception(f"Não foi possível recuperar informações dos parâmetros para Landing Table - {error}")

# COMMAND ----------

# DBTITLE 1,Dados do catalogo - bronze
try:
    bronze_catalog = pipeline_settings['bronze_catalog']
    bronze_schema  = pipeline_settings['bronze_schema']
    bronze_table   = pipeline_settings['bronze_table']

    # Verifica se o schema existe, caso não exista cria
    create_schema(bronze_catalog, bronze_schema, owner_schema)
except Exception as e:
    error = str(e).replace("'","").replace('"','')
    raise Exception(f"Não foi possível recuperar informações dos parâmetros para Bronze Table - {error}")

# COMMAND ----------

# DBTITLE 1,Recupera os valores dos parametro - partition_column e days_past
try:
    parameter        = "partition_column"
    partition_column = pipeline_settings['partition_column']
    partition_column = partition_column if partition_column != "" else ""

    parameter        = "days_past"
    days_past        = pipeline_settings['days_past']
except Exception as e:
    error = str(e).replace("'","").replace('"','')
    raise Exception(f"Não foi possível recuperar informações do parâmetro: {parameter} - {error}")

# COMMAND ----------

# DBTITLE 1,Recupera os valores dos parms: replace_colums e columns
try:
    parameter       = "replace_columns"
    replace_columns = pipeline_settings['replace_columns']
    
    parameter       = "columns"
    columns         = pipeline_settings['columns']
except Exception as e:
    error = str(e).replace("'","").replace('"','')
    raise Exception(f"Não foi possível recuperar informações do parâmetro: {parameter} - {error}")

# COMMAND ----------

# DBTITLE 1,Query do pipeline
query_source = dbutils.widgets.get("query_source")
if query_source != "":
    query_source = sql_format(query_source)

# COMMAND ----------

# DBTITLE 1,Path do Bucket no S3
s3_buckt_path = landing_catalog + landing_schema + landing_table

# COMMAND ----------

# DBTITLE 1,Verifica se o Bucket está particionado
found_file     = False
ls_table_parts = []
ls_part_cols   = ["YEAR", "MONTH", "DAY"]
ls_part_names  = list_S3_bucket_partition_names(s3_buckt_path, ls_part_cols)

# COMMAND ----------

# DBTITLE 1,Verifica se a tabela Destino possui partição, se sim monta o filtro de datas
default_past_day = 730 # 2 Anos - Colocar no arquivo de parametros 

# Se tiver partição recebida nos parametros ou o Bucket estiver particionado, monta a lista de datas a serem processadas.
if ((partition_column is not None and partition_column != '') or (len(ls_part_names) > 0)):
    if spark.catalog.tableExists(f'{bronze_catalog}.{bronze_schema}.{bronze_table}'):
        last_table_part = get_lasts_partitions(spark
                                              ,f'{bronze_catalog}.{bronze_schema}.{bronze_table}'
                                              ,partitions_numbers = 1)
    else:
        last_table_part = []

    # Monta os intervalos de datas a serem processadas. 
    first_day_of_year = False
    if len(last_table_part) > 0: # Tabela já existe e já possui partições
        start_date = f"{last_table_part[0]._year}-{last_table_part[0]._month:02d}-{last_table_part[0]._day:02d}"
        days_past  = (date.today() - datetime.strptime(start_date, "%Y-%m-%d").date()).days
    else:
        first_day_of_year = True
        days_past  = max(default_past_day, days_past)
        start_date = (datetime.now() - timedelta(days=days_past)).strftime("%Y-%m-%d")
else: # FULL
    days_past  = 1
    start_date = (datetime.now() - timedelta(days=days_past)).strftime("%Y-%m-%d")
    first_day_of_year = False

end_date = date.today().strftime("%Y-%m-%d")
ls_process_interval = get_interval_bronze_dates(start_date, end_date, days_past, first_day_of_year)

# COMMAND ----------

# DBTITLE 1,Tipos de filtro a ser aplicado no Bucket do S3
# Nesta célula será montado os possíveis tipos de filtros a serem aplicados no Bucket do S3, em 3 possibilidades:

# 1. Filtro pelo PARTITION_COLUMN (precisa sem uma data) + o intervalo de datas calculado anteriormente ou
# 2. Se o Bucket no S3 estiver particionado e for ano e mes,  filtra pelo intervalo calculado anteriormente ou
# 3. Sem Filtro 

filter_type = "NO_FILTER"
if (partition_column is not None and partition_column != ''):
    filter_type = "PARTITION_COLUMN"
elif len(ls_part_names) > 0:
    filter_type = "BUCKET_S3_PARTITIONED"

# COMMAND ----------

process_step = ""
try:
    inserted_rows = 0
    ls_part_cols  = []
    s3_buckt_path = landing_catalog + landing_schema + landing_table

    print(f"Tabela: {bronze_catalog}.{bronze_schema}.{bronze_table} - Filtro: {filter_type}")
    for interval in ls_process_interval[-5:]:

        read_write_start = datetime.now()
        
        process_step = "Montagem do Filtro para a query"
        if filter_type == "PARTITION_COLUMN":
            print(f"\tProcessando o intervalo: {start_date} - {end_date} ", end="")
            df_source  = spark.read.parquet(s3_buckt_path)
            start_date = ls_process_interval[0]["first_day"]
            end_date   = ls_process_interval[-1]["last_day"]

            df_source.createOrReplaceTempView("tmp_df_source")
            query_filter = \
                f"""Select * 
                    from tmp_df_source
                    where date_format({partition_column}, 'yyyy-MM-dd') between '{start_date}' and '{end_date}' 
            """
            df_source = spark.sql(query_filter)

        elif filter_type == "BUCKET_S3_PARTITIONED":
            print(f"\tProcessando o intervalo: {interval['first_day']} - {interval['last_day']} ", end="")
            path_run = s3_buckt_path
            for rec, part_name in enumerate(ls_table_parts[0:2],0): # Seleciona somente Ano e Mês
                if ls_part_cols[rec].upper() == part_name.upper():
                    value = int(interval['first_day'].split('-')[rec])
                    path_run += f"/{part_name}={value}"

            try:
                dbutils.fs.ls(path_run) # esse ls é para confirmar que o path existe
                df_source = spark.read.parquet(path_run)
            except Exception as e:
                # Salta para o próxima data
                continue
        else:
            print(f"\tExecutando carga FULL", end="")
            df_source  = spark.read.parquet(s3_buckt_path)
        
        # Substitui o nome das colunas - parâmetro replace_columns
        process_step = "Substitui o nome das colunas"
        df_source = replace_columns_name(df_source)

        # Substitui caracteres no nome das colunas - parâmetro column
        process_step = "Substitui caracteres no nome das colunas"
        df_source = replace_columns_caracters(df_source)
        
        # Cria a partição e o registro de data e hora de ingestão
        process_step = "Cria a partição e o registro de data e hora de ingestão"
        if filter_type == "PARTITION_COLUMN":
            df_source = df_source.withColumns({'_year' : year(partition_column)
                                              ,'_month': month(partition_column)
                                              ,'_day'  : day(partition_column)
                                              ,'_hash' : lit("")
                                              ,"_ingestionin": from_utc_timestamp(current_timestamp(), "America/Sao_Paulo")})
        elif filter_type == "BUCKET_S3_PARTITIONED":
            df_source = df_source.withColumns({"_year" : lit(int(interval['first_day'].split('-')[0]))
                                              ,"_month": lit(int(interval['first_day'].split('-')[1]))
                                              ,"_day"  : lit(1)
                                              ,'_hash' : lit("")
                                              ,"_ingestionin": from_utc_timestamp(current_timestamp(), "America/Sao_Paulo")}) 
        else:
            df_source = df_source.withColumns({"_year" : lit(start_job.year)
                                              ,"_month": lit(start_job.month)
                                              ,"_day"  : lit(start_job.day)
                                              ,'_hash' : lit("")
                                              ,"_ingestionin": from_utc_timestamp(current_timestamp(), "America/Sao_Paulo")})
            
        # Verifica se existe difereça de schema (somente colunas a mais):
        alter_table_add_columns(df_source, f'{bronze_catalog}.{bronze_schema}.{bronze_table}')
        
        # Equaliza os datatype das colunas _year e _month
        convert_year_month_to_int(f'{bronze_catalog}.{bronze_schema}.{bronze_table}')

        # Persiste o Dataframe na camada Bronze
        process_step = "Persiste o Dataframe na camada Bronze"

        spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic") # Possibilitar o overwrite das partições

        (df_source.write
                  .format('delta')
                  .mode('overwrite')
                  .partitionBy('_year', '_month', '_day')
                  .saveAsTable(f'{bronze_catalog}.{bronze_schema}.{bronze_table}'))

        written_rows      = count_written_rows(f'{bronze_catalog}.{bronze_schema}.{bronze_table}') 
        inserted_rows    += written_rows
        read_write_finish = datetime.now()
        read_write_time   = round(((read_write_finish - read_write_start).total_seconds()), 4)

        print(f"{written_rows} registros persistidos em {read_write_time} segundos")

        if filter_type in ["PARTITION_COLUMN", "NO_FILTER"]:
            # Nesses 2 casos Interrompe o loop pois o DF é filtrado uma só vês ou não é filtrado
            break
except Exception as e:
    error = str(e).replace("'","").replace('"','')
    raise Exception(f"Não foi realizar o processamento, passo: {process_step} - {error}")

# COMMAND ----------

# DBTITLE 1,Adiciona a execução ao log
try:
    finish_job     = datetime.now(pytz.timezone('America/Sao_Paulo'))
    partition_date = datetime.now(timezone(timedelta(hours=-3))).strftime("%Y-%m-%d")

    affected_rows = inserted_rows
    updated_rows  = 0
    deleted_rows  = 0

    sql = f'''
        INSERT INTO controls_{env}.loads.jobs
        (
            job, task, framework, type, mode, start, finish, minutes, pipeline_config, query_source, affected_rows, inserted_rows, updated_rows, deleted_rows, status, partition_date
        )
        VALUES
        (
            '{job_name}', '{task_name}', '{framework}', '{pipeline_type}', '{pipeline_mode}', '{start_job}', '{finish_job}', {round(((finish_job - start_job).total_seconds() / 60), 4)}, '{pipeline_parameters}', '{query_source.replace("'", "").replace("'", "")}', {affected_rows}, {inserted_rows}, {updated_rows}, {deleted_rows}, 'Success', '{partition_date}'
        )
    '''

    spark.sql(sql)
except Exception as e:
    print(f"Não foi possível registrar a informações de execução do job")

# COMMAND ----------

# DBTITLE 1,Inclui comentários nas colunas de partição e momento da ingestão
try:
    if not (partition_column is None or partition_column == ''):
        sql_update_comments = f"""
            ALTER TABLE {bronze_catalog}.{bronze_schema}.{bronze_table}
            CHANGE COLUMN _year COMMENT 'Coluna contendo o ano utilizado para particionamento'
        """
        spark.sql(sql_update_comments)

        sql_update_comments = f"""
            ALTER TABLE {bronze_catalog}.{bronze_schema}.{bronze_table}
            CHANGE COLUMN _month COMMENT 'Coluna contendo o mês utilizado para particionamento'
        """
        spark.sql(sql_update_comments) 

        sql_update_comments = f"""
            ALTER TABLE {bronze_catalog}.{bronze_schema}.{bronze_table}
            CHANGE COLUMN _day COMMENT 'Coluna contendo o dia utilizado para particionamento'
        """
        spark.sql(sql_update_comments) 

    sql_update_comments = f"""
        ALTER TABLE {bronze_catalog}.{bronze_schema}.{bronze_table}
        CHANGE COLUMN _ingestionin COMMENT 'Coluna contendo o momento da ingestão'
    """

    spark.sql(sql_update_comments)
except Exception as e:
    print(f"Não foi possível adicionar comentário às colunas ")

# COMMAND ----------

# DBTITLE 1,Aplica tags da configuração YAML nas tabelas bronze
try:
    if 'tags' in pipeline_settings and pipeline_settings['tags']:
        tags_list = pipeline_settings['tags']
        
        # Converte lista de tags para formato SQL de propriedades de tabela
        if tags_list:
            tblproperties_list = []
            for tag in tags_list:
                if isinstance(tag, str) and ':' in tag:
                    key, value = tag.split(':', 1)
                    tblproperties_list.append(f"'{key.strip()}' = '{value.strip()}'")
                elif isinstance(tag, dict):
                    for k, v in tag.items():
                        tblproperties_list.append(f"'{k}' = '{v}'")
            
            if tblproperties_list:
                tblproperties_sql = ', '.join(tblproperties_list)
                sql_apply_tags = f"""
                    ALTER TABLE {bronze_catalog}.{bronze_schema}.{bronze_table}
                    SET TBLPROPERTIES ({tblproperties_sql})
                """
                
                try:
                    spark.sql(sql_apply_tags)
                    print(f"Tags aplicadas na tabela {bronze_catalog}.{bronze_schema}.{bronze_table}")
                except Exception as e:
                    print(f"Erro ao aplicar tags na tabela: {str(e)}")
except Exception as e:
    print(f"Não foi possível aplicar as tags na tabela - {str(e)} ")

# COMMAND ----------

# DBTITLE 1,Finaliza engine
print('*** Finalizado ***')