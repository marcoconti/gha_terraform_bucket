# Databricks notebook source
# MAGIC %md
# MAGIC #### Este Notebook será incluído em um job a ser executado a cada 1 hora
# MAGIC
# MAGIC * Irá verificar no repositório https://github.com/YMH-BR/data/source/pipeline_parameters se existem configurações de ingestões de tabelas aptas para criação ou alteração de jobs, estes jobs irá executar o framework de ingestão.
# MAGIC
# MAGIC * 2025-06-25 - Marco Conti - Versão 0.2.1
# MAGIC   * Correção na execução via notebook de testes de unitários
# MAGIC * 2025-06-26 - Marco conti - Versão 0.2.2
# MAGIC   * Mudança no método de autenticação do Databricks SDK
# MAGIC * 2025-07-07 - Marco Conti - Versão 0.3.1
# MAGIC   * Mudança no método de leitura de arquivos de workspace para repositório Git
# MAGIC * 2025-07-09 - Weslley - Versão 0.3.1
# MAGIC   * Tratamento nas permissões do job criado ou atualizado

# COMMAND ----------

# DBTITLE 1,Importa as lib's necessárias na execução
from datetime import datetime, timezone, timedelta
import requests, json, os, time, yaml, re, io, ast
from pathlib import Path
from git import Repo
from zoneinfo import ZoneInfo
import pytz

# COMMAND ----------

# DBTITLE 1,Verifica se o databricks sdk está instalada
import pkg_resources
import subprocess
import sys

ls_package = ["databricks-sdk"]
for package_name in ls_package:
    try:
        dist = pkg_resources.get_distribution(package_name)
        print(f"'{package_name}' Já está instalada, versão: {dist.version}, {type(dist.version)}")
    except pkg_resources.DistributionNotFound:
        print(f"'{package_name}' Ainda não está instalada, será instalada a seguir...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", f"{package_name}>=0.57.0"])
        dist = pkg_resources.get_distribution(package_name)
        print(f"'{package_name}' Instalada com sucesso, versão: {dist.version}")

from databricks.sdk import WorkspaceClient
from databricks.sdk.service import jobs

# COMMAND ----------

# DBTITLE 1,Prepara o databricks sdk
host = spark.conf.get("spark.databricks.workspaceUrl")
wc = WorkspaceClient(host=host)

# COMMAND ----------

# DBTITLE 1,Métodos e funções utilizadas durante a execução
def get_env():
    return os.environ.get("DATABRICKS_ENV")

def create_clone_git_repo(env, branch):
    token = dbutils.secrets.get(scope="git-token", key="token").strip()

    repo_path  = f"https://{token}@github.com/YMH-BR/data.git"
    timestamp  = int(datetime.now(timezone(timedelta(hours=-3))).timestamp())
    clone_path = f"/tmp/clone_ymhbr_data_variables_{timestamp}"

    if branch == "":
        branch = env if env == "dev" else "main"

    repo = Repo.clone_from(repo_path, clone_path, branch=branch)
    return repo, clone_path

def rmdir_clone_git_repo(clone_path):
    # Remove o diretório temporário usado para clonar o repositório
    try:
        if os.path.exists(clone_path):
            import shutil
            shutil.rmtree(clone_path)
            print("Diretório temp para clone Git repo removido com sucesso")    
    except Exception as e:
        print("Não foi possível excluir a pasta temporaria")

def get_all_job_variables(repo):
    file_path = "framework/create_ingestion_job_variables.json"
    # Itera sobre os commits que modificaram esse arquivo e retorna a última alteração
    last_commit = next(repo.iter_commits(paths=file_path, max_count=1))

    # Acessa o blob do arquivo na árvore do commit
    blob = None
    if last_commit is not None:
        blob = last_commit.tree / file_path
    
    if blob is None:
        print(f"Não foi possível encontrar o arquivo {file_path} no repositório.")
        return {}
    
    # Lê o conteúdo do arquivo
    with io.BytesIO(blob.data_stream.read()) as f:
        variables = f.read().decode("utf-8")

    json_content = json.loads(variables)    
    return json_content

def get_job_variables(job_variables, *keys):
    try:
        value = job_variables
        for key in keys:
            value = value[key]
        return value
    except Exception as e:
        print(f"Variavel: {keys[0]} não encontrada")
        return ""

def log_register(log_data):
    def gen_id():
        timestamp = time.time()
        randon_number = (int(timestamp) ^ (int(timestamp) << 1)) % 10000000000
        return randon_number
    
    env = get_env()
    current_datetime = datetime.now(timezone(timedelta(hours=-3)))
    current_datetime = current_datetime.strftime("%Y-%m-%d %H:%M:%S")
    table = f"controls_{env}.loads.create_ingestion_job_log"
    log_id = gen_id()
    try:
        user_email = user = spark.sql("Select current_user()").collect()[0][0]
    except Exception as e:
        user_email = ""

    for rec in range(2):
        erro = ""
        if rec == 1:
            prefix = "Não foi possível caregar os dados do atributo:"
            log_data["pipeline_parameters"] = f"{prefix} pipeline_parameters - {erro}"
            log_data["job_settings"] = f"{prefix} job_settings - {erro}"
        try:
            insert_clause = f"Insert into {table}(log_id, log_date, user_email, "
            cols_ins = ",".join( [i[0] for i in log_data.items()])+")"
            insert_clause += cols_ins

            insert_values = f"Values({log_id}, '{current_datetime}', '{user_email}', "
            clear_None = [i[1] if i[1] is not None else "" for i in log_data.items()]

            for i in clear_None:
                if isinstance(i, str):
                    insert_values += f"'{i}'"+","
                    insert_values.replace("'","''")
                else:
                    insert_values += f"{i}"+","
            insert_values = insert_values[:-1]+")"

            dml_cmd = f"""{insert_clause} {insert_values}"""
            spark.sql(dml_cmd)
            break
        except Exception as e:
            pass          
    return log_id

def normalize_list(value=None):
    if value is None:
        return []   
    if isinstance(value, list):
        return [v for v in value if isinstance(v, (str, dict))]
    elif isinstance(value, str):
        value = value.strip()
        try:
            if isinstance( ast.literal_eval(value) , list):
                return ast.literal_eval(value)
        except:
            return []
        return [value] if value else []
    elif isinstance(value, dict):
        return [value]
    else:
        return []

def read_sql_files(repo, file_path, file_name):
    try:
        if ((file_path and str(file_path).strip()) and \
            (file_name and str(file_name).strip())):

            file_path = os.path.dirname(file_path) + f"/query_source/{file_name}"
            
            # Itera sobre os commits que modificaram esse arquivo e retorna a última alteração
            last_commit = next(repo.iter_commits(paths = file_path, max_count = 1))
            
            # Acessa o blob do arquivo na árvore do commit
            blob = None
            if last_commit is not None:
                blob = last_commit.tree / file_path
            
            if blob is None:
                print(f"Não foi possível encontrar o arquivo {file_path} no repositório.")
                return {}

            # Lê o conteúdo do arquivo
            with io.BytesIO(blob.data_stream.read()) as f:
                sql_content = f.read().decode("utf-8")

            sql_content = sql_content.replace("<env>", get_env().lower())

            return sql_content
        else:
            ""
    except Exception as e:
        print(f"read_sql_files - Erro ao ler o arquivo {file_path}")
        return ""

def get_last_changed_files(repo, check_updates_interval, files_filter):
    """
        Lista todos os arquivos *.sql e *.yaml (pipeline_parameters e table schema) no repositório:
        https://github.com/YMH-BR/data/sources/pipeline_parameters
    """
    # Define o tempo limite
    since_time = datetime.now(ZoneInfo("America/Sao_Paulo")) - timedelta(hours=check_updates_interval)

    # Recupera os commits recentes
    recent_commits = list(repo.iter_commits(since=since_time.isoformat()))
    
    changed_files = {}
    for commit in recent_commits:
        commit_time = commit.committed_datetime
        for file_path in commit.stats.files.keys():
            if ((".yaml" in file_path) and ("ad-hoc" not in file_path)):
                if file_path not in changed_files or changed_files[file_path]["time"] < commit_time:
                    changed_files[file_path] = {
                        "commit": commit,
                        "time": commit_time
                    }
    
    modified_files = []
    for file_path, info in changed_files.items():
        try:
            blob = repo.head.commit.tree / file_path
            content = blob.data_stream.read().decode("utf-8")

            commit_datetime = \
                info['time'].astimezone(pytz.timezone("America/Sao_Paulo")).strftime("%Y-%m-%d %H:%M:%S")
            modified_files.append((file_path
                                  ,commit_datetime
                                  ,yaml.safe_load(content)))
        except Exception as e:
            print(f"get_last_changed_files - Erro ao ler o arquivo de configuração {file_path}")
            continue
    
    latest_files_ret = modified_files
    if len(files_filter) > 0:
        latest_files_ret = [f for f in modified_files if Path(f[0]).name in files_filter]
    
    return latest_files_ret

def check_layers(pipeline_parameter):
    """
        Verifica se as camadas estão corretas, com os campos preenchidos e as dependências corretas
    """
    layers_config = [d for d in pipeline_parameter if d in ("landing", "bronze", "silver", "gold")]

    standard_order = {0: "landing", 1: "bronze", 2: "silver", 3: "gold"}
    standard_order_ = list(standard_order.values())
    layers_ordered = sorted(layers_config, key=lambda x: standard_order_.index(x))

    fields_check = ["catalog", "schema", "table"]

    exec_layers = []
    for layer in layers_ordered:
        count_check = 0

        # a camada bronze depende obrigatoriamente da camada landing
        if layer == 'bronze':
            if ((all(key in pipeline_parameter["landing"] for key in fields_check)) and 
                (all(key in pipeline_parameter["bronze"] for key in fields_check))):

                for field in fields_check:
                    count_check += 1 if pipeline_parameter["landing"][field] else 0
                    count_check += 1 if pipeline_parameter["bronze"][field]  else 0
            
                if (count_check == 6):
                    exec_layers.append(layer)

        elif layer in ("silver", "gold"):
            if ((all(key in pipeline_parameter[layer]["source"] for key in fields_check)) and 
                (all(key in pipeline_parameter[layer]["target"] for key in fields_check))):

                for field in fields_check:
                    count_check += 1 if pipeline_parameter[layer]["source"][field] else 0
                    count_check += 1 if pipeline_parameter[layer]["target"][field] else 0

                if (count_check == 6):
                    exec_layers.append(layer)
    return exec_layers

def get_job_status(job_id):
    try:
        runs = list(wc.jobs.list_runs(job_id=job_id, limit=1))
        life_cycle_state = ""
        if runs:
            latest_run = runs[0]
            life_cycle_state = latest_run.state.life_cycle_state.name
        return life_cycle_state
    except Exception as e:
        return ""

def get_job_id_by_name(job_name):
    try:
        matching_jobs = [job for job in wc.jobs.list() if job.settings.name == job_name]
        job_id = None
        job_status = None
        if matching_jobs:
            job_id = matching_jobs[0].job_id
            job_status = get_job_status(job_id)
        return job_id, job_status
    except Exception as e:
        return job_id, job_status

def create_job_tasks(env, job_name, repo
                    ,notebook_engine_path_bronze, notebook_engine_path_others
                    ,databricks_cluster_id, layers_run, param, path_config_json):
    """
        Baseado nos arquivos de parametros YAML (<tabela>.yaml), monta as tasks que serão usadas para criar ou atualizar os jobs
    """    
    try:
        pipeline_parameters = {}

        pipeline_parameters_header = {}
        pipeline_parameters_header['pipeline_type'] = param['pipeline_type']
        pipeline_parameters_header['pipeline_mode'] = param['pipeline_mode']
        pipeline_parameters_header['rdbms']         = param['rdbms']

        pipeline_parameters_footer = {}
        pipeline_parameters_footer["days_past"]       = param["days_past"]
        pipeline_parameters_footer['replace_columns'] = normalize_list(param['replace_columns'])
        pipeline_parameters_footer['columns']         = normalize_list(param['columns'])

        job_tasks = []
        for rec_l, layer in enumerate(layers_run):
            task_param = {}
            task_param["temporary_catalog"] = "temporary_"+env
            task_param["temporary_schema"]  = param["bronze"]['schema'] if layers_run[0] == 'bronze' else param["silver"]['schema'] 
            task_param["temporary_table"]   = param["bronze"]['table']  if layers_run[0] == 'bronze' else param["silver"]['table'] 

            if layer == 'bronze':
                for ind, aux_layer in enumerate(["landing", "bronze"]):
                    task_param[f"{aux_layer}_catalog"] = param[aux_layer]['catalog']+"_"+env
                    task_param[f"{aux_layer}_schema"]  = param[aux_layer]['schema']
                    task_param[f"{aux_layer}_table"]   = param[aux_layer]['table']
            else:
                for ind, aux_layer in enumerate(["source", "target"]):
                    if ind == 0:
                        table_name = param[layer][aux_layer]['catalog']+ "_" + env + '.' + \
                                     param[layer][aux_layer]['schema'] + '.' + \
                                     param[layer][aux_layer]['table']
                    
                    task_param[f"{aux_layer}_catalog"] = param[layer][aux_layer]['catalog']+"_"+env
                    task_param[f"{aux_layer}_schema"]  = param[layer][aux_layer]['schema']
                    task_param[f"{aux_layer}_table"]   = param[layer][aux_layer]['table']
            
            task_param["hash_columns"] = normalize_list(param[layer]["hash_columns"])
            
            task_param["partition_column"] = param[layer]["partition_column"]

            # Identifica se existe algum arquivo SQL a ser utilizado
            query_source = ""
            query_source_file_name = param[layer]['query_source_file_name'] if 'query_source_file_name' in param[layer] else ""
            if (query_source_file_name != "" and query_source_file_name is not None):
                query_source = read_sql_files(repo, path_config_json, query_source_file_name)

            # Se a query_source não estiver preenchida monta uma query com a tabela Source pois o FrameWork necessita de uma query para o processamento
            if query_source == "":
                if layer in ("silver", "gold"):
                    query_source = f"Select * from {table_name}"
                else:
                    query_source = ""
            
            # Junta as partes dos parametros a serem enviados ao JOB
            pipeline_parameters = pipeline_parameters_header.copy()
            pipeline_parameters.update(task_param)
            pipeline_parameters.update(pipeline_parameters_footer)
            
            # Cria a lista de task's a serem utilizadas na criação ou atualização do JOb
            task_name = "landing_bronze" if layer == "bronze" else "bronze_silver" if layer == "silver" else "silver_gold"
            notebook_engine_path = \
                notebook_engine_path_bronze if layer == "bronze" else notebook_engine_path_others
            
            notebook_path_run_ingestion = "framework/run_ingestion_jobs"

            depends_task = []
            if rec_l > 0:
                depends_task = [jobs.TaskDependency(task_key=layers_run[(rec_l-1)])]
            
            task = jobs.Task(
                        task_key = layer,
                        depends_on = depends_task,
                        existing_cluster_id = f"{databricks_cluster_id}",
                        notebook_task = jobs.NotebookTask(
                            notebook_path = f"{notebook_path_run_ingestion}",
                            source = jobs.Source("GIT"),
                            base_parameters = {"job_name": f"{job_name}"
                                              ,"notebook_run": f"framework/{notebook_engine_path}"
                                              ,"timeout": "3600"
                                              ,"task_name": task_name
                                              ,"pipeline_parameters": json.dumps(pipeline_parameters)
                                              ,"query_source": str(query_source)}))

            job_tasks.append(task)
        return job_tasks
    except Exception as e:
        return []
    return job_tasks

def transfer_job_ownership(wc, env: str, job_id: int):
    """
    Substitui TODAS as permissões do job:
      • NEW_OWNER ⇒ IS_OWNER
      • grupo do ambiente ⇒ CAN_MANAGE
    Não preserva o old owner.
    """
    if env not in ENV_GROUP_MAP:
        raise ValueError(f"Ambiente '{env}' inválido "
                         f"(opções: {', '.join(ENV_GROUP_MAP)})")

    acl = [
        jobs.JobAccessControlRequest(
            user_name       = NEW_OWNER,
            permission_level= jobs.JobPermissionLevel.IS_OWNER
        ),
        jobs.JobAccessControlRequest(
            group_name      = ENV_GROUP_MAP[env],
            permission_level= jobs.JobPermissionLevel.CAN_MANAGE
        )
    ]

    try:
        if hasattr(wc.jobs, "replace_permissions"):
            wc.jobs.replace_permissions(job_id=job_id,
                                        access_control_list=acl)
        else:
            wc.api_client.do(
                "PUT",
                f"/api/2.0/permissions/jobs/{job_id}",
                body={"access_control_list": [a.as_dict() for a in acl]}
            )

        print(
            f" - Ownership do job {job_id} transferido para '{NEW_OWNER}' "
            f"e grupo '{ENV_GROUP_MAP[env]}' recebeu CAN_MANAGE."
        )

    except Exception as e:
        raise RuntimeError(
            f" - Falha ao transferir ownership do job {job_id}: {e}"
        )


# COMMAND ----------

# DBTITLE 1,Verifica parâmetros para teste unitários
env = get_env().lower()

parameters = dbutils.widgets.getAll()

branch = dbutils.widgets.get('branch') if (any('branch' in key for key in parameters)) else env
try:
    files_filter = normalize_list(dbutils.widgets.get('files_filter')) \
                        if (any('files_filter' in key for key in parameters)) \
                        else []
except Exception as e:
    files_filter = []

print(f"Branch específica: {branch}" if branch != "" else "" )
print(f"Filtrar arquivos: {files_filter} - {type(files_filter)}")

# COMMAND ----------

# DBTITLE 1,Definição de variáveis
# Se a branch foi enviada via parametro então ela será usada, caso contrario define a branch de acordo com o ambiente
git_branch = branch if branch != "" else ("dev" if env == "dev" else "main")

# Clona o repositório Git para recuperar arquivos alterados e arquivo de configuração
clone_git_repo, clone_path  = create_clone_git_repo(env, branch)

job_variables               = get_all_job_variables(clone_git_repo)
notebook_engine_path_bronze = get_job_variables(job_variables, "notebook_engine_path_bronze", env.upper())
notebook_engine_path_others = get_job_variables(job_variables, "notebook_engine_path_others", env.upper())
databricks_cluster_id       = get_job_variables(job_variables, "databricks_cluster_id", env.upper())
check_updates_interval      = get_job_variables(job_variables, "check_updates_interval", env.upper())

NEW_OWNER = "ymdb.servicoawsgit@yamaha-motor.com.br"

ENV_GROUP_MAP = {
    "dev":     "data-eng-yamaha",
    "prod":    "data-admins-yamaha"
}

print("Variáveis:"
     ,'\nenv: ', env
     ,'\nnotebook_engine_path_bronze: ', notebook_engine_path_bronze
     ,'\nnotebook_engine_path_others: ', notebook_engine_path_others
     ,'\ndatabricks_cluster_id:       ', databricks_cluster_id
     ,'\ncheck_updates_interval:      ', check_updates_interval)

# COMMAND ----------

# DBTITLE 1,Validações de parâmetros e Execução da criação ou atualização dos job
results = get_last_changed_files(clone_git_repo, check_updates_interval, files_filter)

created_jobs = []
updated_jobs = []
error_jobs   = []

print(f"{len(results)} Arquivo(s) a serem processados:\n" if len(results) > 0 else "Não há arquivos para processar")

for file in results:
    print(f" - {file[0]}")
    json_config_parameters = {}

    table_param = file[2] # Separa o conteudo yaml para processamento

    # Verifica se as camadas(bronze, silver e gold) estão preenchidas corretamente
    layers_run = check_layers(table_param)
    print("   - Camadas a serem processadas:", layers_run)

    if len(layers_run) > 0:
        schema_table = table_param["landing"]["schema"]+table_param["landing"]["table"]
        job_name = str(schema_table.replace("/","_").replace("full","")[1:(len(schema_table)-1)]).rstrip("_")
        job_name = "pipeline_"+job_name
        table_name = \
            table_param[layers_run[0]]['table'] \
                if layers_run[0] == 'bronze' \
                else table_param[layers_run[0]]["source"]['table']

        job_id, job_status = get_job_id_by_name(job_name)

        # NÃO Atualiza o job se ele estiver em execução
        if job_status not in ["RUNNING", "PENDING", "QUEUED"]:
            # Monta as task para o job a ser criado ao atualizado
            job_tasks = create_job_tasks(env, job_name, clone_git_repo
                                        ,notebook_engine_path_bronze, notebook_engine_path_others
                                        ,databricks_cluster_id, layers_run, table_param, file[0])

            if len(job_tasks) > 0:
                # Monta o source (repositório Git) do Job
                git_source = \
                    jobs.GitSource(git_url      = "https://github.com/YMH-BR/data"
                                  ,git_provider = jobs.GitProvider.GIT_HUB
                                  ,git_branch   = git_branch)

                # Monta o agendamento do Job
                schedule = table_param['schedule']['quartz_cron']
                pause_status = jobs.PauseStatus.PAUSED if ((table_param['schedule']['paused']) or (env == "dev")) \
                                                     else jobs.PauseStatus.UNPAUSED
                job_schedule = jobs.CronSchedule(quartz_cron_expression = f"{schedule}"
                                                ,timezone_id            = "UTC"
                                                ,pause_status           = pause_status)

                # Inicio o processo de atualização ou criação do job
                try:
                    status = 'success'
                    if job_id: # Atualiza o job
                        try:
                            new_settings = \
                                jobs.JobSettings(name       = job_name
                                                ,git_source = git_source
                                                ,schedule   = job_schedule
                                                ,tasks      = job_tasks)
                            
                            ret = wc.jobs.update(job_id       = job_id
                                                ,new_settings = new_settings)
                            action = "Atualizado"
                            updated_jobs.append(job_name)
                            # Comentado provisoriamente devido a mudança de estratégia
                            # transfer_job_ownership(wc, env, job_id)
                        except Exception as e:
                            status = 'error'                            
                            error_jobs.append(job_name)
                            msg_error = f"Erro ao atualizar o job {job_name} - {str(e)[0:100]}"
                    else: # Cria o Job
                        try:
                            create_response = wc.jobs.create(name       = job_name
                                                            ,git_source = git_source
                                                            ,schedule   = job_schedule
                                                            ,tasks      = job_tasks)
                            job_id = create_response.job_id
                            action = "Criado"
                            created_jobs.append(job_name)
                            # Comentado provisoriamente devido a mudança de estratégia
                            # transfer_job_ownership(wc, env, job_id)
                        except Exception as e:
                            status = 'error'
                            error_jobs.append(job_name)
                            msg_error = f"Erro ao criar o job {job_name} - {str(e)[0:100]}"

                    # Registra o log da criação ou atualização do job
                    log_data = {"log_status": status
                               ,"ingest_config_file": file
                               ,"table_name": table_name
                               ,"schedule": schedule
                               ,"message": f"Job {job_id} - {job_name} - {action} com sucesso" if status == 'success' else msg_error
                               ,"job_id": job_id
                               ,"job_name": job_name}
                    log_id = log_register(log_data)
                except Exception as e:
                    log_data = {"log_status": "error"
                               ,"ingest_config_file": file
                               ,"table_name": table_name
                               ,"message": f"Erro na criação/atualização do Job {job_id} {job_name} - {str(e)[0:100]}"
                               ,"job_id": job_id
                               ,"job_name": job_name}
                    log_id = log_register(log_data)
    else:
        log_data = {"log_status": "error"
                   ,"ingest_config_file": file
                   ,"message": "Erro no preenchimento nos parametros de camadas (landing, bronze, silver ou gold)"}
        log_id = log_register(log_data)

print("-"*100)
print(f"Data e hora: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

if len(created_jobs) > 0:
    print("-"*100)
    print(f"{len(created_jobs)} job(s) criado(s):")
    for j in created_jobs:
        print("\t", j)

if len(updated_jobs) > 0:
    print("\n", "-"*100)
    print(f"{len(updated_jobs)} job(s) atualizado(s):")
    for j in updated_jobs:
        print("\t", j)

if len(error_jobs) > 0:
    print("\n", "-"*100)
    print(f"{len(error_jobs)} job(s) com erro:")
    for j in error_jobs:
        print("\t", j)

# COMMAND ----------

# Remove o diretório temporário do git clone
rmdir_clone_git_repo(clone_path)
