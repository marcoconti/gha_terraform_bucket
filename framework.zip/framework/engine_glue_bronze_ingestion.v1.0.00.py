# Databricks notebook source
# MAGIC %md
# MAGIC ### **Engine Glue Bronze Ingestion**

# COMMAND ----------

# DBTITLE 1,Carrega as bibliotecas
import sys
import json
import pytz

from datetime import date, datetime, timedelta
from delta.tables import DeltaTable
from functools import reduce
from pyspark.sql.functions import concat, sha2, col, coalesce, expr, lit, year, month, current_timestamp, to_timestamp, from_utc_timestamp, format_string
from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DateType

# COMMAND ----------

# DBTITLE 1,Cria tabela de logs se não existir
sql = """
  create table if not exists controls_dev.loads.jobs
  (
    job string,
    task string,
    framework string,
    type string,
    mode string,
    start timestamp,
    finish timestamp,
    minutes float,
    pipeline_config string,
    query_source string,
    affected_rows long,
    inserted_rows long,
    updated_rows long,
    deleted_rows long,
    status string
    )
  using delta
"""

spark.sql(sql)

# COMMAND ----------

# DBTITLE 1,Captura nome do job
job_name = dbutils.notebook.entry_point.getDbutils().notebook().getContext().jobName()

# COMMAND ----------

# DBTITLE 1,Captura nome da task
task_name = dbutils.widgets.get("task_name")

# COMMAND ----------

# DBTITLE 1,Captura o framework utilizado
framework = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()

# COMMAND ----------

# DBTITLE 1,Captura os parametros do pipeline
pipeline_parameters = dbutils.widgets.get("pipeline_parameters")

# COMMAND ----------

# DBTITLE 1,Momento de inicio do job
start_job = datetime.now(pytz.timezone('America/Sao_Paulo'))

# COMMAND ----------

# DBTITLE 1,Atribui os parametros as configurações
pipeline_settings = json.loads(pipeline_parameters)

# COMMAND ----------

# DBTITLE 1,Parametro do tipo e modo do pipeline
pipeline_type = pipeline_settings['pipeline_type']
pipeline_mode = pipeline_settings['pipeline_mode']

# COMMAND ----------

rdbms = pipeline_settings['rdbms']

# COMMAND ----------

# DBTITLE 1,Dados do catalogo temporario
temporary_catalog = pipeline_settings['temporary_catalog']
temporary_schema = pipeline_settings['temporary_schema']
temporary_table = pipeline_settings['temporary_table']

# COMMAND ----------

# DBTITLE 1,Dados do catalogo  landing
landing_catalog = pipeline_settings['landing_catalog']
landing_schema = pipeline_settings['landing_schema']
landing_table = pipeline_settings['landing_table']

# COMMAND ----------

# DBTITLE 1,Dados do catalogo bronze
bronze_catalog = pipeline_settings['bronze_catalog']
bronze_schema = pipeline_settings['bronze_schema']
bronze_table = pipeline_settings['bronze_table']

# COMMAND ----------

# DBTITLE 1,Se primeira carga transforma o pipeline em full e overwrite
if not spark.catalog.tableExists(f'{bronze_catalog}.{bronze_schema}.{bronze_table}'):

    pipeline_type = 'full'
    pipeline_mode = 'overwrite'

# COMMAND ----------

# DBTITLE 1,Colunas que vão entrar na composição do hash
hash_columns = pipeline_settings['hash_columns']

# COMMAND ----------

# DBTITLE 1,Coluna de particionamento
partition_column = pipeline_settings['partition_column']

# COMMAND ----------

# DBTITLE 1,Strings que serão substituidas no nome das colunas
replace_columns = pipeline_settings['replace_columns']

# COMMAND ----------

# DBTITLE 1,Colunas que serão renomeadas
columns = pipeline_settings['columns']

# COMMAND ----------

# DBTITLE 1,Dias no passado que o pipeline irá consultar
days_past = pipeline_settings['days_past']

# COMMAND ----------

# DBTITLE 1,Query do pipeline
query_source = dbutils.widgets.get("query_source")

# COMMAND ----------

# DBTITLE 1,Se pipeline for incremental define range de datas
if pipeline_type in ['incremental']:

    date_start = (datetime.now() - timedelta(days = days_past)).strftime('%Y-%m-%d')
    date_end = datetime.now().strftime('%Y-%m-%d')


# COMMAND ----------

# DBTITLE 1,Carrega o dataframe de origem
df_source = spark.read.parquet(landing_catalog + landing_schema + landing_table)

# COMMAND ----------

# DBTITLE 1,Substitui o nome das colunas - parâmetro replace_columns
df_source = reduce(lambda df_source, col: df_source.withColumnRenamed(col[0], col[1]), zip(df_source.columns, [col.replace(replace_columns[0], replace_columns[1]) for col in df_source.columns]), df_source)

# COMMAND ----------

# DBTITLE 1,Substitui o nome das colunas - parâmetro columns
for old_name, new_name in columns.items():

    df_source = df_source.withColumnRenamed(old_name.replace('-', '_'), new_name)

# COMMAND ----------

# DBTITLE 1,Se não informa coluna hash, considera todas
if not (hash_columns is None or hash_columns == ''):

    hash_columns = df_source.columns

# COMMAND ----------

# DBTITLE 1,Calcula valor do hash
df_source = df_source.withColumn("_hash", sha2(concat(*[coalesce(col(col_name).cast("string"), lit('')) for col_name in hash_columns]), 256))

# COMMAND ----------

# DBTITLE 1,Se conter coluna de partição cria as mesmas
if not (partition_column is None or partition_column == ''):

    df_source = df_source.withColumn('_year', format_string('%04d', year(partition_column)))
    df_source = df_source.withColumn('_month', format_string('%02d', month(partition_column)))

# COMMAND ----------

# DBTITLE 1,Cria coluna do momento da ingestão
df_source = df_source.withColumn("_ingestionin", from_utc_timestamp(current_timestamp(), "America/Sao_Paulo"))

# COMMAND ----------

# DBTITLE 1,Ingere dados na tabela de catalogo na bronze
if pipeline_type in ['full', 'incremental'] and pipeline_mode in ['overwrite', 'append']:

    if not (partition_column is None or partition_column == ''):

        df_source.write.format("delta").mode(f'{pipeline_mode}').partitionBy("_year", "_month").saveAsTable(f'{bronze_catalog}.{bronze_schema}.{bronze_table}')

    else: 

        df_source.write.format("delta").mode(f'{pipeline_mode}').saveAsTable(f'{bronze_catalog}.{bronze_schema}.{bronze_table}')
    
    #

    affected_rows = df_source.count()
    inserted_rows = affected_rows
    updated_rows = 0
    deleted_rows = 0

# COMMAND ----------

# DBTITLE 1,Combina os dados da temporaria (origem) com a bronze (destino)
if pipeline_type in ['full', 'incremental'] and pipeline_mode == 'merge':

    #

    if not (partition_column is None or partition_column == ''):
        
        df_source.write.format("delta").mode(f'overwrite').partitionBy("_year", "_month").saveAsTable(f'{temporary_catalog}.{temporary_schema}.{temporary_table}')

    else:

        df_source.write.format("delta").mode(f'overwrite').saveAsTable(f'{temporary_catalog}.{temporary_schema}.{temporary_table}')

    #

    if pipeline_type == 'full':

        sql = f'''
            MERGE INTO 
                {bronze_catalog}.{bronze_schema}.{bronze_table} AS target
            USING
                {temporary_catalog}.{temporary_schema}.{temporary_table} AS source
            ON
                target._hash = source._hash
            WHEN MATCHED THEN
                UPDATE SET *
            WHEN NOT MATCHED THEN
                INSERT *
            WHEN NOT MATCHED BY SOURCE THEN
                DELETE
        '''
    
    #

    if pipeline_type == 'incremental':

        if not (partition_column is None or partition_column == ''):

            sql = f'''
                MERGE INTO
                    {bronze_catalog}.{bronze_schema}.{bronze_table} AS target
                USING
                    {temporary_catalog}.{temporary_schema}.{temporary_table} AS source 
                ON
                    target._hash = source._hash
                WHEN MATCHED THEN
                    UPDATE SET *
                WHEN NOT MATCHED THEN
                    INSERT *
                WHEN NOT MATCHED BY SOURCE AND target.{partition_column.replace('-', '_')} BETWEEN '{date_start}' AND '{date_end}' THEN 
                    DELETE
            '''

        else:

            sql = f'''
                MERGE INTO
                    {bronze_catalog}.{bronze_schema}.{bronze_table} AS target
                USING
                    {temporary_catalog}.{temporary_schema}.{temporary_table} AS source 
                ON
                    target._hash = source._hash
                WHEN MATCHED THEN
                    UPDATE SET *
                WHEN NOT MATCHED THEN
                    INSERT *
                WHEN NOT MATCHED BY SOURCE THEN
                    DELETE
            '''

    #
    print(sql)
    df_result = spark.sql(sql)

    #

    affected_rows = df_result.select('num_affected_rows').head()[0]
    inserted_rows = df_result.select('num_inserted_rows').head()[0]
    updated_rows = df_result.select('num_updated_rows').head()[0]
    deleted_rows = df_result.select('num_deleted_rows').head()[0]

# COMMAND ----------

# DBTITLE 1,Adiciona a execução ao log
finish_job = datetime.now(pytz.timezone('America/Sao_Paulo'))

sql = f'''
    INSERT INTO controls_dev.loads.jobs
    (
        job, task, framework, type, mode, start, finish, minutes, pipeline_config, query_source, affected_rows, inserted_rows, updated_rows, deleted_rows, status
    )
    VALUES
    (
        '{job_name}', '{task_name}', '{framework}', '{pipeline_type}', '{pipeline_mode}', '{start_job}', '{finish_job}', {round(((finish_job - start_job).total_seconds() / 60), 4)}, '{pipeline_parameters}', '{query_source.replace("'", "").replace("'", "")}', {affected_rows}, {inserted_rows}, {updated_rows}, {deleted_rows}, 'Success'
    )
'''

spark.sql(sql)

# COMMAND ----------

sql = f'DROP TABLE IF EXISTS {temporary_catalog}.{temporary_schema}.{temporary_table}'

spark.sql(sql)

# COMMAND ----------

sql_update_comments = f"""
    ALTER TABLE {bronze_catalog}.{bronze_schema}.{bronze_table}
    CHANGE COLUMN _hash COMMENT 'Coluna (hash) de identificação unica da linha'
"""

spark.sql(sql_update_comments)

# COMMAND ----------

if not (partition_column is None or partition_column == ''):

    #

    sql_update_comments = f"""
        ALTER TABLE {bronze_catalog}.{bronze_schema}.{bronze_table}
        CHANGE COLUMN _year COMMENT 'Coluna contendo o ano utilizada para particionamento'
    """

    spark.sql(sql_update_comments)

    #

    sql_update_comments = f"""
        ALTER TABLE {bronze_catalog}.{bronze_schema}.{bronze_table}
        CHANGE COLUMN _month COMMENT 'Coluna contendo o mês utilizada para particionamento'
    """

    spark.sql(sql_update_comments) 

# COMMAND ----------

sql_update_comments = f"""
    ALTER TABLE {bronze_catalog}.{bronze_schema}.{bronze_table}
    CHANGE COLUMN _ingestionin COMMENT 'Coluna contendo o momento da ingestão'
"""

spark.sql(sql_update_comments)

# COMMAND ----------

# DBTITLE 1,Finaliza engine
print('*** Finalizado ***')
