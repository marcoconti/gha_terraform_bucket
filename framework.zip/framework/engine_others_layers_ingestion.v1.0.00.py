# Databricks notebook source
# MAGIC %md
# MAGIC ### **Engine Other Layers Ingestion**

# COMMAND ----------

# DBTITLE 1,Carrega bibliotecas
import sys
import json
import pytz

from datetime import date, datetime, timedelta
from delta.tables import DeltaTable
from functools import reduce
from pyspark.sql.functions import concat, sha2, col, coalesce, lit, year, month, current_timestamp, to_timestamp, from_utc_timestamp, format_string
from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DateType

# COMMAND ----------

# DBTITLE 1,Cria tabela de logs
sql = """
  create table if not exists controls_dev.loads.jobs
  (
    job string,
    task string,
    framework string,
    type string,
    mode string,
    start timestamp,
    finish timestamp,
    minutes float,
    pipeline_config string,
    query_source string,
    affected_rows long,
    inserted_rows long,
    updated_rows long,
    deleted_rows long,
    status string
    )
  using delta
"""

spark.sql(sql)

# COMMAND ----------

# DBTITLE 1,Nome job
job_name = dbutils.notebook.entry_point.getDbutils().notebook().getContext().jobName()

# COMMAND ----------

# DBTITLE 1,Nome task
task_name = dbutils.widgets.get("task_name")

# COMMAND ----------

# DBTITLE 1,Framework
framework = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()

# COMMAND ----------

# DBTITLE 1,Parametros
pipeline_parameters = dbutils.widgets.get("pipeline_parameters")

# COMMAND ----------

# DBTITLE 1,Inicio job
start_job = datetime.now(pytz.timezone('America/Sao_Paulo'))

# COMMAND ----------

# DBTITLE 1,Atribui parametros as configurações
pipeline_settings = json.loads(pipeline_parameters)

# COMMAND ----------

# DBTITLE 1,Tipo e modo pipeline
pipeline_type = pipeline_settings['pipeline_type']
pipeline_mode = pipeline_settings['pipeline_mode']

# COMMAND ----------

# DBTITLE 1,RDBMS origem
rdbms = pipeline_settings['rdbms']

# COMMAND ----------

# DBTITLE 1,Catalogo temporário
temporary_catalog = pipeline_settings['temporary_catalog']
temporary_schema = pipeline_settings['temporary_schema']
temporary_table = pipeline_settings['temporary_table']

# COMMAND ----------

# DBTITLE 1,Catalogo origem
source_catalog = pipeline_settings['source_catalog']
source_schema = pipeline_settings['source_schema']
source_table = pipeline_settings['source_table']

# COMMAND ----------

# DBTITLE 1,Catalogo destino
target_catalog = pipeline_settings['target_catalog']
target_schema = pipeline_settings['target_schema']
target_table = pipeline_settings['target_table']

# COMMAND ----------

# DBTITLE 1,Se primeira carga, transforma pipeline full e overwrite
if not spark.catalog.tableExists(f'{target_catalog}.{target_schema}.{target_table}'):

    pipeline_type = 'full'
    pipeline_mode = 'overwrite'

# COMMAND ----------

# DBTITLE 1,Coluna(s) hash
hash_columns = pipeline_settings['hash_columns']

# COMMAND ----------

# DBTITLE 1,Particionamento
partition_column = pipeline_settings['partition_column']

# COMMAND ----------

# DBTITLE 1,Substituições nome colunas
replace_columns = pipeline_settings['replace_columns']

# COMMAND ----------

# DBTITLE 1,Colunas renomeadas
columns = pipeline_settings['columns']

# COMMAND ----------

# DBTITLE 1,Dias no passado
days_past = pipeline_settings['days_past']

# COMMAND ----------

# DBTITLE 1,Query
query_source = dbutils.widgets.get('query_source')

# COMMAND ----------

# DBTITLE 1,Se pipeline incremental, define range datas
if pipeline_type in ['incremental']:

    date_start = (datetime.now() - timedelta(days = days_past)).strftime('%Y-%m-%d')
    date_end = datetime.now().strftime('%Y-%m-%d')

# COMMAND ----------

# DBTITLE 1,Ajuste sintax OpenEdge (Progress)
if rdbms.lower() in 'openedge':

    aspas_simples = "'"
    aspas_duplas = '"'

else:

    aspas_simples = ''
    aspas_duplas = ''

# COMMAND ----------

# DBTITLE 1,Se pipeline incremental, define range datas
if pipeline_type in ['incremental']:

    if not ('partition_column' is None or partition_column == ''):

        query_source = query_source + f" WHERE {aspas_duplas}{partition_column}{aspas_duplas} BETWEEN '{date_start}' AND '{date_end}' or \"{partition_column}\" IS NULL"

# COMMAND ----------

# DBTITLE 1,Executa query captura origem
print(query_source)
df_source = spark.sql(query_source)

# COMMAND ----------

# DBTITLE 1,Substituição caracteres colunas
for old_name, new_name in columns.items():

    df_source = df_source.withColumnRenamed(old_name.replace('-', '_'), new_name)

# COMMAND ----------

# DBTITLE 1,Substituição nome colunas
df_source = reduce(lambda df_source, col: df_source.withColumnRenamed(col[0], col[1]), zip(df_source.columns, [col.replace(replace_columns[0], replace_columns[1]) for col in df_source.columns]), df_source)

# COMMAND ----------

# DBTITLE 1,Coluna(s) hash
if not (hash_columns is None or hash_columns == ''):

    hash_columns = df_source.columns

# COMMAND ----------

# DBTITLE 1,Adiciona hash
df_source = df_source.withColumn("_hash", sha2(concat(*[coalesce(col(col_name).cast("string"), lit('')) for col_name in hash_columns]), 256))

# COMMAND ----------

# DBTITLE 1,Adiciona partição
if not (partition_column is None or partition_column == ''):

    if "_year" not in df_source.columns:

        df_source = df_source.withColumn('_year', format_string('%04d', year(partition_column)))
        df_source = df_source.withColumn('_month', format_string('%02d', month(partition_column)))

# COMMAND ----------

# DBTITLE 1,Adiciona controle ingestão
df_source = df_source.withColumn("_ingestionin", from_utc_timestamp(current_timestamp(), "America/Sao_Paulo"))

# COMMAND ----------

# DBTITLE 1,Ingere origem
if pipeline_type in ['full', 'incremental'] and pipeline_mode in ['overwrite', 'append']:

    if not (partition_column is None or partition_column == ''):

        df_source.write.format("delta").mode(f'{pipeline_mode}').partitionBy("_year", "_month").saveAsTable(f'{target_catalog}.{target_schema}.{target_table}')

    else: 

        df_source.write.format("delta").mode(f'{pipeline_mode}').saveAsTable(f'{target_catalog}.{target_schema}.{target_table}')
    
    #

    affected_rows = df_source.count()
    inserted_rows = affected_rows
    updated_rows = 0
    deleted_rows = 0

# COMMAND ----------

# DBTITLE 1,DDL tabela catalogo temporaria
if pipeline_type in ['full', 'incremental'] and pipeline_mode == 'merge':
    
    ddl_sql_temporary = f"CREATE TABLE IF NOT EXISTS {temporary_catalog}.{temporary_schema}.{temporary_table} ({', '.join([f'{field.name} {field.dataType.simpleString()}' for field in df_source.schema])})"

# COMMAND ----------

# DBTITLE 1,Adiciona DDL catalogo temporaria particionamento
if pipeline_type in ['full', 'incremental'] and pipeline_mode == 'merge':

    if not (partition_column is None or partition_column == ''):

        ddl_sql_temporary += "PARTITIONED BY (_year, _month)"

# COMMAND ----------

# DBTITLE 1,Cria tabela catalogo temporaria
if pipeline_type in ['full', 'incremental'] and pipeline_mode == 'merge':
    
    spark.sql(ddl_sql_temporary)

# COMMAND ----------

# DBTITLE 1,Combina dados temporaria (origem) com destino
if pipeline_type in ['full', 'incremental'] and pipeline_mode == 'merge':

    #

    if not (partition_column is None or partition_column == ''):
        
        df_source.write.format("delta").mode(f'overwrite').partitionBy("_year", "_month").saveAsTable(f'{temporary_catalog}.{temporary_schema}.{temporary_table}')

    else:

        df_source.write.format("delta").option("mergeSchema", "true").mode(f'overwrite').saveAsTable(f'{temporary_catalog}.{temporary_schema}.{temporary_table}')

    #

    if pipeline_type == 'full':

        sql = f'''
            MERGE INTO 
                {target_catalog}.{target_schema}.{target_table} AS target
            USING
                {temporary_catalog}.{temporary_schema}.{temporary_table} AS source
            ON
                target._hash = source._hash
            WHEN MATCHED THEN
                UPDATE SET *
            WHEN NOT MATCHED THEN
                INSERT *
            WHEN NOT MATCHED BY SOURCE THEN
                DELETE
        '''
    
    #

    if pipeline_type == 'incremental':

        if not (partition_column is None or partition_column == ''):

            sql = f'''
                MERGE INTO
                    {target_catalog}.{target_schema}.{target_table} AS target
                USING
                    {temporary_catalog}.{temporary_schema}.{temporary_table} AS source 
                ON
                    target._hash = source._hash
                WHEN MATCHED THEN
                    UPDATE SET *
                WHEN NOT MATCHED THEN
                    INSERT *
                WHEN NOT MATCHED BY SOURCE AND target.{partition_column.replace('-', '_')} BETWEEN '{date_start}' AND '{date_end}' THEN 
                    DELETE
            '''

        else:

            sql = f'''
                MERGE INTO
                    {target_catalog}.{target_schema}.{target_table} AS target
                USING
                    {temporary_catalog}.{temporary_schema}.{temporary_table} AS source 
                ON
                    target._hash = source._hash
                WHEN MATCHED THEN
                    UPDATE SET *
                WHEN NOT MATCHED THEN
                    INSERT *
                WHEN NOT MATCHED BY SOURCE THEN
                    DELETE
            '''

    #
    print(sql)
    df_result = spark.sql(sql)

    #

    affected_rows = df_result.select('num_affected_rows').head()[0]
    inserted_rows = df_result.select('num_inserted_rows').head()[0]
    updated_rows = df_result.select('num_updated_rows').head()[0]
    deleted_rows = df_result.select('num_deleted_rows').head()[0]

# COMMAND ----------

# DBTITLE 1,Adiciona execução log
finish_job = datetime.now(pytz.timezone('America/Sao_Paulo'))

sql = f'''
    INSERT INTO controls_dev.loads.jobs
    (
        job, task, framework, type, mode, start, finish, minutes, pipeline_config, query_source, affected_rows, inserted_rows, updated_rows, deleted_rows, status
    )
    VALUES
    (
        '{job_name}', '{task_name}', '{framework}', '{pipeline_type}', '{pipeline_mode}', '{start_job}', '{finish_job}', {round(((finish_job - start_job).total_seconds() / 60), 4)}, '{pipeline_parameters}', '{query_source.replace("'", "").replace("'", "")}', {affected_rows}, {inserted_rows}, {updated_rows}, {deleted_rows}, 'Success'
    )
'''

spark.sql(sql)

# COMMAND ----------

# DBTITLE 1,Apaga temporaria
sql = f'DROP TABLE IF EXISTS {temporary_catalog}.{temporary_schema}.{temporary_table}'

spark.sql(sql)

# COMMAND ----------

# DBTITLE 1,Metadata hash
sql_update_comments = f"""
    ALTER TABLE {target_catalog}.{target_schema}.{target_table}
    CHANGE COLUMN _hash COMMENT 'Coluna (hash) de identificação unica da linha'
"""

spark.sql(sql_update_comments)

# COMMAND ----------

# DBTITLE 1,Metadata partição
if not (partition_column is None or partition_column == ''):

    #

    sql_update_comments = f"""
        ALTER TABLE {target_catalog}.{target_schema}.{target_table}
        CHANGE COLUMN _year COMMENT 'Coluna contendo o ano utilizada para particionamento'
    """

    spark.sql(sql_update_comments)

    #

    sql_update_comments = f"""
        ALTER TABLE {target_catalog}.{target_schema}.{target_table}
        CHANGE COLUMN _month COMMENT 'Coluna contendo o mês utilizada para particionamento'
    """

    spark.sql(sql_update_comments) 

# COMMAND ----------

# DBTITLE 1,Metadata controle ingestão
sql_update_comments = f"""
    ALTER TABLE {target_catalog}.{target_schema}.{target_table}
    CHANGE COLUMN _ingestionin COMMENT 'Coluna contendo o momento da ingestão'
"""

spark.sql(sql_update_comments)

# COMMAND ----------

# DBTITLE 1,Finaliza engine
print('*** Finalizado ***')
