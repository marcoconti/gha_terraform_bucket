# Databricks notebook source
# MAGIC %md
# MAGIC #### Este Notebook será utilizado para executar outros notebooks
# MAGIC #### Através dele será possível registrar log de sucesso ou erro na execução.
# MAGIC
# MAGIC * Os logs serão mantidos na tabela controls_dev.loads.jobs
# MAGIC
# MAGIC 2025-07-07 - Marco Conti - Criação
# MAGIC 2025-08-06 - Marco Conti - Inclusão de verificaão de versão do Framework
# MAGIC

# COMMAND ----------

from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo
import os

# Libs do projeto Datamax (Yamaha)
from datamax.commons import get_env
from datamax.files import get_last_version_framework

# COMMAND ----------

# DBTITLE 1,Seleciona os parâmetros recebidos
parameters   = dbutils.widgets.getAll()

job_name     = parameters['job_name']
notebook_run = parameters['notebook_run']
notebook_run = "../"+notebook_run
timeout      = parameters['timeout'] if 'timeout' in parameters else "3600"
timeout      = int(timeout)

parameters.pop('job_name')
parameters.pop('notebook_run')
parameters.pop('timeout')

print("job_name:", job_name)
print("notebook_run:", notebook_run)
print("parameters","\n","-"*100)
print(parameters)

# COMMAND ----------

# DBTITLE 1,Método responsável por registrar o log (Sucesso ou Erro)
# def get_env():
#     env = os.environ.get("DATABRICKS_ENV")
#     return env.lower()

env = get_env()

def log_register(job, task, type, start, finish, minutes, status):
    try:
        remove_chars = "@#$'"
        status = str(status).translate(str.maketrans('', '', remove_chars))
        partition_date = datetime.now(timezone(timedelta(hours=-3))).strftime("%Y-%m-%d")
        insert_cmd = \
           f"""Insert into controls_{env}.loads.jobs(job, task, type, start, finish, minutes, status, partition_date)
               values('{job}', '{task}', '{type}', '{start}', '{finish}', {minutes}, '{status}', '{partition_date}')
            """
        spark.sql(insert_cmd)
    except Exception as e:
        print("Não foi possível registrar log")

# COMMAND ----------

try:
    branch = "feat/controle_versao_framework" if env == "dev" else "main"

    print(branch, notebook_run)

    notebook_run = get_last_version_framework(dbutils, branch, notebook_run, ".py")
except Exception as e:
    pass # Mantem a versão enviada via parametro

# COMMAND ----------

print(notebook_run)

# COMMAND ----------

parar aqui

# COMMAND ----------

# DBTITLE 1,Executa o notebook, com seus argumentos, recebidos c/ parâmetro
try:
    start_ts = datetime.now() #ZoneInfo("America/Sao_Paulo"))
    
    # Executa o notebook de ingestão
    print("Executa o notebook:\n", notebook_run)
    dbutils.notebook.run(notebook_run, arguments=parameters, timeout_seconds = timeout)

except Exception as e:
    status   = f"ERROR:\n{e}"
    end_ts   = datetime.now() #ZoneInfo("America/Sao_Paulo"))
    run_time = end_ts - start_ts

    minutes = round((run_time.total_seconds()/60),5)
    # Só registra log se ocorrer algum erro, pois em caso de sucesso o Framework já faz isso
    log_register(job_name
                ,""
                ,'ad-hoc'
                ,start_ts
                ,end_ts
                ,minutes
                ,status)
    
    raise Exception(f"Falha ao executar o notebook, verifica o erro na tabela controls_{env}.loads.jobs") 

